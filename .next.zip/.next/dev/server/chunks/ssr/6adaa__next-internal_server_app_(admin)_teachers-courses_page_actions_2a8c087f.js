module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(admin)/teachers-courses/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=6adaa__next-internal_server_app_%28admin%29_teachers-courses_page_actions_2a8c087f.js.map