module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(admin)/saudi_source_course/edit/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=68041_server_app_%28admin%29_saudi_source_course_edit_%5Bid%5D_page_actions_94beb6ef.js.map