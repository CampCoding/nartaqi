module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(admin)/exams/edit/[exam-id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=6adaa__next-internal_server_app_%28admin%29_exams_edit_%5Bexam-id%5D_page_actions_28a505d2.js.map