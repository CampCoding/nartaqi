module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_nartaqi__next-internal_server_app__not-found_page_actions_3a6a7542.js.map