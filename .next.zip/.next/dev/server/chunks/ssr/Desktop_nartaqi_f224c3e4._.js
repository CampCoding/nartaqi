module.exports = [
"[project]/Desktop/nartaqi/components/layout/RouteLoader.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RouteLoader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
"use client";
;
;
;
function RouteLoader() {
    const navigation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useNavigation"])();
    const isLoading = navigation?.state === "loading";
    const [show, setShow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let t;
        if (isLoading) {
            // debounce to avoid flash on very fast transitions
            t = setTimeout(()=>setShow(true), 100);
        } else {
            setShow(false);
        }
        return ()=>clearTimeout(t);
    }, [
        isLoading
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        "aria-hidden": "true",
        className: `fixed top-0 left-0 right-0 h-1 z-50 transition-all duration-300 transform origin-left ${show ? "scale-x-100" : "scale-x-0"} bg-[#0F7490]`
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/layout/RouteLoader.jsx",
        lineNumber: 23,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/data/subjects.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "subjects",
    ()=>subjects
]);
const subjects = [
    {
        code: "MTH101",
        imageUrl: "https://res.cloudinary.com/dcs1nwnmm/image/upload/v1755438842/26_zg3km6.png",
        name: "دورة الرخصة المهنية للتربية الإسلامية (2)",
        price: 499,
        duration: "3 شهور",
        attachment: "شامل كتاب الدورة pdf",
        description: `دورة الرخصة المهنية بنيت على أسس علمية تبدأ من المعارف الأساسية التي تغطي كافة معايير اختبار الرخصة المهنية في مقررات التربية الإسلامية (2) إلى العمق المعرفي والتوسع ، ويتم ذلك من خلال محاضرات البث المباشر والتدريبات والاختبارات المحاكية للاختبار الفعلي. كما يتم متابعة جميع المتدربين وحثهم على رفع مستوى إنجازهم والتواصل المستمر والرد على كافة استفساراتهم حتى دخول الاختبار.`,
        date: "2024-08-01",
        students: 245,
        questions: 156,
        lastUpdated: "2024-08-01",
        status: "نشط",
        genderPolicy: "female",
        capacity: 300,
        availableFrom: "2025-08-01",
        availableTo: "2025-12-01",
        enrolledStudents: [
            {
                id: 1,
                name: "سارة أحمد",
                email: "sara@example.com",
                joinedAt: "2025-08-10",
                gender: "female"
            },
            {
                id: 2,
                name: "منى علي",
                email: "mona@example.com",
                joinedAt: "2025-08-12",
                gender: "female"
            }
        ],
        units: [
            {
                name: "الجبر",
                students: 88,
                questions: 56,
                lastUpdated: "2024-08-01",
                videos: 3,
                topics: [
                    {
                        name: "المعادلات الخطية",
                        questions: 19,
                        flashcards: 20,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "مدخل إلى المعادلات الخطية",
                            url: "https://cdn.example.com/videos/mth101/algebra/linear-equations.mp4",
                            duration: "12:34",
                            thumbnail: "https://cdn.example.com/thumbs/mth101/linear-equations.jpg",
                            views: 1540,
                            likes: 210,
                            uploadedAt: "2024-07-20",
                            completionRate: 78
                        }
                    },
                    {
                        name: "المعادلات التربيعية",
                        questions: 19,
                        flashcards: 20,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "حل المعادلات التربيعية",
                            url: "https://cdn.example.com/videos/mth101/algebra/quadratics.mp4",
                            duration: "15:02",
                            thumbnail: "https://cdn.example.com/thumbs/mth101/quadratics.jpg",
                            views: 1325,
                            likes: 185,
                            uploadedAt: "2024-07-22",
                            completionRate: 73
                        }
                    },
                    {
                        name: "المتباينات",
                        questions: 18,
                        flashcards: 20,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "المتباينات وتمثيلها",
                            url: "https://cdn.example.com/videos/mth101/algebra/inequalities.mp4",
                            duration: "10:48",
                            thumbnail: "https://cdn.example.com/thumbs/mth101/inequalities.jpg",
                            views: 980,
                            likes: 120,
                            uploadedAt: "2024-07-25",
                            completionRate: 69
                        }
                    }
                ]
            },
            {
                name: "الهندسة",
                students: 82,
                questions: 45,
                lastUpdated: "2024-08-01",
                videos: 3,
                topics: [
                    {
                        name: "المثلثات",
                        questions: 15,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "أساسيات المثلثات",
                            url: "https://cdn.example.com/videos/mth101/geometry/triangles.mp4",
                            duration: "09:41",
                            thumbnail: "https://cdn.example.com/thumbs/mth101/triangles.jpg",
                            views: 1120,
                            likes: 140,
                            uploadedAt: "2024-07-26",
                            completionRate: 75
                        }
                    },
                    {
                        name: "الدوائر",
                        questions: 15,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "خواص الدائرة",
                            url: "https://cdn.example.com/videos/mth101/geometry/circles.mp4",
                            duration: "11:15",
                            thumbnail: "https://cdn.example.com/thumbs/mth101/circles.jpg",
                            views: 990,
                            likes: 118,
                            uploadedAt: "2024-07-28",
                            completionRate: 71
                        }
                    },
                    {
                        name: "المساحة والمحيط",
                        questions: 15,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "حساب المساحة والمحيط",
                            url: "https://cdn.example.com/videos/mth101/geometry/area-perimeter.mp4",
                            duration: "08:57",
                            thumbnail: "https://cdn.example.com/thumbs/mth101/area-perimeter.jpg",
                            views: 860,
                            likes: 102,
                            uploadedAt: "2024-07-30",
                            completionRate: 68
                        }
                    }
                ]
            },
            {
                name: "حساب التفاضل والتكامل",
                students: 75,
                questions: 55,
                lastUpdated: "2024-08-01",
                videos: 3,
                topics: [
                    {
                        name: "النهايات",
                        questions: 18,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "فهم النهايات",
                            url: "https://cdn.example.com/videos/mth101/calculus/limits.mp4",
                            duration: "13:21",
                            thumbnail: "https://cdn.example.com/thumbs/mth101/limits.jpg",
                            views: 1470,
                            likes: 190,
                            uploadedAt: "2024-07-18",
                            completionRate: 77
                        }
                    },
                    {
                        name: "المشتقات",
                        questions: 18,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "المشتقة وقواعدها",
                            url: "https://cdn.example.com/videos/mth101/calculus/derivatives.mp4",
                            duration: "16:05",
                            thumbnail: "https://cdn.example.com/thumbs/mth101/derivatives.jpg",
                            views: 1255,
                            likes: 165,
                            uploadedAt: "2024-07-21",
                            completionRate: 70
                        }
                    },
                    {
                        name: "التكاملات",
                        questions: 19,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "مدخل إلى التكامل",
                            url: "https://cdn.example.com/videos/mth101/calculus/integrals.mp4",
                            duration: "14:49",
                            thumbnail: "https://cdn.example.com/thumbs/mth101/integrals.jpg",
                            views: 1015,
                            likes: 130,
                            uploadedAt: "2024-07-24",
                            completionRate: 66
                        }
                    }
                ]
            }
        ]
    },
    {
        code: "PHY201",
        imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBGrvivmAtwpuVN7BKchYTp1Ps0WL_ywr2hQ&s",
        name: "الفيزياء",
        description: "الميكانيكا الكلاسيكية، الديناميكا الحرارية، ونظرية الكهرومغناطيسية",
        date: "2024-07-28",
        price: 599,
        duration: "4 شهور",
        attachment: "شامل كتاب الدورة pdf",
        students: 189,
        questions: 98,
        lastUpdated: "2024-08-01",
        status: "نشط",
        genderPolicy: "both",
        availableFrom: "2025-09-01",
        availableTo: "2025-12-01",
        capacity: 300,
        enrolledStudents: [
            {
                id: 1,
                name: "سارة أحمد",
                email: "sara@example.com",
                joinedAt: "2025-08-10",
                gender: "female"
            },
            {
                id: 2,
                name: "منى علي",
                email: "mona@example.com",
                joinedAt: "2025-08-12",
                gender: "female"
            }
        ],
        //   { id: 1, name: "سارة أحمد", email: "sara@example.com", joinedAt: "2025-08-10", gender: "female" },
        //   { id: 2, name: "منى علي", email: "mona@example.com", joinedAt: "2025-08-12", gender: "female" }
        // ]
        units: [
            {
                name: "الميكانيكا",
                students: 65,
                questions: 32,
                lastUpdated: "2024-08-01",
                videos: 4,
                topics: [
                    {
                        name: "الحركة",
                        questions: 8,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "الحركة في بعد واحد",
                            url: "https://cdn.example.com/videos/phy201/mechanics/kinematics.mp4",
                            duration: "11:20",
                            thumbnail: "https://cdn.example.com/thumbs/phy201/kinematics.jpg",
                            views: 880,
                            likes: 110,
                            uploadedAt: "2024-07-19",
                            completionRate: 72
                        }
                    },
                    {
                        name: "القوى",
                        questions: 8,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "قوانين نيوتن",
                            url: "https://cdn.example.com/videos/phy201/mechanics/forces.mp4",
                            duration: "12:09",
                            thumbnail: "https://cdn.example.com/thumbs/phy201/forces.jpg",
                            views: 940,
                            likes: 125,
                            uploadedAt: "2024-07-22",
                            completionRate: 74
                        }
                    },
                    {
                        name: "الطاقة",
                        questions: 8,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "الشغل والطاقة",
                            url: "https://cdn.example.com/videos/phy201/mechanics/energy.mp4",
                            duration: "10:31",
                            thumbnail: "https://cdn.example.com/thumbs/phy201/energy.jpg",
                            views: 790,
                            likes: 96,
                            uploadedAt: "2024-07-25",
                            completionRate: 67
                        }
                    },
                    {
                        name: "الزخم",
                        questions: 8,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "الزخم والتصادمات",
                            url: "https://cdn.example.com/videos/phy201/mechanics/momentum.mp4",
                            duration: "09:58",
                            thumbnail: "https://cdn.example.com/thumbs/phy201/momentum.jpg",
                            views: 730,
                            likes: 90,
                            uploadedAt: "2024-07-27",
                            completionRate: 65
                        }
                    }
                ]
            },
            {
                name: "الديناميكا الحرارية",
                students: 60,
                questions: 36,
                lastUpdated: "2024-08-01",
                videos: 2,
                topics: [
                    {
                        name: "انتقال الحرارة",
                        questions: 18,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "آليات انتقال الحرارة",
                            url: "https://cdn.example.com/videos/phy201/thermo/heat-transfer.mp4",
                            duration: "13:12",
                            thumbnail: "https://cdn.example.com/thumbs/phy201/heat-transfer.jpg",
                            views: 640,
                            likes: 80,
                            uploadedAt: "2024-07-23",
                            completionRate: 69
                        }
                    },
                    {
                        name: "قوانين الديناميكا الحرارية",
                        questions: 18,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "القانون الأول والثاني",
                            url: "https://cdn.example.com/videos/phy201/thermo/laws.mp4",
                            duration: "14:44",
                            thumbnail: "https://cdn.example.com/thumbs/phy201/laws.jpg",
                            views: 615,
                            likes: 77,
                            uploadedAt: "2024-07-29",
                            completionRate: 63
                        }
                    }
                ]
            },
            {
                name: "الكهرومغناطيسية",
                students: 64,
                questions: 30,
                lastUpdated: "2024-08-01",
                videos: 3,
                topics: [
                    {
                        name: "المجالات الكهربائية",
                        questions: 10,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "شحنة ومجال كهربائي",
                            url: "https://cdn.example.com/videos/phy201/em/electric-fields.mp4",
                            duration: "12:27",
                            thumbnail: "https://cdn.example.com/thumbs/phy201/electric-fields.jpg",
                            views: 700,
                            likes: 88,
                            uploadedAt: "2024-07-24",
                            completionRate: 66
                        }
                    },
                    {
                        name: "المجالات المغناطيسية",
                        questions: 10,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "المغناطيسية والتيار",
                            url: "https://cdn.example.com/videos/phy201/em/magnetic-fields.mp4",
                            duration: "11:36",
                            thumbnail: "https://cdn.example.com/thumbs/phy201/magnetic-fields.jpg",
                            views: 660,
                            likes: 82,
                            uploadedAt: "2024-07-26",
                            completionRate: 64
                        }
                    },
                    {
                        name: "الدوائر الكهربائية",
                        questions: 10,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "مبادئ الدوائر الكهربائية",
                            url: "https://cdn.example.com/videos/phy201/em/circuits.mp4",
                            duration: "13:05",
                            thumbnail: "https://cdn.example.com/thumbs/phy201/circuits.jpg",
                            views: 720,
                            likes: 90,
                            uploadedAt: "2024-07-31",
                            completionRate: 62
                        }
                    }
                ]
            }
        ]
    },
    {
        code: "BIO111",
        imageUrl: "https://img.freepik.com/premium-vector/biology-doodle-set-collection-hand-drawn-elements-science-biology-isolated-white-background_308665-1569.jpg",
        name: "الأحياء",
        description: "مقدمة في علوم الحياة، علم الخلية، وعلم الوراثة",
        date: "2024-07-30",
        students: 312,
        questions: 203,
        lastUpdated: "2024-08-01",
        price: 399,
        duration: "3 شهور",
        attachment: "شامل كتاب الدورة pdf",
        status: "نشط",
        genderPolicy: "male",
        availableFrom: "2025-09-01",
        availableTo: "2025-12-01",
        capacity: 300,
        enrolledStudents: [
            {
                id: 1,
                name: "سارة أحمد",
                email: "sara@example.com",
                joinedAt: "2025-08-10",
                gender: "female"
            },
            {
                id: 2,
                name: "منى علي",
                email: "mona@example.com",
                joinedAt: "2025-08-12",
                gender: "female"
            }
        ],
        //   { id: 1, name: "سارة أحمد", email: "sara@example.com", joinedAt: "2025-08-10", gender: "female" },
        //   { id: 2, name: "منى علي", email: "mona@example.com", joinedAt: "2025-08-12", gender: "female" }
        // ]
        units: [
            {
                name: "علم الخلية",
                students: 100,
                questions: 60,
                lastUpdated: "2024-08-01",
                videos: 3,
                topics: [
                    {
                        name: "تركيب الخلية",
                        questions: 20,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "جولة داخل الخلية",
                            url: "https://cdn.example.com/videos/bio111/cell/structure.mp4",
                            duration: "10:22",
                            thumbnail: "https://cdn.example.com/thumbs/bio111/cell-structure.jpg",
                            views: 1500,
                            likes: 200,
                            uploadedAt: "2024-07-15",
                            completionRate: 80
                        }
                    },
                    {
                        name: "الانقسام المتساوي",
                        questions: 20,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "مراحل الانقسام المتساوي",
                            url: "https://cdn.example.com/videos/bio111/cell/mitosis.mp4",
                            duration: "09:50",
                            thumbnail: "https://cdn.example.com/thumbs/bio111/mitosis.jpg",
                            views: 1320,
                            likes: 176,
                            uploadedAt: "2024-07-19",
                            completionRate: 74
                        }
                    },
                    {
                        name: "الخاصية الأسموزية",
                        questions: 20,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "الأسموزية والانتشار",
                            url: "https://cdn.example.com/videos/bio111/cell/osmosis.mp4",
                            duration: "08:45",
                            thumbnail: "https://cdn.example.com/thumbs/bio111/osmosis.jpg",
                            views: 1180,
                            likes: 150,
                            uploadedAt: "2024-07-23",
                            completionRate: 69
                        }
                    }
                ]
            },
            {
                name: "علم الوراثة",
                students: 102,
                questions: 43,
                lastUpdated: "2024-08-01",
                videos: 3,
                topics: [
                    {
                        name: "الحمض النووي DNA",
                        questions: 15,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "ما هو الـ DNA؟",
                            url: "https://cdn.example.com/videos/bio111/genetics/dna.mp4",
                            duration: "12:10",
                            thumbnail: "https://cdn.example.com/thumbs/bio111/dna.jpg",
                            views: 1400,
                            likes: 185,
                            uploadedAt: "2024-07-20",
                            completionRate: 76
                        }
                    },
                    {
                        name: "الجينات",
                        questions: 14,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "الجين والتعبير الوراثي",
                            url: "https://cdn.example.com/videos/bio111/genetics/genes.mp4",
                            duration: "11:02",
                            thumbnail: "https://cdn.example.com/thumbs/bio111/genes.jpg",
                            views: 1205,
                            likes: 160,
                            uploadedAt: "2024-07-27",
                            completionRate: 70
                        }
                    },
                    {
                        name: "الوراثة",
                        questions: 14,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "قوانين مندل",
                            url: "https://cdn.example.com/videos/bio111/genetics/inheritance.mp4",
                            duration: "13:30",
                            thumbnail: "https://cdn.example.com/thumbs/bio111/inheritance.jpg",
                            views: 1250,
                            likes: 168,
                            uploadedAt: "2024-07-30",
                            completionRate: 68
                        }
                    }
                ]
            },
            {
                name: "البيئة",
                students: 110,
                questions: 100,
                lastUpdated: "2024-08-01",
                videos: 3,
                topics: [
                    {
                        name: "النظم البيئية",
                        questions: 33,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "مكونات النظام البيئي",
                            url: "https://cdn.example.com/videos/bio111/ecology/ecosystems.mp4",
                            duration: "12:55",
                            thumbnail: "https://cdn.example.com/thumbs/bio111/ecosystems.jpg",
                            views: 990,
                            likes: 130,
                            uploadedAt: "2024-07-28",
                            completionRate: 64
                        }
                    },
                    {
                        name: "سلاسل الغذاء",
                        questions: 33,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "سلاسل وشبكات الغذاء",
                            url: "https://cdn.example.com/videos/bio111/ecology/food-chains.mp4",
                            duration: "10:40",
                            thumbnail: "https://cdn.example.com/thumbs/bio111/food-chains.jpg",
                            views: 910,
                            likes: 118,
                            uploadedAt: "2024-07-29",
                            completionRate: 61
                        }
                    },
                    {
                        name: "التنوع البيولوجي",
                        questions: 34,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "أهمية التنوع البيولوجي",
                            url: "https://cdn.example.com/videos/bio111/ecology/biodiversity.mp4",
                            duration: "11:18",
                            thumbnail: "https://cdn.example.com/thumbs/bio111/biodiversity.jpg",
                            views: 870,
                            likes: 112,
                            uploadedAt: "2024-08-01",
                            completionRate: 59
                        }
                    }
                ]
            }
        ]
    },
    {
        code: "CHE151",
        imageUrl: "https://blog.educationnest.com/wp-content/uploads/2023/10/Untitled-design-2023-10-10T165957.095.jpg",
        name: "الكيمياء",
        description: "أساسيات الكيمياء العضوية وغير العضوية",
        date: "2024-07-26",
        price: 455,
        duration: "2 شهور",
        attachment: "شامل كتاب الدورة pdf",
        status: "مسودة",
        students: 167,
        questions: 134,
        lastUpdated: "2024-08-01",
        genderPolicy: "female",
        availableFrom: "2025-09-01",
        availableTo: "2025-12-01",
        capacity: 300,
        enrolledStudents: [
            {
                id: 1,
                name: "سارة أحمد",
                email: "sara@example.com",
                joinedAt: "2025-08-10",
                gender: "female"
            },
            {
                id: 2,
                name: "منى علي",
                email: "mona@example.com",
                joinedAt: "2025-08-12",
                gender: "female"
            }
        ],
        //   { id: 1, name: "سارة أحمد", email: "sara@example.com", joinedAt: "2025-08-10", gender: "female" },
        //   { id: 2, name: "منى علي", email: "mona@example.com", joinedAt: "2025-08-12", gender: "female" }
        // ]
        units: [
            {
                name: "الكيمياء العضوية",
                students: 67,
                questions: 46,
                lastUpdated: "2024-08-01",
                videos: 3,
                topics: [
                    {
                        name: "الهيدروكربونات",
                        questions: 15,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "تصنيف الهيدروكربونات",
                            url: "https://cdn.example.com/videos/che151/organic/hydrocarbons.mp4",
                            duration: "12:03",
                            thumbnail: "https://cdn.example.com/thumbs/che151/hydrocarbons.jpg",
                            views: 780,
                            likes: 95,
                            uploadedAt: "2024-07-18",
                            completionRate: 65
                        }
                    },
                    {
                        name: "الكحولات",
                        questions: 15,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "خواص وتفاعلات الكحولات",
                            url: "https://cdn.example.com/videos/che151/organic/alcohols.mp4",
                            duration: "11:27",
                            thumbnail: "https://cdn.example.com/thumbs/che151/alcohols.jpg",
                            views: 720,
                            likes: 90,
                            uploadedAt: "2024-07-21",
                            completionRate: 63
                        }
                    },
                    {
                        name: "الأحماض الكربوكسيلية",
                        questions: 16,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "بنية وتفاعلات الأحماض الكربوكسيلية",
                            url: "https://cdn.example.com/videos/che151/organic/carboxylic-acids.mp4",
                            duration: "13:19",
                            thumbnail: "https://cdn.example.com/thumbs/che151/carboxylic-acids.jpg",
                            views: 690,
                            likes: 86,
                            uploadedAt: "2024-07-24",
                            completionRate: 60
                        }
                    }
                ]
            },
            {
                name: "الكيمياء غير العضوية",
                students: 100,
                questions: 45,
                lastUpdated: "2024-08-01",
                videos: 3,
                topics: [
                    {
                        name: "الجدول الدوري",
                        questions: 15,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "الاتجاهات الدورية",
                            url: "https://cdn.example.com/videos/che151/inorganic/periodic-table.mp4",
                            duration: "10:55",
                            thumbnail: "https://cdn.example.com/thumbs/che151/periodic-table.jpg",
                            views: 830,
                            likes: 100,
                            uploadedAt: "2024-07-27",
                            completionRate: 62
                        }
                    },
                    {
                        name: "الروابط الكيميائية",
                        questions: 15,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "تشاركية وأيونية وتساهمية",
                            url: "https://cdn.example.com/videos/che151/inorganic/chemical-bonding.mp4",
                            duration: "12:42",
                            thumbnail: "https://cdn.example.com/thumbs/che151/chemical-bonding.jpg",
                            views: 790,
                            likes: 98,
                            uploadedAt: "2024-07-30",
                            completionRate: 60
                        }
                    },
                    {
                        name: "الأحماض والقواعد",
                        questions: 15,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "مفاهيم الأحماض والقواعد",
                            url: "https://cdn.example.com/videos/che151/inorganic/acids-bases.mp4",
                            duration: "11:06",
                            thumbnail: "https://cdn.example.com/thumbs/che151/acids-bases.jpg",
                            views: 760,
                            likes: 92,
                            uploadedAt: "2024-08-01",
                            completionRate: 58
                        }
                    }
                ]
            },
            {
                name: "الكيمياء الفيزيائية",
                students: 100,
                questions: 43,
                lastUpdated: "2024-08-01",
                videos: 3,
                topics: [
                    {
                        name: "الكيمياء الحرارية",
                        questions: 14,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "الطاقة الداخلية والإنثالبي",
                            url: "https://cdn.example.com/videos/che151/physical/thermochemistry.mp4",
                            duration: "12:18",
                            thumbnail: "https://cdn.example.com/thumbs/che151/thermochemistry.jpg",
                            views: 710,
                            likes: 88,
                            uploadedAt: "2024-07-20",
                            completionRate: 61
                        }
                    },
                    {
                        name: "الحركية الكيميائية",
                        questions: 14,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "سرعة التفاعل والعوامل المؤثرة",
                            url: "https://cdn.example.com/videos/che151/physical/kinetics.mp4",
                            duration: "13:02",
                            thumbnail: "https://cdn.example.com/thumbs/che151/kinetics.jpg",
                            views: 680,
                            likes: 84,
                            uploadedAt: "2024-07-23",
                            completionRate: 57
                        }
                    },
                    {
                        name: "الاتزان الكيميائي",
                        questions: 15,
                        lastUpdated: "2024-08-01",
                        video: {
                            title: "ثابت الاتزان وتحويلاته",
                            url: "https://cdn.example.com/videos/che151/physical/equilibrium.mp4",
                            duration: "12:40",
                            thumbnail: "https://cdn.example.com/thumbs/che151/equilibrium.jpg",
                            views: 640,
                            likes: 80,
                            uploadedAt: "2024-07-26",
                            completionRate: 55
                        }
                    }
                ]
            }
        ]
    }
];
}),
"[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Sidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/users.js [app-ssr] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$graduation$2d$cap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__GraduationCap$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/graduation-cap.js [app-ssr] (ecmascript) <export default as GraduationCap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/file-text.js [app-ssr] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/bell.js [app-ssr] (ecmascript) <export default as Bell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/settings.js [app-ssr] (ecmascript) <export default as Settings>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/chart-column.js [app-ssr] (ecmascript) <export default as BarChart3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/book-open.js [app-ssr] (ecmascript) <export default as BookOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/cog.js [app-ssr] (ecmascript) <export default as Cog>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleAlert$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/circle-alert.js [app-ssr] (ecmascript) <export default as CircleAlert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2d$round$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users2$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/users-round.js [app-ssr] (ecmascript) <export default as Users2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Book$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/book.js [app-ssr] (ecmascript) <export default as Book>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/star.js [app-ssr] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Text$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/text.js [app-ssr] (ecmascript) <export default as Text>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2d$fading$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ClockFading$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/clock-fading.js [app-ssr] (ecmascript) <export default as ClockFading>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/book-open.js [app-ssr] (ecmascript) <export default as BookOpenIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$credit$2d$card$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CreditCard$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/credit-card.js [app-ssr] (ecmascript) <export default as CreditCard>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$qr$2d$code$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__QrCode$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/qr-code.js [app-ssr] (ecmascript) <export default as QrCode>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$headset$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Headset$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/headset.js [app-ssr] (ecmascript) <export default as Headset>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$files$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Files$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/files.js [app-ssr] (ecmascript) <export default as Files>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/award.js [app-ssr] (ecmascript) <export default as Award>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/trophy.js [app-ssr] (ecmascript) <export default as Trophy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$badge$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/badge.js [app-ssr] (ecmascript) <export default as Badge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$data$2f$subjects$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/data/subjects.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
function Sidebar() {
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("نظرة عامة");
    const [selectedSubject, setSelectedSubject] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$data$2f$subjects$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["subjects"][0].name);
    const [isSubjectDropdownOpen, setIsSubjectDropdownOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const baseMenuItems = [
        {
            name: "نظرة عامة",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"],
            path: "/"
        }
    ];
    // Subject items (translated)
    const getSubjectSpecificItems = (subjectName)=>{
        const subject = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$data$2f$subjects$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["subjects"].find((s)=>s.name === subjectName);
        const subjectPath = subject?.code;
        return [
            {
                name: "المعلمين",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"],
                path: `/subjects/${subjectPath}/teachers`
            },
            {
                name: "الدورات",
                icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$cog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog$3e$__["Cog"],
                path: `/subjects/${subjectPath}/units`
            }
        ];
    };
    const handleSubjectChange = (subjectName)=>{
        const subject = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$data$2f$subjects$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["subjects"].find((s)=>s.name === subjectName);
        if (!subject) return;
        setSelectedSubject(subjectName);
        setIsSubjectDropdownOpen(false);
        const pathSegments = pathname.split("/");
        const subjectIndex = pathSegments.findIndex((seg)=>seg === "subjects");
        if (subjectIndex !== -1 && pathSegments.length > subjectIndex + 1) {
            pathSegments[subjectIndex + 1] = subject.code;
            const isInUnitsChildRoute = pathSegments[subjectIndex + 2] === "units" && pathSegments.length > subjectIndex + 3;
            if (isInUnitsChildRoute) {
                router.replace(`/subjects/${subject.code}/units`);
                return;
            }
        }
        const newPath = pathSegments.join("/");
        router.replace(newPath);
    };
    const menuItems = [
        {
            name: "الفئات",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"],
            path: "/categories"
        },
        {
            name: "دورات الوجهه السعودية",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"],
            path: "/teachers-courses"
        },
        // {
        //   name:"دورات الوجهه المصرية",
        //   icon : BookOpen,
        //   path:"/egyptian_course"
        // },
        {
            name: "دورة المصدر ",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$files$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Files$3e$__["Files"],
            path: "/saudi_source_course"
        },
        // {
        //   name:"محتوي الدورة",
        //   icon: Files,
        //   path:"/round_content"
        // },
        {
            name: "المتدربين",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$graduation$2d$cap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__GraduationCap$3e$__["GraduationCap"],
            path: "/students"
        },
        // { name: "أقسام الاختبارات", icon: BookCopy , path: "/exam_sections" },
        {
            name: "الاختبارات",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"],
            path: "/exams"
        },
        {
            name: "المدونة",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__["BookOpenIcon"],
            path: "/blog"
        },
        {
            name: "متجر الكتب",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Book$3e$__["Book"],
            path: "/book-store"
        },
        {
            name: "المسابقات",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"],
            path: '/competitions'
        },
        {
            name: "المسوقين",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"],
            path: '/marketers'
        },
        {
            name: "المكافآت",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__["Trophy"],
            path: "/rewards"
        },
        {
            name: "الشارات",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$badge$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__["Badge"],
            path: "/badge"
        },
        {
            name: "فريق العمل",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2d$round$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users2$3e$__["Users2"],
            path: "/teams"
        },
        {
            name: "التقييم",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"],
            path: "/rating"
        },
        {
            name: "الإشعارات",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"],
            path: "/notifications"
        },
        {
            name: "QR",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$qr$2d$code$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__QrCode$3e$__["QrCode"],
            path: "/qr-code"
        },
        {
            name: "الدعم الفني",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$headset$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Headset$3e$__["Headset"],
            path: "/technical_support"
        },
        {
            name: "بوابة الدعم",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2d$fading$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ClockFading$3e$__["ClockFading"],
            path: "/support"
        },
        {
            name: "تأكيد الدفع",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$credit$2d$card$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CreditCard$3e$__["CreditCard"],
            path: "/confirm-payment"
        },
        {
            name: "أسئلة شائعة",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Text$3e$__["Text"],
            path: "/faq"
        },
        {
            name: "الشروط والأحكام",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CircleAlert$3e$__["CircleAlert"],
            badge: "",
            path: "/privacy-policy"
        },
        {
            name: "الموقع",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$settings$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Settings$3e$__["Settings"],
            path: "/settings"
        }
    ];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const currentItem = [
            ...baseMenuItems,
            ...getSubjectSpecificItems(selectedSubject)
        ].find((item)=>pathname === item.path);
        if (currentItem) setActiveTab(currentItem.name);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        pathname
    ]);
    const selectedSubjectData = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$data$2f$subjects$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["subjects"].find((s)=>s.name === selectedSubject);
    const SelectedSubjectIcon = selectedSubjectData?.icon || __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        dir: "rtl",
        className: "fixed right-0 top-0 h-screen overflow-y-auto w-64 bg-white shadow-lg border-l border-gray-100",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-6 border-b-2 border-accent/30 border-dashed",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: "group flex items-center justify-center gap-4 gap-reverse transition-transform duration-300 hover:scale-105",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "/images/logo.svg",
                            className: "w-24 h-24 mx-auto",
                            alt: "الشعار"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                            lineNumber: 221,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                        lineNumber: 217,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                    lineNumber: 216,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                lineNumber: 214,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: "mt-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RenderNavs, {
                        items: baseMenuItems,
                        activeTab: activeTab,
                        setActiveTab: setActiveTab,
                        selectedSubject: selectedSubject,
                        rtl: true
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                        lineNumber: 231,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {}, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                        lineNumber: 239,
                        columnNumber: 9
                    }, this),
                    menuItems.map((item)=>{
                        const IconComponent = item.icon;
                        const isActive = activeTab === item.name;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: item.path,
                            onClick: ()=>setActiveTab(item.name),
                            className: `w-full flex items-center px-6 gap-3 py-3 text-right transition-all duration-200 hover:bg-gray-50 ${isActive ? "border-l-4 bg-blue-50" : ""}`,
                            style: {
                                borderLeftColor: isActive ? "#0F7490" : "transparent",
                                color: isActive ? "#0F7490" : "#202938"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(IconComponent, {
                                    className: "w-5 h-5"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                                    lineNumber: 257,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-medium ml-3",
                                    children: item.name
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                                    lineNumber: 258,
                                    columnNumber: 15
                                }, this),
                                item.badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "mr-auto px-2 py-1 text-xs rounded-full text-white",
                                    style: {
                                        backgroundColor: "#8B5CF6"
                                    },
                                    children: item.badge
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                                    lineNumber: 260,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, item.name, true, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                            lineNumber: 245,
                            columnNumber: 13
                        }, this);
                    })
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                lineNumber: 230,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
        lineNumber: 210,
        columnNumber: 5
    }, this);
}
function RenderNavs({ items, setActiveTab, activeTab, selectedSubject, rtl }) {
    return items.map((item)=>{
        const IconComponent = item.icon;
        const isActive = activeTab === item.name;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            href: {
                pathname: item.path,
                query: selectedSubject ? {
                    subject: selectedSubject
                } : {}
            },
            onClick: ()=>setActiveTab(item.name),
            className: `w-full flex items-center gap-3 px-6 py-3 text-right transition-all duration-200 hover:bg-gray-50 ${isActive ? "border-l-4 bg-blue-50" : ""}`,
            style: {
                borderLeftColor: isActive ? "#0F7490" : "transparent",
                color: isActive ? "#0F7490" : "#202938"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(IconComponent, {
                    className: "w-5 h-5"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                    lineNumber: 295,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "font-medium ml-3",
                    children: item.name
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
                    lineNumber: 296,
                    columnNumber: 9
                }, this)
            ]
        }, `${item.name}-${selectedSubject}`, true, {
            fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx",
            lineNumber: 280,
            columnNumber: 7
        }, this);
    });
}
}),
"[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Topbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/bell.js [app-ssr] (ecmascript) <export default as Bell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/search.js [app-ssr] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$configs$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/configs/index.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function Topbar() {
    const [notifications, setNotifications] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(3);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: " shadow-2xl bg-background  border-b-2 border-accent/30 border-dashed px-8 py-4 mr-64",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-between",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-3xl font-bold text-text",
                            children: "لوحة التحكم"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                            lineNumber: 32,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-600 mt-1",
                            children: "مرحبًا بعودتك "
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                            lineNumber: 33,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                    lineNumber: 31,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                    className: "absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                                    lineNumber: 38,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "text",
                                    placeholder: "بحث...",
                                    className: "pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                                    lineNumber: 39,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                            lineNumber: 37,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>router.push("/notifications"),
                            className: "relative p-2  text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"], {
                                    className: "w-5 h-5"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this),
                                notifications > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "absolute -top-1 -right-1 w-4 h-4 text-xs text-white rounded-full flex items-center justify-center",
                                    style: {
                                        backgroundColor: "#8B5CF6"
                                    },
                                    children: notifications
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                                    lineNumber: 51,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-8 h-8 rounded-full mx-2 flex items-center justify-center text-white font-semibold",
                                    style: {
                                        backgroundColor: "#0F7490"
                                    },
                                    children: "م"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                                    lineNumber: 61,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-sm font-medium",
                                    style: {
                                        color: "#202938"
                                    },
                                    children: "المسئول"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                                    lineNumber: 67,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        localStorage.removeItem(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$configs$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["configs"].tokenKey);
                                        localStorage.removeItem(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$configs$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["configs"].userKey);
                                        router.push("/login");
                                    },
                                    className: "text-sm text-gray-600 hover:text-gray-800",
                                    children: "تسجيل الخروج"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                            lineNumber: 60,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
                    lineNumber: 36,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
            lineNumber: 30,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/app/(admin)/layout.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AdminLayout
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$layout$2f$RouteLoader$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/layout/RouteLoader.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$app$2f28$admin$292f$components$2f$Sidebar$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/app/(admin)/components/Sidebar.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$app$2f28$admin$292f$components$2f$Topbar$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/app/(admin)/components/Topbar.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$LayoutProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/LayoutProvider.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
function AdminLayout({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex min-h-screen  ",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$LayoutProvider$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$app$2f28$admin$292f$components$2f$Sidebar$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/layout.jsx",
                        lineNumber: 14,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$app$2f28$admin$292f$components$2f$Topbar$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/layout.jsx",
                                lineNumber: 16,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                                className: "flex-1 mr-64 p-8   overflow-auto min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100",
                                children: children
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/layout.jsx",
                                lineNumber: 17,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/layout.jsx",
                        lineNumber: 15,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/layout.jsx",
                lineNumber: 12,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastContainer"], {}, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/layout.jsx",
                lineNumber: 23,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/app/(admin)/layout.jsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=Desktop_nartaqi_f224c3e4._.js.map