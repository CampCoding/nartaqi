module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(admin)/subjects/[id]/units/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=6adaa__next-internal_server_app_%28admin%29_subjects_%5Bid%5D_units_page_actions_9d3a725e.js.map