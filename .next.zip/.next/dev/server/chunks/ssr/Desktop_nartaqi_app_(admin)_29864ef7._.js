module.exports = [
"[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "all_categories",
    ()=>all_categories,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$PlusOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/PlusOutlined.js [app-ssr] (ecmascript) <export default as PlusOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$BookOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/BookOutlined.js [app-ssr] (ecmascript) <export default as BookOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FileTextOutlined.js [app-ssr] (ecmascript) <export default as FileTextOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DeleteOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DeleteOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/DeleteOutlined.js [app-ssr] (ecmascript) <export default as DeleteOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$PlayCircleOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PlayCircleOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/PlayCircleOutlined.js [app-ssr] (ecmascript) <export default as PlayCircleOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$CalendarOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/CalendarOutlined.js [app-ssr] (ecmascript) <export default as CalendarOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$ClockCircleOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ClockCircleOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/ClockCircleOutlined.js [app-ssr] (ecmascript) <export default as ClockCircleOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$TeamOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TeamOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/TeamOutlined.js [app-ssr] (ecmascript) <export default as TeamOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FolderOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FolderOutlined.js [app-ssr] (ecmascript) <export default as FolderOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$SettingOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__SettingOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/SettingOutlined.js [app-ssr] (ecmascript) <export default as SettingOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/form/index.js [app-ssr] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input/index.js [app-ssr] (ecmascript) <export default as Input>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/select/index.js [app-ssr] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/message/index.js [app-ssr] (ecmascript) <export default as message>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$date$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/date-picker/index.js [app-ssr] (ecmascript) <export default as DatePicker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2d$number$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__InputNumber$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input-number/index.js [app-ssr] (ecmascript) <export default as InputNumber>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/upload/index.js [app-ssr] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/row/index.js [app-ssr] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/col/index.js [app-ssr] (ecmascript) <export default as Col>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$card$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/card/index.js [app-ssr] (ecmascript) <export default as Card>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$divider$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/divider/index.js [app-ssr] (ecmascript) <export default as Divider>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$time$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TimePicker$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/time-picker/index.js [app-ssr] (ecmascript) <export default as TimePicker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$badge$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/badge/index.js [app-ssr] (ecmascript) <export default as Badge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$space$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Space$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/space/index.js [app-ssr] (ecmascript) <locals> <export default as Space>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$switch$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/switch/index.js [app-ssr] (ecmascript) <export default as Switch>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/dayjs/dayjs.min.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/shared/lib/app-dynamic.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$TeacherCourses$2f$AddTeacherCourseContent$2f$AddTeacherCourseContent$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/TeacherCourses/AddTeacherCourseContent/AddTeacherCourseContent.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$TeacherCourses$2f$AddCourseResources$2f$AddCourseResources$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/TeacherCourses/AddCourseResources/AddCourseResources.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$TeacherCourses$2f$AddCourseBasicInfo$2f$AddCourseBasicInfo$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/TeacherCourses/AddCourseBasicInfo/AddCourseBasicInfo.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$TeacherCourses$2f$AddCourseSchedule$2f$AddCourseSchedule$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/TeacherCourses/AddCourseSchedule/AddCourseSchedule.jsx [app-ssr] (ecmascript)");
;
"use client";
;
;
;
;
;
;
;
;
;
;
;
const ReactQuill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(async ()=>{}, {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/nartaqi/node_modules/react-quill-new/lib/index.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
const { Dragger } = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"];
const { TextArea } = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"];
const { RangePicker } = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$date$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__["DatePicker"];
const all_categories = [
    {
        id: 1,
        title: "دورات عامة",
        sections: [
            {
                id: 1,
                name: "تطوير الويب",
                isVisible: true
            },
            {
                id: 2,
                name: "تطوير التطبيقات",
                isVisible: true
            },
            {
                id: 3,
                name: "الذكاء الاصطناعي",
                isVisible: true
            }
        ]
    },
    {
        id: 2,
        title: "الرخصة المهنية",
        sections: [
            {
                id: 4,
                name: "تصميم UI/UX",
                isVisible: true
            },
            {
                id: 5,
                name: "الجرافيك ديزاين",
                isVisible: true
            },
            {
                id: 6,
                name: "الرسم الرقمي",
                isVisible: false
            }
        ]
    },
    {
        id: 3,
        title: "دورات اخري",
        sections: [
            {
                id: 7,
                name: "الرياضيات المتقدمة",
                isVisible: true
            },
            {
                id: 8,
                name: "الفيزياء",
                isVisible: true
            },
            {
                id: 9,
                name: "الكيمياء",
                isVisible: true
            }
        ]
    }
];
const quillModules = {
    toolbar: [
        [
            {
                header: [
                    1,
                    2,
                    3,
                    false
                ]
            }
        ],
        [
            "bold",
            "italic",
            "underline",
            "strike"
        ],
        [
            {
                list: "ordered"
            },
            {
                list: "bullet"
            }
        ],
        [
            {
                align: [
                    "",
                    "center",
                    "right",
                    "justify"
                ]
            }
        ],
        [
            {
                direction: "rtl"
            }
        ],
        [
            {
                color: []
            },
            {
                background: []
            }
        ],
        [
            "link",
            "blockquote",
            "code-block"
        ],
        [
            "clean"
        ]
    ]
};
const quillFormats = [
    "header",
    "bold",
    "italic",
    "underline",
    "strike",
    "list",
    "align",
    "direction",
    "color",
    "background",
    "link",
    "blockquote",
    "code-block"
];
const RichTextField = ({ value, onChange, placeholder })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        dir: "rtl",
        className: "rich-text-field",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactQuill, {
            className: "ql-rtl",
            theme: "snow",
            value: value,
            onChange: (html)=>onChange?.(html),
            modules: quillModules,
            formats: quillFormats,
            placeholder: placeholder,
            style: {
                minHeight: "120px"
            }
        }, void 0, false, {
            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
            lineNumber: 108,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
        lineNumber: 107,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
// Helper: convert file -> base64
const getBase64 = (file)=>new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = ()=>resolve(reader.result);
        reader.onerror = reject;
    });
const CourseScheduleCard = ({ schedule, onUpdate, onRemove, index })=>{
    const [isEditing, setIsEditing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [editForm] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].useForm();
    const handleSave = (values)=>{
        onUpdate(index, values);
        setIsEditing(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$card$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Card$3e$__["Card"], {
        size: "small",
        className: "mb-3 hover:shadow-md transition-shadow duration-300 border-l-4 border-l-blue-500",
        extra: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$space$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Space$3e$__["Space"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                    type: "text",
                    size: "small",
                    onClick: ()=>setIsEditing(!isEditing),
                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$SettingOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__SettingOutlined$3e$__["SettingOutlined"], {}, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                        lineNumber: 149,
                        columnNumber: 19
                    }, void 0)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                    lineNumber: 145,
                    columnNumber: 11
                }, void 0),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                    type: "text",
                    size: "small",
                    danger: true,
                    onClick: ()=>onRemove(index),
                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DeleteOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DeleteOutlined$3e$__["DeleteOutlined"], {}, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                        lineNumber: 156,
                        columnNumber: 19
                    }, void 0)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                    lineNumber: 151,
                    columnNumber: 11
                }, void 0)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
            lineNumber: 144,
            columnNumber: 9
        }, void 0),
        children: !isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2 mb-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$CalendarOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarOutlined$3e$__["CalendarOutlined"], {
                            className: "text-blue-500"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 164,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-medium",
                            children: schedule.day
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 165,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$badge$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Badge$3e$__["Badge"], {
                            status: schedule.isActive ? "processing" : "default",
                            text: schedule.isActive ? "نشط" : "متوقف"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 166,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                    lineNumber: 163,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-4 text-sm text-gray-600",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "flex items-center gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$ClockCircleOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ClockCircleOutlined$3e$__["ClockCircleOutlined"], {}, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                    lineNumber: 173,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                schedule.startTime,
                                " - ",
                                schedule.endTime
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 172,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "flex items-center gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$TeamOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TeamOutlined$3e$__["TeamOutlined"], {}, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                    lineNumber: 177,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                schedule.maxStudents,
                                " طالب كحد أقصى"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 176,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                    lineNumber: 171,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
            lineNumber: 162,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
            form: editForm,
            layout: "vertical",
            initialValues: schedule,
            onFinish: handleSave,
            className: "mb-0",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                    gutter: 16,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                            span: 8,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                name: "day",
                                label: "اليوم",
                                className: "mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                                    options: [
                                        {
                                            label: "السبت",
                                            value: "السبت"
                                        },
                                        {
                                            label: "الأحد",
                                            value: "الأحد"
                                        },
                                        {
                                            label: "الاثنين",
                                            value: "الاثنين"
                                        },
                                        {
                                            label: "الثلاثاء",
                                            value: "الثلاثاء"
                                        },
                                        {
                                            label: "الأربعاء",
                                            value: "الأربعاء"
                                        },
                                        {
                                            label: "الخميس",
                                            value: "الخميس"
                                        },
                                        {
                                            label: "الجمعة",
                                            value: "الجمعة"
                                        }
                                    ]
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                    lineNumber: 193,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                lineNumber: 192,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 191,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                            span: 8,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                name: "startTime",
                                label: "بداية",
                                className: "mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$time$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TimePicker$3e$__["TimePicker"], {
                                    format: "HH:mm",
                                    className: "w-full"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                    lineNumber: 208,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                lineNumber: 207,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 206,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                            span: 8,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                name: "endTime",
                                label: "نهاية",
                                className: "mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$time$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TimePicker$3e$__["TimePicker"], {
                                    format: "HH:mm",
                                    className: "w-full"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                    lineNumber: 213,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                lineNumber: 212,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 211,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                    lineNumber: 190,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                    gutter: 16,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                            span: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                name: "maxStudents",
                                label: "الحد الأقصى",
                                className: "mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2d$number$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__InputNumber$3e$__["InputNumber"], {
                                    className: "w-full",
                                    min: 1
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                    lineNumber: 220,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                lineNumber: 219,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 218,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                            span: 12,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                name: "isActive",
                                valuePropName: "checked",
                                label: "الحالة",
                                className: "mb-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$switch$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
                                    checkedChildren: "نشط",
                                    unCheckedChildren: "متوقف"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                    lineNumber: 225,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                lineNumber: 224,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 223,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                    lineNumber: 217,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-end gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "small",
                            onClick: ()=>setIsEditing(false),
                            children: "إلغاء"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 230,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "small",
                            type: "primary",
                            htmltype: "submit",
                            children: "حفظ"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 233,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                    lineNumber: 229,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
            lineNumber: 183,
            columnNumber: 9
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
        lineNumber: 140,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const EnhancedCourseForm = ({ open, setOpen })=>{
    const [form] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].useForm();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1);
    const [fileList, setFileList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [fileNames, setFileNames] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({}); // uid -> custom name
    const [videos, setVideos] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: 1,
            name: "",
            url: ""
        }
    ]);
    const [imagePreview, setImagePreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [availableSections, setAvailableSections] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [schedules, setSchedules] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [newSchedule, setNewSchedule] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        day: "",
        date: "",
        startTime: null,
        endTime: null,
        maxStudents: 30,
        isActive: true
    });
    // Update sections when category changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (selectedCategory) {
            const category = all_categories.find((cat)=>cat.id === selectedCategory);
            if (category) {
                setAvailableSections(category.sections.filter((section)=>section.isVisible));
            }
        } else {
            setAvailableSections([]);
        }
    }, [
        selectedCategory
    ]);
    const beforeUpload = async (file)=>{
        const isImage = file.type?.startsWith("image/");
        if (!isImage) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("من فضلك ارفع ملف صورة فقط.");
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"].LIST_IGNORE;
        }
        const isLt5M = file.size / 1024 / 1024 < 5;
        if (!isLt5M) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("حجم الصورة يجب أن يكون أقل من 5MB.");
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"].LIST_IGNORE;
        }
        const preview = await getBase64(file);
        setImagePreview(preview);
        setFileList([
            {
                uid: file.uid || file.name,
                name: file.name,
                status: "done",
                originFileObj: file
            }
        ]);
        return false;
    };
    const onFilesChange = ({ fileList })=>{
        setFileList(fileList);
        setFileNames((prev)=>{
            const next = {
                ...prev
            };
            fileList.forEach((f)=>{
                if (f.uid && !next[f.uid]) next[f.uid] = f.name?.replace(/\.[^.]+$/, "") || "";
            });
            // remove stale uids
            Object.keys(next).forEach((uid)=>{
                if (!fileList.find((f)=>f.uid === uid)) delete next[uid];
            });
            return next;
        });
    };
    const handleAddSchedule = ()=>{
        if (newSchedule.date && newSchedule.startTime && newSchedule.endTime) {
            const schedule = {
                ...newSchedule,
                startTime: newSchedule.startTime.format("HH:mm"),
                endTime: newSchedule.endTime.format("HH:mm")
            };
            setSchedules([
                ...schedules,
                schedule
            ]);
            setNewSchedule({
                day: "",
                startTime: null,
                endTime: null,
                maxStudents: 30,
                isActive: true
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].success("تم إضافة الجدولة بنجاح!");
        } else {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("يجب إدخال جميع البيانات المطلوبة.");
        }
    };
    const handleUpdateSchedule = (index, updatedSchedule)=>{
        const newSchedules = [
            ...schedules
        ];
        newSchedules[index] = {
            ...updatedSchedule,
            startTime: updatedSchedule.startTime?.format ? updatedSchedule.startTime.format("HH:mm") : updatedSchedule.startTime,
            endTime: updatedSchedule.endTime?.format ? updatedSchedule.endTime.format("HH:mm") : updatedSchedule.endTime
        };
        setSchedules(newSchedules);
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].success("تم تحديث الجدولة بنجاح!");
    };
    const handleRemoveSchedule = (index)=>{
        const newSchedules = [
            ...schedules
        ];
        newSchedules.splice(index, 1);
        setSchedules(newSchedules);
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].success("تم حذف الجدولة بنجاح!");
    };
    const handleFinish = async ()=>{
        setLoading(true);
        try {
            const raw = form.getFieldsValue(true);
            const payload = {
                code: raw.code?.toUpperCase(),
                imageUrl: imagePreview,
                name: raw.name?.trim(),
                category: raw.category,
                section: raw.section,
                price: Number(raw.price ?? 0),
                duration: raw.duration?.trim(),
                description: raw.description?.trim(),
                status: raw.status,
                genderPolicy: raw.genderPolicy,
                capacity: Number(raw.capacity ?? 0),
                instructor: raw.instructor,
                availableFrom: raw.availableRange?.[0] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(raw.availableRange[0]).format("YYYY-MM-DD") : undefined,
                availableTo: raw.availableRange?.[1] ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(raw.availableRange[1]).format("YYYY-MM-DD") : undefined,
                summary: raw.summary || "",
                schedules: schedules,
                resources: {
                    files: (raw.resources?.files || []).map((f)=>({
                            // preserve original file object where possible
                            uid: f.uid,
                            name: fileNames[f.uid] ?? f.name,
                            originName: f.name,
                            type: f.type
                        })),
                    telegram: raw.resources?.telegram || "",
                    whatsapp: raw.resources?.whatsapp || "",
                    videos: videos.filter((v)=>v.url?.trim()).map((v)=>({
                            name: v.name?.trim() || "",
                            url: v.url.trim()
                        }))
                }
            };
            await new Promise((r)=>setTimeout(r, 1500));
            console.log("Enhanced Form Data:", payload);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].success("تمت إضافة الدورة بنجاح!");
            handleReset();
            setOpen(false);
        } catch (e) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("فشل إضافة الدورة. حاول مرة أخرى.");
        } finally{
            setLoading(false);
        }
    };
    const handleReset = ()=>{
        form.resetFields();
        setFileList([]);
        setImagePreview(null);
        setSelectedCategory(null);
        setAvailableSections([]);
        setSchedules([]);
        setNewSchedule({
            day: "",
            startTime: null,
            endTime: null,
            maxStudents: 30,
            isActive: true
        });
    };
    const tabItems = [
        {
            key: 1,
            label: "المعلومات الأساسية",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$BookOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOutlined$3e$__["BookOutlined"], {}, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                lineNumber: 423,
                columnNumber: 50
            }, ("TURBOPACK compile-time value", void 0))
        },
        {
            key: 2,
            label: "الجدولة والمواعيد",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$CalendarOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarOutlined$3e$__["CalendarOutlined"], {}, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                lineNumber: 424,
                columnNumber: 49
            }, ("TURBOPACK compile-time value", void 0))
        },
        {
            key: 3,
            label: "المحتوى التفصيلي",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__["FileTextOutlined"], {}, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                lineNumber: 425,
                columnNumber: 48
            }, ("TURBOPACK compile-time value", void 0))
        },
        {
            key: 4,
            label: "المصادر والملفات",
            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FolderOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderOutlined$3e$__["FolderOutlined"], {}, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                lineNumber: 426,
                columnNumber: 48
            }, ("TURBOPACK compile-time value", void 0))
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-gradient-to-br from-gray-50 to-blue-50/30 min-h-[80vh]",
        dir: "rtl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative mb-8 p-6 bg-white rounded-2xl shadow-sm border-b-4 border-b-blue-500",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-400/10 to-purple-400/10 rounded-full -translate-y-16 translate-x-16"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                        lineNumber: 433,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative flex items-center gap-4 mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-14 h-14 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center shadow-lg",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$PlusOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusOutlined$3e$__["PlusOutlined"], {
                                    className: "text-white text-xl"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                    lineNumber: 436,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                lineNumber: 435,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "text-3xl font-bold bg-gradient-to-r from-gray-800 to-blue-800 bg-clip-text text-transparent",
                                        children: "إضافة دورة جديدة"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 439,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-600 mt-1",
                                        children: "إنشاء وتكوين دورة تعليمية شاملة مع الجدولة والمحتوى"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 442,
                                        columnNumber: 17
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                lineNumber: 438,
                                columnNumber: 15
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                        lineNumber: 434,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 mt-4",
                        children: tabItems.map((tab, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-all cursor-pointer
                    ${activeTab === tab.key ? 'bg-blue-100 text-blue-700 border border-blue-200' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`,
                                onClick: ()=>setActiveTab(tab.key),
                                children: [
                                    tab.icon,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "hidden sm:inline",
                                        children: tab.label
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 459,
                                        columnNumber: 19
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, tab.key, true, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                lineNumber: 449,
                                columnNumber: 17
                            }, ("TURBOPACK compile-time value", void 0)))
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                        lineNumber: 447,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                lineNumber: 432,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
                    form: form,
                    layout: "vertical",
                    onFinish: handleFinish,
                    initialValues: {
                        code: "COURSE_" + Math.random().toString(36).substr(2, 6).toUpperCase(),
                        name: "",
                        category: null,
                        section: null,
                        price: 499,
                        duration: "3 شهور",
                        description: "",
                        status: "نشط",
                        genderPolicy: "both",
                        capacity: 50,
                        instructor: [],
                        availableRange: [
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])().add(1, 'week'),
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])().add(3, 'month')
                        ],
                        summary: ""
                    },
                    className: "p-8",
                    children: [
                        activeTab === 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$TeacherCourses$2f$AddCourseBasicInfo$2f$AddCourseBasicInfo$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            all_categories: all_categories,
                            availableSections: availableSections,
                            beforeUpload: beforeUpload,
                            fileList: fileList,
                            selectedCategory: selectedCategory,
                            setFileList: setFileList,
                            setImagePreview: setImagePreview,
                            setSelectedCategory: setSelectedCategory
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 489,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0)),
                        activeTab === 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$TeacherCourses$2f$AddCourseSchedule$2f$AddCourseSchedule$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            handleAddSchedule: handleAddSchedule,
                            handleRemoveSchedule: handleRemoveSchedule,
                            handleUpdateSchedule: handleUpdateSchedule,
                            newSchedule: newSchedule,
                            schedules: schedules,
                            setNewSchedule: setNewSchedule
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 503,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0)),
                        activeTab === 3 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-8",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-2xl p-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xl font-bold text-gray-800 mb-6 flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__["FileTextOutlined"], {
                                                className: "text-green-600"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                                lineNumber: 518,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            "المحتوى التفصيلي للدورة"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 517,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700",
                                            children: "ملخص الدورة"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                            lineNumber: 523,
                                            columnNumber: 30
                                        }, void 0),
                                        name: "summary",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RichTextField, {
                                            placeholder: "اكتب ملخصاً شاملاً للدورة يتضمن الأهداف التعليمية والمخرجات المتوقعة..."
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                            lineNumber: 526,
                                            columnNumber: 23
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 522,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700",
                                            children: "الشروط والأحكام"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                            lineNumber: 532,
                                            columnNumber: 30
                                        }, void 0),
                                        name: "privacy",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RichTextField, {
                                            placeholder: "اكتب ملخصاً شاملاً للدورة يتضمن الأهداف التعليمية والمخرجات المتوقعة..."
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                            lineNumber: 535,
                                            columnNumber: 23
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 531,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700",
                                            children: "مميزات الدورة"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                            lineNumber: 541,
                                            columnNumber: 30
                                        }, void 0),
                                        name: "benefits",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RichTextField, {
                                            placeholder: "اكتب مميزات الدورة ...."
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                            lineNumber: 544,
                                            columnNumber: 23
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 540,
                                        columnNumber: 23
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$divider$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Divider$3e$__["Divider"], {}, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 549,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                className: "text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$PlayCircleOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PlayCircleOutlined$3e$__["PlayCircleOutlined"], {
                                                        className: "text-blue-600"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                                        lineNumber: 553,
                                                        columnNumber: 25
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    "المحتوى التعليمي"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                                lineNumber: 552,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-gray-600 mb-4",
                                                children: "يمكنك إضافة المحتوى التعليمي التفصيلي (الدروس، الفيديوهات، الاختبارات) بعد إنشاء الدورة"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                                lineNumber: 556,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$TeacherCourses$2f$AddTeacherCourseContent$2f$AddTeacherCourseContent$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                courseId: null,
                                                onContentAdded: (content)=>console.log('Content added:', content)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                                lineNumber: 559,
                                                columnNumber: 23
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 551,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                lineNumber: 516,
                                columnNumber: 19
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 515,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0)),
                        activeTab === 4 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$TeacherCourses$2f$AddCourseResources$2f$AddCourseResources$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            setVideos: setVideos,
                            videos: videos
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 570,
                            columnNumber: 17
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between pt-8 border-t border-gray-200",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-3",
                                    children: activeTab > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                        size: "large",
                                        onClick: ()=>setActiveTab(activeTab - 1),
                                        className: "rounded-xl",
                                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "←"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                            lineNumber: 584,
                                            columnNumber: 29
                                        }, void 0),
                                        children: "السابق"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 580,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                    lineNumber: 578,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-3",
                                    children: activeTab < 4 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                        type: "primary",
                                        size: "large",
                                        onClick: ()=>setActiveTab(activeTab + 1),
                                        className: "rounded-xl",
                                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "→"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                            lineNumber: 598,
                                            columnNumber: 29
                                        }, void 0),
                                        children: "التالي"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 593,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                        type: "primary",
                                        size: "large",
                                        htmltype: "submit",
                                        loading: loading,
                                        className: "rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800",
                                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$PlusOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusOutlined$3e$__["PlusOutlined"], {}, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                            lineNumber: 609,
                                            columnNumber: 29
                                        }, void 0),
                                        children: "إنشاء الدورة"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                        lineNumber: 603,
                                        columnNumber: 21
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                                    lineNumber: 591,
                                    columnNumber: 17
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                            lineNumber: 577,
                            columnNumber: 15
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                    lineNumber: 466,
                    columnNumber: 13
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
                lineNumber: 465,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/app/(admin)/teachers-courses/add-course/page.jsx",
        lineNumber: 430,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = EnhancedCourseForm;
}),
"[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StudentAccountPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/user.js [app-ssr] (ecmascript) <export default as User>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/book-open.js [app-ssr] (ecmascript) <export default as BookOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/award.js [app-ssr] (ecmascript) <export default as Award>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/file-text.js [app-ssr] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/trophy.js [app-ssr] (ecmascript) <export default as Trophy>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/shield.js [app-ssr] (ecmascript) <export default as Shield>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/chart-column.js [app-ssr] (ecmascript) <export default as BarChart3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/users.js [app-ssr] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User2$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/user-round.js [app-ssr] (ecmascript) <export default as User2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/star.js [app-ssr] (ecmascript) <export default as Star>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$StudentProgressBar$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/ui/StudentProgressBar.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentCourses$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Students/StudentAccount/StudentCourses.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentBadges$2f$StudentsBadges$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Students/StudentAccount/StudentBadges/StudentsBadges.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentCertificates$2f$StudentCertificates$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Students/StudentAccount/StudentCertificates/StudentCertificates.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$BreadCrumbs$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentsPrivacy$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Students/StudentAccount/StudentsPrivacy.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Students/StudentAccount/StudentData.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentRating$2f$StudentRatings$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Students/StudentAccount/StudentRating/StudentRatings.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$TabButton$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/ui/TabButton.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentPayments$2f$StudentPayments$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Students/StudentAccount/StudentPayments/StudentPayments.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
// Mock PageLayout component (replace with your real layout)
const PageLayout = ({ children })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gray-50",
        children: children
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
        lineNumber: 32,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
function StudentAccountPage() {
    // Student data state
    const [student, setStudent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        firstName: "أحمد",
        middleName: "محمد",
        lastName: "علي",
        email: "ahmed@example.com",
        phone: "01234567890",
        alternativePhone: "",
        familyPhone: "01098765432",
        avatar: "",
        gender: "male",
        birthDate: "2010-05-15",
        joinDate: "2023-09-01",
        // Account verification
        emailVerified: true,
        phoneVerified: false,
        // Settings
        notifications: true,
        parentAccess: true
    });
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log(id);
    }, [
        id
    ]);
    const breadcrumbs = [
        {
            label: "الرئيسية",
            href: "/",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"]
        },
        {
            label: "المتدربين",
            href: "/students",
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"]
        },
        {
            label: "بيانات المتدرب",
            href: `/students/${id}`,
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User2$3e$__["User2"],
            current: true
        }
    ];
    // UI state
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("account");
    const [isEditing, setIsEditing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showPasswordForm, setShowPasswordForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [pendingPhone, setPendingPhone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [otpSent, setOtpSent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [otp, setOtp] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    // Courses data
    const [courses] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: 1,
            title: "أساسيات البرمجة للأطفال",
            instructor: "أ. سارة أحمد",
            status: "نشط",
            progress: 75,
            totalLessons: 20,
            completedLessons: 15,
            enrollDate: "2023-09-15",
            color: "emerald",
            nextLesson: "الدرس 16: المتغيرات المتقدمة",
            lastAccessed: "منذ يومين"
        },
        {
            id: 2,
            title: "اللغة الإنجليزية - المستوى الأول",
            instructor: "أ. مريم حسن",
            status: "متوقف",
            progress: 40,
            totalLessons: 25,
            completedLessons: 10,
            enrollDate: "2023-10-01",
            color: "amber",
            nextLesson: "الدرس 11: الأفعال الماضية",
            lastAccessed: "منذ أسبوع"
        },
        {
            id: 3,
            title: "الرياضيات الممتعة",
            instructor: "أ. خالد محمود",
            status: "مكتمل",
            progress: 100,
            totalLessons: 15,
            completedLessons: 15,
            enrollDate: "2023-08-01",
            completionDate: "2023-11-15",
            color: "blue",
            grade: "امتياز"
        }
    ]);
    // Badges
    const [badges] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: 1,
            name: "طالب متميز",
            description: "حصل على درجات عالية في جميع الاختبارات",
            courseTitle: "أساسيات البرمجة للأطفال",
            awardedDate: "2023-11-20",
            icon: "🏆",
            color: "from-yellow-400 to-orange-500",
            type: "تميز أكاديمي"
        },
        {
            id: 2,
            name: "مثابر الشهر",
            description: "التزام مستمر بحضور الدروس",
            courseTitle: "اللغة الإنجليزية",
            awardedDate: "2023-10-30",
            icon: "⭐",
            color: "from-blue-400 to-purple-500",
            type: "الالتزام والحضور"
        },
        {
            id: 3,
            name: "محل ثقة الأهل",
            description: "تقييم إيجابي من ولي الأمر",
            courseTitle: "عام",
            awardedDate: "2023-12-01",
            icon: "💙",
            color: "from-green-400 to-teal-500",
            type: "تقدير الأهل"
        }
    ]);
    // Certificates
    const [certificates] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: 1,
            title: "شهادة إتمام دورة الرياضيات الممتعة",
            courseTitle: "الرياضيات الممتعة",
            issueDate: "2023-11-15",
            grade: "امتياز",
            instructorName: "أ. خالد محمود",
            pdfUrl: "/certificates/math-cert.pdf",
            certificateId: "CERT-MATH-2023-001"
        },
        {
            id: 2,
            title: "شهادة تقدير للالتزام والحضور",
            courseTitle: "أساسيات البرمجة للأطفال",
            issueDate: "2023-10-30",
            grade: "جيد جداً",
            instructorName: "أ. سارة أحمد",
            pdfUrl: "/certificates/attendance-cert.pdf",
            certificateId: "CERT-ATT-2023-002"
        }
    ]);
    const [rating, setRating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            name: "مايكل",
            description: "الكورس منظم جدًا وشرح البرمجة للأطفال بسيط وممتع. بنتي بدأت تعمل مشاريع صغيرة!",
            rating: 4.8,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=سارة+محمود&background=02AAA0&color=fff&rounded=true&size=128",
            type: "teacher"
        },
        {
            name: "مايكل",
            description: "طريقة الميس في الإنجليزي حلوة وبتخلّيني أتكلّم بثقة. الواجبات ساعدتني أراجع.",
            rating: 4.6,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=أحمد+محمد&background=3B82F6&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "تفاعل المدرس ممتاز، في أسئلة مباشرة وأنشطة أثناء الدرس تخلي الأولاد مركزين.",
            rating: 4.7,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=محمود+عبدالله&background=10B981&color=fff&rounded=true&size=128",
            type: "teacher"
        },
        {
            name: "مايكل",
            description: "لوحة التحكم سهلة والمواد مرتبة، لكن أحيانًا الفيديو يتأخر في التحميل.",
            rating: 4.1,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=ندى+خالد&background=6366F1&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "الدعم الفني رد سريع وحل مشكلة تسجيل الدخول في نفس اليوم.",
            rating: 4.9,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=أمينة+أشرف&background=F59E0B&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "تمارين كثيرة ومتصاعدة الصعوبة؛ حسّنت مستواي في الحساب بشكل واضح.",
            rating: 4.5,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=كريم+علي&background=EF4444&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "المتابعة الفردية ممتازة، في ملاحظات خاصة بعد كل اختبار.",
            rating: 4.7,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=ميس+إيمان&background=14B8A6&color=fff&rounded=true&size=128",
            type: "teacher"
        },
        {
            name: "مايكل",
            description: "السعر مناسب مقارنة بالجودة، خاصة مع الشهادات المعتمدة في النهاية.",
            rating: 4.4,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=علاء+الدين&background=0EA5E9&color=fff&rounded=true&size=128",
            type: "teacher"
        },
        {
            name: "مايكل",
            description: "جدول الحصص منظم بس ساعات يبدأ متأخر 5 دقايق.",
            rating: 4.0,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=منى+حسن&background=8B5CF6&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "الدروس المسجّلة بجودة عالية وترجمة واضحة على الشاشة.",
            rating: 4.6,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=فاطمة+حسين&background=0F766E&color=fff&rounded=true&size=128",
            type: "teacher"
        },
        {
            name: "مايكل",
            description: "الاختبارات تقيس الفهم الحقيقي مش الحفظ، والتغذية الراجعة دقيقة.",
            rating: 4.8,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=مروان+رمزي&background=F97316&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "أنشطة تفاعلية حلوة جدًا، خصوصًا تحديات الكود الأسبوعية.",
            rating: 4.7,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=يوسف+سامي&background=22C55E&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "التواصل مع ولي الأمر محترم وواضح، بيبعتوا تقارير تقدم مفصلة.",
            rating: 4.9,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=وليد+مصطفى&background=EF4444&color=fff&rounded=true&size=128",
            type: "teacher"
        },
        {
            name: "مايكل",
            description: "الخصوصية والأمان ممتازين، حسابتنا محمية بخطوتين وتأكيد للهاتف.",
            rating: 4.8,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=ميسرة+أمين&background=1D4ED8&color=fff&rounded=true&size=128",
            type: "teacher"
        },
        {
            name: "مايكل",
            description: "شهادة الإنجاز شكلها احترافي وتفيد في التقديم للمسابقات.",
            rating: 4.6,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=مي+إسلام&background=3B82F6&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "في حصص دعم إضافية قبل الامتحان، فرقت معانا فعلًا.",
            rating: 4.7,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=ليلى+سيد&background=EA580C&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "مرة واحدة حصل تأجيل غير مُعلن مبكرًا، أتمنى إشعار أبكر.",
            rating: 3.6,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=حازم+جلال&background=64748B&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "المعلمون معتمدون ويستخدمون أمثلة من الحياة اليومية للأطفال.",
            rating: 4.9,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=ميس+نور&background=9333EA&color=fff&rounded=true&size=128",
            type: "teacher"
        },
        {
            name: "مايكل",
            description: "بدأت من صفر في البرمجة وبقيت أعرف أعمل لعبة بسيطة على Scratch.",
            rating: 4.8,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=رنا+محمود&background=16A34A&color=fff&rounded=true&size=128",
            type: "student"
        },
        {
            name: "مايكل",
            description: "القسم الإداري متعاون جدًا في الاستفسارات وطلبات الإجازات.",
            rating: 4.5,
            category: "مهارات التعليم والتدريس",
            image: "https://ui-avatars.com/api/?name=شيماء+طارق&background=DC2626&color=fff&rounded=true&size=128",
            type: "teacher"
        }
    ]);
    // File input ref for avatar
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Helpers
    const getAvatarUrl = ()=>{
        if (student.avatar) return student.avatar;
        return student.gender === "male" ? "https://ui-avatars.com/api/?name=Student&background=3B82F6&color=fff&rounded=true&size=200" : "https://ui-avatars.com/api/?name=Student&background=EC4899&color=fff&rounded=true&size=200";
    };
    const calculateOverallProgress = ()=>{
        const activeCourses = courses.filter((c)=>c.status === "نشط" || c.status === "مكتمل");
        if (activeCourses.length === 0) return 0;
        const totalProgress = activeCourses.reduce((sum, course)=>sum + course.progress, 0);
        return Math.round(totalProgress / activeCourses.length);
    };
    // Events
    const handleAvatarClick = ()=>fileInputRef.current?.click();
    const handleAvatarChange = (e)=>{
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev)=>setStudent((prev)=>({
                    ...prev,
                    avatar: ev.target.result
                }));
        reader.readAsDataURL(file);
    };
    const handleSaveAccount = (e)=>{
        e.preventDefault();
        setIsEditing(false);
        alert("تم حفظ بيانات الحساب بنجاح ✅");
    };
    const sendOtpForPhone = ()=>{
        if (!pendingPhone) {
            alert("من فضلك أدخل رقم الهاتف الجديد");
            return;
        }
        setOtpSent(true);
        alert("تم إرسال كود التحقق إلى الرقم الجديد");
    };
    const verifyPhoneOtp = ()=>{
        if (otp.length < 4) {
            alert("من فضلك أدخل كود التحقق");
            return;
        }
        setStudent((prev)=>({
                ...prev,
                phone: pendingPhone,
                phoneVerified: true
            }));
        setPendingPhone("");
        setOtp("");
        setOtpSent(false);
        alert("تم تأكيد رقم الهاتف بنجاح ✅");
    };
    // UI atoms
    const StatCard = ({ icon: Icon, title, value, subtitle, color })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-2xl p-6 border border-gray-100 hover:shadow-lg transition-all duration-300",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-600 text-sm font-medium",
                                children: title
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                                lineNumber: 455,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-2xl font-bold text-gray-800 mt-1",
                                children: value
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                                lineNumber: 456,
                                columnNumber: 11
                            }, this),
                            subtitle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-500 mt-1",
                                children: subtitle
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                                lineNumber: 457,
                                columnNumber: 24
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                        lineNumber: 454,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `p-3 rounded-2xl bg-gradient-to-br ${color}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                            size: 24,
                            className: "text-white"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 460,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                        lineNumber: 459,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                lineNumber: 453,
                columnNumber: 7
            }, this)
        }, void 0, false, {
            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
            lineNumber: 452,
            columnNumber: 5
        }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(PageLayout, {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            dir: "rtl",
            className: "p-6 min-h-screen",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$BreadCrumbs$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    items: breadcrumbs,
                    variant: "pill"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                    lineNumber: 470,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 md:grid-cols-4 gap-6 mb-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StatCard, {
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"],
                            title: "الدورات النشطة",
                            value: courses.filter((c)=>c.status === "نشط").length,
                            subtitle: "دورة جارية",
                            color: "from-blue-400 to-blue-600"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 474,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StatCard, {
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__["Trophy"],
                            title: "الدورات المكتملة",
                            value: courses.filter((c)=>c.status === "مكتمل").length,
                            subtitle: "بنجاح",
                            color: "from-green-400 to-green-600"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 481,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StatCard, {
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trophy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trophy$3e$__["Trophy"],
                            title: "مدفوعات الطالب",
                            value: "",
                            subtitle: "المدفوعات",
                            color: "from-green-400 to-green-600"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 488,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StatCard, {
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"],
                            title: "الشارات المحققة",
                            value: badges.length,
                            subtitle: "إنجاز متميز",
                            color: "from-amber-400 to-amber-600"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 495,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(StatCard, {
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"],
                            title: "الشهادات",
                            value: certificates.length,
                            subtitle: "شهادة معتمدة",
                            color: "from-purple-400 to-purple-600"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 502,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                    lineNumber: 473,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-wrap gap-3 mb-8 p-2 bg-white rounded-2xl border border-gray-200 shadow-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$TabButton$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            setActiveTab: setActiveTab,
                            activeTab: activeTab,
                            id: "account",
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__User$3e$__["User"],
                            children: "بيانات الحساب"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 513,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$TabButton$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            setActiveTab: setActiveTab,
                            activeTab: activeTab,
                            id: "security",
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Shield$3e$__["Shield"],
                            children: "الأمان والخصوصية"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 516,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$TabButton$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            setActiveTab: setActiveTab,
                            activeTab: activeTab,
                            id: "courses",
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"],
                            children: "دوراتي"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 519,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$TabButton$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            setActiveTab: setActiveTab,
                            activeTab: activeTab,
                            id: "payment",
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"],
                            children: "المدفوعات"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 522,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$TabButton$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            setActiveTab: setActiveTab,
                            activeTab: activeTab,
                            id: "badges",
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$award$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Award$3e$__["Award"],
                            children: "شاراتي"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 525,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$TabButton$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            setActiveTab: setActiveTab,
                            activeTab: activeTab,
                            id: "certificates",
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"],
                            children: "شهاداتي"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 528,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$TabButton$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            setActiveTab: setActiveTab,
                            activeTab: activeTab,
                            id: "rating",
                            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$star$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Star$3e$__["Star"],
                            children: "التقييمات"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                            lineNumber: 535,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                    lineNumber: 512,
                    columnNumber: 9
                }, this),
                activeTab === "account" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    id: id,
                    calculateOverallProgress: calculateOverallProgress,
                    fileInputRef: fileInputRef,
                    getAvatarUrl: getAvatarUrl,
                    handleAvatarChange: handleAvatarChange,
                    handleAvatarClick: handleAvatarClick,
                    handleSaveAccount: handleSaveAccount,
                    isEditing: isEditing,
                    otp: otp,
                    sendOtpForPhone: sendOtpForPhone,
                    otpSent: otpSent,
                    pendingPhone: pendingPhone,
                    setIsEditing: setIsEditing,
                    setOtp: setOtp,
                    setPendingPhone: setPendingPhone,
                    setStudent: setStudent,
                    student: student,
                    verifyPhoneOtp: verifyPhoneOtp
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                    lineNumber: 540,
                    columnNumber: 11
                }, this),
                activeTab === "security" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentsPrivacy$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                    lineNumber: 546,
                    columnNumber: 38
                }, this),
                activeTab === "courses" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentCourses$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    id: id,
                    courses: courses,
                    calculateOverallProgress: calculateOverallProgress
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                    lineNumber: 550,
                    columnNumber: 11
                }, this),
                activeTab === "badges" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentBadges$2f$StudentsBadges$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    student_id: id
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                    lineNumber: 558,
                    columnNumber: 36
                }, this),
                activeTab === "certificates" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentCertificates$2f$StudentCertificates$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    student_id: id
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                    lineNumber: 561,
                    columnNumber: 42
                }, this),
                activeTab === "rating" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentRating$2f$StudentRatings$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    data: rating
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                    lineNumber: 564,
                    columnNumber: 36
                }, this),
                activeTab === "payment" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Students$2f$StudentAccount$2f$StudentPayments$2f$StudentPayments$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
                    lineNumber: 565,
                    columnNumber: 37
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
            lineNumber: 468,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/app/(admin)/students/[id]/page.jsx",
        lineNumber: 467,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=Desktop_nartaqi_app_%28admin%29_29864ef7._.js.map