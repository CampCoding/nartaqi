module.exports = [
"[project]/Desktop/nartaqi/components/layout/PageLayout.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
const PageLayout = ({ children })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-[#F9FAFC] p-6",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto",
            children: children
        }, void 0, false, {
            fileName: "[project]/Desktop/nartaqi/components/layout/PageLayout.jsx",
            lineNumber: 6,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/layout/PageLayout.jsx",
        lineNumber: 5,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = PageLayout;
}),
"[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/chevron-left.js [app-ssr] (ecmascript) <export default as ChevronLeft>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
const BreadcrumbsShowcase = ({ items, variant = "default", className = "" })=>{
    const BreadcrumbItem = ({ item, isLast, variant = "default" })=>{
        const IconComponent = item.icon;
        const getItemStyles = ()=>{
            switch(variant){
                case "modern":
                    return {
                        link: `inline-flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 hover:shadow-md ${item.current ? "text-white shadow-lg" : "hover:scale-105"}`,
                        linkStyle: item.current ? {
                            backgroundColor: "#0F7490"
                        } : {
                            color: "#202938"
                        },
                        hoverStyle: !item.current ? {
                            backgroundColor: "rgba(15, 116, 144, 0.05)",
                            color: "#0F7490"
                        } : {}
                    };
                case "pill":
                    return {
                        link: `inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${item.current ? "text-white shadow-lg transform scale-105" : "hover:scale-105 border border-opacity-20"}`,
                        linkStyle: item.current ? {
                            backgroundColor: "#0F7490"
                        } : {
                            color: "#202938",
                            borderColor: "#0F7490"
                        },
                        hoverStyle: !item.current ? {
                            backgroundColor: "#0F749040",
                            color: "#0F7490",
                            borderColor: "#0F7490"
                        } : {}
                    };
                case "minimal":
                    return {
                        link: `inline-flex items-center text-sm font-medium transition-all duration-200 pb-1 border-b-2 border-transparent ${item.current ? "" : "hover:border-opacity-50"}`,
                        linkStyle: item.current ? {
                            color: "#C9AE6C",
                            borderBottomColor: "#C9AE6C"
                        } : {
                            color: "#202938"
                        },
                        hoverStyle: !item.current ? {
                            color: "#0F7490",
                            borderBottomColor: "#0F7490"
                        } : {}
                    };
                default:
                    return {
                        link: `inline-flex items-center text-sm font-medium transition-colors duration-200 ${item.current ? "" : "hover:underline"}`,
                        linkStyle: item.current ? {
                            color: "#0F7490"
                        } : {
                            color: "#6B7280"
                        },
                        hoverStyle: !item.current ? {
                            color: "#0F7490"
                        } : {}
                    };
            }
        };
        const styles = getItemStyles();
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
            className: "flex items-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    href: item.href,
                    className: styles.link,
                    style: styles.linkStyle,
                    onMouseEnter: (e)=>{
                        if (!item.current && styles.hoverStyle) {
                            Object.assign(e.target.style, styles.hoverStyle);
                        }
                    },
                    onMouseLeave: (e)=>{
                        if (!item.current) {
                            Object.assign(e.target.style, styles.linkStyle);
                        }
                    },
                    children: [
                        IconComponent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(IconComponent, {
                            className: "w-4 h-4 mr-2 flex-shrink-0"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx",
                            lineNumber: 98,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "truncate",
                            children: item.label
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx",
                            lineNumber: 100,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx",
                    lineNumber: 82,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                !isLast && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$left$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronLeft$3e$__["ChevronLeft"], {
                    className: "w-4 h-4 mx-2 text-gray-400 flex-shrink-0"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx",
                    lineNumber: 104,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx",
            lineNumber: 81,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    };
    const Breadcrumb = ({ items, variant = "default", className = "" })=>{
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
            className: `flex ${className} pb-10`,
            "aria-label": "Breadcrumb",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                className: "inline-flex items-center gap-1 md:gap-3 flex-wrap",
                children: items.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(BreadcrumbItem, {
                        item: item,
                        isLast: index === items.length - 1,
                        variant: variant
                    }, index, false, {
                        fileName: "[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx",
                        lineNumber: 115,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx",
                lineNumber: 113,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx",
            lineNumber: 112,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Breadcrumb, {
        items: items,
        variant: variant,
        className: className
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx",
        lineNumber: 127,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = BreadcrumbsShowcase;
}),
"[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
const PagesHeader = ({ title, subtitle, extra })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center justify-between mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-4xl font-bold text-[#202938] mb-2",
                        children: title ?? "Subjects Management"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx",
                        lineNumber: 7,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[#202938]/60 text-lg",
                        children: subtitle ?? "Organize and manage your teaching subjects"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx",
                        lineNumber: 10,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx",
                lineNumber: 6,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            extra
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx",
        lineNumber: 5,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = PagesHeader;
}),
"[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>QuestionStats
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/book-open.js [app-ssr] (ecmascript) <export default as BookOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/clock.js [app-ssr] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/file-text.js [app-ssr] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/users.js [app-ssr] (ecmascript) <export default as Users>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
;
function QuestionStats({ examData, getEstimatedDuration, getTotalQuestions }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-1 md:grid-cols-4 gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white p-4 rounded-xl border border-gray-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-2 bg-blue-100 rounded-lg",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"], {
                                className: "h-5 w-5 text-blue-600"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                lineNumber: 10,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                            lineNumber: 9,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600",
                                    children: "إجمالي الأسئلة"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                    lineNumber: 13,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xl font-bold text-gray-900",
                                    children: getTotalQuestions()
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                    lineNumber: 14,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                            lineNumber: 12,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                    lineNumber: 8,
                    columnNumber: 15
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                lineNumber: 7,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white p-4 rounded-xl border border-gray-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-2 bg-green-100 rounded-lg",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
                                className: "h-5 w-5 text-green-600"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                lineNumber: 22,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                            lineNumber: 21,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600",
                                    children: "الأقسام"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                    lineNumber: 25,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xl font-bold text-gray-900",
                                    children: examData?.sections?.length
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                    lineNumber: 26,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                            lineNumber: 24,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                    lineNumber: 20,
                    columnNumber: 15
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                lineNumber: 19,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white p-4 rounded-xl border border-gray-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-2 bg-purple-100 rounded-lg",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"], {
                                className: "h-5 w-5 text-purple-600"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                lineNumber: 34,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                            lineNumber: 33,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600",
                                    children: "المدة (دقيقة)"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                    lineNumber: 37,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xl font-bold text-gray-900",
                                    children: getEstimatedDuration()
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                    lineNumber: 38,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                            lineNumber: 36,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                    lineNumber: 32,
                    columnNumber: 15
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                lineNumber: 31,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white p-4 rounded-xl border border-gray-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-2 bg-orange-100 rounded-lg",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$users$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Users$3e$__["Users"], {
                                className: "h-5 w-5 text-orange-600"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                lineNumber: 46,
                                columnNumber: 19
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                            lineNumber: 45,
                            columnNumber: 17
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-gray-600",
                                    children: "نوع الاختبار"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                    lineNumber: 49,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xl font-bold text-gray-900",
                                    children: examData?.type === "intern" ? "تدريب" : examData?.type === "mock" ? "محاكي" : "-"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                                    lineNumber: 50,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                            lineNumber: 48,
                            columnNumber: 17
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                    lineNumber: 44,
                    columnNumber: 15
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
                lineNumber: 43,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx",
        lineNumber: 6,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
const Card = ({ title, children, className = "", icon: Icon, actions })=>{
    const renderIcon = ()=>{
        if (!Icon) return null;
        // إذا كانت Icon كمبوننت React:
        if (/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].isValidElement(Icon)) {
            return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].cloneElement(Icon, {
                className: "h-5 w-5 text-gray-600"
            });
        }
        // إذا كانت Icon عنصر JSX
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
            className: "h-5 w-5 text-gray-600"
        }, void 0, false, {
            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx",
            lineNumber: 15,
            columnNumber: 12
        }, ("TURBOPACK compile-time value", void 0));
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden ${className}`,
        children: [
            title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-6 py-4 bg-gradient-to-r from-gray-50 to-white border-b border-gray-100",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-3",
                            children: [
                                renderIcon(),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-lg font-semibold text-gray-900",
                                    children: title
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx",
                                    lineNumber: 25,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx",
                            lineNumber: 23,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        actions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2",
                            children: actions
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx",
                            lineNumber: 27,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx",
                    lineNumber: 22,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx",
                lineNumber: 21,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-6",
                children: children
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx",
                lineNumber: 31,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx",
        lineNumber: 19,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Card;
}),
"[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/circle-alert.js [app-ssr] (ecmascript) <export default as AlertCircle>");
;
;
const Input = ({ label, error, icon: Icon, className = "", ...props })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-2",
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "block text-sm font-medium text-gray-700",
                children: label
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx",
                lineNumber: 6,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    Icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-y-0 left-3 flex items-center pointer-events-none",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                            className: "h-4 w-4 text-gray-400"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx",
                            lineNumber: 11,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx",
                        lineNumber: 10,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        className: `w-full px-3 py-3 ${Icon ? "pl-10" : ""} border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all duration-200 ${error ? "border-red-300 focus:border-red-500 focus:ring-red-500/20" : ""} ${className}`,
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx",
                        lineNumber: 14,
                        columnNumber: 7
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx",
                lineNumber: 8,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-red-600 flex items-center gap-1",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__AlertCircle$3e$__["AlertCircle"], {
                        className: "h-4 w-4"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    error
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx",
                lineNumber: 26,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx",
        lineNumber: 4,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const __TURBOPACK__default__export__ = Input;
}),
"[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ExamMainInfo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamInput$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/file-text.js [app-ssr] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamCard$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
function ExamMainInfo({ lessonId = null, examData, setExamData, examInfoData, handleBasicDataChange, handleExamTypeChange, handleSubmitBasicData, exam_types, add_exam_loading, edit_exam_loading }) {
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const { all_exam_list } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExams"])({}));
    }, [
        dispatch
    ]);
    const currentDate = new Date().toISOString().split("T")[0];
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamCard$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        title: "معلومات الاختبار الأساسية",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"],
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 md:grid-cols-2 gap-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamInput$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                label: "اسم الاختبار",
                                placeholder: "أدخل اسم الاختبار",
                                value: examInfoData?.title || "",
                                onChange: (e)=>handleBasicDataChange("title", e.target.value)
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                lineNumber: 39,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamInput$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                label: "الوصف",
                                placeholder: "أدخل وصف الاختبار",
                                value: examInfoData?.description || "",
                                onChange: (e)=>handleBasicDataChange("description", e.target.value),
                                multiline: true
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                lineNumber: 45,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamInput$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                min: currentDate,
                                required: true,
                                label: "التاريخ",
                                type: "date",
                                placeholder: "",
                                value: examInfoData?.date || "",
                                onChange: (e)=>handleBasicDataChange("date", e.target.value)
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                lineNumber: 64,
                                columnNumber: 12
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-gray-700",
                                        children: "المستوي"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                        lineNumber: 75,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                        value: examInfoData?.level || "0",
                                        onChange: (e)=>handleBasicDataChange("level", e.target.value),
                                        className: "w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "normal",
                                                children: "سهل"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                                lineNumber: 81,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "medium",
                                                children: "متوسط"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                                lineNumber: 82,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: "hard",
                                                children: "صعب"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                                lineNumber: 83,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                        lineNumber: 76,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                lineNumber: 74,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                        lineNumber: 38,
                        columnNumber: 9
                    }, this),
                    !lessonId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-gray-700 mb-4",
                                children: "نوع الاختبار"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                lineNumber: 89,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-1 md:grid-cols-2 gap-4",
                                children: exam_types?.map((type)=>{
                                    const isSelected = examInfoData?.type == type.value;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>handleExamTypeChange(type),
                                        className: `p-6 rounded-xl border-2 transition-all duration-200 text-right hover:scale-[1.02] ${isSelected ? "bg-blue-600 !text-white" : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"}`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: `p-3 rounded-lg ${isSelected ? "bg-blue-500" : "bg-gray-100 text-blue-500"}`,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(type.icon, {
                                                        className: "h-6 w-6 text-white"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                                        lineNumber: 108,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                                    lineNumber: 105,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1 text-right",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            className: isSelected ? "font-semibold text-white mb-2" : "font-semibold text-gray-900 mb-2",
                                                            children: type.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                                            lineNumber: 111,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: isSelected ? "text-sm text-white" : "text-sm text-gray-600",
                                                            children: type.description
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                                            lineNumber: 112,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                                    lineNumber: 110,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                            lineNumber: 104,
                                            columnNumber: 19
                                        }, this)
                                    }, type.id, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                        lineNumber: 96,
                                        columnNumber: 19
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                                lineNumber: 90,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                        lineNumber: 88,
                        columnNumber: 23
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamInput$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            label: "نسبة النجاح",
                            placeholder: "",
                            type: "number",
                            onWheel: (e)=>e.target.blur(),
                            name: "success_percentage",
                            value: examInfoData?.success_percentage || "",
                            onChange: (e)=>handleBasicDataChange("success_percentage", e.target.value)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                            lineNumber: 131,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                        lineNumber: 121,
                        columnNumber: 10
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                lineNumber: 37,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: "bg-blue-500 text-white p-3 rounded-md mt-3",
                onClick: handleSubmitBasicData,
                children: add_exam_loading || edit_exam_loading ? "جاري الاضافة...." : params["exam-id"] ? "تعديل" : "إضافة"
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
                lineNumber: 144,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>QuestionSections
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/book-open.js [app-ssr] (ecmascript) <export default as BookOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/square-pen.js [app-ssr] (ecmascript) <export default as Edit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-ssr] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamCard$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/shared/lib/app-dynamic.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
;
"use client";
;
;
;
;
;
;
;
;
;
;
// SSR-safe import
const ReactQuill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(async ()=>{}, {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/nartaqi/node_modules/react-quill-new/lib/index.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
// Quill toolbar config
const quillModules = {
    toolbar: [
        [
            {
                header: [
                    1,
                    2,
                    3,
                    false
                ]
            }
        ],
        [
            "bold",
            "italic",
            "underline",
            "strike"
        ],
        [
            {
                script: "sub"
            },
            {
                script: "super"
            }
        ],
        [
            {
                list: "ordered"
            },
            {
                list: "bullet"
            }
        ],
        [
            {
                align: [
                    "",
                    "center",
                    "right",
                    "justify"
                ]
            }
        ],
        [
            {
                color: []
            },
            {
                background: []
            }
        ],
        [
            "link",
            "clean"
        ]
    ]
};
const quillFormats = [
    "header",
    "bold",
    "italic",
    "underline",
    "strike",
    "script",
    "list",
    "bullet",
    "align",
    "direction",
    "color",
    "background",
    "link"
];
function QuestionSections({ examData, filteredSection, onAddSection, onUpdateSection, onDeleteSection, sections = [], data }) {
    const [nameHtml, setNameHtml] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [descHtml, setDescHtml] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [editingSection, setEditingSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isEditing, setIsEditing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [localSections, setLocalSections] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    // delete modal state
    const [isDeleteModalOpen, setIsDeleteModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [sectionToDelete, setSectionToDelete] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const { add_exam_section_loading, update_exam_section_loading, delete_exam_section_loading, all_exam_list, get_exam_sections_loading, get_exam_sections_list } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam);
    const { time, setTime } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"])();
    // Load sections when component mounts or when params change
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log(data);
        if (params["exam-id"] || data) {
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamSections"])({
                body: {
                    exam_id: params["exam-id"] || data?.sections?.exam_id
                }
            }));
        }
    }, [
        params,
        dispatch,
        data
    ]);
    // Update local sections when API data changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (get_exam_sections_list?.data?.message) {
            setLocalSections(get_exam_sections_list.data.message);
        } else if (sections.length > 0) {
            setLocalSections(sections);
        }
    }, [
        get_exam_sections_list,
        sections
    ]);
    // Reset form
    const resetEditors = ()=>{
        setNameHtml("");
        setDescHtml("");
        setEditingSection(null);
        setIsEditing(false);
    };
    // Set up editing mode
    const startEditing = (section)=>{
        setEditingSection(section);
        setNameHtml(section.title || "");
        setDescHtml(section.description || "");
        setIsEditing(true);
    };
    // Cancel editing
    const cancelEditing = ()=>{
        resetEditors();
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log(isEditing, editingSection);
    }, [
        isEditing,
        editingSection
    ]);
    // Add or Update section
    const handleSaveSection = ()=>{
        const trimmedName = nameHtml?.replace(/<p>|<\/p>/g, "")?.trim();
        if (!trimmedName) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].warn("اسم القسم مطلوب");
            return;
        }
        // If we're editing an existing section
        if (isEditing && editingSection) {
            const updatedSection = {
                ...editingSection,
                title: nameHtml,
                description: descHtml,
                time_if_free: null
            };
            if (params["exam-id"]) {
                // Update via API for existing exam
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleEditExamSection"])({
                    body: updatedSection
                })).unwrap().then((res)=>{
                    if (res?.data?.status === "success") {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم تحديث القسم بنجاح");
                        if (onUpdateSection) {
                            onUpdateSection(updatedSection);
                        }
                        resetEditors();
                        // Refresh sections list
                        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamSections"])({
                            body: {
                                exam_id: params["exam-id"]
                            }
                        }));
                    } else {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("فشل في تحديث القسم");
                    }
                }).catch((error)=>{
                    console.error("Error updating section:", error);
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء تحديث القسم");
                });
            } else {
                // Update locally for new exam
                if (onUpdateSection) {
                    onUpdateSection(updatedSection);
                }
                resetEditors();
            }
        } else {
            if (params["exam-id"]) {
                // Create via API for existing exam
                const newSection = {
                    exam_id: params["exam-id"],
                    title: nameHtml,
                    description: descHtml,
                    time_if_free: null
                };
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleCreateExamSection"])({
                    body: newSection
                })).unwrap().then((res)=>{
                    if (res?.data?.status === "success") {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم إضافة القسم بنجاح");
                        if (onAddSection) {
                            onAddSection(res?.data?.message);
                        }
                        resetEditors();
                        // Refresh sections list
                        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamSections"])({
                            body: {
                                exam_id: params["exam-id"]
                            }
                        }));
                    } else {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("فشل في إضافة القسم");
                    }
                }).catch((error)=>{
                    console.error("Error creating section:", error);
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء إضافة القسم");
                });
            } else {
                // Create locally for new exam
                const newSection = {
                    id: Date.now(),
                    exam_id: data?.id,
                    title: nameHtml,
                    description: descHtml,
                    time_if_free: null,
                    questions: []
                };
                if (onAddSection) {
                    onAddSection(newSection);
                }
                resetEditors();
            }
        }
    };
    // Open delete modal
    const openDeleteModal = (section)=>{
        setSectionToDelete(section);
        setIsDeleteModalOpen(true);
    };
    // Close delete modal
    const closeDeleteModal = ()=>{
        setSectionToDelete(null);
        setIsDeleteModalOpen(false);
    };
    // Confirm delete from modal
    const confirmDeleteSection = ()=>{
        console.log(sectionToDelete);
        if (!sectionToDelete) return;
        const sectionId = sectionToDelete?.id;
        const examId = sectionToDelete?.exam_id || params["exam-id"] || params.examId || data?.sections?.exam_id || data?.id;
        if (examId && sectionId) {
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleDeleteExamSection"])({
                body: {
                    id: sectionId
                }
            })).unwrap().then((res)=>{
                if (res?.data?.status === "success") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم حذف القسم بنجاح");
                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamSections"])({
                        body: {
                            exam_id: examId
                        }
                    })); // ✅ refresh
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("فشل في حذف القسم");
                }
            }).catch((error)=>{
                console.error("Error deleting section:", error);
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء حذف القسم");
            }).finally(()=>{
                closeDeleteModal();
            });
        } else {
            // local-only delete
            removeLocally();
            closeDeleteModal();
        }
    };
    // Get the appropriate button text
    const getButtonText = ()=>{
        if (add_exam_section_loading || update_exam_section_loading) {
            return "جاري الحفظ...";
        }
        if (isEditing) {
            return "تحديث القسم";
        }
        return "إضافة قسم جديد";
    };
    if (!examData?.type) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamCard$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        title: "إدارة الأقسام",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"],
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-6",
            dir: "rtl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded-2xl border border-gray-200 bg-white p-4 shadow-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "font-semibold text-gray-900",
                                    children: isEditing ? "تعديل القسم" : "إنشاء قسم مخصص"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                    lineNumber: 297,
                                    columnNumber: 13
                                }, this),
                                isEditing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs text-blue-600 font-medium",
                                    children: [
                                        "وضع التعديل -",
                                        " ",
                                        editingSection?.title ? editingSection.title.replace(/<[^>]*>/g, "").substring(0, 20) + "..." : ""
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                    lineNumber: 301,
                                    columnNumber: 15
                                }, this),
                                examData?.type === "mock" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-xs text-gray-500",
                                    children: "للمحاكاة: أضِف أسئلة لاحقًا للوصول إلى 24 سؤالًا كحد أدنى"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                    lineNumber: 310,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                            lineNumber: 296,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-3 space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "block text-xs font-semibold text-gray-600",
                                            children: "اسم القسم"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                            lineNumber: 319,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-white rounded-xl border border-gray-200",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactQuill, {
                                                theme: "snow",
                                                value: nameHtml,
                                                onChange: setNameHtml,
                                                modules: quillModules,
                                                formats: quillFormats,
                                                placeholder: "اكتب اسم القسم..."
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                lineNumber: 323,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                            lineNumber: 322,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                    lineNumber: 318,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "block text-xs font-semibold text-gray-600",
                                            children: "وصف القسم"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                            lineNumber: 336,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-white rounded-xl border border-gray-200",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactQuill, {
                                                theme: "snow",
                                                value: descHtml,
                                                onChange: setDescHtml,
                                                modules: quillModules,
                                                formats: quillFormats,
                                                placeholder: "اكتب وصفًا مختصرًا للقسم..."
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                lineNumber: 340,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                            lineNumber: 339,
                                            columnNumber: 15
                                        }, this),
                                        data?.free == 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex flex-col gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "text-gray-500 text-lg",
                                                    children: "الوقت"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                    lineNumber: 351,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "time",
                                                    onChange: (e)=>setTime(e?.target?.value),
                                                    value: time,
                                                    className: "w-full border border-gray-300 p-2 rounded-md"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                    lineNumber: 352,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                            lineNumber: 350,
                                            columnNumber: 34
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                    lineNumber: 335,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-3 justify-end",
                                    children: [
                                        isEditing && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: cancelEditing,
                                            className: "px-3 py-2 rounded-lg border text-sm text-gray-700 hover:bg-gray-50 transition-colors",
                                            type: "button",
                                            disabled: add_exam_section_loading || update_exam_section_loading,
                                            children: "إلغاء التعديل"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                            lineNumber: 359,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: resetEditors,
                                            className: "px-3 py-2 rounded-lg border text-sm text-gray-700 hover:bg-gray-50 transition-colors",
                                            type: "button",
                                            disabled: add_exam_section_loading || update_exam_section_loading,
                                            children: "مسح"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                            lineNumber: 370,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: handleSaveSection,
                                            className: "px-3 py-2 rounded-lg bg-blue-600 text-white text-sm hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors",
                                            type: "button",
                                            disabled: !nameHtml?.replace(/<p>|<\/p>/g, "")?.trim() || add_exam_section_loading || update_exam_section_loading,
                                            title: !nameHtml?.replace(/<p>|<\/p>/g, "")?.trim() ? "اسم القسم مطلوب" : undefined,
                                            children: getButtonText()
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                            lineNumber: 380,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                    lineNumber: 357,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                            lineNumber: 316,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                    lineNumber: 295,
                    columnNumber: 9
                }, this),
                localSections && localSections.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded-2xl border border-gray-200 bg-white p-4 shadow-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "font-semibold text-gray-900 mb-4",
                            children: "الأقسام المضافة"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                            lineNumber: 404,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-3",
                            children: get_exam_sections_loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-center py-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                        lineNumber: 410,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-sm text-gray-500 mt-2",
                                        children: "جاري تحميل الأقسام..."
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                        lineNumber: 411,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                lineNumber: 409,
                                columnNumber: 17
                            }, this) : localSections.map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between p-3 border border-gray-100 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                    className: "font-medium text-gray-800",
                                                    dangerouslySetInnerHTML: {
                                                        __html: section.title
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                    lineNumber: 422,
                                                    columnNumber: 23
                                                }, this),
                                                section.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm text-gray-600 mt-1",
                                                    dangerouslySetInnerHTML: {
                                                        __html: section.description
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                    lineNumber: 427,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "text-xs text-gray-500 mt-1",
                                                    children: [
                                                        "عدد الأسئلة: ",
                                                        section.mcq?.length || 0
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                    lineNumber: 434,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                            lineNumber: 421,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>startEditing(section),
                                                    className: "p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors",
                                                    title: "تعديل القسم",
                                                    disabled: add_exam_section_loading || update_exam_section_loading,
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__["Edit"], {
                                                        className: "w-4 h-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                        lineNumber: 448,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                    lineNumber: 439,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>openDeleteModal(section),
                                                    className: "p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors",
                                                    disabled: delete_exam_section_loading,
                                                    title: "حذف القسم",
                                                    children: delete_exam_section_loading ? "loading..." : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                        className: "w-4 h-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                        lineNumber: 457,
                                                        columnNumber: 70
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                    lineNumber: 450,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                            lineNumber: 438,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, section.id, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                    lineNumber: 417,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                            lineNumber: 407,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                    lineNumber: 403,
                    columnNumber: 11
                }, this),
                (!localSections || localSections.length === 0) && !get_exam_sections_loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "rounded-2xl border border-gray-200 bg-white p-8 text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
                            className: "w-12 h-12 text-gray-300 mx-auto mb-3"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                            lineNumber: 471,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "font-medium text-gray-700 mb-2",
                            children: "لا توجد أقسام مضافة"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                            lineNumber: 472,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-gray-500",
                            children: "ابدأ بإضافة قسم جديد لتنظيم أسئلة الاختبار"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                            lineNumber: 475,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                    lineNumber: 470,
                    columnNumber: 13
                }, this),
                isDeleteModalOpen && sectionToDelete && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "fixed inset-0 !z-[999999] flex items-center justify-center bg-black/40",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-white rounded-2xl shadow-xl max-w-md w-full mx-4 p-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-semibold text-gray-900 mb-2",
                                children: "تأكيد حذف القسم"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                lineNumber: 485,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-gray-600 mb-4",
                                children: "هل أنت متأكد أنك تريد حذف هذا القسم؟ سيتم حذف القسم وكل الأسئلة المرتبطة به."
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                lineNumber: 488,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-gray-50 border border-gray-100 rounded-xl p-3 mb-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm font-medium text-gray-800",
                                        dangerouslySetInnerHTML: {
                                            __html: sectionToDelete.title
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                        lineNumber: 493,
                                        columnNumber: 17
                                    }, this),
                                    sectionToDelete.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-xs text-gray-600 mt-1",
                                        dangerouslySetInnerHTML: {
                                            __html: sectionToDelete.description
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                        lineNumber: 498,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                lineNumber: 492,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-end gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: closeDeleteModal,
                                        className: "px-3 py-2 rounded-lg border text-sm text-gray-700 hover:bg-gray-50 transition-colors",
                                        disabled: delete_exam_section_loading,
                                        children: "إلغاء"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                        lineNumber: 507,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: confirmDeleteSection,
                                        className: "px-3 py-2 rounded-lg bg-red-600 text-white text-sm hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors inline-flex items-center gap-1",
                                        disabled: delete_exam_section_loading,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                className: "w-4 h-4"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                                lineNumber: 521,
                                                columnNumber: 19
                                            }, this),
                                            "حذف نهائي"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                        lineNumber: 515,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                                lineNumber: 506,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                        lineNumber: 484,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
                    lineNumber: 483,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
            lineNumber: 293,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx",
        lineNumber: 292,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/atoms/Button.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const Button = ({ children, type = "default", size = "default", className = "", onClick, disabled = false, loading = false, icon, ...props })=>{
    const baseClasses = "inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";
    const sizeClasses = {
        small: "px-3 py-1.5 text-sm",
        default: "px-4 py-2 text-sm",
        large: "px-6 py-3 text-base"
    };
    const typeClasses = {
        primary: "bg-[#0F7490] hover:bg-[#0F7490]/90 text-white focus:ring-[#0F7490]/50 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5",
        secondary: "bg-[#C9AE6C] hover:bg-[#C9AE6C]/90 text-white focus:ring-[#C9AE6C]/50",
        accent: "bg-[#8B5CF6] hover:bg-[#8B5CF6]/90 text-white focus:ring-[#8B5CF6]/50",
        default: "bg-white hover:bg-gray-50 text-[#202938] border border-gray-200 focus:ring-gray-200",
        text: "bg-transparent hover:bg-gray-100 text-[#202938] focus:ring-gray-200",
        danger: "bg-red-500 hover:bg-red-600 text-white focus:ring-red-200"
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: `${baseClasses} ${sizeClasses[size]} ${typeClasses[type]} ${className}`,
        onClick: onClick,
        disabled: disabled,
        ...props,
        children: [
            icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: children && "ml-2",
                children: icon
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/atoms/Button.jsx",
                lineNumber: 39,
                columnNumber: 16
            }, ("TURBOPACK compile-time value", void 0)),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/atoms/Button.jsx",
        lineNumber: 33,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Button;
}),
"[project]/Desktop/nartaqi/utils/quillConfig.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// utils/quillConfig.js
__turbopack_context__.s([
    "useQuillConfig",
    ()=>useQuillConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
function useQuillConfig({ allowImages = true, onImageRequest } = {}) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const toolbar = [
            [
                {
                    header: [
                        1,
                        2,
                        3,
                        false
                    ]
                }
            ],
            [
                "bold",
                "italic",
                "underline",
                "strike"
            ],
            [
                {
                    script: "sub"
                },
                {
                    script: "super"
                }
            ],
            [
                {
                    list: "ordered"
                },
                {
                    list: "bullet"
                }
            ],
            [
                {
                    direction: "rtl"
                },
                {
                    align: []
                }
            ],
            [
                {
                    color: []
                },
                {
                    background: []
                }
            ],
            [
                "link",
                ...allowImages ? [
                    "image"
                ] : [],
                "clean"
            ]
        ];
        const modules = allowImages && onImageRequest ? {
            toolbar: {
                container: toolbar,
                handlers: {
                    image: onImageRequest
                }
            },
            clipboard: {
                matchVisual: false
            }
        } : {
            toolbar,
            clipboard: {
                matchVisual: false
            }
        };
        const formats = [
            "header",
            "bold",
            "italic",
            "underline",
            "strike",
            "script",
            "list",
            "bullet",
            "direction",
            "align",
            "color",
            "background",
            "link",
            ...allowImages ? [
                "image"
            ] : []
        ];
        return {
            modules,
            formats
        };
    }, [
        allowImages,
        onImageRequest
    ]);
}
}),
"[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TrueFalseQuestions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/shared/lib/app-dynamic.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/atoms/Button.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/check.js [app-ssr] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eraser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eraser$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/eraser.js [app-ssr] (ecmascript) <export default as Eraser>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/image.js [app-ssr] (ecmascript) <export default as Image>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$utils$2f$quillConfig$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/utils/quillConfig.jsx [app-ssr] (ecmascript)");
;
"use client";
;
;
;
;
;
;
;
// SSR-safe
const ReactQuill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(async ()=>{}, {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/nartaqi/node_modules/react-quill-new/lib/index.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
const FIXED_IMG = {
    width: 320,
    height: 200,
    objectFit: "contain"
};
const LabeledQuill = ({ label, value, onChange, placeholder = "اكتب هنا…", minH = 120, className = "", uploadImage, imageSize = FIXED_IMG })=>{
    const quillRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const openPicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>fileInputRef.current?.click(), []);
    const { modules, formats } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$utils$2f$quillConfig$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuillConfig"])({
        allowImages: true,
        onImageRequest: openPicker
    });
    const applyFixedSizeToAllImages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        const q = quillRef.current?.getEditor?.();
        const root = q?.root;
        if (!root) return;
        root.querySelectorAll("img").forEach((img)=>{
            img.style.width = `${imageSize.width}px`;
            img.style.height = `${imageSize.height}px`;
            img.style.objectFit = imageSize.objectFit || "contain";
            img.style.display = "inline-block";
        });
    }, [
        imageSize.height,
        imageSize.objectFit,
        imageSize.width
    ]);
    const fileToDataUrl = (file)=>new Promise((resolve, reject)=>{
            const r = new FileReader();
            r.onload = ()=>resolve(String(r.result || ""));
            r.onerror = reject;
            r.readAsDataURL(file);
        });
    const handleFiles = async (e)=>{
        const file = e.target.files?.[0];
        if (!file) return;
        const url = await (uploadImage ? uploadImage(file) : fileToDataUrl(file)) || "";
        const editor = quillRef.current?.getEditor?.();
        if (!editor || !url) return;
        const range = editor.getSelection(true) || {
            index: editor.getLength(),
            length: 0
        };
        editor.insertEmbed(range.index, "image", url, "user");
        editor.setSelection(range.index + 1, 0);
        requestAnimationFrame(applyFixedSizeToAllImages);
        e.target.value = "";
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const q = quillRef.current?.getEditor?.();
        if (!q) return;
        const h = ()=>requestAnimationFrame(applyFixedSizeToAllImages);
        q.on("text-change", h);
        requestAnimationFrame(applyFixedSizeToAllImages);
        return ()=>q.off("text-change", h);
    }, [
        applyFixedSizeToAllImages
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
            [
                "6b731eb1a48738a4",
                [
                    minH,
                    imageSize.width,
                    imageSize.height,
                    imageSize.objectFit
                ]
            ]
        ]) + " " + `space-y-2 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "6b731eb1a48738a4",
                        [
                            minH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                            [
                                "6b731eb1a48738a4",
                                [
                                    minH,
                                    imageSize.width,
                                    imageSize.height,
                                    imageSize.objectFit
                                ]
                            ]
                        ]) + " " + "block text-xs font-semibold text-gray-700",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        variant: "outline",
                        size: "xs",
                        onClick: openPicker,
                        className: "!p-2",
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__["Image"], {
                            className: "w-4 h-4"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                            lineNumber: 81,
                            columnNumber: 17
                        }, void 0),
                        children: "أدرج صورة"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                lineNumber: 74,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "6b731eb1a48738a4",
                        [
                            minH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "rounded-xl border border-gray-200 bg-white overflow-hidden shadow-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactQuill, {
                    ref: quillRef,
                    value: value,
                    onChange: onChange,
                    modules: modules,
                    formats: formats,
                    placeholder: placeholder
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                    lineNumber: 88,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                lineNumber: 87,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ref: fileInputRef,
                type: "file",
                accept: "image/*",
                onChange: handleFiles,
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "6b731eb1a48738a4",
                        [
                            minH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "hidden"
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                lineNumber: 98,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "6b731eb1a48738a4",
                dynamic: [
                    minH,
                    imageSize.width,
                    imageSize.height,
                    imageSize.objectFit
                ],
                children: `[dir=rtl] .ql-editor{text-align:right;min-height:${minH}px;direction:rtl}.ql-toolbar.ql-snow{background:#fafafa;border:0;border-bottom:1px solid #e5e7eb}.ql-container.ql-snow{border:0}.ql-editor img{object-fit:${imageSize.objectFit};display:inline-block;width:${imageSize.width}px!important;height:${imageSize.height}px!important}`
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
        lineNumber: 73,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
function TrueFalseQuestions({ questionHtml, setQuestionHtml, trueFalseExplanation, trueFalseAnswer, setTrueFalseAnswer, setTrueFalseExplanation, uploadImage }) {
    const [internalQuestion, setInternalQuestion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(questionHtml || "");
    const qValue = typeof questionHtml === "string" ? questionHtml : internalQuestion;
    const setQ = setQuestionHtml || setInternalQuestion;
    const isTrue = trueFalseAnswer === true;
    const isFalse = trueFalseAnswer === false;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-5",
        dir: "rtl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-2xl border border-gray-200 bg-white p-4 shadow-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(MathTypeEditor, {
                    editorData: qValue,
                    setEditorData: (data)=>{
                        setQ(data);
                    }
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                    lineNumber: 144,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                lineNumber: 143,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-2xl border border-gray-200 bg-white p-4 shadow-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-semibold text-gray-800",
                                children: "الإجابة الصحيحة"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                                lineNumber: 161,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                variant: "outline",
                                size: "sm",
                                onClick: ()=>setTrueFalseAnswer(null),
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$eraser$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Eraser$3e$__["Eraser"], {
                                    className: "w-4 h-4"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                                    lineNumber: 162,
                                    columnNumber: 94
                                }, void 0),
                                children: "مسح الاختيار"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                                lineNumber: 162,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                        lineNumber: 160,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        role: "radiogroup",
                        "aria-label": "الإجابة الصحيحة",
                        className: "grid grid-cols-2 gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                className: `w-full ${isTrue ? "ring-2 ring-green-400" : ""}`,
                                variant: isTrue ? "success" : "outline",
                                onClick: ()=>setTrueFalseAnswer(true),
                                "aria-pressed": isTrue,
                                "aria-label": "صحيح",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                    className: "w-4 h-4"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                                    lineNumber: 174,
                                    columnNumber: 19
                                }, void 0),
                                children: "صحيح"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                                lineNumber: 168,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                className: `w-full ${isFalse ? "ring-2 ring-red-400" : ""}`,
                                variant: isFalse ? "danger" : "outline",
                                onClick: ()=>setTrueFalseAnswer(false),
                                "aria-pressed": isFalse,
                                "aria-label": "خطأ",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    className: "w-4 h-4"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                                    lineNumber: 185,
                                    columnNumber: 19
                                }, void 0),
                                children: "خطأ"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                                lineNumber: 179,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                        lineNumber: 167,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                lineNumber: 159,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-2xl border border-gray-200 bg-white p-4 shadow-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(LabeledQuill, {
                    label: "شرح الإجابة (اختياري)",
                    value: trueFalseExplanation,
                    onChange: setTrueFalseExplanation,
                    placeholder: "اكتب سبب صحة/خطأ العبارة… (يدعم الألوان والخلفية وsub/sup)",
                    minH: 140,
                    uploadImage: uploadImage
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                    lineNumber: 193,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
                lineNumber: 192,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx",
        lineNumber: 142,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EssayQuestions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/shared/lib/app-dynamic.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$utils$2f$quillConfig$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/utils/quillConfig.jsx [app-ssr] (ecmascript)");
;
"use client";
;
;
;
;
;
// SSR-safe
const ReactQuill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(async ()=>{}, {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/nartaqi/node_modules/react-quill-new/lib/index.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
const FIXED_IMG = {
    width: 320,
    height: 200,
    objectFit: "contain"
};
const LabeledEditor = ({ label, hint, value, onChange, placeholder = "اكتب هنا…", editorMinH = 200, allowImages = true, uploadImage, imageSize = FIXED_IMG })=>{
    const quillRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const openPicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>inputRef.current?.click(), []);
    const { modules, formats } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$utils$2f$quillConfig$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuillConfig"])({
        allowImages,
        onImageRequest: openPicker
    });
    const applyFixed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        const q = quillRef.current?.getEditor?.();
        const root = q?.root;
        if (!root) return;
        root.querySelectorAll("img").forEach((img)=>{
            img.style.width = `${imageSize.width}px`;
            img.style.height = `${imageSize.height}px`;
            img.style.objectFit = imageSize.objectFit || "contain";
            img.style.display = "inline-block";
        });
    }, [
        imageSize.height,
        imageSize.objectFit,
        imageSize.width
    ]);
    const fileToDataUrl = (file)=>new Promise((resolve, reject)=>{
            const r = new FileReader();
            r.onload = ()=>resolve(String(r.result || ""));
            r.onerror = reject;
            r.readAsDataURL(file);
        });
    const handleFiles = async (e)=>{
        const file = e.target.files?.[0];
        if (!file) return;
        const url = await (uploadImage ? uploadImage(file) : fileToDataUrl(file)) || "";
        const editor = quillRef.current?.getEditor?.();
        if (!editor || !url) return;
        const range = editor.getSelection(true) || {
            index: editor.getLength(),
            length: 0
        };
        editor.insertEmbed(range.index, "image", url, "user");
        editor.setSelection(range.index + 1, 0);
        requestAnimationFrame(applyFixed);
        e.target.value = "";
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const q = quillRef.current?.getEditor?.();
        if (!q) return;
        const h = ()=>requestAnimationFrame(applyFixed);
        q.on("text-change", h);
        requestAnimationFrame(applyFixed);
        return ()=>q.off("text-change", h);
    }, [
        applyFixed
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
            [
                "e0e9b997c6a2f914",
                [
                    editorMinH,
                    imageSize.width,
                    imageSize.height,
                    imageSize.objectFit
                ]
            ]
        ]) + " " + "space-y-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "e0e9b997c6a2f914",
                        [
                            editorMinH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                            [
                                "e0e9b997c6a2f914",
                                [
                                    editorMinH,
                                    imageSize.width,
                                    imageSize.height,
                                    imageSize.objectFit
                                ]
                            ]
                        ]) + " " + "block text-xs font-semibold text-gray-700",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    allowImages && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: openPicker,
                                title: "أدرج صورة",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                    [
                                        "e0e9b997c6a2f914",
                                        [
                                            editorMinH,
                                            imageSize.width,
                                            imageSize.height,
                                            imageSize.objectFit
                                        ]
                                    ]
                                ]) + " " + "inline-flex items-center gap-1 px-2 py-1 text-xs rounded-lg border border-gray-200 hover:bg-gray-50",
                                children: "📷 أدرج صورة"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                                lineNumber: 76,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                ref: inputRef,
                                type: "file",
                                accept: "image/*",
                                onChange: handleFiles,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                                    [
                                        "e0e9b997c6a2f914",
                                        [
                                            editorMinH,
                                            imageSize.width,
                                            imageSize.height,
                                            imageSize.objectFit
                                        ]
                                    ]
                                ]) + " " + "hidden"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                                lineNumber: 84,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                lineNumber: 72,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "e0e9b997c6a2f914",
                        [
                            editorMinH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "rounded-2xl border border-gray-200 bg-white overflow-hidden shadow-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactQuill, {
                    ref: quillRef,
                    value: value,
                    onChange: onChange,
                    modules: modules,
                    formats: formats,
                    placeholder: placeholder
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                    lineNumber: 90,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                lineNumber: 89,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            hint && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "e0e9b997c6a2f914",
                        [
                            editorMinH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "text-[11px] text-gray-500",
                children: hint
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                lineNumber: 100,
                columnNumber: 16
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "e0e9b997c6a2f914",
                dynamic: [
                    editorMinH,
                    imageSize.width,
                    imageSize.height,
                    imageSize.objectFit
                ],
                children: `[dir=rtl] .ql-editor{text-align:right;min-height:${editorMinH}px;direction:rtl}.ql-toolbar.ql-snow{background:#fafafa;border:0;border-bottom:1px solid #e5e7eb}.ql-container.ql-snow{border:0}.ql-editor img{object-fit:${imageSize.objectFit};display:inline-block;width:${imageSize.width}px!important;height:${imageSize.height}px!important}`
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
        lineNumber: 71,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
function EssayQuestions({ modalAnswer, setModalAnswer, label = "الإجابة النموذجية", hint = "يدعم الألوان وخلفية النص وكتابة H₂O عبر زر x₂", showCounters = true, uploadImage }) {
    const plainText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>(modalAnswer || "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim(), [
        modalAnswer
    ]);
    const words = plainText ? plainText.split(" ").length : 0;
    const chars = plainText.length;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-2xl border border-gray-200 bg-white p-4 shadow-sm",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(LabeledEditor, {
                label: label,
                hint: hint,
                value: modalAnswer,
                onChange: setModalAnswer,
                placeholder: "أدخل الإجابة النموذجية هنا…",
                editorMinH: 200,
                allowImages: true,
                uploadImage: uploadImage
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                lineNumber: 144,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-3 flex items-center justify-between text-xs text-gray-500",
                children: [
                    showCounters ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-x-3 space-x-reverse",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "عدد الكلمات: ",
                                    words
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                                lineNumber: 158,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    "عدد الحروف: ",
                                    chars
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                                lineNumber: 159,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                        lineNumber: 157,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {}, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                        lineNumber: 162,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: ()=>setModalAnswer(""),
                        className: "px-2.5 py-1 rounded-lg border border-gray-200 hover:bg-gray-50 text-gray-700",
                        title: "مسح المحتوى",
                        children: "مسح"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                        lineNumber: 165,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
                lineNumber: 155,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx",
        lineNumber: 143,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CompleteQuestions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/atoms/Button.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/plus.js [app-ssr] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-ssr] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/image.js [app-ssr] (ecmascript) <export default as Image>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/shared/lib/app-dynamic.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$utils$2f$quillConfig$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/utils/quillConfig.jsx [app-ssr] (ecmascript)");
;
"use client";
;
;
;
;
;
;
;
// SSR-safe
const ReactQuill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(async ()=>{}, {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/nartaqi/node_modules/react-quill-new/lib/index.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
const FIXED_IMG = {
    width: 320,
    height: 200,
    objectFit: "contain"
};
const LabeledQuill = ({ label, value, onChange, placeholder = "اكتب هنا…", minH = 120, className = "", uploadImage, imageSize = FIXED_IMG })=>{
    const quillRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const openPicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>fileInputRef.current?.click(), []);
    const { modules, formats } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$utils$2f$quillConfig$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useQuillConfig"])({
        allowImages: true,
        onImageRequest: openPicker
    });
    const applyFixed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        const q = quillRef.current?.getEditor?.();
        const root = q?.root;
        if (!root) return;
        root.querySelectorAll("img").forEach((img)=>{
            img.style.width = `${imageSize.width}px`;
            img.style.height = `${imageSize.height}px`;
            img.style.objectFit = imageSize.objectFit || "contain";
            img.style.display = "inline-block";
        });
    }, [
        imageSize.height,
        imageSize.objectFit,
        imageSize.width
    ]);
    const fileToDataUrl = (file)=>new Promise((resolve, reject)=>{
            const r = new FileReader();
            r.onload = ()=>resolve(String(r.result || ""));
            r.onerror = reject;
            r.readAsDataURL(file);
        });
    const handleFiles = async (e)=>{
        const file = e.target.files?.[0];
        if (!file) return;
        const url = await (uploadImage ? uploadImage(file) : fileToDataUrl(file)) || "";
        const editor = quillRef.current?.getEditor?.();
        if (!editor || !url) return;
        const range = editor.getSelection(true) || {
            index: editor.getLength(),
            length: 0
        };
        editor.insertEmbed(range.index, "image", url, "user");
        editor.setSelection(range.index + 1, 0);
        requestAnimationFrame(applyFixed);
        e.target.value = "";
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const q = quillRef.current?.getEditor?.();
        if (!q) return;
        const h = ()=>requestAnimationFrame(applyFixed);
        q.on("text-change", h);
        requestAnimationFrame(applyFixed);
        return ()=>q.off("text-change", h);
    }, [
        applyFixed
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
            [
                "6b731eb1a48738a4",
                [
                    minH,
                    imageSize.width,
                    imageSize.height,
                    imageSize.objectFit
                ]
            ]
        ]) + " " + `space-y-2 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "6b731eb1a48738a4",
                        [
                            minH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                            [
                                "6b731eb1a48738a4",
                                [
                                    minH,
                                    imageSize.width,
                                    imageSize.height,
                                    imageSize.objectFit
                                ]
                            ]
                        ]) + " " + "block text-xs font-semibold text-gray-700",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        variant: "outline",
                        size: "xs",
                        className: "!p-2",
                        onClick: openPicker,
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__["Image"], {
                            className: "w-4 h-4"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                            lineNumber: 81,
                            columnNumber: 17
                        }, void 0),
                        "aria-label": "أدرج صورة",
                        children: "أدرج صورة"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                        lineNumber: 76,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                lineNumber: 74,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "6b731eb1a48738a4",
                        [
                            minH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "rounded-xl border border-gray-200 bg-white overflow-hidden shadow-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactQuill, {
                    ref: quillRef,
                    value: value,
                    onChange: onChange,
                    modules: modules,
                    formats: formats,
                    placeholder: placeholder
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                    lineNumber: 89,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                lineNumber: 88,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ref: fileInputRef,
                type: "file",
                accept: "image/*",
                onChange: handleFiles,
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "6b731eb1a48738a4",
                        [
                            minH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "hidden"
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                lineNumber: 99,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "6b731eb1a48738a4",
                dynamic: [
                    minH,
                    imageSize.width,
                    imageSize.height,
                    imageSize.objectFit
                ],
                children: `[dir=rtl] .ql-editor{text-align:right;min-height:${minH}px;direction:rtl}.ql-toolbar.ql-snow{background:#fafafa;border:0;border-bottom:1px solid #e5e7eb}.ql-container.ql-snow{border:0}.ql-editor img{object-fit:${imageSize.objectFit};display:inline-block;width:${imageSize.width}px!important;height:${imageSize.height}px!important}`
            }, void 0, false, void 0, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
        lineNumber: 73,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
function CompleteQuestions({ completeText, setCompleteText, completeAnswers, updateCompleteAnswer, removeCompleteAnswer, addCompleteAnswer, uploadImage }) {
    const isObjectMode = Array.isArray(completeAnswers) && completeAnswers.length > 0 && typeof completeAnswers[0] === "object" && completeAnswers[0] !== null;
    const normalizeItem = (item)=>{
        if (typeof item === "string") return {
            answer: item,
            explanation: ""
        };
        if (item && typeof item === "object") return {
            answer: item.answer || "",
            explanation: item.explanation || ""
        };
        return {
            answer: "",
            explanation: ""
        };
    };
    const patchAnswer = (index, next)=>{
        const curr = normalizeItem(completeAnswers?.[index]);
        const payload = {
            ...curr,
            ...next
        };
        updateCompleteAnswer(index, isObjectMode ? payload : payload.answer);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-5",
        dir: "rtl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-2xl border border-gray-200 bg-white p-4 shadow-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(LabeledQuill, {
                        label: "نص السؤال (ضع … في الأماكن الناقصة)",
                        value: completeText,
                        onChange: setCompleteText,
                        placeholder: "أدخل نص السؤال (يدعم الألوان والخلفية وsub/sup)",
                        minH: 160,
                        uploadImage: uploadImage,
                        imageSize: FIXED_IMG
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                        lineNumber: 157,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-[11px] text-gray-500",
                        children: [
                            "مثال: ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "px-2 py-0.5 rounded bg-gray-100",
                                children: "ولد … في عام …"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                lineNumber: 167,
                                columnNumber: 22
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                        lineNumber: 166,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                lineNumber: 156,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "rounded-2xl border border-gray-200 bg-white p-4 shadow-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between mb-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-semibold text-gray-800",
                                children: "الإجابات الصحيحة"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                lineNumber: 173,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                variant: "outline",
                                onClick: addCompleteAnswer,
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                    className: "w-5 h-5"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                    lineNumber: 174,
                                    columnNumber: 71
                                }, void 0),
                                children: "إضافة إجابة"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                lineNumber: 174,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                        lineNumber: 172,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3",
                        children: completeAnswers?.map((raw, index)=>{
                            const item = normalizeItem(raw);
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "border rounded-xl p-3 bg-gray-50 space-y-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "inline-flex items-center gap-2 text-xs text-gray-600",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "inline-block w-6 h-6 rounded-full bg-blue-100 text-blue-700 grid place-items-center font-bold",
                                                        children: index + 1
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                                        lineNumber: 186,
                                                        columnNumber: 21
                                                    }, this),
                                                    "إجابة رقم ",
                                                    index + 1
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                                lineNumber: 185,
                                                columnNumber: 19
                                            }, this),
                                            completeAnswers?.length > 1 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                variant: "outline",
                                                size: "sm",
                                                onClick: ()=>removeCompleteAnswer(index),
                                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                    className: "w-4 h-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                                    lineNumber: 197,
                                                    columnNumber: 29
                                                }, void 0),
                                                "aria-label": "حذف الإجابة"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                                lineNumber: 193,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                        lineNumber: 184,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(LabeledQuill, {
                                        label: "نص الإجابة",
                                        value: item.answer,
                                        onChange: (v)=>patchAnswer(index, {
                                                answer: v
                                            }),
                                        placeholder: `الإجابة ${index + 1} (يدعم الألوان والخلفية وsub/sup)`,
                                        minH: 110,
                                        uploadImage: uploadImage,
                                        imageSize: FIXED_IMG
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                        lineNumber: 203,
                                        columnNumber: 17
                                    }, this),
                                    isObjectMode && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(LabeledQuill, {
                                        label: "شرح الإجابة (اختياري)",
                                        value: item.explanation,
                                        onChange: (v)=>patchAnswer(index, {
                                                explanation: v
                                            }),
                                        placeholder: "اكتب شرحًا لهذه الإجابة… (يدعم الألوان والخلفية وsub/sup)",
                                        minH: 100,
                                        uploadImage: uploadImage,
                                        imageSize: FIXED_IMG
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                        lineNumber: 214,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                                lineNumber: 183,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                        lineNumber: 179,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
                lineNumber: 171,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx",
        lineNumber: 155,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/MathTypeEditor/MathTypeEditor.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$react$2f$dist$2f$ckeditor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-react/dist/ckeditor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2d$classic$2d$with$2d$mathtype$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5-classic-with-mathtype/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2d$classic$2d$with$2d$mathtype$2f$build$2f$ckeditor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5-classic-with-mathtype/build/ckeditor.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function MathTypeEditor({ editorData = '<p></p>', setEditorData }) {
    const [isRTL, setIsRTL] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [ready, setReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setReady(true);
        return ()=>setReady(false);
    }, []);
    if (!ready) return null;
    const editorConfiguration = {
        language: 'ar',
        toolbar: {
            items: [
                'heading',
                'MathType',
                'ChemType',
                '|',
                'bold',
                'italic',
                'link',
                'bulletedList',
                'numberedList',
                '|',
                'blockQuote',
                'insertTable',
                '|',
                'undo',
                'redo'
            ]
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "math-editor-container",
        dir: isRTL ? 'rtl' : 'ltr',
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$react$2f$dist$2f$ckeditor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CKEditor"], {
            editor: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2d$classic$2d$with$2d$mathtype$2f$build$2f$ckeditor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
            config: editorConfiguration,
            data: editorData,
            placeholder: "اكتب هنا…",
            className: "!w-full border border-gray-200",
            style: {
                fontSize: "14px",
                minHeight: "48px",
                width: "100%",
                textAlign: "right"
            },
            // I want to change confirm button text
            toolbarConfirmButtonLabel: "تأكيد",
            toolbarCancelButtonLabel: "إلغاء",
            toolbarUndoButtonLabel: "تراجع",
            toolbarRedoButtonLabel: "إعادة",
            toolbarBoldButtonLabel: "عريض",
            toolbarItalicButtonLabel: "مائل",
            toolbarUnderlineButtonLabel: "تحتي",
            toolbarStrikethroughButtonLabel: "مشطوب",
            toolbarSuperscriptButtonLabel: "رفع",
            toolbarSubscriptButtonLabel: "خفض",
            onReady: (editor)=>{
                console.log('CKEditor is ready to use!', editor);
                try {
                    // Set editor direction
                    if (editor && editor.editing && editor.editing.view) {
                        editor.editing.view.document.dir = isRTL ? 'rtl' : 'ltr';
                    }
                } catch (error) {
                    console.warn('Error setting editor direction:', error);
                }
            },
            onChange: (event, editor)=>{
                try {
                    if (editor) {
                        const data = editor.getData();
                        setEditorData(data);
                    }
                } catch (error) {
                    console.error('Error in onChange:', error);
                }
            },
            onError: (error, { phase, willEditorRestart })=>{
                console.error('CKEditor error:', error, phase, willEditorRestart);
            }
        }, void 0, false, {
            fileName: "[project]/Desktop/nartaqi/components/MathTypeEditor/MathTypeEditor.jsx",
            lineNumber: 44,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/MathTypeEditor/MathTypeEditor.jsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
const __TURBOPACK__default__export__ = MathTypeEditor;
}),
"[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// "use client";
// import React, { useMemo, useState, useEffect } from "react";
// import { Edit3, Trash2, GripVertical, Save, X, ChevronDown, ChevronUp } from "lucide-react";
// import { Collapse, Empty, Spin, Tag, Button, Modal } from "antd";
// import { useDispatch, useSelector } from "react-redux";
// import { questionTypes } from "./utils";
// import Card from "./ExamCard";
// import dynamic from "next/dynamic";
// // Dynamically import Quill to avoid SSR issues
// const ReactQuill = dynamic(() => import("react-quill"), { ssr: false });
// import "quill/dist/quill.snow.css";
// import TabButton from "../ui/TabButton";
// import { handleDeleteExamQuestions, handleGetExamQuestions } from "../../lib/features/examSlice";
// import { toast } from "react-toastify";
// const { Panel } = Collapse;
// const { confirm } = Modal;
// export default function DisplayQuestions({
//   selectedSectionId,
//   setEditingQuestion,
//   editingQuestion,
//   selectedSection
// }) {
//   const dispatch = useDispatch();
//   const { get_exam_questions_list, get_exam_questions_loading, delete_question_loading } = useSelector(state => state?.exam);
//   // State for collapsable panels
//   const [expandedQuestions, setExpandedQuestions] = useState({});
//   // State for editing
//   const [editingQuestionId, setEditingQuestionId] = useState(null);
//   const [editingContent, setEditingContent] = useState("");
//   const [editingOptions, setEditingOptions] = useState([]);
//   const [editingCorrectAnswer, setEditingCorrectAnswer] = useState(0);
//   const [editingParagraphContent, setEditingParagraphContent] = useState("");
//   const [editingParagraphQuestions, setEditingParagraphQuestions] = useState([]);
//   const [deleteModal, setDeleteModal] = useState(false);
//   const [questionToDelete, setQuestionToDelete] = useState(null);
//   const [sectionName , setSectionName] = useState("");
//   // Log to verify if selectedSectionId is set correctly
//   useEffect(() => {
//     console.log("selectedSection" , selectedSection)
//   } ,[selectedSection])
//   useEffect(() => {
//     if (selectedSectionId) {
//       console.log("Fetching questions for section ID:", selectedSectionId);
//       dispatch(handleGetExamQuestions({ body: { exam_section_id: selectedSectionId } }))
//       .unwrap()
//       .then(res => {
//         console.log(res);
//         if(res?.data?.status == "success") {
//           const filtered = res?.data?.message?.filter(item=> item?.id == selectedSectionId)
//           setSectionName(filtered?.title)
//         }
//       })
//     }
//   }, [selectedSectionId, dispatch]);
//   // Initialize all questions as expanded by default
//   useEffect(() => {
//     if (get_exam_questions_list) {
//       const questions = get_exam_questions_list?.data?.message;
//       const initialExpandedState = {};
//       // Process MCQs
//       (questions?.mcq || []).forEach((q, index) => {
//         initialExpandedState[`mcq-${q.id}`] = false; // Default expanded
//       });
//       // Process paragraphs
//       (questions?.paragraphs || []).forEach((p, index) => {
//         initialExpandedState[`paragraph-${p?.paragraph?.id}`] = false; // Default expanded
//       });
//       setExpandedQuestions(initialExpandedState);
//     }
//   }, [get_exam_questions_list]);
//   // Quill configuration
//   const quillModules = {
//     toolbar: [
//       [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
//       ['bold', 'italic', 'underline', 'strike'],
//       [{ 'list': 'ordered'}, { 'list': 'bullet' }],
//       [{ 'script': 'sub'}, { 'script': 'super' }],
//       [{ 'indent': '-1'}, { 'indent': '+1' }],
//       [{ 'direction': 'rtl' }],
//       [{ 'size': ['small', false, 'large', 'huge'] }],
//       [{ 'color': [] }, { 'background': [] }],
//       [{ 'font': [] }],
//       [{ 'align': [] }],
//       ['clean'],
//       ['formula', 'link', 'image']
//     ],
//   };
//   const quillFormats = [
//     'header',
//     'bold', 'italic', 'underline', 'strike',
//     'list', 'bullet', 'indent',
//     'script',
//     'direction',
//     'size',
//     'color', 'background',
//     'font',
//     'align',
//     'formula', 'link', 'image'
//   ];
//   // UseMemo to process the API data into the desired format
//   const apiQuestions = useMemo(() => {
//     if (!get_exam_questions_list) return [];
//     const apiResponse = get_exam_questions_list;
//     const apiData = apiResponse?.data?.message;
//     // Process MCQs
//     const mcqQuestions = (apiData?.mcq || []).map((q) => {
//       const options = q?.options || [];
//       const correctIndex = options?.findIndex((opt) => Number(opt?.is_correct) === 1);
//       return {
//         id: q.id,
//         type: "mcq",
//         question: q?.question_text || "",
//         exam_section_id: q?.exam_section_id,
//         instructions: q?.instructions || "Instructions",
//         correctAnswer: correctIndex >= 0 ? correctIndex : 0,
//         options: options?.map((opt) => ({
//           id: opt?.id,
//           text: opt?.option_text || "",
//           explanation: opt?.question_explanation || "",
//           is_correct: opt?.is_correct || 0,
//         })),
//         rawData: q // Keep original data for editing
//       };
//     });
//     // Process paragraph questions
//     const paragraphQuestions = (apiData?.paragraphs || []).map((p) => ({
//       id: p?.paragraph.id,
//       type: "paragraph_mcq",
//       paragraphContent: p?.paragraph?.paragraph_content || "",
//       questions: p?.questions?.map((q) => ({
//         id: q?.id,
//         questionText: q?.question_text || "",
//         instructions: q?.instructions || "Choose the correct answer",
//         options: (q?.options || []).map((opt) => ({
//           id: opt?.id,
//           text: opt?.option_text || "",
//           explanation: opt?.question_explanation || "",
//           isCorrect: opt?.is_correct === 1 ? true : false,
//         })),
//         rawData: q
//       })),
//       rawData: p
//     }));
//     return [...mcqQuestions, ...paragraphQuestions];
//   }, [get_exam_questions_list]);
//   // Toggle question expansion
//   const toggleQuestion = (questionId, questionType = 'mcq') => {
//     const key = `${questionType === 'mcq' ? 'mcq' : 'paragraph'}-${questionId}`;
//     setExpandedQuestions(prev => ({
//       ...prev,
//       [key]: !prev[key]
//     }));
//   };
//   // Check if question is expanded
//  // Check if question is expanded
// const isQuestionExpanded = (questionId, questionType = 'mcq') => {
//   const key = `${questionType === 'mcq' ? 'mcq' : 'paragraph'}-${questionId}`;
//   return expandedQuestions[key] === true; // Only true if explicitly set to true
// };
//   // Function to delete a question
//   const handleDeleteQuestion = () => {
//     if (!questionToDelete) return;
//     dispatch(handleDeleteExamQuestions({
//       body: {
//         id: questionToDelete.id
//       }
//     }))
//     .unwrap()
//     .then(res => {
//       console.log(res);
//       if (res?.data?.status === "success") {
//         // Refresh questions list
//         toast.success(res?.data?.message);
//         dispatch(handleGetExamQuestions({ body: { exam_section_id: selectedSectionId } }));
//         setDeleteModal(false);
//         setQuestionToDelete(null);
//       }else {
//         toast.error(res?.data?.message);
//       }
//     })
//     .catch(error => {
//       console.error("Delete error:", error);
//     });
//   };
//   // Function to cancel editing
//   const cancelEditing = () => {
//     setEditingQuestionId(null);
//     setEditingContent("");
//     setEditingOptions([]);
//     setEditingCorrectAnswer(0);
//     setEditingParagraphContent("");
//     setEditingParagraphQuestions([]);
//   };
//   // Function to save edited question
//   const saveEditedQuestion = (questionId, questionType) => {
//     // Implement save logic here
//     console.log("Save edited question:", { questionId, questionType });
//     cancelEditing();
//   };
//   // Update an option in editing mode
//   const updateEditingOption = (index, field, value) => {
//     const newOptions = [...editingOptions];
//     newOptions[index] = { ...newOptions[index], [field]: value };
//     setEditingOptions(newOptions);
//   };
//   // Render question content based on type with editing capabilities
//   const renderQuestionContent = (q) => {
//     // If this question is being edited
//     if (editingQuestionId === q.id) {
//       if (q.type === "mcq") {
//         return (
//           <div className="space-y-4">
//             {/* Question Text Editor */}
//             <div className="space-y-2">
//               <label className="text-sm font-medium text-gray-700">نص السؤال</label>
//               <ReactQuill
//                 value={editingContent}
//                 onChange={setEditingContent}
//                 modules={quillModules}
//                 formats={quillFormats}
//                 className="bg-white rounded-lg"
//                 style={{ minHeight: '150px' }}
//               />
//             </div>
//             {/* Options Editor */}
//             <div className="space-y-3">
//               <label className="text-sm font-medium text-gray-700">خيارات الإجابة</label>
//               {editingOptions.map((option, idx) => (
//                 <div key={idx} className="border rounded-lg p-3 space-y-2">
//                   <div className="flex items-center justify-between">
//                     <label className="flex items-center space-x-2 space-x-reverse">
//                       <input
//                         type="radio"
//                         checked={editingCorrectAnswer === idx}
//                         onChange={() => setEditingCorrectAnswer(idx)}
//                         className="h-4 w-4 text-blue-600"
//                       />
//                       <span>الإجابة الصحيحة</span>
//                     </label>
//                     <span className="text-xs bg-gray-100 px-2 py-1 rounded">
//                       {String.fromCharCode(1632 + (idx + 1))}
//                     </span>
//                   </div>
//                   <div className="space-y-2">
//                     <label className="text-xs text-gray-600">نص الخيار</label>
//                     <ReactQuill
//                       value={option.text}
//                       onChange={(value) => updateEditingOption(idx, 'text', value)}
//                       modules={quillModules}
//                       formats={quillFormats}
//                       className="bg-white rounded-lg"
//                       style={{ minHeight: '80px' }}
//                     />
//                   </div>
//                   <div className="space-y-2">
//                     <label className="text-xs text-gray-600">شرح الخيار</label>
//                     <ReactQuill
//                       value={option.explanation}
//                       onChange={(value) => updateEditingOption(idx, 'explanation', value)}
//                       modules={quillModules}
//                       formats={quillFormats}
//                       className="bg-white rounded-lg"
//                       style={{ minHeight: '80px' }}
//                     />
//                   </div>
//                 </div>
//               ))}
//             </div>
//             {/* Action Buttons */}
//             <div className="flex justify-end space-x-2 space-x-reverse pt-4 border-t">
//               <TabButton
//                 onClick={cancelEditing}
//                 className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
//               >
//                 <X className="w-4 h-4 ml-1" />
//                 إلغاء
//               </TabButton>
//               <Button
//                 onClick={() => saveEditedQuestion(q.id, q.type)}
//                 className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
//                 loading={delete_question_loading}
//               >
//                 <Save className="w-4 h-4 ml-1" />
//                 حفظ التعديلات
//               </Button>
//             </div>
//           </div>
//         );
//       }
//       if (q.type === "paragraph_mcq") {
//         return (
//           <div className="space-y-4">
//             {/* Paragraph Content Editor */}
//             <div className="space-y-2">
//               <label className="text-sm font-medium text-gray-700">محتوى الفقرة</label>
//               <ReactQuill
//                 value={editingParagraphContent}
//                 onChange={setEditingParagraphContent}
//                 modules={quillModules}
//                 formats={quillFormats}
//                 className="bg-white rounded-lg"
//                 style={{ minHeight: '150px' }}
//               />
//             </div>
//             {/* Questions Editor */}
//             {editingParagraphQuestions.map((pq, pIdx) => (
//               <div key={pIdx} className="border rounded-lg p-4 space-y-3">
//                 <div className="space-y-2">
//                   <label className="text-sm font-medium text-gray-700">سؤال {pIdx + 1}</label>
//                   <ReactQuill
//                     value={pq.questionText}
//                     onChange={(value) => {
//                       const newQuestions = [...editingParagraphQuestions];
//                       newQuestions[pIdx].questionText = value;
//                       setEditingParagraphQuestions(newQuestions);
//                     }}
//                     modules={quillModules}
//                     formats={quillFormats}
//                     className="bg-white rounded-lg"
//                     style={{ minHeight: '100px' }}
//                   />
//                 </div>
//                 {/* Options for this question */}
//                 <div className="space-y-3">
//                   <label className="text-sm font-medium text-gray-700">خيارات السؤال</label>
//                   {pq.options.map((option, oIdx) => (
//                     <div key={oIdx} className="border rounded p-3 space-y-2">
//                       <div className="flex items-center justify-between">
//                         <label className="flex items-center space-x-2 space-x-reverse">
//                           <input
//                             type="radio"
//                             checked={option.isCorrect}
//                             onChange={() => {
//                               const newQuestions = [...editingParagraphQuestions];
//                               newQuestions[pIdx].options = newQuestions[pIdx].options.map((opt, idx) => ({
//                                 ...opt,
//                                 isCorrect: idx === oIdx
//                               }));
//                               setEditingParagraphQuestions(newQuestions);
//                             }}
//                             className="h-4 w-4 text-blue-600"
//                           />
//                           <span>الإجابة الصحيحة</span>
//                         </label>
//                         <span className="text-xs bg-gray-100 px-2 py-1 rounded">
//                           {String.fromCharCode(1632 + (oIdx + 1))}
//                         </span>
//                       </div>
//                       <div className="space-y-2">
//                         <label className="text-xs text-gray-600">نص الخيار</label>
//                         <ReactQuill
//                           value={option.text}
//                           onChange={(value) => {
//                             const newQuestions = [...editingParagraphQuestions];
//                             newQuestions[pIdx].options[oIdx].text = value;
//                             setEditingParagraphQuestions(newQuestions);
//                           }}
//                           modules={quillModules}
//                           formats={quillFormats}
//                           className="bg-white rounded-lg"
//                           style={{ minHeight: '80px' }}
//                         />
//                       </div>
//                     </div>
//                   ))}
//                 </div>
//               </div>
//             ))}
//             {/* Action Buttons */}
//             <div className="flex justify-end space-x-2 space-x-reverse pt-4 border-t">
//               <Button
//                 onClick={cancelEditing}
//                 className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
//               >
//                 <X className="w-4 h-4 ml-1" />
//                 إلغاء
//               </Button>
//               <Button
//                 onClick={() => saveEditedQuestion(q.id, q.type)}
//                 className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
//                 loading={delete_question_loading}
//               >
//                 <Save className="w-4 h-4 ml-1" />
//                 حفظ التعديلات
//               </Button>
//             </div>
//           </div>
//         );
//       }
//     }
//     // Normal view (not editing)
//     if (q.type === "mcq") {
//       return (
//         <div className="space-y-3">
//           <div className="flex justify-between items-start mb-2">
//             <div className="flex-1">
//               <div 
//                 className="text-[13px] text-gray-800 leading-6 mb-3" 
//                 dangerouslySetInnerHTML={{__html : q?.question}}
//               />
//             </div>
//             <div className="flex space-x-2 space-x-reverse mr-2">
//               <button
//                 onClick={() => setEditingQuestion(q)}
//                 className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
//                 title="تعديل السؤال"
//               >
//                 <Edit3 className="w-4 h-4" />
//               </button>
//               <button
//                 onClick={() => {
//                   setQuestionToDelete(q);
//                   setDeleteModal(true);
//                 }}
//                 className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
//                 title="حذف السؤال"
//                 disabled={delete_question_loading}
//               >
//                 <Trash2 className="w-4 h-4" />
//               </button>
//             </div>
//           </div>
//           <div className="grid gap-2">
//             {q.options.map((option, idx) => {
//               const isCorrect = idx === q.correctAnswer;
//               return (
//                 <div
//                   key={idx}
//                   className={`rounded-lg border px-3 py-2 text-[12px] ${
//                     isCorrect
//                       ? "bg-emerald-50 border-emerald-200 text-emerald-800"
//                       : "bg-gray-50 border-gray-200 text-gray-700"
//                   }`}
//                 >
//                   <div 
//                     dangerouslySetInnerHTML={{__html : `${String.fromCharCode(1632 + (idx + 1))}. ${option?.text}`}}
//                     className="font-medium"
//                   />
//                   {option.explanation && (
//                     <div 
//                       dangerouslySetInnerHTML={{__html : `Explanation: ${option.explanation}`}}
//                       className="mt-1 text-[12px] text-gray-600"
//                     />
//                   )}
//                 </div>
//               );
//             })}
//           </div>
//         </div>
//       );
//     }
//     if (q.type === "paragraph_mcq") {
//       return (
//         <div className="space-y-3">
//           <div className="flex justify-between items-start mb-2">
//             <div className="flex-1">
//               <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 mb-3">
//                 <div className="text-[12px] font-semibold text-blue-800 mb-1">Paragraph:</div>
//                 <div 
//                   className="text-[12px] text-blue-700 leading-6"
//                   dangerouslySetInnerHTML={{__html : q.paragraphContent}}
//                 />
//               </div>
//             </div>
//             <div className="flex space-x-2 space-x-reverse mr-2">
//               <button
//                 onClick={() => setEditingQuestion(q)}
//                 className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
//                 title="تعديل الفقرة والأسئلة"
//               >
//                 <Edit3 className="w-4 h-4" />
//               </button>
//               <button
//                 onClick={() => {
//                   setQuestionToDelete(q);
//                   setDeleteModal(true);
//                 }}
//                 className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
//                 title="حذف الفقرة والأسئلة"
//                 disabled={delete_question_loading}
//               >
//                 <Trash2 className="w-4 h-4" />
//               </button>
//             </div>
//           </div>
//           {q.questions.map((question, idx) => (
//             <div key={idx} className="space-y-3">
//               <div className="flex justify-between items-start">
//                 <h2 className="font-bold text-lg">أسئله القطعه</h2>
//                 <div className="flex-1">
//                   <p 
//                     className="text-[13px] text-gray-800 leading-6 mb-2"
//                     dangerouslySetInnerHTML={{__html : question.questionText}}
//                   />
//                 </div>
//               </div>
//               <div className="grid gap-2">
//                 {question.options.map((option, i) => {
//                   const isCorrect = option.isCorrect;
//                   return (
//                     <div
//                       key={i}
//                       className={`rounded-lg border px-3 py-2 text-[12px] ${
//                         isCorrect
//                           ? "bg-emerald-50 border-emerald-200 text-emerald-800"
//                           : "bg-gray-50 border-gray-200 text-gray-700"
//                       }`}
//                     >
//                       <div 
//                         className="font-medium" 
//                         dangerouslySetInnerHTML={{__html : `${String.fromCharCode(1632 + (i + 1))}. ${option?.text}`}}
//                       />
//                       {option.explanation && (
//                         <div 
//                           dangerouslySetInnerHTML={{__html :` Explanation: ${option.explanation}`}}
//                           className="mt-1 text-[12px] text-gray-600"
//                         />
//                       )}
//                     </div>
//                   );
//                 })}
//               </div>
//             </div>
//           ))}
//         </div>
//       );
//     }
//     return (
//       <div className="flex justify-between items-start">
//         <div className="flex-1">
//           <p className="text-[13px] text-gray-800" dangerouslySetInnerHTML={{__html : q.question}}></p>
//         </div>
//         <div className="flex space-x-2 space-x-reverse mr-2">
//           <button
//             onClick={() => setEditingQuestion(q)}
//             className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
//             title="تعديل السؤال"
//           >
//             <Edit3 className="w-4 h-4" />
//           </button>
//           <button
//             onClick={() => {
//               setQuestionToDelete(q);
//               setDeleteModal(true);
//             }}
//             className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
//             title="حذف السؤال"
//             disabled={delete_question_loading}
//           >
//             <Trash2 className="w-4 h-4" />
//           </button>
//         </div>
//       </div>
//     );
//   };
//   if (get_exam_questions_loading) {
//     return (
//       <div className="h-screen flex justify-center items-center">
//         <Spin spinning size="large" />
//       </div>
//     );
//   }
//   return (
//     <Card title="Exam Questions" icon={Edit3}>
//       {apiQuestions.length === 0 ? (
//         <Empty description="No questions available for this section" />
//       ) : (
//         <div className="space-y-4">
//           <div className="p-4 bg-blue-50 rounded-xl border border-blue-200">
//             <div className="flex items-center justify-between">
//               <div>
//                 <h3 
//                 dangerouslySetInnerHTML={{__html : `Section ${sectionName}`}}
//                 className="font-semibold text-blue-800"></h3>
//                 <p className="text-sm text-blue-600">Total Questions: {apiQuestions.length}</p>
//               </div>
//               <Tag color="blue" className="!m-0">
//                 {selectedSectionId}
//               </Tag>
//             </div>
//           </div>
//           <div className="space-y-3">
//             {apiQuestions.map((q, index) => {
//               console.log(q);
//               const typeLabel = q?.type == "mcq" ? "MCQ" : "Paragraph" || "Question";
//               const subTag = q.mcqSubType && q.mcqSubType !== "general" ? q.mcqSubType === "chemical" ? "Chemical" : "Passage" : null;
//               const isExpanded = isQuestionExpanded(q.id, q.type);
//               return (
//                 <div 
//                   key={q.id} 
//                   className="rounded-2xl border bg-white shadow-sm transition-all hover:shadow-md"
//                 >
//                   {/* Collapsible Header */}
//                   <div 
//                     className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-50 rounded-t-2xl transition-colors"
//                     onClick={() => toggleQuestion(q.id, q.type)}
//                   >
//                     <div className="flex items-center gap-2">
//                       <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-gray-100 text-gray-700 text-xs font-semibold">
//                         {index + 1}
//                       </span>
//                       <Tag color="blue" className="!m-0 !text-[11px]">
//                         {typeLabel}
//                       </Tag>
//                       {subTag && (
//                         <Tag color="purple" className="!m-0 !text-[11px]">
//                           {subTag}
//                         </Tag>
//                       )}
//                     </div>
//                   </div>
//                   {/* Collapsible Content */}
//                   {isExpanded && (
//                     <div className="p-4 pt-0 border-t">
//                       <div className="mt-3">{renderQuestionContent(q)}</div>
//                     </div>
//                   )}
//                 </div>
//               );
//             })}
//           </div>
//         </div>
//       )}
//       {/* Delete Confirmation Modal */}
//       <Modal
//         open={deleteModal}
//         onCancel={() => {
//           setDeleteModal(false);
//           setQuestionToDelete(null);
//         }}
//         onOk={handleDeleteQuestion}
//         okText="حذف"
//         cancelText="إلغاء"
//         okButtonProps={{ className: "!bg-red-500 hover:!bg-red-600" }}
//         confirmLoading={delete_question_loading}
//       >
//         <div className="text-center py-4">
//           <Trash2 className="w-12 h-12 text-red-500 mx-auto mb-4" />
//           <h2 className="text-lg font-semibold mb-2">هل أنت متأكد من حذف السؤال؟</h2>
//           <p className="text-gray-600">
//             هذا الإجراء لا يمكن التراجع عنه. سيتم حذف السؤال نهائياً.
//           </p>
//         </div>
//       </Modal>
//     </Card>
//   );
// }
__turbopack_context__.s([
    "default",
    ()=>DisplayQuestions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit3$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/pen-line.js [app-ssr] (ecmascript) <export default as Edit3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-ssr] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/save.js [app-ssr] (ecmascript) <export default as Save>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/chevron-down.js [app-ssr] (ecmascript) <export default as ChevronDown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/chevron-up.js [app-ssr] (ecmascript) <export default as ChevronUp>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$empty$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Empty$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/empty/index.js [app-ssr] (ecmascript) <export default as Empty>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$spin$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Spin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/spin/index.js [app-ssr] (ecmascript) <export default as Spin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tag$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/tag/index.js [app-ssr] (ecmascript) <export default as Tag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/shared/lib/app-dynamic.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamCard$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$MathTypeEditor$2f$MathTypeEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/MathTypeEditor/MathTypeEditor.jsx [app-ssr] (ecmascript)");
;
"use client";
;
;
;
;
;
;
;
;
;
const ReactQuill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(async ()=>{}, {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/nartaqi/node_modules/react-quill-new/lib/index.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
;
;
const { confirm } = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"];
function DisplayQuestions({ selectedSectionId, setEditingQuestion, selectedSection }) {
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const { get_exam_questions_list, get_exam_questions_loading, delete_question_loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam);
    const [expandedQuestions, setExpandedQuestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [editingQuestionId, setEditingQuestionId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [editingContent, setEditingContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [editingOptions, setEditingOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [editingCorrectAnswer, setEditingCorrectAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [editingParagraphContent, setEditingParagraphContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [editingParagraphQuestions, setEditingParagraphQuestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [deleteModal, setDeleteModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [questionToDelete, setQuestionToDelete] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [sectionName, setSectionName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (get_exam_questions_list) {
            const initial = {};
            (get_exam_questions_list?.data?.message?.mcq || []).forEach((q)=>initial[`mcq-${q.id}`] = false);
            (get_exam_questions_list?.data?.message?.paragraphs || []).forEach((p)=>initial[`paragraph-${p.paragraph.id}`] = false);
            setExpandedQuestions(initial);
        }
    }, [
        get_exam_questions_list
    ]);
    const quillModules = {
        toolbar: [
            [
                {
                    header: [
                        1,
                        2,
                        3,
                        false
                    ]
                }
            ],
            [
                'bold',
                'italic',
                'underline'
            ],
            [
                {
                    list: 'ordered'
                },
                {
                    list: 'bullet'
                }
            ],
            [
                {
                    align: []
                }
            ],
            [
                'clean'
            ],
            [
                'link',
                'image',
                'formula'
            ]
        ]
    };
    const quillFormats = [
        'header',
        'bold',
        'italic',
        'underline',
        'list',
        'bullet',
        'align',
        'link',
        'image',
        'formula'
    ];
    const apiQuestions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (!get_exam_questions_list && !selectedSection) return [];
        const data = get_exam_questions_list?.data?.message || {
            mcq: [],
            paragraphs: []
        };
        const mcqs = (data?.mcq && data?.mcq?.length ? data?.mcq : selectedSection?.mcq && selectedSection?.mcq?.length ? selectedSection?.mcq : []).map((q)=>{
            const options = q?.options || [];
            const correctIndex = options.findIndex((opt)=>Number(opt?.is_correct) === 1);
            return {
                id: q.id,
                type: "mcq",
                question: q?.question_text || "",
                correctAnswer: correctIndex >= 0 ? correctIndex : 0,
                options: options.map((opt)=>({
                        text: opt.option_text || "",
                        explanation: opt.question_explanation || ""
                    })),
                rawData: q
            };
        });
        console.log("get_exam_questions_list--------", data?.mcq && data?.mcq?.length ? data?.mcq : selectedSection?.mcq && selectedSection?.mcq?.length ? selectedSection?.mcq : []);
        const paragraphs = (selectedSection?.paragraphs || []).map((p)=>({
                id: p.paragraph.id,
                type: "paragraph_mcq",
                paragraphContent: p.paragraph.paragraph_content || "",
                questions: p.questions.map((q)=>({
                        questionText: q.question_text || "",
                        options: (q.options || []).map((opt)=>({
                                text: opt.option_text || "",
                                explanation: opt.question_explanation || "",
                                isCorrect: opt.is_correct === 1
                            }))
                    })),
                rawData: p
            }));
        return [
            ...mcqs,
            ...paragraphs
        ];
    }, [
        get_exam_questions_list,
        selectedSection
    ]);
    const toggleQuestion = (id, type)=>{
        const key = `${type === 'mcq' ? 'mcq' : 'paragraph'}-${id}`;
        setExpandedQuestions((prev)=>({
                ...prev,
                [key]: !prev[key]
            }));
    };
    const isExpanded = (id, type)=>expandedQuestions[`${type === 'mcq' ? 'mcq' : 'paragraph'}-${id}`] || false;
    const startEditing = (q)=>{
        setEditingQuestionId(q.id);
        if (q.type === "mcq") {
            setEditingContent(q.question);
            setEditingOptions(q.options.map((opt)=>({
                    ...opt
                })));
            setEditingCorrectAnswer(q.correctAnswer);
        } else if (q.type === "paragraph_mcq") {
            setEditingParagraphContent(q.paragraphContent);
            setEditingParagraphQuestions(q.questions.map((pq)=>({
                    questionText: pq.questionText,
                    options: pq.options.map((opt)=>({
                            ...opt
                        }))
                })));
        }
        setEditingQuestion(q);
    };
    const cancelEditing = ()=>{
        setEditingQuestionId(null);
        setEditingContent("");
        setEditingOptions([]);
        setEditingCorrectAnswer(0);
        setEditingParagraphContent("");
        setEditingParagraphQuestions([]);
        setEditingQuestion(null);
    };
    const handleDeleteQuestion = ()=>{
        if (!questionToDelete) return;
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleDeleteExamQuestions"])({
            body: {
                id: questionToDelete.id
            }
        })).unwrap().then((res)=>{
            if (res?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم حذف السؤال بنجاح");
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetExamQuestions"])({
                    body: {
                        exam_section_id: selectedSectionId
                    }
                }));
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.data?.message || "فشل الحذف");
            }
        }).finally(()=>{
            setDeleteModal(false);
            setQuestionToDelete(null);
        });
    };
    const renderQuestionContent = (q)=>{
        const isEditing = editingQuestionId === q.id;
        if (isEditing) {
            // Editing mode - clean and spacious
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-8 py-6",
                children: [
                    q.type === "mcq" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-semibold text-gray-800 mb-3",
                                        children: "نص السؤال"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                        lineNumber: 860,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactQuill, {
                                        value: editingContent,
                                        onChange: setEditingContent,
                                        modules: quillModules,
                                        formats: quillFormats,
                                        className: "bg-white"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                        lineNumber: 861,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 859,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-semibold text-gray-800 mb-4",
                                        children: "الخيارات"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                        lineNumber: 865,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-5",
                                        children: editingOptions.map((opt, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "p-5 bg-gray-50 border border-gray-200 rounded-xl",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4 mb-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                type: "radio",
                                                                checked: editingCorrectAnswer === idx,
                                                                onChange: ()=>setEditingCorrectAnswer(idx),
                                                                className: "w-5 h-5 text-blue-600"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                lineNumber: 870,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-medium text-gray-700",
                                                                children: "الإجابة الصحيحة"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                lineNumber: 876,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "px-3 py-1 bg-indigo-100 text-indigo-700 rounded-lg text-sm font-medium",
                                                                children: String.fromCharCode(1632 + idx + 1)
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                lineNumber: 877,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                        lineNumber: 869,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "space-y-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                        className: "text-sm text-gray-600 mb-2 block",
                                                                        children: "نص الخيار"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                        lineNumber: 883,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$MathTypeEditor$2f$MathTypeEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                        editorData: opt.text,
                                                                        setEditorData: (data)=>{
                                                                            const newOpts = [
                                                                                ...editingOptions
                                                                            ];
                                                                            newOpts[idx].text = data;
                                                                            setEditingOptions(newOpts);
                                                                        }
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                        lineNumber: 884,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                lineNumber: 882,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                        className: "text-sm text-gray-600 mb-2 block",
                                                                        children: "الشرح (اختياري)"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                        lineNumber: 905,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactQuill, {
                                                                        value: opt.explanation,
                                                                        onChange: (v)=>{
                                                                            const newOpts = [
                                                                                ...editingOptions
                                                                            ];
                                                                            newOpts[idx].explanation = v;
                                                                            setEditingOptions(newOpts);
                                                                        },
                                                                        modules: quillModules,
                                                                        formats: quillFormats
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                        lineNumber: 906,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                lineNumber: 904,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                        lineNumber: 881,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, idx, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                lineNumber: 868,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                        lineNumber: 866,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 864,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true) : // Paragraph editing mode - similar spacious layout (omitted for brevity, follow same pattern)
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: "Paragraph editing UI goes here with same padding style..."
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                        lineNumber: 925,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-end gap-4 pt-6 border-t border-gray-200",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                onClick: cancelEditing,
                                size: "large",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    className: "w-5 h-5"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                    lineNumber: 929,
                                    columnNumber: 64
                                }, void 0),
                                children: "إلغاء"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 929,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                type: "primary",
                                size: "large",
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__["Save"], {
                                    className: "w-5 h-5"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                    lineNumber: 932,
                                    columnNumber: 55
                                }, void 0),
                                loading: delete_question_loading,
                                children: "حفظ التعديلات"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 932,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                        lineNumber: 928,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                lineNumber: 856,
                columnNumber: 9
            }, this);
        }
        // Normal display mode
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-8 px-2",
            children: [
                q.type === "paragraph_mcq" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-6 bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                            className: "font-bold text-blue-900 mb-4 text-lg",
                            children: "الفقرة"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                            lineNumber: 946,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            dangerouslySetInnerHTML: {
                                __html: q.paragraphContent
                            },
                            className: "text-gray-800 leading-relaxed text-base"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                            lineNumber: 947,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                    lineNumber: 945,
                    columnNumber: 11
                }, this),
                (q.type === "mcq" ? [
                    {
                        questionText: q.question,
                        options: q.options,
                        correctAnswer: q.correctAnswer
                    }
                ] : q.questions).map((item, qIdx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-5",
                        children: [
                            q.type === "paragraph_mcq" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                className: "font-bold text-gray-900 text-lg",
                                children: [
                                    "سؤال ",
                                    qIdx + 1
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 955,
                                columnNumber: 15
                            }, this),
                            q.type === "paragraph_mcq" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                dangerouslySetInnerHTML: {
                                    __html: item.questionText
                                },
                                className: "text-gray-800 leading-relaxed text-base mb-4"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 958,
                                columnNumber: 15
                            }, this),
                            q.type === "mcq" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                dangerouslySetInnerHTML: {
                                    __html: item.questionText
                                },
                                className: "text-gray-800 leading-relaxed text-base mb-5"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 961,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid gap-4",
                                children: item.options.map((opt, oIdx)=>{
                                    const isCorrect = q.type === "mcq" ? oIdx === q.correctAnswer : opt.isCorrect;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `p-5 rounded-xl border-2 transition-all ${isCorrect ? "bg-emerald-50 border-emerald-300 shadow-sm" : "bg-white border-gray-200 hover:border-gray-300"}`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-start gap-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-bold text-lg text-gray-700 mt-1",
                                                    children: [
                                                        String.fromCharCode(1632 + oIdx + 1),
                                                        "."
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                    lineNumber: 976,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            dangerouslySetInnerHTML: {
                                                                __html: opt.text
                                                            },
                                                            className: "font-medium text-gray-800 leading-relaxed"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                            lineNumber: 980,
                                                            columnNumber: 25
                                                        }, this),
                                                        opt.explanation && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mt-3 pt-3 border-t border-gray-200",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm font-medium text-gray-600",
                                                                    children: "الشرح:"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                    lineNumber: 983,
                                                                    columnNumber: 29
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    dangerouslySetInnerHTML: {
                                                                        __html: opt.explanation
                                                                    },
                                                                    className: "text-sm text-gray-600 mt-1 leading-relaxed"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                    lineNumber: 984,
                                                                    columnNumber: 29
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                            lineNumber: 982,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                    lineNumber: 979,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                            lineNumber: 975,
                                            columnNumber: 21
                                        }, this)
                                    }, oIdx, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                        lineNumber: 968,
                                        columnNumber: 19
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 964,
                                columnNumber: 13
                            }, this)
                        ]
                    }, qIdx, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                        lineNumber: 953,
                        columnNumber: 11
                    }, this)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-end gap-4 pt-8 border-t border-gray-200",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "large",
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit3$3e$__["Edit3"], {
                                className: "w-5 h-5"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 1000,
                                columnNumber: 19
                            }, void 0),
                            type: "primary",
                            ghost: true,
                            onClick: ()=>startEditing(q),
                            children: "تعديل"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                            lineNumber: 998,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "large",
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                className: "w-5 h-5"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 1009,
                                columnNumber: 19
                            }, void 0),
                            danger: true,
                            onClick: ()=>{
                                setQuestionToDelete(q);
                                setDeleteModal(true);
                            },
                            loading: delete_question_loading,
                            children: "حذف"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                            lineNumber: 1007,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                    lineNumber: 997,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
            lineNumber: 942,
            columnNumber: 7
        }, this);
    };
    if (get_exam_questions_loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center justify-center py-32",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$spin$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Spin$3e$__["Spin"], {
                    size: "large"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                    lineNumber: 1027,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "mt-4 text-gray-600",
                    children: "جاري تحميل الأسئلة..."
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                    lineNumber: 1028,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
            lineNumber: 1026,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamCard$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        title: "أسئلة الامتحان",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit3$3e$__["Edit3"],
        className: "p-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "p-6",
                children: [
                    " ",
                    apiQuestions.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$empty$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Empty$3e$__["Empty"], {
                        description: "لا توجد أسئلة في هذا القسم بعد"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                        lineNumber: 1037,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "p-8 bg-gradient-to-r from-indigo-50 to-blue-50 rounded-3xl border border-indigo-200 shadow-sm",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                className: "text-3xl font-bold text-indigo-900",
                                                dangerouslySetInnerHTML: {
                                                    __html: `قسم : ${selectedSection?.title}`
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                lineNumber: 1044,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-lg text-indigo-700 mt-2",
                                                children: [
                                                    "عدد الأسئلة: ",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "font-bold",
                                                        children: apiQuestions.length
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                        lineNumber: 1045,
                                                        columnNumber: 76
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                lineNumber: 1045,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                        lineNumber: 1043,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                    lineNumber: 1042,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 1041,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "space-y-6",
                                children: apiQuestions.map((q, index)=>{
                                    const isExp = isExpanded(q.id, q.type);
                                    const typeLabel = q.type === "mcq" ? "سؤال اختيار متعدد" : "فقرة مع أسئلة";
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden transition-all hover:shadow-xl",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                onClick: ()=>toggleQuestion(q.id, q.type),
                                                className: "flex items-center justify-between p-6 cursor-pointer hover:bg-gray-50 transition-colors",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-5",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center text-xl font-bold shadow-md",
                                                                children: index + 1
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                lineNumber: 1068,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "font-bold text-xl text-gray-900",
                                                                        children: typeLabel
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                        lineNumber: 1072,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "text-sm text-gray-600 mt-1 line-clamp-2",
                                                                        dangerouslySetInnerHTML: {
                                                                            __html: q.type === "mcq" ? q.question : q.paragraphContent || q.questions[0]?.questionText || "فقرة"
                                                                        }
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                        lineNumber: 1073,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                lineNumber: 1071,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                        lineNumber: 1067,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tag$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
                                                                color: q.type === "mcq" ? "blue" : "purple",
                                                                className: "text-sm px-4 py-1",
                                                                children: q.type === "mcq" ? "MCQ" : "فقرة"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                lineNumber: 1083,
                                                                columnNumber: 25
                                                            }, this),
                                                            isExp ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$up$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronUp$3e$__["ChevronUp"], {
                                                                className: "w-6 h-6 text-gray-500"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                lineNumber: 1087,
                                                                columnNumber: 27
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chevron$2d$down$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDown$3e$__["ChevronDown"], {
                                                                className: "w-6 h-6 text-gray-500"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                                lineNumber: 1089,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                        lineNumber: 1082,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                lineNumber: 1063,
                                                columnNumber: 21
                                            }, this),
                                            isExp && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "border-t border-gray-200 px-8 pb-8 pt-6 bg-gray-50/50",
                                                children: renderQuestionContent(q)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                                lineNumber: 1096,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, q.id, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                        lineNumber: 1058,
                                        columnNumber: 19
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                lineNumber: 1052,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                        lineNumber: 1039,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                lineNumber: 1035,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                open: deleteModal,
                onCancel: ()=>setDeleteModal(false),
                onOk: handleDeleteQuestion,
                okText: "حذف نهائياً",
                cancelText: "إلغاء",
                okButtonProps: {
                    danger: true,
                    loading: delete_question_loading
                },
                width: 500,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center py-10",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                            className: "w-20 h-20 text-red-500 mx-auto mb-6"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                            lineNumber: 1119,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-2xl font-bold text-gray-900 mb-4",
                            children: "تأكيد الحذف"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                            lineNumber: 1120,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-600 text-lg leading-relaxed",
                            children: [
                                "هل أنت متأكد من حذف هذا ",
                                questionToDelete?.type === "mcq" ? "السؤال" : "الفقرة مع أسئلتها",
                                "؟",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                    lineNumber: 1122,
                                    columnNumber: 105
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    className: "text-red-600",
                                    children: "هذا الإجراء لا رجعة فيه"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                                    lineNumber: 1123,
                                    columnNumber: 13
                                }, this),
                                "."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                            lineNumber: 1121,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                    lineNumber: 1118,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
                lineNumber: 1109,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx",
        lineNumber: 1034,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/Questions/utils/index.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "colorMap",
    ()=>colorMap,
    "exam_types",
    ()=>exam_types,
    "makeBlankMathPassage",
    ()=>makeBlankMathPassage,
    "makeBlankQuestion",
    ()=>makeBlankQuestion,
    "makeBlankTextPassage",
    ()=>makeBlankTextPassage,
    "mock_exam_section_Data",
    ()=>mock_exam_section_Data,
    "normalizeInitial",
    ()=>normalizeInitial,
    "questionTypes",
    ()=>questionTypes
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/book-open.js [app-ssr] (ecmascript) <export default as BookOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/circle-check-big.js [app-ssr] (ecmascript) <export default as CheckCircle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/clock.js [app-ssr] (ecmascript) <export default as Clock>");
;
function makeBlankQuestion() {
    return {
        id: typeof crypto !== "undefined" && crypto.randomUUID?.() || Math.random().toString(36).slice(2),
        text: "",
        allowMultipleCorrect: false,
        options: [
            {
                text: "",
                explanation: "",
                isCorrect: false
            },
            {
                text: "",
                explanation: "",
                isCorrect: false
            },
            {
                text: "",
                explanation: "",
                isCorrect: false
            },
            {
                text: "",
                explanation: "",
                isCorrect: false
            }
        ]
    };
}
function makeBlankMathPassage() {
    return {
        id: typeof crypto !== "undefined" && crypto.randomUUID?.() || Math.random().toString(36).slice(2),
        latex: "",
        allowMultipleCorrect: false,
        answers: [
            {
                text: "",
                explanation: "",
                isCorrect: false
            },
            {
                text: "",
                explanation: "",
                isCorrect: false
            }
        ]
    };
}
function makeBlankTextPassage() {
    return {
        id: typeof crypto !== "undefined" && crypto.randomUUID?.() || Math.random().toString(36).slice(2),
        text: "",
        questions: [
            makeBlankQuestion()
        ]
    };
}
function normalizeInitial(v) {
    // Final shape:
    // {
    //   questions: [...],                  // general questions
    //   mathPassages: [{ latex, answers, allowMultipleCorrect }, ...],
    //   textPassages: [{ text, questions: [...] }, ...]
    // }
    const base = {
        questions: [
            makeBlankQuestion()
        ],
        mathPassages: [
            makeBlankMathPassage()
        ],
        textPassages: []
    };
    if (!v || typeof v !== "object") return base;
    // Backward-compat from older single fields
    const migratedMath = Array.isArray(v.mathPassages) && v.mathPassages.length ? v.mathPassages : v.passageMath || v.mathAnswers ? [
        {
            ...makeBlankMathPassage(),
            latex: v.passageMath || "",
            answers: Array.isArray(v.mathAnswers) && v.mathAnswers.length ? v.mathAnswers : makeBlankMathPassage().answers,
            allowMultipleCorrect: !!v.allowMultipleCorrectMath
        }
    ] : base.mathPassages;
    const migratedText = Array.isArray(v.textPassages) && v.textPassages.length ? v.textPassages : v.hasPassage || v.passageText ? [
        {
            ...makeBlankTextPassage(),
            text: v.passageText || "",
            questions: Array.isArray(v.questions) && v.questions.length ? v.questions : [
                makeBlankQuestion()
            ]
        }
    ] : base.textPassages;
    return {
        questions: Array.isArray(v.questions) && v.questions.length ? v.questions : base.questions,
        mathPassages: migratedMath,
        textPassages: migratedText
    };
}
const mock_exam_section_Data = {
    1: [
        {
            id: 1,
            name: "القراءة والفهم",
            desc: "أسئلة الفهم والاستيعاب",
            questions: new Array(30).fill(0).map((_, i)=>({
                    id: i,
                    type: "mcq"
                }))
        },
        {
            id: 2,
            name: "القواعد النحوية",
            desc: "قواعد اللغة العربية",
            questions: new Array(25).fill(0).map((_, i)=>({
                    id: i,
                    type: "mcq"
                }))
        }
    ],
    2: [
        {
            id: 3,
            name: "الرياضيات",
            desc: "الحساب والجبر",
            questions: new Array(24).fill(0).map((_, i)=>({
                    id: i,
                    type: "mcq"
                }))
        },
        {
            id: 4,
            name: "العلوم",
            desc: "الفيزياء والكيمياء",
            questions: new Array(24).fill(0).map((_, i)=>({
                    id: i,
                    type: "mcq"
                }))
        }
    ]
};
const exam_types = [
    {
        id: 1,
        title: "تدريب",
        value: "intern",
        description: "اختبار تدريبي بدون قيود",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"],
        color: "blue"
    },
    {
        id: 2,
        title: "اختبار محاكي",
        value: "mock",
        description: "24 سؤال لكل قسم، 25 دقيقة",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"],
        color: "purple"
    }
];
const questionTypes = [
    {
        id: "mcq",
        label: "اختيار من متعدد",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"],
        color: "green"
    },
    {
        id: "trueFalse",
        label: "صح/خطأ",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$circle$2d$check$2d$big$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircle$3e$__["CheckCircle"],
        color: "blue"
    }
];
const colorMap = {
    blue: {
        cardSelected: "border-blue-500 bg-blue-50",
        icon: "text-blue-600",
        badge: "bg-blue-100 text-blue-700",
        chip: "bg-blue-100"
    },
    purple: {
        cardSelected: "border-purple-500 bg-purple-50",
        icon: "text-purple-600",
        badge: "bg-purple-100 text-purple-700",
        chip: "bg-purple-100"
    },
    green: {
        cardSelected: "border-green-500 bg-green-50",
        icon: "text-green-600",
        badge: "bg-green-100 text-green-700",
        chip: "bg-green-100"
    },
    orange: {
        cardSelected: "border-orange-500 bg-orange-50",
        icon: "text-orange-600",
        badge: "bg-orange-100 text-orange-700",
        chip: "bg-orange-100"
    }
};
}),
"[project]/Desktop/nartaqi/components/Questions/QuestionTypeSelector.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$utils$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/utils/index.jsx [app-ssr] (ecmascript)");
;
;
;
const QuestionTypeSelector = ({ questionType, colorMap, onTypeChange })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-2 md:grid-cols-4 gap-3",
        children: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$utils$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["questionTypes"].map((type)=>{
            const Icon = type.icon;
            const isSelected = questionType === type.id;
            const palette = colorMap[type.color];
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: ()=>onTypeChange(type.id),
                className: `p-4 rounded-xl border-2 transition-all duration-200 text-center group ${isSelected ? palette.cardSelected : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                        className: `h-6 w-6 mx-auto mb-2 ${isSelected ? palette.icon : "text-gray-400 group-hover:text-gray-600"}`
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionTypeSelector.jsx",
                        lineNumber: 21,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm font-medium",
                        children: type.label
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionTypeSelector.jsx",
                        lineNumber: 28,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, type.id, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionTypeSelector.jsx",
                lineNumber: 12,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0));
        })
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/QuestionTypeSelector.jsx",
        lineNumber: 5,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const __TURBOPACK__default__export__ = QuestionTypeSelector;
}),
"[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/hooks/useMathliveArabicSetupOnce.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useMathliveArabicSetupOnce
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$mathlive$2f$mathlive$2d$ssr$2e$min$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/mathlive/mathlive-ssr.min.mjs [app-ssr] (ecmascript)"); // JS only. Put CSS in app/globals.css (see note at bottom).
"use client";
;
;
function useMathliveArabicSetupOnce() {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if ("TURBOPACK compile-time truthy", 1) return;
        //TURBOPACK unreachable
        ;
    }, []);
}
}),
"[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/MathKeyboardTheme.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MathKeyboardTheme
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
function MathKeyboardTheme({ fontSize = 11, keyHeight = 48, keyPaddingV = 8, keyPaddingH = 8, keyGap = 6 }) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const STYLE_ID = "ml-keyboard-theme";
        let style = document.getElementById(STYLE_ID);
        if (!style) {
            style = document.createElement("style");
            style.id = STYLE_ID;
            document.head.appendChild(style);
        }
        style.textContent = `
:root {
  --vk-bg: #f8fafc;
  --vk-key-bg: #fff;
  --vk-key-border: #e5e7eb;
  --vk-key-shadow: 0 1px 0 rgba(0,0,0,.03), 0 2px 8px rgba(0,0,0,.06);
  --vk-key-radius: 8px; /* Slightly smaller radius */
  --vk-key-gap: ${keyGap}px;
  --vk-font: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Noto Sans Arabic", "Tajawal", "Cairo", sans-serif;
  --vk-z: 1000; /* Reduced z-index to avoid excessive overlap */
  --vk-font-size: ${fontSize}px;
  --vk-key-minh: ${keyHeight}px;
  --vk-key-pv: ${keyPaddingV}px;
  --vk-key-ph: ${keyPaddingH}px;
}

/* الجذر */
math-virtual-keyboard,
.ML__keyboard,
.ML__virtual-keyboard {
 
  border-top: 1px solid #e5e7eb !important;
  box-shadow: 0 -10px 30px rgba(0,0,0,.08) !important;
  font-family: var(--vk-font) !important;
}

/* صفوف ومباعدات */
math-virtual-keyboard .rows,
.ML__keyboard .rows,
.ML__virtual-keyboard .rows {
  padding: 8px 8px calc(8px + env(safe-area-inset-bottom, 0)) !important;
  display: grid !important;
  gap: var(--vk-key-gap) !important;
}
math-virtual-keyboard .row,
.ML__keyboard .row,
.ML__virtual-keyboard .row {
  display: grid !important;
  grid-auto-flow: column !important;
  gap: var(--vk-key-gap) !important;
  align-items: center !important;
}

/* الأزرار */
math-virtual-keyboard button,
math-virtual-keyboard .keycap,
math-virtual-keyboard .key,
.ML__keyboard button,
.ML__keyboard .keycap,
.ML__virtual-keyboard .keycap,
.ML__keyboard .key,
.ML__virtual-keyboard .key {
  border: 1px solid var(--vk-key-border) !important;
  border-radius: var(--vk-key-radius) !important;
  padding: var(--vk-key-pv) var(--vk-key-ph) !important;
  font-size: var(--vk-font-size) !important;
  line-height: 1.2 !important; /* Adjusted for better text fit */
  box-shadow: var(--vk-key-shadow) !important;
  color: #0f172a !important;
  width: auto; /* Removed fixed width to fit content */
  min-width: 100px; /* Minimum width to ensure usability */
}

/* شريط التبويبات */
math-virtual-keyboard .tabbar,
.ML__keyboard .tabbar,
.ML__virtual-keyboard .tabbar {
  background: #fff !important;
  border-bottom: 1px solid #e5e7eb !important;
  padding: 4px 8px !important;
}
math-virtual-keyboard .tabbar .tab,
.ML__keyboard .tabbar .tab,
.ML__virtual-keyboard .tabbar .tab {
  border-radius: 999px !important;
  padding: 4px 8px !important;
  margin-inline: 2px !important;
  border: 1px solid #e5e7eb !important;
  background: #fff !important;
  font-size: 12px !important;
}
math-virtual-keyboard .tabbar .tab[aria-selected="true"],
.ML__keyboard .tabbar .tab[aria-selected="true"],
.ML__virtual-keyboard .tabbar .tab[aria-selected="true"] {
}

/* مفاتيح خاصة */
math-virtual-keyboard .key[data-key="[space]"],
.ML__keyboard .key[data-key="[space]"] {
  grid-column: span 3 !important;
}
math-virtual-keyboard .key[data-key="[backspace]"],
math-virtual-keyboard .key[data-key="[hide-keyboard]"],
.ML__keyboard .key[data-key="[backspace]"],
.ML__keyboard .key[data-key="[hide-keyboard]"] {
  color: #fff !important;
  border-color: #0f172a !important;
  min-width: 60px; /* Adjusted for special keys */
}

/* ديسكتوب: تمركز وتدوير أعلى */
@media (min-width: 1024px) {
  math-virtual-keyboard,
  .ML__keyboard,
  .ML__virtual-keyboard {
    max-width: 800px !important; /* Reduced max-width */
    border-radius: 12px 12px 0 0 !important;
  }
}
`;
    }, [
        fontSize,
        keyHeight,
        keyPaddingV,
        keyPaddingH,
        keyGap
    ]);
    return null;
}
}),
"[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/MathFieldInput.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MathFieldInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$hooks$2f$useMathliveArabicSetupOnce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/hooks/useMathliveArabicSetupOnce.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$MathKeyboardTheme$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/MathKeyboardTheme.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$html2canvas$2f$dist$2f$html2canvas$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/html2canvas/dist/html2canvas.esm.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
function MathFieldInput({ value = "", onChange, className = "", placeholder = "أدخل المعادلة (LaTeX)…", options = {
    virtualKeyboardMode: "onfocus"
} }) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$hooks$2f$useMathliveArabicSetupOnce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])();
    const fieldRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const captureRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const el = fieldRef.current;
        if (!el) return;
        el.setAttribute("dir", "rtl");
        el.style.textAlign = "right";
        if (placeholder) el.setAttribute("aria-label", placeholder);
        if (options?.virtualKeyboardMode) el.setAttribute("virtual-keyboard-mode", options.virtualKeyboardMode);
        const handleInput = (e)=>onChange?.(e?.target?.value ?? "");
        const handleFocus = ()=>{
            try {
                el.executeCommand?.("showVirtualKeyboard");
            } catch  {}
        };
        el.addEventListener("input", handleInput);
        el.addEventListener("focus", handleFocus);
        return ()=>{
            el.removeEventListener("input", handleInput);
            el.removeEventListener("focus", handleFocus);
        };
    }, [
        onChange,
        placeholder,
        options?.virtualKeyboardMode
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const el = fieldRef.current;
        if (!el) return;
        if (String(el.value || "") !== String(value || "")) {
            el.value = value || "";
        }
    }, [
        value
    ]);
    const handleDownloadImage = async ()=>{
        if (!captureRef.current) return;
        try {
            const canvas = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$html2canvas$2f$dist$2f$html2canvas$2e$esm$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(captureRef.current, {
                backgroundColor: "#ffffff",
                scale: 2
            });
            const dataUrl = canvas.toDataURL("image/png");
            const link = document.createElement("a");
            link.href = dataUrl;
            link.download = "equation.png";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } catch (err) {
            console.error("Failed to capture equation image:", err);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    ref: captureRef,
                    className: "inline-block bg-white px-3 py-2 rounded-md",
                    style: {
                        direction: "rtl"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("math-field", {
                        ref: fieldRef,
                        dir: "rtl",
                        style: {
                            fontSize: "14px",
                            minHeight: "48px",
                            border: "1px solid #555",
                            borderRadius: "4px",
                            width: "100%",
                            textAlign: "right"
                        },
                        class: className
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/MathFieldInput.jsx",
                        lineNumber: 82,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/MathFieldInput.jsx",
                    lineNumber: 77,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    onClick: handleDownloadImage,
                    className: "self-start rounded-md bg-blue-600 px-4 py-1.5 text-sm font-medium text-white hover:bg-blue-700 transition",
                    children: "تحميل المعادلة كصورة"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/MathFieldInput.jsx",
                    lineNumber: 98,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/MathFieldInput.jsx",
            lineNumber: 75,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
}),
"[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/hooks/useQuillConfig.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useQuillConfig
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
"use client";
;
function useQuillConfig({ allowImages = true, onImageRequest } = {}) {
    const modules = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const toolbar = [
            [
                {
                    header: [
                        1,
                        2,
                        3,
                        false
                    ]
                }
            ],
            [
                "bold",
                "italic",
                "underline",
                "strike"
            ],
            [
                {
                    script: "sub"
                },
                {
                    script: "super"
                }
            ],
            [
                {
                    list: "ordered"
                },
                {
                    list: "bullet"
                }
            ],
            [
                {
                    align: []
                },
                {
                    direction: "rtl"
                }
            ],
            [
                {
                    color: []
                },
                {
                    background: []
                }
            ],
            [
                "link",
                "blockquote",
                "code-block",
                "clean"
            ]
        ];
        if (allowImages) toolbar.push([
            "image"
        ]);
        return {
            toolbar: allowImages ? {
                container: toolbar,
                handlers: {
                    image: ()=>typeof onImageRequest === "function" && onImageRequest()
                }
            } : toolbar,
            clipboard: {
                matchVisual: false
            },
            history: {
                delay: 500,
                maxStack: 200,
                userOnly: true
            }
        };
    }, [
        allowImages,
        onImageRequest
    ]);
    const formats = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>[
            "header",
            "bold",
            "italic",
            "underline",
            "strike",
            "script",
            "list",
            "bullet",
            "align",
            "direction",
            "color",
            "background",
            "link",
            "blockquote",
            "code-block",
            ...allowImages ? [
                "image"
            ] : []
        ], [
        allowImages
    ]);
    return {
        modules,
        formats
    };
}
}),
"[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FIXED_IMG",
    ()=>FIXED_IMG,
    "default",
    ()=>LabeledEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/shared/lib/app-dynamic.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/image.js [app-ssr] (ecmascript) <export default as Image>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$hooks$2f$useQuillConfig$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/hooks/useQuillConfig.jsx [app-ssr] (ecmascript)");
;
"use client";
;
;
;
;
;
;
const ReactQuill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(async ()=>{}, {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/nartaqi/node_modules/react-quill-new/lib/index.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
const FIXED_IMG = {
    width: 320,
    height: 200,
    objectFit: "contain"
};
async function fileToDataUrl(file) {
    if (!file) return "";
    const reader = new FileReader();
    return new Promise((resolve, reject)=>{
        reader.onerror = reject;
        reader.onload = ()=>resolve(String(reader.result || ""));
        reader.readAsDataURL(file);
    });
}
function LabeledEditor({ label, hint, value, onChange, placeholder = "اكتب هنا…", editorMinH = 140, uploadImage, imageSize = FIXED_IMG }) {
    const quillRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fileRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const openPicker = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>fileRef.current?.click(), []);
    const { modules, formats } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$hooks$2f$useQuillConfig$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({
        allowImages: true,
        onImageRequest: openPicker
    });
    const applyFixedSizeToAllImages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(()=>{
        const quill = quillRef.current?.getEditor?.();
        const root = quill?.root;
        if (!root) return;
        root.querySelectorAll("img").forEach((img)=>{
            img.style.width = `${imageSize.width}px`;
            img.style.height = `${imageSize.height}px`;
            img.style.objectFit = imageSize.objectFit || "contain";
            img.style.display = "inline-block";
        });
    }, [
        imageSize.height,
        imageSize.objectFit,
        imageSize.width
    ]);
    const handleFiles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (e)=>{
        const file = e.target.files?.[0];
        if (!file) return;
        try {
            const url = await (uploadImage ? uploadImage(file) : fileToDataUrl(file)) || "";
            const editor = quillRef.current?.getEditor?.();
            if (!editor || !url) return;
            const range = editor.getSelection(true) || {
                index: editor.getLength(),
                length: 0
            };
            editor.insertEmbed(range.index, "image", url, "user");
            editor.setSelection(range.index + 1, 0);
            requestAnimationFrame(()=>{
                const root = editor.root;
                try {
                    const img = root.querySelector(`img[src="${CSS.escape(url)}"]`);
                    if (img) {
                        img.style.width = `${imageSize.width}px`;
                        img.style.height = `${imageSize.height}px`;
                        img.style.objectFit = imageSize.objectFit || "contain";
                        img.style.display = "inline-block";
                    } else {
                        applyFixedSizeToAllImages();
                    }
                } catch  {
                    applyFixedSizeToAllImages();
                }
            });
        } finally{
            if (e?.target) e.target.value = "";
        }
    }, [
        uploadImage,
        imageSize.height,
        imageSize.objectFit,
        imageSize.width,
        applyFixedSizeToAllImages
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const quill = quillRef.current?.getEditor?.();
        if (!quill) return;
        const handler = ()=>requestAnimationFrame(applyFixedSizeToAllImages);
        quill.on("text-change", handler);
        requestAnimationFrame(applyFixedSizeToAllImages);
        return ()=>quill.off("text-change", handler);
    }, [
        applyFixedSizeToAllImages
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
            [
                "3fa97188d6fa36bb",
                [
                    editorMinH,
                    imageSize.width,
                    imageSize.height,
                    imageSize.objectFit
                ]
            ]
        ]) + " " + "space-y-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "3fa97188d6fa36bb",
                        [
                            editorMinH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                            [
                                "3fa97188d6fa36bb",
                                [
                                    editorMinH,
                                    imageSize.width,
                                    imageSize.height,
                                    imageSize.objectFit
                                ]
                            ]
                        ]) + " " + "block text-xs font-semibold text-gray-700",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, this),
                    hint ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                            [
                                "3fa97188d6fa36bb",
                                [
                                    editorMinH,
                                    imageSize.width,
                                    imageSize.height,
                                    imageSize.objectFit
                                ]
                            ]
                        ]) + " " + "text-[11px] text-gray-400",
                        children: hint
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx",
                        lineNumber: 99,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: openPicker,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                            [
                                "3fa97188d6fa36bb",
                                [
                                    editorMinH,
                                    imageSize.width,
                                    imageSize.height,
                                    imageSize.objectFit
                                ]
                            ]
                        ]) + " " + "inline-flex items-center gap-1.5 rounded-lg border border-gray-200 bg-white px-2 py-1 text-xs hover:bg-gray-50",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Image$3e$__["Image"], {
                                className: "h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx",
                                lineNumber: 106,
                                columnNumber: 13
                            }, this),
                            " أدرج صورة"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx",
                        lineNumber: 101,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx",
                lineNumber: 96,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "3fa97188d6fa36bb",
                        [
                            editorMinH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm focus-within:ring-2 focus-within:ring-blue-500/20",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactQuill, {
                    ref: quillRef,
                    value: value,
                    onChange: onChange,
                    modules: modules,
                    formats: formats,
                    placeholder: placeholder
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx",
                    lineNumber: 112,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx",
                lineNumber: 111,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ref: fileRef,
                type: "file",
                accept: "image/*",
                onChange: handleFiles,
                className: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].dynamic([
                    [
                        "3fa97188d6fa36bb",
                        [
                            editorMinH,
                            imageSize.width,
                            imageSize.height,
                            imageSize.objectFit
                        ]
                    ]
                ]) + " " + "hidden"
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx",
                lineNumber: 122,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "3fa97188d6fa36bb",
                dynamic: [
                    editorMinH,
                    imageSize.width,
                    imageSize.height,
                    imageSize.objectFit
                ],
                children: `[dir=rtl] .ql-editor{text-align:right;min-height:${editorMinH}px;direction:rtl}.ql-toolbar.ql-snow{background:#fafafa;border:0;border-bottom:1px solid #e5e7eb}.ql-container.ql-snow{border:0}.ql-editor img{object-fit:${imageSize.objectFit};display:inline-block;width:${imageSize.width}px!important;height:${imageSize.height}px!important}`
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx",
        lineNumber: 95,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AttachmentPicker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$paperclip$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Paperclip$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/paperclip.js [app-ssr] (ecmascript) <export default as Paperclip>");
"use client";
;
;
;
function AttachmentPicker({ label = "مرفقات", files = [], onAddFiles, onRemoveFile, accept = "application/pdf,image/*", multiple = true }) {
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const handlePick = ()=>inputRef.current?.click();
    const handleChange = (e)=>{
        const list = Array.from(e.target.files || []);
        if (list.length && onAddFiles) onAddFiles(list);
        e.target.value = "";
    };
    const isImage = (f)=>(f?.type || "").startsWith("image/");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: "block text-xs font-semibold text-gray-700",
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handlePick,
                        className: "inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs shadow-sm hover:bg-gray-50",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$paperclip$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Paperclip$3e$__["Paperclip"], {
                                className: "h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                                lineNumber: 32,
                                columnNumber: 11
                            }, this),
                            " اختر ملفات"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                lineNumber: 25,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                ref: inputRef,
                type: "file",
                multiple: multiple,
                accept: accept,
                onChange: handleChange,
                className: "hidden"
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            !!files?.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-2",
                children: files.map((f, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "group relative overflow-hidden rounded-lg border bg-white p-2",
                        children: [
                            isImage(f) ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                src: URL.createObjectURL(f),
                                alt: f.name,
                                className: "h-20 w-28 rounded-md object-cover"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                                lineNumber: 50,
                                columnNumber: 17
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex h-20 w-28 items-center justify-center rounded-md bg-gray-100 p-2 text-center text-[11px] text-gray-600",
                                children: f.type === "application/pdf" ? "PDF" : "ملف"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                                lineNumber: 52,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>onRemoveFile?.(idx),
                                className: "absolute right-1 top-1 hidden rounded bg-red-600 px-1.5 py-0.5 text-[10px] text-white group-hover:block",
                                children: "حذف"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                                lineNumber: 56,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-1 w-28 truncate text-[11px] text-gray-700",
                                title: f.name,
                                children: f.name
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                                lineNumber: 63,
                                columnNumber: 15
                            }, this)
                        ]
                    }, idx, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                        lineNumber: 48,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                lineNumber: 46,
                columnNumber: 9
            }, this),
            !files?.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-xs text-gray-500",
                children: "مسموح: صور وملفات PDF"
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
                lineNumber: 70,
                columnNumber: 26
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// "use client";
// import React, { useEffect, useState } from "react";
// import { Plus as PlusIcon, Trash2 } from "lucide-react";
// import MathFieldInput from "./parts/MathFieldInput";
// import LabeledEditor, { FIXED_IMG } from "./parts/LabeledEditor";
// import AttachmentPicker from "./parts/AttachmentPicker";
// /** Main editor */
// export default function McqSharedPassageEditor({
//   mcqSubType = "passage", // "passage" | "chemical" | "math"
//   initialData = [],
//   onPassagesChange,
//   uploadImage, // async (file) => url
// }) {
//   const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
//   const toOptionObject = (opt) => {
//     if (typeof opt === "string") return { latex: "", explanation: "", images: [] };
//     if (opt && typeof opt === "object")
//       return {
//         latex: opt.latex || "",
//         explanation: opt.explanation || "",
//         images: Array.isArray(opt.images) ? opt.images : [],
//       };
//     return { latex: "", explanation: "", images: [] };
//   };
//   const createQuestion = () => ({
//     id: uid(),
//     text: "",
//     options: [toOptionObject(""), toOptionObject("")],
//     correctIndex: 0,
//     attachments: [],
//   });
//   const createPassage = () => ({
//     id: uid(),
//     content: "",
//     questions: [createQuestion()],
//     attachments: [],
//   });
//   const normalize = (arr) =>
//     (arr || []).map((p) => ({
//       id: p.id || uid(),
//       content: p.content || "",
//       attachments: Array.isArray(p.attachments) ? p.attachments : [],
//       questions: (p.questions || []).map((q) => {
//         const opts =
//           Array.isArray(q.options) && q.options.length >= 2
//             ? q.options.map(toOptionObject)
//             : [toOptionObject(""), toOptionObject("")];
//         return {
//           id: q.id || uid(),
//           text: q.text || "",
//           options: opts,
//           correctIndex:
//             typeof q.correctIndex === "number" && q.correctIndex >= 0 && q.correctIndex < (opts?.length || 0)
//               ? q.correctIndex
//               : 0,
//           attachments: Array.isArray(q.attachments) ? q.attachments : [],
//         };
//       }),
//     }));
//   const [passages, setPassages] = useState(() =>
//     initialData?.length ? normalize(initialData) : [createPassage()]
//   );
//   useEffect(() => {
//     onPassagesChange?.(passages);
//   }, [passages, onPassagesChange]);
//   // ---- passage ops ----
//   const addPassage = () => setPassages((ps) => [...ps, createPassage()]);
//   const removePassage = (pId) =>
//     setPassages((ps) => (ps.length > 1 ? ps.filter((p) => p.id !== pId) : ps));
//   const updatePassageContent = (pId, content) =>
//     setPassages((ps) => ps.map((p) => (p.id === pId ? { ...p, content } : p)));
//   const addPassageFiles = (pId, files) =>
//     setPassages((ps) =>
//       ps.map((p) => (p.id === pId ? { ...p, attachments: [...(p.attachments || []), ...files] } : p))
//     );
//   const removePassageFile = (pId, fileIdx) =>
//     setPassages((ps) =>
//       ps.map((p) =>
//         p.id === pId ? { ...p, attachments: (p.attachments || []).filter((_, i) => i !== fileIdx) } : p
//       )
//     );
//   // ---- question ops ----
//   const addQuestion = (pId) =>
//     setPassages((ps) => ps.map((p) => (p.id === pId ? { ...p, questions: [...p.questions, createQuestion()] } : p)));
//   const removeQuestion = (pId, qId) =>
//     setPassages((ps) =>
//       ps.map((p) =>
//         p.id === pId
//           ? { ...p, questions: p.questions.length > 1 ? p.questions.filter((q) => q.id !== qId) : p.questions }
//           : p
//       )
//     );
//   const updateQuestionText = (pId, qId, text) =>
//     setPassages((ps) =>
//       ps.map((p) => (p.id === pId ? { ...p, questions: p.questions.map((q) => (q.id === qId ? { ...q, text } : q)) } : p))
//     );
//   // ---- options ops ----
//   const addOption = (pId, qId) =>
//     setPassages((ps) =>
//       ps.map((p) =>
//         p.id === pId
//           ? {
//               ...p,
//               questions: p.questions.map((q) =>
//                 q.id === qId ? { ...q, options: [...q.options, { latex: "", explanation: "", images: [] }] } : q
//               ),
//             }
//           : p
//       )
//     );
//   const removeOption = (pId, qId, optIndex) =>
//     setPassages((ps) =>
//       ps.map((p) => {
//         if (p.id !== pId) return p;
//         return {
//           ...p,
//           questions: p.questions.map((q) => {
//             if (q.id !== qId) return q;
//             if (q.options.length <= 2) return q;
//             const nextOpts = q.options.filter((_, i) => i !== optIndex);
//             let nextCorrect = q.correctIndex;
//             if (optIndex <= q.correctIndex) nextCorrect = Math.max(0, nextCorrect - 1);
//             if (nextCorrect >= nextOpts.length) nextCorrect = nextOpts.length - 1;
//             return { ...q, options: nextOpts, correctIndex: nextCorrect };
//           }),
//         };
//       })
//     );
//   const updateOptionField = (pId, qId, optIndex, field, value) =>
//     setPassages((ps) =>
//       ps.map((p) =>
//         p.id === pId
//           ? {
//               ...p,
//               questions: p.questions.map((q) => {
//                 if (q.id !== qId) return q;
//                 const next = q.options.map((opt, i) => (i === optIndex ? { ...opt, [field]: value } : opt));
//                 return { ...q, options: next };
//               }),
//             }
//           : p
//       )
//     );
//   const addOptionImages = (pId, qId, optIndex, files) =>
//     setPassages((ps) =>
//       ps.map((p) =>
//         p.id === pId
//           ? {
//               ...p,
//               questions: p.questions.map((q) => {
//                 if (q.id !== qId) return q;
//                 const next = q.options.map((opt, i) =>
//                   i === optIndex ? { ...opt, images: [...(opt.images || []), ...files] } : opt
//                 );
//                 return { ...q, options: next };
//               }),
//             }
//           : p
//       )
//     );
//   const removeOptionImage = (pId, qId, optIndex, imgIdx) =>
//     setPassages((ps) =>
//       ps.map((p) =>
//         p.id === pId
//           ? {
//               ...p,
//               questions: p.questions.map((q) => {
//                 if (q.id !== qId) return q;
//                 const next = q.options.map((opt, i) =>
//                   i === optIndex ? { ...opt, images: (opt.images || []).filter((_, k) => k !== imgIdx) } : opt
//                 );
//                 return { ...q, options: next };
//               }),
//             }
//           : p
//       )
//     );
//   const setCorrectIndex = (pId, qId, idx) =>
//     setPassages((ps) =>
//       ps.map((p) =>
//         p.id === pId ? { ...p, questions: p.questions.map((q) => (q.id === qId ? { ...q, correctIndex: idx } : q)) } : p
//       )
//     );
//   const isPassage = mcqSubType === "passage";
//   const isChemical = mcqSubType === "chemical";
//   const isMath = mcqSubType === "math" || mcqSubType === "chemical";
//   return (
//     <div className="space-y-6" dir="rtl">
//       <div className="flex items-center justify-between">
//         <h4 className="font-semibold text-gray-900">
//           {isPassage
//             ? "إدارة القطع وأسئلتها"
//             : isMath
//             ? "أسئلة معادلات — الإجابات معادلات + دعم مرفقات صور/PDF"
//             : "أسئلة (وصف/تعليمات عامة)"}
//         </h4>
//         {isPassage && (
//           <button
//             type="button"
//             onClick={addPassage}
//             className="inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm shadow-sm hover:bg-gray-50"
//           >
//             <PlusIcon className="h-4 w-4" />
//             إضافة قطعة
//           </button>
//         )}
//       </div>
//       {passages.map((p, pIndex) => {
//         const questionsCount = p.questions?.length || 0;
//         return (
//           <div key={p.id} className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
//             <div className="flex items-center justify-between border-b bg-gray-50 px-4 py-3">
//               <div className="flex items-center gap-3">
//                 <div className="text-sm font-semibold text-gray-800">
//                   {isPassage ? `قطعة ${pIndex + 1}` : isMath ? `معادلة ${pIndex + 1}` : `وصف عام ${pIndex + 1}`}
//                 </div>
//                 <span className="rounded-full border border-blue-100 bg-blue-50 px-2 py-0.5 text-[11px] text-blue-700">
//                   {questionsCount} سؤال
//                 </span>
//               </div>
//               <button
//                 type="button"
//                 onClick={() => removePassage(p.id)}
//                 className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-sm text-red-600 hover:bg-red-50 hover:text-red-700"
//                 title="حذف"
//               >
//                 <Trash2 className="h-4 w-4" /> حذف
//               </button>
//             </div>
//             {/* content */}
//             <div className="space-y-4 p-4">
//               {isChemical ? (
//                 <>
//                   <label className="block text-xs font-semibold text-gray-600">معادلات/صيغ عامة</label>
//                   <MathFieldInput
//                     value={p.content}
//                     onChange={(latex) => updatePassageContent(p.id, latex)}
//                     className="w-full"
//                     options={{ virtualKeyboardMode: "onfocus" }}
//                     placeholder="أدخل المعادلات/الصيغ العامة هنا…"
//                   />
//                 </>
//               ) : isMath ? (
//                 <>
//                   <label className="block text-xs font-semibold text-gray-600">المعادلة</label>
//                   <MathFieldInput
//                     value={p.content}
//                     onChange={(latex) => updatePassageContent(p.id, latex)}
//                     className="!w-full border border-gray-200"
//                     options={{ virtualKeyboardMode: "onfocus" }}
//                     placeholder="أدخل المعادلة هنا…"
//                   />
//                   <AttachmentPicker
//                     label="مرفقات المعادلة (صور / PDF)"
//                     files={p.attachments || []}
//                     onAddFiles={(files) => addPassageFiles(p.id, files)}
//                     onRemoveFile={(idx) => removePassageFile(p.id, idx)}
//                     accept="application/pdf,image/*"
//                     multiple
//                   />
//                 </>
//               ) : (
//                 <LabeledEditor
//                   label={isPassage ? "نص القطعة" : "وصف/تعليمات عامة (اختياري)"}
//                   value={p.content}
//                   onChange={(value) => updatePassageContent(p.id, value)}
//                   editorMinH={140}
//                   uploadImage={uploadImage}
//                   imageSize={FIXED_IMG}
//                 />
//               )}
//             </div>
//             {/* questions */}
//             <div className="p-4 pt-0">
//               {isPassage && (
//                 <div className="mb-3 flex items-center justify-between">
//                   <div className="text-sm font-semibold text-gray-700">أسئلة هذه القطعة</div>
//                   <button
//                     type="button"
//                     onClick={() => addQuestion(p.id)}
//                     className="inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm shadow-sm hover:bg-gray-50"
//                   >
//                     <PlusIcon className="h-4 w-4" /> إضافة سؤال
//                   </button>
//                 </div>
//               )}
//               <div className="space-y-4">
//                 {p.questions.map((q, qIndex) => (
//                   <div key={q.id} className="rounded-xl border border-gray-200 bg-gray-50 p-4">
//                     {isPassage && (
//                       <div className="mb-3 flex items-center justify-between">
//                         <div className="text-sm font-medium text-gray-800">سؤال {qIndex + 1}</div>
//                         <button
//                           type="button"
//                           onClick={() => removeQuestion(p.id, q.id)}
//                           className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs text-red-600 hover:bg-red-50 hover:text-red-700"
//                           title="حذف السؤال"
//                         >
//                           <Trash2 className="h-4 w-4" /> حذف
//                         </button>
//                       </div>
//                     )}
//                     {isPassage && (
//                       <LabeledEditor
//                         label="نص السؤال"
//                         value={q.text}
//                         onChange={(val) => updateQuestionText(p.id, q.id, val)}
//                         editorMinH={110}
//                         uploadImage={uploadImage}
//                         imageSize={FIXED_IMG}
//                       />
//                     )}
//                     <div className="mt-4 space-y-3">
//                       <div className="text-xs font-semibold text-gray-700">
//                         الاختيارات{isMath ? " (تُكتب كمعادلات) + مرفقات صور/PDF" : ""}
//                       </div>
//                       {q.options.map((opt, optIndex) => {
//                         const isCorrect = q.correctIndex === optIndex;
//                         const letter = String.fromCharCode(65 + optIndex);
//                         return (
//                           <div
//                             key={optIndex}
//                             className={`flex flex-col gap-3 rounded-xl border bg-white p-3 shadow-sm transition ${
//                               isCorrect ? "ring-1 ring-green-200" : "ring-1 ring-transparent"
//                             }`}
//                           >
//                             <div className="flex items-center gap-3">
//                               <span
//                                 className={`inline-flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${
//                                   isCorrect ? "bg-green-600 text-white" : "bg-gray-100 text-gray-700"
//                                 }`}
//                               >
//                                 {letter}
//                               </span>
//                               <label className="flex items-center gap-2 text-xs font-medium text-gray-600">
//                                 <input
//                                   type="radio"
//                                   name={`correct-${p.id}-${q.id}`}
//                                   checked={isCorrect}
//                                   onChange={() => setCorrectIndex(p.id, q.id, optIndex)}
//                                   className="h-4 w-4 text-blue-600 focus:ring-blue-500"
//                                   title="الإجابة الصحيحة"
//                                 />
//                                 إجابة صحيحة
//                               </label>
//                               {q.options.length > 2 && (
//                                 <button
//                                   type="button"
//                                   onClick={() => removeOption(p.id, q.id, optIndex)}
//                                   className="ml-auto rounded-lg px-2 py-1 text-xs text-red-600 hover:bg-red-50 hover:text-red-800"
//                                   title="حذف الاختيار"
//                                 >
//                                   حذف
//                                 </button>
//                               )}
//                             </div>
//                             {isMath ? (
//                               <>
//                                 <div className="space-y-2">
//                                   <label className="block text-xs font-semibold text-gray-600">معادلة الاختيار</label>
//                                   <MathFieldInput
//                                     value={opt.latex}
//                                     onChange={(latex) => updateOptionField(p.id, q.id, optIndex, "latex", latex)}
//                                     placeholder="مثال: \\frac{a+b}{c}"
//                                     className="w-full"
//                                     options={{ virtualKeyboardMode: "onfocus" }}
//                                   />
//                                 </div>
//                                 <AttachmentPicker
//                                   label="مرفقات الاختيار (صور / PDF)"
//                                   files={opt.images || []}
//                                   onAddFiles={(files) => addOptionImages(p.id, q.id, optIndex, files)}
//                                   onRemoveFile={(idx) => removeOptionImage(p.id, q.id, optIndex, idx)}
//                                   accept="application/pdf,image/*"
//                                   multiple
//                                 />
//                               </>
//                             ) : (
//                               <LabeledEditor
//                                 label="نص الاختيار"
//                                 value={opt.latex}
//                                 onChange={(val) => updateOptionField(p.id, q.id, optIndex, "latex", val)}
//                                 editorMinH={90}
//                                 uploadImage={uploadImage}
//                                 imageSize={FIXED_IMG}
//                               />
//                             )}
//                             <LabeledEditor
//                               label="شرح الاختيار (لماذا هو صحيح/خاطئ)"
//                               value={opt.explanation}
//                               onChange={(value) => updateOptionField(p.id, q.id, optIndex, "explanation", value)}
//                               editorMinH={90}
//                               uploadImage={uploadImage}
//                               imageSize={FIXED_IMG}
//                             />
//                           </div>
//                         );
//                       })}
//                       <button
//                         type="button"
//                         onClick={() => addOption(p.id, q.id)}
//                         className="inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs shadow-sm hover:bg-gray-50"
//                       >
//                         <PlusIcon className="h-4 w-4" /> إضافة خيار
//                       </button>
//                     </div>
//                   </div>
//                 ))}
//               </div>
//             </div>
//           </div>
//         );
//       })}
//     </div>
//   );
// }
__turbopack_context__.s([
    "default",
    ()=>McqSharedPassageEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/plus.js [app-ssr] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-ssr] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$MathFieldInput$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/MathFieldInput.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$LabeledEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$AttachmentPicker$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/AttachmentPicker.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$MathTypeEditor$2f$MathTypeEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/MathTypeEditor/MathTypeEditor.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
function McqSharedPassageEditor({ mcqSubType = "passage", initialData = [], onPassagesChange, uploadImage }) {
    const uid = ()=>Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    // ✅ OPTION SHAPE NOW MATCHES NORMAL MCQ
    const toOptionObject = (opt)=>{
        if (typeof opt === "string") return {
            answer: opt,
            question_explanation: "",
            images: []
        };
        if (opt && typeof opt === "object") return {
            // support old shapes + new shape
            answer: opt.answer || opt.latex || "",
            question_explanation: opt.question_explanation || opt.explanation || "",
            images: Array.isArray(opt.images) ? opt.images : []
        };
        return {
            answer: "",
            question_explanation: "",
            images: []
        };
    };
    const createQuestion = ()=>({
            id: uid(),
            text: "",
            options: [
                toOptionObject(""),
                toOptionObject("")
            ],
            correctIndex: 0,
            attachments: []
        });
    const createPassage = ()=>({
            id: uid(),
            content: "",
            questions: [
                createQuestion()
            ],
            attachments: []
        });
    const normalize = (arr)=>(arr || []).map((p)=>({
                id: p.id || uid(),
                content: p.content || "",
                attachments: Array.isArray(p.attachments) ? p.attachments : [],
                questions: (p.questions || []).map((q)=>{
                    const opts = Array.isArray(q.options) && q.options.length >= 2 ? q.options.map(toOptionObject) : [
                        toOptionObject(""),
                        toOptionObject("")
                    ];
                    return {
                        id: q.id || uid(),
                        text: q.text || "",
                        options: opts,
                        correctIndex: typeof q.correctIndex === "number" && q.correctIndex >= 0 && q.correctIndex < (opts?.length || 0) ? q.correctIndex : 0,
                        attachments: Array.isArray(q.attachments) ? q.attachments : []
                    };
                })
            }));
    const [passages, setPassages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>initialData?.length ? normalize(initialData) : [
            createPassage()
        ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        onPassagesChange?.(passages);
    }, [
        passages,
        onPassagesChange
    ]);
    // ---- passage ops ----
    const addPassage = ()=>setPassages((ps)=>[
                ...ps,
                createPassage()
            ]);
    const removePassage = (pId1)=>setPassages((ps)=>ps.length > 1 ? ps.filter((p)=>p.id !== pId1) : ps);
    const updatePassageContent = (pId1, content)=>setPassages((ps)=>ps.map((p)=>p.id === pId1 ? {
                    ...p,
                    content
                } : p));
    const addPassageFiles = (pId1, files)=>setPassages((ps)=>ps.map((p)=>p.id === pId1 ? {
                    ...p,
                    attachments: [
                        ...p.attachments || [],
                        ...files
                    ]
                } : p));
    const removePassageFile = (pId1, fileIdx)=>setPassages((ps)=>ps.map((p)=>p.id === pId1 ? {
                    ...p,
                    attachments: (p.attachments || []).filter((_, i)=>i !== fileIdx)
                } : p));
    // ---- question ops ----
    const addQuestion = (pId1)=>setPassages((ps)=>ps.map((p)=>p.id === pId1 ? {
                    ...p,
                    questions: [
                        ...p.questions,
                        createQuestion()
                    ]
                } : p));
    const removeQuestion = (pId1, qId1)=>setPassages((ps)=>ps.map((p)=>p.id === pId1 ? {
                    ...p,
                    questions: p.questions.length > 1 ? p.questions.filter((q)=>q.id !== qId1) : p.questions
                } : p));
    const updateQuestionText = (pId1, qId1, text)=>setPassages((ps)=>ps.map((p)=>p.id === pId1 ? {
                    ...p,
                    questions: p.questions.map((q)=>q.id === qId1 ? {
                            ...q,
                            text
                        } : q)
                } : p));
    // ---- options ops ----
    const addOption = (pId1, qId1)=>setPassages((ps)=>ps.map((p)=>p.id === pId1 ? {
                    ...p,
                    questions: p.questions.map((q)=>q.id === qId1 ? {
                            ...q,
                            options: [
                                ...q.options,
                                {
                                    answer: "",
                                    question_explanation: "",
                                    images: []
                                }
                            ]
                        } : q)
                } : p));
    const removeOption = (pId1, qId1, optIndex)=>setPassages((ps)=>ps.map((p)=>{
                if (p.id !== pId1) return p;
                return {
                    ...p,
                    questions: p.questions.map((q)=>{
                        if (q.id !== qId1) return q;
                        if (q.options.length <= 2) return q;
                        const nextOpts = q.options.filter((_, i)=>i !== optIndex);
                        let nextCorrect = q.correctIndex;
                        if (optIndex <= q.correctIndex) nextCorrect = Math.max(0, nextCorrect - 1);
                        if (nextCorrect >= nextOpts.length) nextCorrect = nextOpts.length - 1;
                        return {
                            ...q,
                            options: nextOpts,
                            correctIndex: nextCorrect
                        };
                    })
                };
            }));
    const updateOptionField = (pId1, qId1, optIndex, field, value)=>setPassages((ps)=>ps.map((p)=>p.id === pId1 ? {
                    ...p,
                    questions: p.questions.map((q)=>{
                        if (q.id !== qId1) return q;
                        const next = q.options.map((opt, i)=>i === optIndex ? {
                                ...opt,
                                [field]: value
                            } : opt);
                        return {
                            ...q,
                            options: next
                        };
                    })
                } : p));
    const addOptionImages = (pId1, qId1, optIndex, files)=>setPassages((ps)=>ps.map((p)=>p.id === pId1 ? {
                    ...p,
                    questions: p.questions.map((q)=>{
                        if (q.id !== qId1) return q;
                        const next = q.options.map((opt, i)=>i === optIndex ? {
                                ...opt,
                                images: [
                                    ...opt.images || [],
                                    ...files
                                ]
                            } : opt);
                        return {
                            ...q,
                            options: next
                        };
                    })
                } : p));
    const removeOptionImage = (padding, qIdpadding, optIndex, imgIdx)=>setPassages((ps)=>ps.map((p)=>p.id === pId ? {
                    ...p,
                    questions: p.questions.map((q)=>{
                        if (q.id !== qId) return q;
                        const next = q.options.map((opt, i)=>i === optIndex ? {
                                ...opt,
                                images: (opt.images || []).filter((_, k)=>k !== imgIdx)
                            } : opt);
                        return {
                            ...q,
                            options: next
                        };
                    })
                } : p));
    const setCorrectIndex = (pId1, qId1, idx)=>setPassages((ps)=>ps.map((p)=>p.id === pId1 ? {
                    ...p,
                    questions: p.questions.map((q)=>q.id === qId1 ? {
                            ...q,
                            correctIndex: idx
                        } : q)
                } : p));
    const isPassage = mcqSubType === "passage";
    const isChemical = mcqSubType === "chemical";
    const isMath = mcqSubType === "math" || mcqSubType === "chemical";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        dir: "rtl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                        className: "font-semibold text-gray-900",
                        children: isPassage ? "إدارة القطع وأسئلتها" : isMath ? "أسئلة معادلات — الإجابات معادلات + دعم مرفقات صور/PDF" : "أسئلة (وصف/تعليمات عامة)"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                        lineNumber: 751,
                        columnNumber: 9
                    }, this),
                    isPassage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: addPassage,
                        className: "inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm shadow-sm hover:bg-gray-50",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                className: "h-4 w-4"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                lineNumber: 764,
                                columnNumber: 13
                            }, this),
                            "إضافة قطعة"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                        lineNumber: 759,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                lineNumber: 750,
                columnNumber: 7
            }, this),
            passages.map((p, pIndex)=>{
                const questionsCount = p.questions?.length || 0;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between border-b bg-gray-50 px-4 py-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm font-semibold text-gray-800",
                                            children: isPassage ? `قطعة ${pIndex + 1}` : isMath ? `معادلة ${pIndex + 1}` : `وصف عام ${pIndex + 1}`
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                            lineNumber: 779,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "rounded-full border border-blue-100 bg-blue-50 px-2 py-0.5 text-[11px] text-blue-700",
                                            children: [
                                                questionsCount,
                                                " سؤال"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                            lineNumber: 786,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                    lineNumber: 778,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>removePassage(p.id),
                                    className: "inline-flex items-center gap-1 rounded-lg px-2 py-1 text-sm text-red-600 hover:bg-red-50 hover:text-red-700",
                                    title: "حذف",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                            className: "h-4 w-4"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                            lineNumber: 797,
                                            columnNumber: 17
                                        }, this),
                                        " حذف"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                    lineNumber: 791,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                            lineNumber: 777,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4 p-4",
                            children: isChemical ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-xs font-semibold text-gray-600",
                                        children: "معادلات/صيغ عامة"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                        lineNumber: 805,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$MathTypeEditor$2f$MathTypeEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        editorData: p.content,
                                        setEditorData: (data)=>updatePassageContent(p.id, data)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                        lineNumber: 808,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true) : isMath ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-xs font-semibold text-gray-600",
                                        children: "المعادلة"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                        lineNumber: 823,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$MathFieldInput$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        value: p.content,
                                        onChange: (latex)=>updatePassageContent(p.id, latex),
                                        className: "!w-full border border-gray-200",
                                        options: {
                                            virtualKeyboardMode: "onfocus"
                                        },
                                        placeholder: "أدخل المعادلة هنا…"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                        lineNumber: 826,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$AttachmentPicker$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        label: "مرفقات المعادلة (صور / PDF)",
                                        files: p.attachments || [],
                                        onAddFiles: (files)=>addPassageFiles(p.id, files),
                                        onRemoveFile: (idx)=>removePassageFile(p.id, idx),
                                        accept: "application/pdf,image/*",
                                        multiple: true
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                        lineNumber: 834,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$LabeledEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                label: isPassage ? "نص القطعة" : "وصف/تعليمات عامة (اختياري)",
                                value: p.content,
                                onChange: (value)=>updatePassageContent(p.id, value),
                                editorMinH: 140,
                                uploadImage: uploadImage,
                                imageSize: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$LabeledEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FIXED_IMG"]
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                lineNumber: 844,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                            lineNumber: 802,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "p-4 pt-0",
                            children: [
                                isPassage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mb-3 flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-sm font-semibold text-gray-700",
                                            children: "أسئلة هذه القطعة"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                            lineNumber: 861,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>addQuestion(p.id),
                                            className: "inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-2 text-sm shadow-sm hover:bg-gray-50",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                    className: "h-4 w-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                    lineNumber: 869,
                                                    columnNumber: 21
                                                }, this),
                                                " إضافة سؤال"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                            lineNumber: 864,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                    lineNumber: 860,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: p.questions.map((q, qIndex)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "rounded-xl border border-gray-200 bg-gray-50 p-4",
                                            children: [
                                                isPassage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mb-3 flex items-center justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-sm font-medium text-gray-800",
                                                            children: [
                                                                "سؤال ",
                                                                qIndex + 1
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                            lineNumber: 882,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            onClick: ()=>removeQuestion(p.id, q.id),
                                                            className: "inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs text-red-600 hover:bg-red-50 hover:text-red-700",
                                                            title: "حذف السؤال",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                    className: "h-4 w-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                    lineNumber: 891,
                                                                    columnNumber: 27
                                                                }, this),
                                                                " حذف"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                            lineNumber: 885,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                    lineNumber: 881,
                                                    columnNumber: 23
                                                }, this),
                                                isPassage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$MathTypeEditor$2f$MathTypeEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    editorData: q.text,
                                                    setEditorData: (data)=>updateQuestionText(p.id, q.id, data)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                    lineNumber: 897,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mt-4 space-y-3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "text-xs font-semibold text-gray-700",
                                                            children: [
                                                                "الاختيارات",
                                                                isMath ? " (تُكتب كمعادلات) + مرفقات صور/PDF" : ""
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                            lineNumber: 915,
                                                            columnNumber: 23
                                                        }, this),
                                                        q.options.map((opt, optIndex)=>{
                                                            const isCorrect = q.correctIndex === optIndex;
                                                            const letter = String.fromCharCode(65 + optIndex);
                                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: `flex flex-col gap-3 rounded-xl border bg-white p-3 shadow-sm transition ${isCorrect ? "ring-1 ring-green-200" : "ring-1 ring-transparent"}`,
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "flex items-center gap-3",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: `inline-flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold ${isCorrect ? "bg-green-600 text-white" : "bg-gray-100 text-gray-700"}`,
                                                                                children: letter
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                                lineNumber: 935,
                                                                                columnNumber: 31
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                className: "flex items-center gap-2 text-xs font-medium text-gray-600",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                        type: "radio",
                                                                                        name: `correct-${p.id}-${q.id}`,
                                                                                        checked: isCorrect,
                                                                                        onChange: ()=>setCorrectIndex(p.id, q.id, optIndex),
                                                                                        className: "h-4 w-4 text-blue-600 focus:ring-blue-500",
                                                                                        title: "الإجابة الصحيحة"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                                        lineNumber: 945,
                                                                                        columnNumber: 33
                                                                                    }, this),
                                                                                    "إجابة صحيحة"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                                lineNumber: 944,
                                                                                columnNumber: 31
                                                                            }, this),
                                                                            q.options.length > 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                type: "button",
                                                                                onClick: ()=>removeOption(p.id, q.id, optIndex),
                                                                                className: "ml-auto rounded-lg px-2 py-1 text-xs text-red-600 hover:bg-red-50 hover:text-red-800",
                                                                                title: "حذف الاختيار",
                                                                                children: "حذف"
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                                lineNumber: 963,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                        lineNumber: 934,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    isMath ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "space-y-2",
                                                                                children: [
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                        className: "block text-xs font-semibold text-gray-600",
                                                                                        children: "معادلة الاختيار"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                                        lineNumber: 979,
                                                                                        columnNumber: 35
                                                                                    }, this),
                                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$MathTypeEditor$2f$MathTypeEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                                        editorData: opt.answer,
                                                                                        setEditorData: (data)=>updateOptionField(p.id, q.id, optIndex, "answer", data)
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                                        lineNumber: 983,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                                lineNumber: 978,
                                                                                columnNumber: 33
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$AttachmentPicker$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                                label: "مرفقات الاختيار (صور / PDF)",
                                                                                files: opt.images || [],
                                                                                onAddFiles: (files)=>addOptionImages(p.id, q.id, optIndex, files),
                                                                                onRemoveFile: (idx)=>removeOptionImage(p.id, q.id, optIndex, idx),
                                                                                accept: "application/pdf,image/*",
                                                                                multiple: true
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                                lineNumber: 1016,
                                                                                columnNumber: 33
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$MathTypeEditor$2f$MathTypeEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                        editorData: opt.answer,
                                                                        setEditorData: (data)=>{
                                                                            onChange(p.id, q.id, optIndex, "latex", data);
                                                                        }
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                        lineNumber: 1040,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$LabeledEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                        label: "شرح الاختيار (لماذا هو صحيح/خاطئ)",
                                                                        value: opt.question_explanation,
                                                                        onChange: (value)=>updateOptionField(p.id, q.id, optIndex, "question_explanation", value),
                                                                        editorMinH: 90,
                                                                        uploadImage: uploadImage,
                                                                        imageSize: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$LabeledEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FIXED_IMG"]
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                        lineNumber: 1048,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, optIndex, true, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                lineNumber: 927,
                                                                columnNumber: 27
                                                            }, this);
                                                        }),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            onClick: ()=>addOption(p.id, q.id),
                                                            className: "inline-flex items-center gap-2 rounded-xl border border-gray-200 bg-white px-3 py-2 text-xs shadow-sm hover:bg-gray-50",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                                    className: "h-4 w-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                                    lineNumber: 1073,
                                                                    columnNumber: 25
                                                                }, this),
                                                                " إضافة خيار"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                            lineNumber: 1068,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                                    lineNumber: 914,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, q.id, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                            lineNumber: 876,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                                    lineNumber: 874,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                            lineNumber: 858,
                            columnNumber: 13
                        }, this)
                    ]
                }, p.id, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
                    lineNumber: 773,
                    columnNumber: 11
                }, this);
            })
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx",
        lineNumber: 749,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AssignExam
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundsSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/select/index.js [app-ssr] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$spin$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Spin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/spin/index.js [app-ssr] (ecmascript) <export default as Spin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Book$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/book.js [app-ssr] (ecmascript) <export default as Book>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamInput$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/ExamInput.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamCard$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
function AssignExam({ exam, lessonId }) {
    const { assign_exam_loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam);
    const examData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam);
    const { all_round_lessons, source_round_loading, source_round_list } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.rounds);
    console.log("lesson_or_round_id", examData?.all_exam_data_list?.data?.message?.exam?.id);
    const [assignData, setAssignData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        type: "full_round",
        round_id: null,
        lesson_id: null
    });
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    // Fetch rounds and lessons
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetSourceRound"])({
            page: 1,
            per_page: 1000000
        }));
    }, [
        dispatch
    ]);
    const handleTypeChange = (value)=>{
        setAssignData((prevState)=>({
                ...prevState,
                type: value,
                round_id: value === "full_round" ? prevState.round_id : null,
                lesson_id: value === "lesson" ? prevState.lesson_id : null
            }));
    };
    const handleRoundChange = (value)=>{
        setAssignData((prevState)=>({
                ...prevState,
                round_id: value,
                lesson_id: null
            }));
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetRoundLessons"])({
            body: {
                round_content_id: assignData?.round_id
            }
        }));
    }, [
        assignData.round_id
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log("assign data", exam);
    }, [
        exam
    ]);
    const handleSubmit = ()=>{
        const { type, round_id, lesson_id } = assignData;
        if (!round_id && !lesson_id) {
            alert("Please select a round or lesson to assign.");
            return;
        }
        const data_send = {
            type: type,
            exam_id: exam?.id || examData?.all_exam_data_list?.data?.message?.exam?.id,
            lesson_or_round_id: type === "lesson" ? lesson_id : round_id
        };
        console.log(data_send);
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleAssignExam"])({
            body: data_send
        })).unwrap().then((res)=>{
            console.log(res);
            if (res?.data?.status == "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم تعيين الاختبار بنجاح");
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.data?.message || "فشل في تعيين الاختبار");
            }
        }).catch((e)=>console.log(e));
    // Call dispatch or API to assign the exam (this would be handled in your backend)
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamCard$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        title: "تعيين الاختبار لدوره معينه او درس",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Book$3e$__["Book"],
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "block text-sm font-medium text-gray-700 mb-2",
                            children: "اختر الدورة"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 102,
                            columnNumber: 13
                        }, this),
                        source_round_loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$spin$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Spin$3e$__["Spin"], {
                            size: "large"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 106,
                            columnNumber: 15
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                            value: assignData.round_id,
                            onChange: handleRoundChange,
                            className: "w-full",
                            placeholder: "اختر دورة",
                            children: source_round_list?.data?.message?.data?.map((round)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"].Option, {
                                    value: round?.id,
                                    children: round?.name
                                }, round?.id, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                                    lineNumber: 115,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 108,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                    lineNumber: 101,
                    columnNumber: 11
                }, this),
                assignData.type === "lesson" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "block text-sm font-medium text-gray-700 mb-2",
                            children: "اختر الدورة"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 126,
                            columnNumber: 13
                        }, this),
                        source_round_loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$spin$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Spin$3e$__["Spin"], {
                            size: "large"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 130,
                            columnNumber: 15
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                            value: assignData.round_id,
                            onChange: handleRoundChange,
                            className: "w-full",
                            placeholder: "اختر دورة",
                            children: source_round_list?.data?.message?.data?.map((round)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"].Option, {
                                    value: round?.id,
                                    children: round?.name
                                }, round?.id, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                                    lineNumber: 139,
                                    columnNumber: 19
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 132,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                    lineNumber: 125,
                    columnNumber: 11
                }, this),
                assignData.type === "lesson" && assignData.round_id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "block text-sm font-medium text-gray-700 mb-2",
                            children: "اختر الدرس"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 151,
                            columnNumber: 13
                        }, this),
                        source_round_loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$spin$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Spin$3e$__["Spin"], {
                            size: "large"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 155,
                            columnNumber: 15
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                            value: assignData.lesson_id,
                            onChange: (value)=>setAssignData((prev)=>({
                                        ...prev,
                                        lesson_id: value
                                    })),
                            className: "w-full",
                            placeholder: "اختر درس",
                            children: all_round_lessons?.data?.message?.map((lesson)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"].Option, {
                                    value: lesson?.id,
                                    children: lesson?.title
                                }, lesson?.id, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                                    lineNumber: 164,
                                    columnNumber: 21
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 157,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                    lineNumber: 150,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-end gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            type: "default",
                            onClick: ()=>setAssignData({
                                    type: "full_round",
                                    round_id: null,
                                    lesson_id: null
                                }),
                            children: "إلغاء"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 175,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            type: "primary",
                            onClick: handleSubmit,
                            className: "!bg-blue-500 !text-white",
                            loading: assign_exam_loading,
                            disabled: !assignData.round_id && !assignData.lesson_id,
                            children: assign_exam_loading ? "جاري التعيين..." : "تعيين"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                            lineNumber: 181,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
                    lineNumber: 174,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
            lineNumber: 96,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx",
        lineNumber: 95,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/form/index.js [app-ssr] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input/index.js [app-ssr] (ecmascript) <export default as Input>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundContentSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
const AddExamVideoModal = ({ open, id, setOpen, exam_id, lesson_id })=>{
    const [form] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].useForm();
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const { add_exam_video_loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log(open, "exam_id", exam_id, "lesson_id", lesson_id);
    }, [
        exam_id,
        open,
        lesson_id
    ]);
    const handleSubmit = async (values)=>{
        try {
            setLoading(true);
            const body = {
                title: values.title,
                description: values.description || "",
                video_url: values.video_url,
                lesson_id: exam_id?.id || lesson_id || ""
            };
            const result = await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleAddExamVideo"])({
                body
            })).unwrap();
            if (result?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم إضافة الفيديو بنجاح");
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundContent"])({
                    body: {
                        round_id: id
                    }
                }));
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamData"])({
                    body: {
                        id: exam_id
                    }
                }));
                form.resetFields();
                setOpen(false);
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("فشل في إضافة الفيديو");
            }
        } catch (error) {
            console.error('Error adding exam video:', error);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء إضافة الفيديو");
        } finally{
            setLoading(false);
        }
    };
    const handleCancel = ()=>{
        form.resetFields();
        setOpen(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        title: "إضافة فيديو للاختبار",
        open: open,
        onCancel: handleCancel,
        footer: null,
        centered: true,
        width: 600,
        dir: "rtl",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
            form: form,
            layout: "vertical",
            onFinish: handleSubmit,
            className: "mt-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "title",
                    label: "عنوان الفيديو",
                    rules: [
                        {
                            required: true,
                            message: 'يرجى إدخال عنوان الفيديو'
                        },
                        {
                            min: 3,
                            message: 'العنوان يجب أن يكون على الأقل 3 أحرف'
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                        placeholder: "أدخل عنوان الفيديو",
                        size: "large"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
                        lineNumber: 85,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
                    lineNumber: 77,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "description",
                    label: "وصف الفيديو (اختياري)",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"].TextArea, {
                        placeholder: "أدخل وصف للفيديو",
                        rows: 3,
                        size: "large"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
                        lineNumber: 95,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
                    lineNumber: 91,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "video_url",
                    label: "رابط الفيديو",
                    rules: [
                        {
                            required: true,
                            message: 'يرجى إدخال رابط الفيديو'
                        },
                        {
                            type: 'url',
                            message: 'يرجى إدخال رابط صحيح'
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                        placeholder: "https://example.com/video.mp4",
                        size: "large"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
                    lineNumber: 102,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3 justify-end mt-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "large",
                            onClick: handleCancel,
                            disabled: loading,
                            children: "إلغاء"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
                            lineNumber: 117,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            type: "primary",
                            size: "large",
                            htmlType: "submit",
                            loading: loading || add_exam_video_loading,
                            className: "bg-blue-600 hover:bg-blue-700",
                            children: "إضافة الفيديو"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
                            lineNumber: 125,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
                    lineNumber: 116,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
            lineNumber: 71,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx",
        lineNumber: 62,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = AddExamVideoModal;
}),
"[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/form/index.js [app-ssr] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input/index.js [app-ssr] (ecmascript) <export default as Input>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/upload/index.js [app-ssr] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/message/index.js [app-ssr] (ecmascript) <export default as message>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/select/index.js [app-ssr] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/UploadOutlined.js [app-ssr] (ecmascript) <export default as UploadOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundContentSlice.jsx [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
const AddExamPdfModal = ({ open, setOpen, exam_id, lesson_id, id })=>{
    const [form] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].useForm();
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [fileList, setFileList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const { add_exam_pdf } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam);
    const handleUploadChange = ({ fileList: newFileList })=>{
        setFileList(newFileList);
    };
    const beforeUpload = (file)=>{
        const isPdf = file.type === "application/pdf";
        const isLt5M = file.size / 1024 / 1024 < 5; // Less than 5MB
        if (!isPdf) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("يمكنك رفع ملفات PDF فقط!");
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"].LIST_IGNORE;
        }
        if (!isLt5M) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("حجم الملف يجب أن يكون أقل من 5MB!");
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"].LIST_IGNORE;
        }
        // Prevent auto upload, we will send it manually in FormData
        return false;
    };
    const handleSubmit = async (values)=>{
        try {
            if (fileList.length === 0) {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("يرجى رفع ملف PDF");
                return;
            }
            const fileObj = fileList[0].originFileObj;
            if (!fileObj) {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("حدث خطأ في قراءة الملف، حاول مرة أخرى");
                return;
            }
            setLoading(true);
            // Build FormData to match your Postman request
            const formData = new FormData();
            formData.append("lesson_id", lesson_id || exam_id?.id || exam_id); // same as Postman
            formData.append("title", values.title);
            formData.append("description", values.description || "");
            formData.append("type", values?.type || "");
            formData.append("pdf_url", fileObj); // the actual file
            console.log("Sending FormData for add_exam_pdf");
            const result = await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleAddExamPdf"])({
                body: formData
            })).unwrap();
            if (result?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم إضافة الملف PDF بنجاح");
                // refresh round content
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundContent"])({
                    body: {
                        round_id: id
                    }
                }));
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamData"])({
                    body: {
                        id: exam_id
                    }
                }));
                form.resetFields();
                setFileList([]);
                setOpen(false);
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.error?.response?.data?.message || "فشل في إضافة الملف PDF");
            }
        } catch (error) {
            console.error("Error adding exam PDF:", error);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء إضافة الملف PDF");
        } finally{
            setLoading(false);
        }
    };
    const handleCancel = ()=>{
        form.resetFields();
        setFileList([]);
        setOpen(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        title: "إضافة ملف PDF للاختبار",
        open: open,
        onCancel: handleCancel,
        footer: null,
        centered: true,
        width: 600,
        dir: "rtl",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
            form: form,
            layout: "vertical",
            onFinish: handleSubmit,
            className: "mt-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "title",
                    label: "عنوان الملف",
                    rules: [
                        {
                            required: true,
                            message: "يرجى إدخال عنوان الملف"
                        },
                        {
                            min: 3,
                            message: "العنوان يجب أن يكون على الأقل 3 أحرف"
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                        placeholder: "أدخل عنوان الملف",
                        size: "large"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                        lineNumber: 117,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                    lineNumber: 109,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "description",
                    label: "وصف الملف (اختياري)",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"].TextArea, {
                        placeholder: "أدخل وصف للملف",
                        rows: 3,
                        size: "large"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                        lineNumber: 121,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                    lineNumber: 120,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "type",
                    label: "نوع الملف",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                        placeholder: "اختر نوع الملف",
                        options: [
                            {
                                label: "الأسئلة",
                                value: "question"
                            },
                            {
                                label: "الاجابات",
                                value: "answers"
                            }
                        ]
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                        lineNumber: 133,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                    lineNumber: 128,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    label: "رفع ملف PDF",
                    required: true,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"], {
                            accept: ".pdf",
                            beforeUpload: beforeUpload,
                            onChange: handleUploadChange,
                            fileList: fileList,
                            maxCount: 1,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__["UploadOutlined"], {}, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                                    lineNumber: 153,
                                    columnNumber: 27
                                }, void 0),
                                children: "اختر ملف PDF"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                                lineNumber: 153,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                            lineNumber: 146,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        fileList.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-green-600 mt-1",
                            children: [
                                "✓ تم اختيار ملف: ",
                                fileList[0].name
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                            lineNumber: 157,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                    lineNumber: 142,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3 justify-end mt-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "large",
                            onClick: handleCancel,
                            disabled: loading || add_exam_pdf,
                            children: "إلغاء"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                            lineNumber: 164,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            type: "primary",
                            size: "large",
                            htmlType: "submit",
                            loading: loading || add_exam_pdf,
                            className: "bg-green-600 hover:bg-green-700",
                            disabled: fileList.length === 0,
                            children: loading ? "جاري الإضافة..." : "إضافة الملف"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                            lineNumber: 168,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
                    lineNumber: 163,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
            lineNumber: 103,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx",
        lineNumber: 94,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = AddExamPdfModal;
}),
"[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/form/index.js [app-ssr] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input/index.js [app-ssr] (ecmascript) <export default as Input>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundContentSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
const EditExamVideoModal = ({ open, setOpen, rowData, setRowData, exam_id, id })=>{
    const [form] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].useForm();
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const { edit_exam_video_loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log(rowData);
        if (rowData && open) {
            form.setFieldsValue({
                title: rowData.title || '',
                description: rowData.description || '',
                video_url: rowData.video_url || rowData.video || ''
            });
        }
    }, [
        rowData,
        open,
        form
    ]);
    const handleSubmit = async (values)=>{
        try {
            setLoading(true);
            const body = {
                id: rowData.id,
                exam_id: exam_id || rowData.exam_id,
                title: values.title,
                description: values.description || "",
                video_url: values.video_url
            };
            const result = await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleEditExamVideo"])({
                body
            })).unwrap();
            console.log(result);
            if (result?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم تعديل الفيديو بنجاح");
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamData"])({
                    body: {
                        id: exam_id
                    }
                }));
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundContent"])({
                    body: {
                        round_id: id
                    }
                }));
                form.resetFields();
                setOpen(false);
                setRowData({});
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("فشل في تعديل الفيديو");
            }
        } catch (error) {
            console.error('Error editing exam video:', error);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء تعديل الفيديو");
        } finally{
            setLoading(false);
        }
    };
    const handleCancel = ()=>{
        form.resetFields();
        setOpen(false);
        setRowData({});
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        title: "تعديل فيديو الاختبار",
        open: open,
        onCancel: handleCancel,
        footer: null,
        centered: true,
        width: 600,
        dir: "rtl",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
            form: form,
            layout: "vertical",
            onFinish: handleSubmit,
            className: "mt-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "title",
                    label: "عنوان الفيديو",
                    rules: [
                        {
                            required: true,
                            message: 'يرجى إدخال عنوان الفيديو'
                        },
                        {
                            min: 3,
                            message: 'العنوان يجب أن يكون على الأقل 3 أحرف'
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                        placeholder: "أدخل عنوان الفيديو",
                        size: "large"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
                        lineNumber: 91,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
                    lineNumber: 83,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "description",
                    label: "وصف الفيديو (اختياري)",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"].TextArea, {
                        placeholder: "أدخل وصف للفيديو",
                        rows: 3,
                        size: "large"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
                        lineNumber: 101,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
                    lineNumber: 97,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "video_url",
                    label: "رابط الفيديو",
                    rules: [
                        {
                            required: true,
                            message: 'يرجى إدخال رابط الفيديو'
                        },
                        {
                            type: 'url',
                            message: 'يرجى إدخال رابط صحيح'
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                        placeholder: "https://example.com/video.mp4",
                        size: "large"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
                        lineNumber: 116,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
                    lineNumber: 108,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3 justify-end mt-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "large",
                            onClick: handleCancel,
                            disabled: loading,
                            children: "إلغاء"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
                            lineNumber: 123,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            type: "primary",
                            size: "large",
                            htmlType: "submit",
                            loading: loading || edit_exam_video_loading,
                            className: "bg-blue-600 hover:bg-blue-700",
                            children: "حفظ التعديلات"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
                            lineNumber: 131,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
                    lineNumber: 122,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
            lineNumber: 77,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx",
        lineNumber: 68,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = EditExamVideoModal;
}),
"[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/form/index.js [app-ssr] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input/index.js [app-ssr] (ecmascript) <export default as Input>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/upload/index.js [app-ssr] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/message/index.js [app-ssr] (ecmascript) <export default as message>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/select/index.js [app-ssr] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/UploadOutlined.js [app-ssr] (ecmascript) <export default as UploadOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundContentSlice.jsx [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
const EditExamPdfModal = ({ open, setOpen, pdfData, exam_id, id, lesson_id })=>{
    const [form] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].useForm();
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const [fileList, setFileList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const { edit_exam_pdf } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam || {});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (pdfData && open) {
            form.setFieldsValue({
                title: pdfData?.title || "",
                description: pdfData?.description || "",
                type: pdfData?.type || ""
            });
            // لا نعرض ملف في الـ Upload إلا لو المستخدم اختار واحد جديد
            setFileList([]);
        }
    }, [
        pdfData,
        open,
        form
    ]);
    const handleUploadChange = ({ fileList: newFileList })=>{
        setFileList(newFileList);
    };
    const beforeUpload = (file)=>{
        const isPdf = file.type === "application/pdf";
        const isLt5M = file.size / 1024 / 1024 < 5;
        if (!isPdf) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("يمكنك رفع ملفات PDF فقط!");
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"].LIST_IGNORE;
        }
        // نمنع الرفع التلقائي، هنرفع مع الفورم
        return false;
    };
    const handleSubmit = async (values)=>{
        if (!pdfData?.id) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("لا يوجد ملف محدد للتعديل");
            return;
        }
        try {
            setLoading(true);
            const formData = new FormData();
            formData.append("id", pdfData.id);
            formData.append("lesson_id", exam_id || pdfData?.exam_id);
            formData.append("title", values.title);
            formData.append("description", values.description || "");
            formData.append("type", values?.type || "");
            // لو المستخدم اختار ملف جديد نبعته، لو لأ نسيب القديم زي ما هو
            if (fileList.length > 0 && fileList[0]?.originFileObj) {
                formData.append("pdf_url", fileList[0].originFileObj);
            }
            const result = await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleEditExamPdf"])({
                body: formData
            })).unwrap();
            if (result?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم تعديل ملف PDF بنجاح");
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamData"])({
                    body: {
                        id: exam_id
                    }
                }));
                // تحديث محتوى الدورة
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundContent"])({
                    body: {
                        round_id: id
                    }
                }));
                form.resetFields();
                setFileList([]);
                setOpen(false);
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.error?.response?.data?.message || "فشل في تعديل ملف PDF");
            }
        } catch (error) {
            console.error("Error editing exam PDF:", error);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء تعديل الملف PDF");
        } finally{
            setLoading(false);
        }
    };
    const handleCancel = ()=>{
        form.resetFields();
        setFileList([]);
        setOpen(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        title: "تعديل ملف PDF للاختبار",
        open: open,
        onCancel: handleCancel,
        footer: null,
        centered: true,
        width: 600,
        dir: "rtl",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
            form: form,
            layout: "vertical",
            onFinish: handleSubmit,
            className: "mt-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "title",
                    label: "عنوان الملف",
                    rules: [
                        {
                            required: true,
                            message: "يرجى إدخال عنوان الملف"
                        },
                        {
                            min: 3,
                            message: "العنوان يجب أن يكون على الأقل 3 أحرف"
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                        placeholder: "أدخل عنوان الملف",
                        size: "large"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                        lineNumber: 121,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                    lineNumber: 113,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "description",
                    label: "وصف الملف (اختياري)",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"].TextArea, {
                        placeholder: "أدخل وصف للملف",
                        rows: 3,
                        size: "large"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                        lineNumber: 125,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                    lineNumber: 124,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "type",
                    label: "نوع الملف",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                        placeholder: "اختر نوع الملف",
                        options: [
                            {
                                label: "الأسئلة",
                                value: "question"
                            },
                            {
                                label: "الإجابات",
                                value: "answers"
                            }
                        ]
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                        lineNumber: 137,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                    lineNumber: 132,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                pdfData?.pdf_url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-3 text-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "text-gray-600",
                            children: "الملف الحالي: "
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                            lineNumber: 148,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: pdfData.pdf_url,
                            target: "_blank",
                            rel: "noreferrer",
                            className: "text-blue-600 hover:text-blue-700",
                            children: "فتح الملف الحالي"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                            lineNumber: 149,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                    lineNumber: 147,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    label: "رفع ملف PDF جديد (اختياري)",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"], {
                            accept: ".pdf",
                            beforeUpload: beforeUpload,
                            onChange: handleUploadChange,
                            fileList: fileList,
                            maxCount: 1,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__["UploadOutlined"], {}, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                                    lineNumber: 168,
                                    columnNumber: 27
                                }, void 0),
                                children: "اختر ملف PDF جديد"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                                lineNumber: 168,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                            lineNumber: 161,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-gray-500 mt-2",
                            children: "يمكنك ترك هذه الخانة فارغة إذا كنت لا تريد تغيير الملف الحالي."
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                            lineNumber: 170,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        fileList.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs text-green-600 mt-1",
                            children: [
                                "✓ تم اختيار ملف: ",
                                fileList[0].name
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                            lineNumber: 174,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                    lineNumber: 160,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3 justify-end mt-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "large",
                            onClick: handleCancel,
                            disabled: loading || edit_exam_pdf,
                            children: "إلغاء"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                            lineNumber: 181,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            type: "primary",
                            size: "large",
                            htmlType: "submit",
                            loading: loading || edit_exam_pdf,
                            className: "bg-green-600 hover:bg-green-700",
                            children: loading ? "جاري التعديل..." : "حفظ التعديلات"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                            lineNumber: 189,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
                    lineNumber: 180,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
            lineNumber: 107,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx",
        lineNumber: 98,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = EditExamPdfModal;
}),
"[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FilePdfOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FilePdfOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FilePdfOutlined.js [app-ssr] (ecmascript) <export default as FilePdfOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundContentSlice.jsx [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
const DeleteExamPdfModal = ({ open, setOpen, rowData, setRowData, id })=>{
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleDelete = async ()=>{
        try {
            setLoading(true);
            const body = {
                id: rowData?.id
            };
            const result = await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleDeleteExamPdf"])({
                body
            })).unwrap();
            if (result?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم حذف الملف بنجاح");
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamData"])({
                    body: {
                        id
                    }
                }));
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundContent"])({
                    body: {
                        round_id: id
                    }
                }));
                setOpen(false);
                setRowData({});
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.error?.response?.data?.message || "فشل في حذف الملف");
            }
        } catch (error) {
            console.error('Error deleting exam PDF:', error);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء حذف الملف");
        } finally{
            setLoading(false);
        }
    };
    const handleCancel = ()=>{
        setOpen(false);
        setRowData({});
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        title: "حذف ملف PDF",
        open: open,
        onCancel: handleCancel,
        footer: null,
        centered: true,
        width: 500,
        dir: "rtl",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center py-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FilePdfOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FilePdfOutlined$3e$__["FilePdfOutlined"], {
                    className: "text-red-500 text-5xl mb-4"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-lg font-semibold text-gray-800 mb-2",
                    children: "هل أنت متأكد من حذف هذا الملف؟"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
                    lineNumber: 62,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600 mb-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-medium",
                            children: "الملف:"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
                            lineNumber: 67,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        " ",
                        rowData?.title
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
                    lineNumber: 66,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                rowData?.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600 mb-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-medium",
                            children: "الوصف:"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
                            lineNumber: 72,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)),
                        " ",
                        rowData?.description
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
                    lineNumber: 71,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600 mb-6",
                    children: "سيتم حذف الملف بشكل دائم ولا يمكن استرجاعه."
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
                    lineNumber: 76,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3 justify-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "large",
                            onClick: handleCancel,
                            disabled: loading,
                            children: "إلغاء"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
                            lineNumber: 81,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            type: "primary",
                            size: "large",
                            onClick: handleDelete,
                            loading: loading,
                            danger: true,
                            children: "حذف الملف"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
                            lineNumber: 89,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
                    lineNumber: 80,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
            lineNumber: 59,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx",
        lineNumber: 50,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = DeleteExamPdfModal;
}),
"[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$ExclamationCircleOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ExclamationCircleOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/ExclamationCircleOutlined.js [app-ssr] (ecmascript) <export default as ExclamationCircleOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundContentSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
const DeleteExamVideoModal = ({ open, setOpen, rowData, setRowData, id })=>{
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleDelete = async ()=>{
        try {
            setLoading(true);
            const body = {
                id: rowData.id
            };
            const result = await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleDeleteExamVideo"])({
                body
            })).unwrap();
            if (result?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم حذف الفيديو بنجاح");
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamData"])({
                    body: {
                        id
                    }
                }));
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundContent"])({
                    body: {
                        round_id: id
                    }
                }));
                setOpen(false);
                setRowData({});
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("فشل في حذف الفيديو");
            }
        } catch (error) {
            console.error('Error deleting exam video:', error);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء حذف الفيديو");
        } finally{
            setLoading(false);
        }
    };
    const handleCancel = ()=>{
        setOpen(false);
        setRowData({});
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        title: "حذف فيديو الاختبار",
        open: open,
        onCancel: handleCancel,
        footer: null,
        centered: true,
        width: 500,
        dir: "rtl",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center py-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$ExclamationCircleOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ExclamationCircleOutlined$3e$__["ExclamationCircleOutlined"], {
                    className: "text-red-500 text-5xl mb-4"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx",
                    lineNumber: 58,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-lg font-semibold text-gray-800 mb-2",
                    children: "هل أنت متأكد من حذف هذا الفيديو؟"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600 mb-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "font-medium",
                            children: "العنوان:"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx",
                            lineNumber: 65,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        " ",
                        rowData?.title
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx",
                    lineNumber: 64,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600 mb-6",
                    children: "سيتم حذف الفيديو بشكل دائم ولا يمكن استرجاعه."
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx",
                    lineNumber: 68,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-3 justify-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            size: "large",
                            onClick: handleCancel,
                            disabled: loading,
                            children: "إلغاء"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx",
                            lineNumber: 73,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            type: "primary",
                            size: "large",
                            onClick: handleDelete,
                            loading: loading,
                            danger: true,
                            children: "حذف الفيديو"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx",
                            lineNumber: 81,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx",
                    lineNumber: 72,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx",
            lineNumber: 57,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx",
        lineNumber: 48,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = DeleteExamVideoModal;
}),
"[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ExamMainData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$segmented$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Segmented$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/segmented/index.js [app-ssr] (ecmascript) <export default as Segmented>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/select/index.js [app-ssr] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tag$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/tag/index.js [app-ssr] (ecmascript) <export default as Tag>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/plus.js [app-ssr] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit3$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/pen-line.js [app-ssr] (ecmascript) <export default as Edit3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/book-open.js [app-ssr] (ecmascript) <export default as BookOpen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/save.js [app-ssr] (ecmascript) <export default as Save>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$checks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ListChecks$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/list-checks.js [app-ssr] (ecmascript) <export default as ListChecks>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flask$2d$conical$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FlaskConical$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/flask-conical.js [app-ssr] (ecmascript) <export default as FlaskConical>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/file-text.js [app-ssr] (ecmascript) <export default as FileText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-ssr] (ecmascript) <export default as Trash2>");
// External components (keep your own paths)
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$QuestionStats$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/QuestionStats.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamCard$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/ExamCard.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamMainInfo$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/ExamMainInfo.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$QuestionSections$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/QuestionSections.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$TrueFalseQuestions$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/TrueFalseQuestions.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$EssayQuestions$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/EssayQuestions.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$CompleteQuestions$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/CompleteQuestions.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$DisplayQuestions$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/DisplayQuestions.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$QuestionTypeSelector$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/QuestionTypeSelector.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$utils$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/utils/index.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$McqSharedPassageEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/McqSharedPassageEditor.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$LabeledEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/McqSharedPassageEditor/parts/LabeledEditor.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$AssignExam$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/AssignExam.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$AddExamVideoModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamVideoModal.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$AddExamPdfModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/RoundContent/Exams/AddExamPdfModal.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$EditExamVideoModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamVideoModal.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$EditExamPdfModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/RoundContent/Exams/EditExamPdfModal.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$DeleteExamPdfModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamPdfModal.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$DeleteExamVideoModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/RoundContent/Exams/DeleteExamVideoModal.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$MathTypeEditor$2f$MathTypeEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/MathTypeEditor/MathTypeEditor.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function ExamMainData({ examData: editExamData, rowData = {}, setRowData, examid }) {
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const [openExamVideoModal, setOpenExamVideoModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false); // Add video
    const [openExamPdfModal, setOpenExamPdfModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false); // Add pdf
    const [openEditExamVideo, setOpenEditExamVideo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false); // Edit video
    const [openEditExamPdf, setOpenEditExamPdf] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false); // Edit pdf
    const [openDeleteExamVideo, setOpenDeleteExamVideo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false); // Delete video
    const [openDeleteExamPdf, setOpenDeleteExamPdf] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false); // Delete pdf
    const [selectedExamVideo, setSelectedExamVideo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedExamPdf, setSelectedExamPdf] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [videoRowData, setVideoRowData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [pdfRowData, setPdfRowData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    // const [openEditExamPdf, setOpenEditExamPdf] = useState(false);
    const searchparams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const lessonId = searchparams?.get("lessonId") ?? null;
    const page = searchparams.get("page");
    const pageSize = searchparams.get("pageSize");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log("exam id", examid);
    }, [
        examid
    ]);
    const [examData, setExamData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        name: "",
        duration: "",
        type: "",
        sections: []
    });
    const [filteredSection, setFilteredSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [questionType, setQuestionType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("mcq");
    // Common states
    const [currentQuestion, setCurrentQuestion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedSectionId, setSelectedSectionId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedSectionData, setSelectedSectionData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [expandedSections, setExpandedSections] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [editingQuestion, setEditingQuestion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    // True/False
    const [trueFalseAnswer, setTrueFalseAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [trueFalseExplanation, setTrueFalseExplanation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    // Essay
    const [modalAnswer, setModalAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    // Complete
    const [completeText, setCompleteText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [completeAnswers, setCompleteAnswers] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            answer: ""
        }
    ]);
    const { get_exam_questions_list, get_exam_questions_loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam);
    // MCQ (general) - Updated structure to match API
    const emptyOption = ()=>({
            answer: "",
            question_explanation: "",
            correct_or_not: "0"
        });
    const normalizeOption = (opt)=>{
        if (typeof opt === "string") return {
            answer: opt,
            question_explanation: "",
            correct_or_not: "0"
        };
        if (opt && typeof opt === "object") return {
            // IMPORTANT: support latex from chemical/math editor
            answer: opt.answer || opt.text || opt.latex || "",
            instructions: "Instructions",
            question_explanation: opt.question_explanation || opt.explanation || "",
            correct_or_not: opt.correct_or_not !== undefined && opt.correct_or_not !== null ? String(opt.correct_or_not) : "0"
        };
        return emptyOption();
    };
    const [mcqOptions, setMcqOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        emptyOption(),
        emptyOption(),
        emptyOption(),
        emptyOption()
    ]);
    const [mcqCorrectAnswer, setMcqCorrectAnswer] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    // MCQ subtype
    const [mcqSubType, setMcqSubType] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("general");
    const [mcqPassages, setMcqPassages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        chemical: [],
        passage: []
    });
    const { add_exam_loading, all_exam_loading, all_exam_list, delete_exam_loading, edit_exam_loading, get_exam_sections_list, add_question_loading, all_exam_data_list } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.exam);
    const [exmaInfoData, setExamInfoData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        title: "",
        description: "",
        free: 0,
        time: "",
        date: "",
        type: "mock",
        level: "medium",
        success_percentage: 0
    });
    const [openExamSection, setOpenExamSection] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [openExamQuestion, setOpenExamQuestion] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [filteredData, setFilteredData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"])();
    const isEditMode = Boolean(params["exam-id"]);
    /* Effects */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (examData?.type === "intern") setFilteredSection(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$utils$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mock_exam_section_Data"][1]);
        else if (examData?.type === "mock") setFilteredSection(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$utils$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mock_exam_section_Data"][2]);
        else setFilteredSection([]);
    }, [
        examData?.type
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (editExamData) setExamData(editExamData);
    }, [
        editExamData
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (examData?.sections?.length > 0 && !selectedSectionId) {
            setSelectedSectionId(examData.sections[0].id);
        }
    }, [
        examData?.sections,
        selectedSectionId,
        selectedSectionData
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (selectedSectionId) {
            const filtered = get_exam_sections_list?.data?.message?.find((item)=>item?.id == selectedSectionId);
            console.log(filtered);
            setSelectedSectionData(filtered);
        }
    }, [
        selectedSectionId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExams"])({
            page: page,
            per_page: pageSize
        })).unwrap().then((res)=>{
            console.log(res);
            console.log(res?.data?.message?.data);
        });
    }, [
        dispatch,
        params["exam-id"],
        page,
        pageSize
    ]);
    // Edit mode: load exam info
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log(params["exam-id"], all_exam_list);
        if (params["exam-id"] && !lessonId) {
            const filteredItem = all_exam_list?.data?.message?.data?.find((item)=>item?.id == params["exam-id"]);
            console.log(filteredItem);
            if (!filteredItem) return;
            setFilteredData(filteredItem);
            setExamInfoData((prev)=>({
                    ...prev,
                    id: filteredItem?.id,
                    title: filteredItem?.title,
                    description: filteredItem?.description,
                    free: filteredItem?.free,
                    level: filteredItem?.level,
                    date: filteredItem?.date,
                    time: filteredItem?.time,
                    type: filteredItem?.type,
                    success_percentage: filteredItem?.success_percentage
                }));
            setExamData((prev)=>({
                    ...prev,
                    type: lessonId ? "intern" : filteredItem?.type,
                    sections: filteredItem?.sections || prev.sections || []
                }));
            setOpenExamSection(true);
            setOpenExamQuestion(true);
        } else if (params["exam-id"] && lessonId) {
            const filteredItem = all_exam_data_list?.data?.message?.exam;
            // const filteredItem = all_exam_data_list?.data?.message?.data?.find(
            //   (item) => item?.id == params["exam-id"]
            // );
            // console.log(filteredItem)
            if (!filteredItem) return;
            setFilteredData(filteredItem);
            setExamInfoData((prev)=>({
                    ...prev,
                    id: filteredItem?.id,
                    title: filteredItem?.title,
                    description: filteredItem?.description,
                    free: filteredItem?.free,
                    level: filteredItem?.level,
                    date: filteredItem?.date,
                    time: filteredItem?.time,
                    type: "intern",
                    success_percentage: filteredItem?.success_percentage
                }));
            setExamData((prev)=>({
                    ...prev,
                    type: lessonId ? "intern" : filteredItem?.type,
                    sections: filteredItem?.sections || prev.sections || []
                }));
            setOpenExamSection(true);
            setOpenExamQuestion(true);
        }
    }, [
        params,
        all_exam_list,
        all_exam_data_list
    ]);
    /* Helpers */ const selectedSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>examData.sections.find((s)=>s.id === selectedSectionId), [
        examData.sections,
        selectedSectionId
    ]);
    // Function to handle basic exam data changes
    const handleBasicDataChange = (field, value)=>{
        setExamInfoData((prev)=>({
                ...prev,
                [field]: value
            }));
    };
    const handleExamTypeChange = (type)=>{
        setExamInfoData({
            ...exmaInfoData,
            type: type.value
        });
        setExamData({
            ...examData,
            exam_type: type.value,
            lesson_id: type.value === "full_round" ? "" : examData.lesson_id,
            sections: []
        });
    };
    const [examId, setExamId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log('editingQuestion', editingQuestion);
    }, [
        editingQuestion
    ]);
    const handleSubmitBasicData = ()=>{
        if (!exmaInfoData.title) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].warn("ادخل اسم الاختبار أولا!");
            return;
        }
        // if (!exmaInfoData.description) {
        //   toast.warn("ادخل وصف الاختبار أولا!");
        //   return;
        // }
        // if (!exmaInfoData?.time) {
        //   toast.warn("اختر وقت أولا");
        //   return;
        // }
        if (!exmaInfoData?.date) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].warn("اختر تاريخ أولا");
            return;
        }
        if (params["exam-id"]) {
            const data_send = {
                id: params["exam-id"],
                title: exmaInfoData.title,
                description: exmaInfoData.description,
                free: `${exmaInfoData.free}`,
                time: null,
                date: exmaInfoData.date,
                level: exmaInfoData?.level,
                type: lessonId ? "intern" : exmaInfoData?.type,
                success_percentage: exmaInfoData?.success_percentage
            };
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleEditExam"])({
                body: data_send
            })).unwrap().then((res)=>{
                if (res?.data?.status == "success") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم   تعديل الاختبار بنجاح!");
                    setExamId(res?.data?.message?.id);
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("هناك خطأ أثناء اضافه الاختبار");
                    setOpenExamSection(false);
                }
            }).catch(()=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء إضافة الاختبار.");
            });
        } else {
            const data_send = {
                title: exmaInfoData.title,
                description: exmaInfoData.description,
                free: JSON.stringify(exmaInfoData.free),
                time: null,
                date: exmaInfoData.date,
                level: exmaInfoData?.level,
                type: lessonId ? "intern" : exmaInfoData?.type,
                success_percentage: exmaInfoData?.success_percentage
            };
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleCreateExam"])({
                body: data_send
            })).unwrap().then((res)=>{
                if (res?.data?.status == "success") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم    !ضافة الاختبار بنجاح!");
                    setOpenExamSection(res?.data?.message);
                    if (lessonId) {
                        const data_send = {
                            type: "lesson",
                            exam_id: res?.data?.message?.id,
                            lesson_or_round_id: lessonId
                        };
                        setExamId(res?.data?.message?.id);
                        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleAssignExam"])({
                            body: data_send
                        }));
                    }
                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamSections"])({
                        body: {
                            exam_id: examid || res?.data?.message?.id
                        }
                    }));
                    setExamData({
                        ...examData,
                        sections: []
                    });
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("هناك خطأ أثناء اضافه الاختبار");
                    setOpenExamSection(false);
                }
            }).catch(()=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء إضافة الاختبار.");
            });
        }
    };
    const onAddSection = (section)=>{
        if (!section?.title) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].warn("ادخل عنوان القسم أولا !");
            return;
        }
        if (!section?.description) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].warn("ادخل وصف للقسم أولا!");
            return;
        }
        if (params["exam-id"]) {
            // edit existing section (if section has id)
            if (section.id) {
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleEditExamSection"])({
                    body: {
                        ...section
                    }
                })).unwrap().then((res)=>{
                    if (res?.data?.status == "success") {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم تعديل القسم بنجاح");
                        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamSections"])({
                            body: {
                                exam_id: examid || res?.data?.message?.section?.id
                            }
                        }));
                    } else {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.data?.message || "هناك خطأ أثناء تعديل القسم");
                    }
                }).catch((e)=>console.log(e));
                return;
            }
            // add new section in edit mode
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleCreateExamSection"])({
                body: {
                    ...section,
                    exam_id: params["exam-id"]
                }
            })).unwrap().then((res)=>{
                if (res?.data?.status == "success") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم إضافة القسم بنجاح");
                    const newSection = res?.data?.message;
                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamSections"])({
                        body: {
                            exam_id: examid || newSection?.id
                        }
                    }));
                    setOpenExamQuestion(newSection);
                    if (newSection?.id) {
                        setExamData((prev)=>({
                                ...prev,
                                sections: [
                                    ...prev.sections || [],
                                    newSection
                                ]
                            }));
                    }
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.data?.message || "هناك خطأ أثناء اضافة القسم");
                }
            }).catch((e)=>console.log(e));
            return;
        }
        // create-mode: use openExamSection.id
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleCreateExamSection"])({
            body: {
                ...section,
                exam_id: openExamSection?.id
            }
        })).unwrap().then((res)=>{
            if (res?.data?.status == "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم إضافة القسم بنجاح");
                setOpenExamQuestion(res?.data?.message);
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamSections"])({
                    body: {
                        exam_id: examid || res?.data?.message?.section?.id
                    }
                }));
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.data?.message || "هناك خطأ أثناء اضافة القسم");
            }
        }).catch((e)=>console.log(e));
    };
    const toggleSection = (sectionId)=>setExpandedSections((prev)=>({
                ...prev,
                [sectionId]: !prev[sectionId]
            }));
    const handleQuestionTypeChange = (type)=>{
        setQuestionType(type);
        resetQuestionForm();
    };
    const resetQuestionForm = ()=>{
        setCurrentQuestion("");
        setTrueFalseAnswer(null);
        setTrueFalseExplanation("");
        setModalAnswer("");
        setCompleteText("");
        setCompleteAnswers([
            {
                answer: ""
            }
        ]);
        setMcqOptions([
            emptyOption(),
            emptyOption(),
            emptyOption(),
            emptyOption()
        ]);
        setMcqCorrectAnswer(0);
        setEditingQuestion(null);
        setMcqSubType("general");
        setMcqPassages({
            chemical: [],
            passage: []
        });
    };
    const addCompleteAnswer = ()=>setCompleteAnswers((a)=>[
                ...a,
                {
                    answer: ""
                }
            ]);
    const removeCompleteAnswer = (index)=>setCompleteAnswers((a)=>a.filter((_, i)=>i !== index));
    const updateCompleteAnswer = (index, value)=>{
        setCompleteAnswers((a)=>{
            const next = [
                ...a
            ];
            next[index] = typeof value === "object" ? value : {
                answer: value
            };
            return next;
        });
    };
    // ← UPDATED: Now keeps correct_or_not in sync
    const updateMcqOption = (index, field, v)=>setMcqOptions((opts)=>{
            const next = [
                ...opts
            ];
            next[index] = {
                ...normalizeOption(next[index]),
                [field]: v
            };
            next[index].correct_or_not = mcqCorrectAnswer === index ? "1" : "0";
            return next;
        });
    const addMcqOption = ()=>setMcqOptions((opts)=>[
                ...opts,
                emptyOption()
            ]);
    const removeMcqOption = (index)=>{
        setMcqOptions((opts)=>{
            if (opts.length <= 2) return opts;
            const next = opts.filter((_, i)=>i !== index);
            setMcqCorrectAnswer((curr)=>curr >= index ? Math.max(0, curr - 1) : curr);
            return next;
        });
    };
    const getQuestionsCount = (sectionId)=>sectionId ? examData.sections.find((s)=>s.id === sectionId)?.questions?.length || 0 : 0;
    const getTotalQuestions = ()=>examData.sections.reduce((acc, s)=>acc + (s.questions?.length || 0), 0);
    const getEstimatedDuration = ()=>examData.type === "mock" ? examData.sections.length * 25 : parseInt(examData.duration || "0");
    const canAddMoreQuestions = (sectionId)=>!sectionId ? false : examData.type !== "mock" ? true : getQuestionsCount(sectionId) < 24;
    const handleMcqPassagesChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])((passages)=>setMcqPassages((prev)=>({
                ...prev,
                [mcqSubType]: passages
            })), [
        mcqSubType
    ]);
    // أضف هذه الوظيفة في ExamMainData component
    const editQuestion = async (question)=>{
        // تحضير البيانات حسب نوع السؤال
        let updatedQuestionData = {
            id: question.id,
            question_text: question.question_text || currentQuestion,
            instructions: question.instructions || "Instructions"
        };
        // إضافة البيانات حسب نوع السؤال
        switch(questionType){
            case "mcq":
                if (mcqSubType === "general") {
                    updatedQuestionData = {
                        ...updatedQuestionData,
                        mcq_array: mcqOptions.map((opt, idx)=>({
                                ...normalizeOption(opt),
                                correct_or_not: mcqCorrectAnswer === idx ? "1" : "0"
                            }))
                    };
                }
                break;
            case "trueFalse":
                updatedQuestionData = {
                    ...updatedQuestionData,
                    question_type: "mcq",
                    mcq_array: [
                        {
                            answer: "صحيح",
                            correct_or_not: trueFalseAnswer === true ? "1" : "0",
                            question_explanation: trueFalseExplanation || ""
                        },
                        {
                            answer: "خطأ",
                            correct_or_not: trueFalseAnswer === false ? "1" : "0",
                            question_explanation: trueFalseExplanation || ""
                        }
                    ]
                };
                break;
            case "essay":
                updatedQuestionData = {
                    ...updatedQuestionData,
                    model_answer: modalAnswer
                };
                break;
            case "complete":
                updatedQuestionData = {
                    ...updatedQuestionData,
                    text: completeText,
                    answers: completeAnswers.map((a)=>a.answer).filter(Boolean)
                };
                break;
        }
        try {
            const result = await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleUpdateExamQuestions"])({
                body: updatedQuestionData
            })).unwrap();
            if (result?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم تحديث السؤال بنجاح");
                // تحديث UI بشكل فوري
                const updatedSections = examData.sections.map((section)=>{
                    if (section.id !== selectedSectionId) return section;
                    return {
                        ...section,
                        questions: section.questions.map((q)=>q.id === question.id ? {
                                ...q,
                                ...updatedQuestionData
                            } : q)
                    };
                });
                setExamData((prev)=>({
                        ...prev,
                        sections: updatedSections
                    }));
                resetQuestionForm();
                // إعادة تحميل الأسئلة من API
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetExamQuestions"])({
                    body: {
                        exam_section_id: selectedSectionId
                    }
                }));
            }
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("فشل تحديث السؤال");
        }
    };
    /* ===================== Add / Update Question ===================== */ const addOrUpdateQuestion = async ()=>{
        if (!selectedSectionId) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("يرجى اختيار قسم أولاً");
            return;
        }
        if (questionType !== "mcq" && !currentQuestion.trim()) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("يرجى كتابة نص السؤال");
            return;
        }
        const section = examData?.sections.find((s)=>s.id === selectedSectionId);
        const currentCount = section?.questions?.length || 0;
        const isMock = examData.type === "mock";
        const maxPerSection = 24;
        const canAdd = (count = 1)=>!isMock || currentCount + count <= maxPerSection;
        // ========== إذا كان في وضع تحرير ==========
        if (editingQuestion) {
            let payload;
            switch(questionType){
                case "mcq":
                    if (mcqSubType === "general") {
                        if (mcqOptions?.filter((o)=>o?.answer?.trim())?.length < 2) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("يجب إضافة خيارين على الأقل");
                            return;
                        }
                        payload = {
                            id: editingQuestion.id,
                            question_text: currentQuestion,
                            instructions: "اختر الإجابة الصحيحة",
                            exam_section_id: selectedSectionId,
                            mcq_array: mcqOptions.map((opt, idx)=>({
                                    ...normalizeOption(opt),
                                    correct_or_not: mcqCorrectAnswer === idx ? "1" : "0"
                                }))
                        };
                    } else if (mcqSubType === "passage" || mcqSubType === "chemical") {
                        // معالجة تحرير أسئلة الفقرة والمعادلات
                        const groups = mcqPassages[mcqSubType] || [];
                        if (groups.length === 0) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("يجب إضافة محتوى الفقرة/المعادلة");
                            return;
                        }
                        payload = {
                            id: editingQuestion.id,
                            question_type: mcqSubType === "passage" ? "paragraph_mcq" : "mcq",
                            paragraph_content: mcqSubType === "passage" ? groups[0]?.content : "",
                            question_text: groups[0]?.questions?.[0]?.text || currentQuestion,
                            instructions: "اختر الإجابة الصحيحة",
                            exam_section_id: selectedSectionId,
                            mcq_array: groups[0]?.questions?.[0]?.options?.map((opt, idx)=>({
                                    ...normalizeOption(opt),
                                    correct_or_not: groups[0]?.questions?.[0]?.correctIndex === idx ? "1" : "0"
                                })) || []
                        };
                    }
                    break;
                case "trueFalse":
                    if (trueFalseAnswer === null) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("اختر إجابة صحيحة");
                        return;
                    }
                    payload = {
                        id: editingQuestion.id,
                        question_text: currentQuestion,
                        instructions: "اختر الإجابة الصحيحة",
                        exam_section_id: selectedSectionId,
                        mcq_array: [
                            {
                                answer: "صحيح",
                                correct_or_not: trueFalseAnswer === true ? "1" : "0",
                                question_explanation: trueFalseExplanation || ""
                            },
                            {
                                answer: "خطأ",
                                correct_or_not: trueFalseAnswer === false ? "1" : "0",
                                question_explanation: trueFalseExplanation || ""
                            }
                        ]
                    };
                    break;
                case "essay":
                    payload = {
                        id: editingQuestion.id,
                        question_text: currentQuestion,
                        instructions: "أجب عن السؤال التالي",
                        exam_section_id: selectedSectionId,
                        model_answer: modalAnswer
                    };
                    break;
                case "complete":
                    if (!completeText.trim()) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("اكتب نص الجملة");
                        return;
                    }
                    if (completeAnswers.filter((a)=>a.answer.trim()).length === 0) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("أضف إجابة واحدة على الأقل");
                        return;
                    }
                    payload = {
                        id: editingQuestion.id,
                        question_text: completeText,
                        instructions: "أكمل الجملة التالية",
                        exam_section_id: selectedSectionId,
                        answers: completeAnswers.map((a)=>a.answer).filter(Boolean)
                    };
                    break;
            }
            try {
                const result = await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleUpdateExamQuestions"])({
                    body: payload
                })).unwrap();
                if (result?.data?.status === "success") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم تحديث السؤال بنجاح");
                    // تحديث واجهة المستخدم فورياً
                    const updatedSections = examData.sections.map((s)=>{
                        if (s.id !== selectedSectionId) return s;
                        return {
                            ...s,
                            questions: s.questions.map((q)=>q.id === editingQuestion.id ? {
                                    ...q,
                                    ...payload
                                } : q)
                        };
                    });
                    setExamData((prev)=>({
                            ...prev,
                            sections: updatedSections
                        }));
                    resetQuestionForm();
                    // إعادة تحميل الأسئلة من API
                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetExamQuestions"])({
                        body: {
                            exam_section_id: selectedSectionId
                        }
                    }));
                }
            } catch (error) {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(error?.message || "فشل تحديث السؤال");
            }
            return; // انتهاء الدالة في وضع التحرير
        }
        /* ========== 1) MCQ with subtypes (chemical / passage) ========== */ if (questionType === "mcq" && mcqSubType !== "general") {
            const groups = mcqPassages[mcqSubType] || [];
            /* ----- 1A) Paragraph MCQ → paragraph_mcq payload ----- */ if (mcqSubType === "passage") {
                const flatQuestions = [];
                const paragraphPayloads = [];
                for (const group of groups){
                    if (!group?.content?.trim()) continue;
                    const groupQuestionsForPayload = [];
                    for (const q of group.questions || []){
                        if (!q.text?.trim()) continue;
                        // Normalize options and mark correct
                        const normalizedOptions = (q.options || []).map((opt, idx)=>{
                            const base = normalizeOption(opt);
                            return {
                                ...base,
                                correct_or_not: q.correctIndex === idx ? "1" : "0"
                            };
                        });
                        if (normalizedOptions.length < 2) {
                            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("كل سؤال في الفقرة يجب أن يحتوي على خيارين على الأقل");
                            return;
                        }
                        // UI-level question (flat for DisplayQuestions)
                        const flatQuestion = {
                            id: Date.now() + Math.random(),
                            question_type: "paragraph_mcq",
                            question_text: q.text,
                            exam_section_id: selectedSectionId,
                            mcqSubType,
                            mcq_array: normalizedOptions,
                            correctAnswer: q.correctIndex ?? 0,
                            paragraph_content: group.content,
                            instructions: "اختر الإجابة الصحيحة"
                        };
                        flatQuestions.push(flatQuestion);
                        // API payload inner question
                        groupQuestionsForPayload.push({
                            question_text: q.text,
                            instructions: "اختر الإجابة الصحيحة",
                            mcq_array: normalizedOptions
                        });
                    }
                    if (groupQuestionsForPayload.length) {
                        paragraphPayloads.push({
                            exam_section_id: selectedSectionId,
                            question_type: "paragraph_mcq",
                            paragraph_content: group.content,
                            questions: groupQuestionsForPayload
                        });
                    }
                }
                if (!flatQuestions.length) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("لم يتم إنشاء أي سؤال صالح للفقرة");
                    return;
                }
                const totalNewQuestions = flatQuestions.length;
                if (!canAdd(totalNewQuestions)) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(`الحد الأقصى 24 سؤال لكل قسم في الاختبار المحاكي`);
                    return;
                }
                // Optimistic UI update (flat questions)
                const updatedSections = examData.sections.map((s)=>{
                    if (s.id !== selectedSectionId) return s;
                    return {
                        ...s,
                        questions: [
                            ...s.questions || [],
                            ...flatQuestions
                        ]
                    };
                });
                setExamData((prev)=>({
                        ...prev,
                        sections: updatedSections
                    }));
                resetQuestionForm();
                try {
                    // API: send grouped paragraph_mcq payloads
                    for (const payload of paragraphPayloads){
                        await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleAddQuestion"])({
                            body: payload
                        })).unwrap().then((res)=>{
                            if (res?.data?.status == "success") {
                                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم اضافة السؤال بنجاح");
                                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetExamQuestions"])({
                                    body: {
                                        exam_section_id: res?.data?.message?.exam_section_id || res?.data?.message?.questions[0]?.exam_section_id || res?.data?.message?.paragraph[0]?.exam_section_id
                                    }
                                }));
                            }
                        });
                    }
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم حفظ أسئلة الفقرة بنجاح");
                } catch (err) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("فشل حفظ أسئلة الفقرة");
                }
                return;
            }
            /* ----- 1B) Chemical equations → behave as normal MCQ ----- */ const questionsToAdd = [];
            for (const group of groups){
                for (const q of group.questions || []){
                    // Either a specific question text or fallback to the equation content
                    if (!q.text?.trim() && !group?.content?.trim()) continue;
                    const normalizedOptions = (q.options || []).map((opt, idx)=>{
                        const base = normalizeOption(opt);
                        return {
                            ...base,
                            correct_or_not: q.correctIndex === idx ? "1" : "0"
                        };
                    });
                    if (normalizedOptions.length < 2) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("كل سؤال يجب أن يحتوي على خيارين على الأقل");
                        return;
                    }
                    questionsToAdd.push({
                        id: Date.now() + Math.random(),
                        question_type: "mcq",
                        question_text: q.text || group.content || "",
                        exam_section_id: selectedSectionId,
                        mcqSubType,
                        mcq_array: normalizedOptions,
                        correctAnswer: q.correctIndex ?? 0,
                        instructions: "اختر الاجابة الصحيحه"
                    });
                }
            }
            if (!questionsToAdd.length) {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("لم يتم إنشاء أي سؤال صالح");
                return;
            }
            if (!canAdd(questionsToAdd.length)) {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(`الحد الأقصى 24 سؤال لكل قسم في الاختبار المحاكي`);
                return;
            }
            const updatedSections = examData.sections.map((s)=>s.id === selectedSectionId ? {
                    ...s,
                    questions: [
                        ...s.questions || [],
                        ...questionsToAdd
                    ]
                } : s);
            setExamData((prev)=>({
                    ...prev,
                    sections: updatedSections
                }));
            resetQuestionForm();
            // Send each chemical question as normal MCQ to API
            for (const q of questionsToAdd){
                try {
                    const res = await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleAddQuestion"])({
                        body: q
                    })).unwrap();
                    if (res?.data?.status == "success") {
                        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم اضافة السؤال بنجاح");
                        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetExamQuestions"])({
                            body: {
                                exam_section_id: res?.data?.message?.exam_section_id || res?.data?.message?.questions[0]?.exam_section_id || res?.data?.message?.paragraph[0]?.exam_section_id
                            }
                        }));
                    }
                } catch (err) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(`فشل حفظ سؤال: ${err}`);
                }
            }
            return;
        }
        /* ========== 2) Normal questions (general MCQ, True/False, Essay, Complete) ========== */ if (isMock && !canAdd()) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("تم الوصول للحد الأقصى (24 سؤال) في هذا القسم");
            return;
        }
        const baseQuestion = {
            id: Date.now() + Math.random(),
            question_type: questionType,
            question_text: currentQuestion,
            exam_section_id: selectedSectionId,
            instructions: "Instructions"
        };
        let finalQuestion = {
            ...baseQuestion
        };
        switch(questionType){
            case "mcq":
                if (mcqOptions?.filter((o)=>o?.answer?.trim())?.length < 2) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("يجب إضافة خيارين على الأقل");
                    return;
                }
                finalQuestion = {
                    ...finalQuestion,
                    question_type: "mcq",
                    mcqSubType: "general",
                    mcq_array: mcqOptions.map((opt, idx)=>({
                            ...normalizeOption(opt),
                            correct_or_not: mcqCorrectAnswer === idx ? "1" : "0"
                        })),
                    correctAnswer: mcqCorrectAnswer
                };
                break;
            case "trueFalse":
                if (trueFalseAnswer === null) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("اختر إجابة صحيحة");
                    return;
                }
                // Treat True/False as MCQ type with 2 options
                finalQuestion = {
                    ...finalQuestion,
                    question_type: "mcq",
                    correctAnswer: trueFalseAnswer,
                    explanation: trueFalseExplanation,
                    mcq_array: [
                        {
                            answer: "صحيح",
                            correct_or_not: trueFalseAnswer === true ? "1" : "0",
                            question_explanation: trueFalseExplanation || ""
                        },
                        {
                            answer: "خطأ",
                            correct_or_not: trueFalseAnswer === false ? "1" : "0",
                            question_explanation: trueFalseExplanation || ""
                        }
                    ]
                };
                break;
            case "essay":
                finalQuestion = {
                    ...finalQuestion,
                    model_answer: modalAnswer
                };
                break;
            case "complete":
                if (!completeText.trim()) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("اكتب نص الجملة");
                    return;
                }
                if (completeAnswers.filter((a)=>a.answer.trim()).length === 0) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("أضف إجابة واحدة على الأقل");
                    return;
                }
                finalQuestion = {
                    ...finalQuestion,
                    text: completeText,
                    answers: completeAnswers.map((a)=>a.answer).filter(Boolean)
                };
                break;
        }
        // Optimistic UI update
        const newSections = examData.sections.map((s)=>{
            if (s.id !== selectedSectionId) return s;
            return {
                ...s,
                questions: [
                    ...s.questions || [],
                    finalQuestion
                ]
            };
        });
        setExamData((prev)=>({
                ...prev,
                sections: newSections
            }));
        resetQuestionForm();
        try {
            const result = await dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleAddQuestion"])({
                body: finalQuestion
            })).unwrap();
            if (result?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم اضافة السؤال بنجاح");
                const exSectionId = result?.data?.message?.exam_section_id || selectedSectionId;
                if (exSectionId) {
                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetExamQuestions"])({
                        body: {
                            exam_section_id: exSectionId
                        }
                    }));
                }
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم إضافة السؤال بنجاح");
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(error || "فشل حفظ السؤال");
        }
    };
    const loadQuestionForEdit = (question)=>{
        setEditingQuestion(question);
        setCurrentQuestion(question.question_text || "");
        // تحديد نوع السؤال
        if (question.paragraph_content) {
            setQuestionType("mcq");
            setMcqSubType("passage");
        // معالجة أسئلة الفقرة
        } else if (question.question_type === "mcq") {
            setQuestionType("mcq");
            setMcqSubType("general");
            setMcqOptions(question.mcq_array || []);
            setMcqCorrectAnswer(question.mcq_array?.findIndex((opt)=>opt.correct_or_not === "1") || 0);
        } else if (question.question_type === "essay") {
            setQuestionType("essay");
            setModalAnswer(question.model_answer || "");
        } else if (question.question_type === "complete") {
            setQuestionType("complete");
            setCompleteText(question.text || "");
            setCompleteAnswers(question.answers?.map((ans)=>({
                    answer: ans
                })) || [
                {
                    answer: ""
                }
            ]);
        }
        // معالجة True/False
        if (question.mcq_array?.length === 2 && question.mcq_array[0].answer === "صحيح") {
            setQuestionType("trueFalse");
            setTrueFalseAnswer(question.mcq_array[0].correct_or_not === "1");
            setTrueFalseExplanation(question.mcq_array[0].question_explanation || "");
        }
    };
    const editMcqPassageQuestion = (question)=>{
        setQuestionType("mcq");
        setCurrentQuestion(question.question || "");
        setMcqSubType(question.mcqSubType || "general");
        if (question.mcqSubType && question.mcqSubType !== "general") {
            setMcqPassages((prev)=>({
                    ...prev,
                    [question.mcqSubType]: [
                        {
                            id: question.passage?.id || `${Date.now()}-p`,
                            content: question.passage?.content || "",
                            questions: [
                                {
                                    id: `${Date.now()}-q`,
                                    text: question.question || "",
                                    options: (question.options || []).map(normalizeOption),
                                    correctIndex: question.correctAnswer || 0
                                }
                            ]
                        }
                    ]
                }));
        } else {
            setMcqOptions((question.options || [
                emptyOption(),
                emptyOption(),
                emptyOption(),
                emptyOption()
            ]).map((opt, idx)=>({
                    answer: opt.answer || opt.text || "",
                    question_explanation: opt.question_explanation || opt.explanation || "",
                    correct_or_not: typeof question.correctAnswer === "number" && question.correctAnswer === idx ? "1" : "0"
                })));
            setMcqCorrectAnswer(typeof question.correctAnswer === "number" ? question.correctAnswer : 0);
        }
        setEditingQuestion(question);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamSections"])({
            body: {
                exam_id: examid || openExamSection?.id || openExamQuestion?.section?.id
            }
        }));
    }, [
        openExamSection,
        openExamQuestion,
        dispatch
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamData"])({
            body: {
                id: examid || examId
            }
        }));
    }, [
        examId,
        examid
    ]);
    // In ExamMainData component, add this useEffect to populate form when editingQuestion changes:
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (editingQuestion) {
            console.log("Editing question loaded:", editingQuestion);
            // Determine question type from the editingQuestion object
            if (editingQuestion.type === "mcq") {
                setQuestionType("mcq");
                setCurrentQuestion(editingQuestion.question || "");
                // Set MCQ options
                if (editingQuestion.options && editingQuestion.options.length > 0) {
                    // Convert options to the format expected by mcqOptions
                    const normalizedOptions = editingQuestion.options.map((opt)=>({
                            answer: opt.text || "",
                            question_explanation: opt.explanation || "",
                            correct_or_not: opt.is_correct?.toString() || "0"
                        }));
                    // Ensure we have at least 4 options
                    while(normalizedOptions.length < 4){
                        normalizedOptions.push(emptyOption());
                    }
                    setMcqOptions(normalizedOptions);
                    // Set correct answer
                    const correctIndex = editingQuestion.correctAnswer || 0;
                    setMcqCorrectAnswer(correctIndex);
                }
            } else if (editingQuestion.type === "paragraph_mcq") {
                // Handle paragraph questions
                setQuestionType("mcq");
                setMcqSubType("passage");
            // You'll need to set up passage data here
            }
        }
    }, [
        editingQuestion
    ]);
    const examIdForSections = examid || params["exam-id"] || params.examId || openExamSection?.id;
    const onSectionDeleted = (deletedSectionId)=>{
        console.log(deletedSectionId);
        // refresh redux list
        if (deletedSectionId) {
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllExamSections"])({
                body: {
                    exam_id: examIdForSections
                }
            }));
        }
    };
    /* ===================== UI ===================== */ return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-6xl mx-auto space-y-6 p-6 bg-gray-50 min-h-screen",
        dir: "rtl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamMainInfo$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                lessonId: lessonId || null,
                add_exam_loading: add_exam_loading || edit_exam_loading,
                exam_types: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$utils$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["exam_types"],
                examData: examData,
                setExamData: setExamData,
                examInfoData: exmaInfoData,
                handleBasicDataChange: handleBasicDataChange,
                handleExamTypeChange: handleExamTypeChange,
                handleSubmitBasicData: handleSubmitBasicData
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                lineNumber: 1364,
                columnNumber: 7
            }, this),
            (openExamSection || isEditMode) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$QuestionSections$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                onDeleteSection: onSectionDeleted,
                editData: filteredData,
                data: openExamQuestion,
                examData: examData,
                filteredSection: filteredSection,
                onAddSection: onAddSection
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                lineNumber: 1377,
                columnNumber: 9
            }, this),
            (openExamSection || isEditMode) && !lessonId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$AssignExam$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                lessonId: lessonId,
                exam: openExamSection || filteredData
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                lineNumber: 1388,
                columnNumber: 9
            }, this),
            openExamSection && get_exam_sections_list?.data?.message?.length || isEditMode ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamCard$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        title: "إنشاء الأسئلة",
                        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$pen$2d$line$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit3$3e$__["Edit3"],
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$QuestionTypeSelector$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    colorMap: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$utils$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["colorMap"],
                                    questionType: questionType,
                                    onTypeChange: handleQuestionTypeChange
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                    lineNumber: 1400,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "block text-sm font-medium text-gray-700",
                                                    children: "اختر القسم لإضافة السؤال"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                    lineNumber: 1409,
                                                    columnNumber: 19
                                                }, this),
                                                selectedSection && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tag$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tag$3e$__["Tag"], {
                                                    color: "blue",
                                                    children: [
                                                        "إجمالي أسئلة القسم:",
                                                        " ",
                                                        getQuestionsCount(selectedSection.id)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                    lineNumber: 1413,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                            lineNumber: 1408,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                                            style: {
                                                width: "100%",
                                                height: "105%",
                                                padding: "10px 0px"
                                            },
                                            placeholder: "اختر قسمًا",
                                            value: selectedSectionId ?? undefined,
                                            onChange: (v)=>setSelectedSectionId(v),
                                            showSearch: true,
                                            optionFilterProp: "label",
                                            dropdownStyle: {
                                                borderRadius: 12
                                            },
                                            options: get_exam_sections_list?.data?.message?.map((section)=>({
                                                    value: section?.id,
                                                    label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-start justify-between",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex-1",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "font-medium text-gray-800",
                                                                    dangerouslySetInnerHTML: {
                                                                        __html: section?.title
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1438,
                                                                    columnNumber: 29
                                                                }, void 0),
                                                                section?.description ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "text-xs text-gray-500",
                                                                    dangerouslySetInnerHTML: {
                                                                        __html: section?.description
                                                                    }
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1445,
                                                                    columnNumber: 31
                                                                }, void 0) : null
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1437,
                                                            columnNumber: 27
                                                        }, void 0)
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                        lineNumber: 1436,
                                                        columnNumber: 25
                                                    }, void 0)
                                                })),
                                            dropdownRender: (menu)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "p-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "px-2 pb-2 text-xs text-gray-500",
                                                            children: "اختر من الأقسام المضافة بالأسفل"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1459,
                                                            columnNumber: 23
                                                        }, void 0),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "rounded-xl border",
                                                            children: menu
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1462,
                                                            columnNumber: 23
                                                        }, void 0)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                    lineNumber: 1458,
                                                    columnNumber: 21
                                                }, void 0)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                            lineNumber: 1420,
                                            columnNumber: 17
                                        }, this),
                                        selectedSection && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-4 rounded-2xl border bg-white shadow-sm ring-1 ring-transparent hover:ring-blue-100 transition",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-start justify-between gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "space-y-1",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                className: "font-semibold text-gray-800",
                                                                dangerouslySetInnerHTML: {
                                                                    __html: selectedSection.title
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                lineNumber: 1471,
                                                                columnNumber: 25
                                                            }, this),
                                                            selectedSection?.description ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "text-sm text-gray-600",
                                                                dangerouslySetInnerHTML: {
                                                                    __html: selectedSection.description
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                lineNumber: 1478,
                                                                columnNumber: 27
                                                            }, this) : null
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                        lineNumber: 1470,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: `mt-1 w-4 h-4 rounded-full border-2 ${selectedSectionId ? "border-blue-500 bg-blue-500" : "border-gray-300"}`,
                                                        title: "القسم الحالي"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                        lineNumber: 1486,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                lineNumber: 1469,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                            lineNumber: 1468,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                    lineNumber: 1407,
                                    columnNumber: 15
                                }, this),
                                questionType === "mcq" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center justify-between",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "block text-sm font-medium text-gray-700",
                                                children: "نوع الأسئلة المتعددة"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                lineNumber: 1502,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                            lineNumber: 1501,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "rounded-2xl border bg-white p-3 shadow-sm",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$segmented$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Segmented$3e$__["Segmented"], {
                                                size: "large",
                                                value: mcqSubType,
                                                onChange: (v)=>setMcqSubType(v),
                                                options: [
                                                    {
                                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$list$2d$checks$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ListChecks$3e$__["ListChecks"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1516,
                                                                    columnNumber: 31
                                                                }, void 0),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "أسئلة عامة"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1517,
                                                                    columnNumber: 31
                                                                }, void 0)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1515,
                                                            columnNumber: 29
                                                        }, void 0),
                                                        value: "general"
                                                    },
                                                    {
                                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flask$2d$conical$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FlaskConical$3e$__["FlaskConical"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1525,
                                                                    columnNumber: 31
                                                                }, void 0),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "معادلات"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1526,
                                                                    columnNumber: 31
                                                                }, void 0)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1524,
                                                            columnNumber: 29
                                                        }, void 0),
                                                        value: "chemical"
                                                    },
                                                    {
                                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$file$2d$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileText$3e$__["FileText"], {
                                                                    className: "w-4 h-4"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1534,
                                                                    columnNumber: 31
                                                                }, void 0),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "قطعة"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1535,
                                                                    columnNumber: 31
                                                                }, void 0)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1533,
                                                            columnNumber: 29
                                                        }, void 0),
                                                        value: "passage"
                                                    }
                                                ]
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                lineNumber: 1508,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                            lineNumber: 1507,
                                            columnNumber: 19
                                        }, this),
                                        mcqSubType === "general" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "space-y-8",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                            className: "block text-lg font-semibold text-gray-800 mb-4",
                                                            children: "نص السؤال"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1549,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$MathTypeEditor$2f$MathTypeEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                            editorData: currentQuestion,
                                                            setEditorData: (data)=>{
                                                                setCurrentQuestion(data);
                                                            }
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1552,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                    lineNumber: 1548,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-5",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center justify-between mb-5",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "text-lg font-semibold text-gray-800",
                                                                    children: "خيارات الإجابة"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1570,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "text-sm text-gray-500",
                                                                    children: "يجب تحديد إجابة صحيحة واحدة فقط"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1573,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1569,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-6",
                                                            children: mcqOptions.map((option, index)=>{
                                                                const letter = String.fromCharCode(1632 + index + 1); // Arabic numerals: ١, ٢, ٣...
                                                                const isCorrect = mcqCorrectAnswer === index;
                                                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: `relative overflow-hidden rounded-3xl border-2 transition-all duration-300 ${isCorrect ? "border-green-400 bg-green-50/50 shadow-lg shadow-green-100" : "border-gray-200 bg-white shadow-md"}`,
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "flex items-center justify-between p-5 bg-gradient-to-r from-transparent to-transparent",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "flex items-center gap-4",
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                            className: `flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-lg font-bold shadow-md transition-colors ${isCorrect ? "bg-green-600 text-white" : "bg-gray-100 text-gray-700"}`,
                                                                                            children: letter
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                            lineNumber: 1595,
                                                                                            columnNumber: 37
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                            className: "flex items-center gap-3 cursor-pointer",
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                                    type: "radio",
                                                                                                    name: "correctAnswer",
                                                                                                    checked: isCorrect,
                                                                                                    onChange: ()=>setMcqCorrectAnswer(index),
                                                                                                    className: "h-5 w-5 text-green-600 focus:ring-green-500"
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                                    lineNumber: 1606,
                                                                                                    columnNumber: 39
                                                                                                }, this),
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "font-medium text-gray-700",
                                                                                                    children: isCorrect ? "الإجابة الصحيحة" : "تحديد كإجابة صحيحة"
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                                    lineNumber: 1613,
                                                                                                    columnNumber: 39
                                                                                                }, this),
                                                                                                isCorrect && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "px-3 py-1 text-xs font-bold text-green-700 bg-green-200 rounded-full",
                                                                                                    children: "✓ صحيحة"
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                                    lineNumber: 1617,
                                                                                                    columnNumber: 41
                                                                                                }, this)
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                            lineNumber: 1605,
                                                                                            columnNumber: 37
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                    lineNumber: 1593,
                                                                                    columnNumber: 35
                                                                                }, this),
                                                                                mcqOptions.length > 2 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                                    type: "button",
                                                                                    onClick: ()=>removeMcqOption(index),
                                                                                    className: "p-2 text-red-600 rounded-xl hover:bg-red-50 transition-colors",
                                                                                    title: "حذف هذا الخيار",
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                                                        className: "w-5 h-5"
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                        lineNumber: 1632,
                                                                                        columnNumber: 39
                                                                                    }, this)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                    lineNumber: 1626,
                                                                                    columnNumber: 37
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                            lineNumber: 1592,
                                                                            columnNumber: 33
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: "px-6 pb-6 space-y-6 border-t border-gray-100",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                            className: "block text-sm font-medium text-gray-700 mb-3",
                                                                                            children: "نص الخيار"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                            lineNumber: 1641,
                                                                                            columnNumber: 37
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$MathTypeEditor$2f$MathTypeEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                                            editorData: option.answer,
                                                                                            setEditorData: (data)=>updateMcqOption(index, "answer", data)
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                            lineNumber: 1644,
                                                                                            columnNumber: 37
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                    lineNumber: 1640,
                                                                                    columnNumber: 35
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    children: [
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                                            className: "block text-sm font-medium text-gray-700 mb-3 flex items-center gap-2",
                                                                                            children: [
                                                                                                "شرح الخيار",
                                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                                    className: "text-xs font-normal text-gray-500",
                                                                                                    children: "(يظهر بعد الإجابة في وضع المراجعة)"
                                                                                                }, void 0, false, {
                                                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                                    lineNumber: 1668,
                                                                                                    columnNumber: 39
                                                                                                }, this)
                                                                                            ]
                                                                                        }, void 0, true, {
                                                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                            lineNumber: 1666,
                                                                                            columnNumber: 37
                                                                                        }, this),
                                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$parts$2f$LabeledEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                                                            label: "",
                                                                                            value: option.question_explanation,
                                                                                            onChange: (v)=>updateMcqOption(index, "question_explanation", v),
                                                                                            editorMinH: 100,
                                                                                            allowImages: true,
                                                                                            placeholder: "اشرح لماذا هذا الخيار صحيح أو خاطئ... (اختياري لكن موصى به)"
                                                                                        }, void 0, false, {
                                                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                            lineNumber: 1670,
                                                                                            columnNumber: 37
                                                                                        }, this)
                                                                                    ]
                                                                                }, void 0, true, {
                                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                                    lineNumber: 1665,
                                                                                    columnNumber: 35
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                            lineNumber: 1638,
                                                                            columnNumber: 33
                                                                        }, this)
                                                                    ]
                                                                }, index, true, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                    lineNumber: 1584,
                                                                    columnNumber: 31
                                                                }, this);
                                                            })
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1578,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex justify-center pt-4",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: addMcqOption,
                                                                className: "inline-flex items-center gap-3 px-6 py-3 text-sm font-medium text-blue-700 bg-blue-50 rounded-2xl hover:bg-blue-100 hover:shadow-md transition-all shadow-sm border border-blue-200",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                                        className: "w-5 h-5"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                        lineNumber: 1692,
                                                                        columnNumber: 29
                                                                    }, this),
                                                                    "إضافة خيار جديد"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                                lineNumber: 1687,
                                                                columnNumber: 27
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                            lineNumber: 1686,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                    lineNumber: 1568,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                            lineNumber: 1546,
                                            columnNumber: 21
                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$McqSharedPassageEditor$2f$McqSharedPassageEditor$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            mcqSubType: mcqSubType,
                                            initialData: mcqPassages[mcqSubType] || [],
                                            onPassagesChange: handleMcqPassagesChange
                                        }, `${mcqSubType}:${editingQuestion?.id ?? "new"}`, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                            lineNumber: 1699,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                    lineNumber: 1500,
                                    columnNumber: 17
                                }, this),
                                questionType === "trueFalse" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$TrueFalseQuestions$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    questionHtml: currentQuestion,
                                    setQuestionHtml: setCurrentQuestion,
                                    trueFalseExplanation: trueFalseExplanation,
                                    trueFalseAnswer: trueFalseAnswer,
                                    setTrueFalseAnswer: setTrueFalseAnswer,
                                    setTrueFalseExplanation: setTrueFalseExplanation
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                    lineNumber: 1714,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "pt-4 border-t sticky bottom-0 bg-gray-50/75 backdrop-blur z-10",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: addOrUpdateQuestion,
                                            disabled: add_question_loading || !selectedSectionId || questionType !== "mcq" && !currentQuestion || examData.type === "mock" && !canAddMoreQuestions(selectedSectionId),
                                            className: "w-full inline-flex items-center justify-center gap-2 font-medium rounded-xl transition-all duration-200 bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 px-4 py-3 disabled:opacity-60 disabled:cursor-not-allowed",
                                            children: [
                                                editingQuestion ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$save$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Save$3e$__["Save"], {
                                                    className: "h-4 w-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                    lineNumber: 1738,
                                                    columnNumber: 21
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                    className: "h-4 w-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                                    lineNumber: 1740,
                                                    columnNumber: 21
                                                }, this),
                                                editingQuestion ? "تحديث السؤال" : add_question_loading ? "جاري الحفظ..." : "إضافة السؤال"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                            lineNumber: 1726,
                                            columnNumber: 17
                                        }, this),
                                        examData.type === "mock" && selectedSectionId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-gray-500 mt-2 text-center",
                                            children: [
                                                getQuestionsCount(selectedSectionId),
                                                "/24 سؤال في هذا القسم"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                            lineNumber: 1749,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                                    lineNumber: 1725,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                            lineNumber: 1399,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                        lineNumber: 1398,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$DisplayQuestions$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        selectedSection: selectedSectionData,
                        setEditingQuestion: setEditingQuestion,
                        editingQuestion: editQuestion,
                        selectedSectionId: selectedSectionId
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                        lineNumber: 1758,
                        columnNumber: 12
                    }, this)
                ]
            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center py-12",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-blue-50 p-6 rounded-full w-20 h-20 mx-auto flex items-center justify-center mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$book$2d$open$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpen$3e$__["BookOpen"], {
                            className: "h-10 w-10 text-blue-600"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                            lineNumber: 1765,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                        lineNumber: 1764,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-medium text-gray-900 mb-2",
                        children: "ابدأ بإنشاء اختبار جديد"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                        lineNumber: 1767,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 mb-6",
                        children: "املأ معلومات الاختبار الأساسية وأضف الأقسام لبدء إنشاء الأسئلة"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                        lineNumber: 1770,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                lineNumber: 1763,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$AddExamVideoModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                open: openExamVideoModal,
                setOpen: setOpenExamVideoModal,
                exam_id: examid || examId || openExamSection?.id,
                type: "exam"
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                lineNumber: 1777,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$AddExamPdfModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                open: openExamPdfModal,
                setOpen: setOpenExamPdfModal,
                exam_id: examid || examId || openExamSection?.id,
                type: "exam"
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                lineNumber: 1784,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$EditExamVideoModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                open: openEditExamVideo,
                setOpen: setOpenEditExamVideo,
                rowData: videoRowData,
                setRowData: setVideoRowData,
                exam_id: examid || examId || openExamSection?.id
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                lineNumber: 1792,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$EditExamPdfModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                pdfData: pdfRowData,
                open: openEditExamPdf,
                setOpen: setOpenEditExamPdf,
                rowData: pdfRowData,
                setRowData: setPdfRowData,
                exam_id: examid || examId || openExamSection?.id
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                lineNumber: 1800,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$DeleteExamPdfModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                open: openDeleteExamPdf,
                setOpen: setOpenDeleteExamPdf,
                id: examid || examId || openExamSection?.id,
                rowData: pdfRowData,
                setRowData: setPdfRowData
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                lineNumber: 1810,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Exams$2f$DeleteExamVideoModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                open: openDeleteExamVideo,
                setOpen: setOpenDeleteExamVideo,
                rowData: videoRowData,
                setRowData: setVideoRowData,
                id: examid || examId || openExamSection?.id
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
                lineNumber: 1818,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx",
        lineNumber: 1354,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/Questions/CreateQuestion.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CreateQuestion
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$layout$2f$PageLayout$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/layout/PageLayout.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$BreadCrumbs$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/ui/BreadCrumbs.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/chart-column.js [app-ssr] (ecmascript) <export default as BarChart3>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$PagesHeader$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamMainData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/Questions/ExamMainData.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const breadcrumbs = [
    {
        label: "الرئيسية",
        href: "/",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$chart$2d$column$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BarChart3$3e$__["BarChart3"]
    },
    {
        label: "الاختبارات",
        href: "#",
        icon: "",
        current: true
    }
];
function CreateQuestion() {
    const [examData, setExamData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        name: "",
        duration: "",
        type: "intern",
        sections: []
    });
    // إضافة قسم جديد مع التحقق من عدد الأسئلة للاختبار المحاكي
    const addSection = (section)=>{
        const isAlreadyAdded = examData?.sections?.some((s)=>s.id === section.id);
        if (!isAlreadyAdded) {
            // للاختبار المحاكي: نأخذ فقط 24 سؤال من كل قسم
            const questionsToAdd = examData.type === "mock" ? section?.questions?.slice(0, 24) // 24 سؤال فقط للاختبار المحاكي
             : section?.questions; // جميع الأسئلة للتدريب
            // للاختبار المحاكي: مدة كل قسم ثابتة (25 دقيقة)
            const sectionDuration = examData.type === "mock" ? 25 // 25 دقيقة للاختبار المحاكي
             : section.time; // المدة الأصلية للتدريب
            setExamData({
                ...examData,
                sections: [
                    ...examData.sections,
                    {
                        ...section,
                        questions: questionsToAdd,
                        duration: sectionDuration,
                        originalQuestionsCount: section.questions?.length || 0
                    }
                ]
            });
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log(examData);
    }, [
        examData
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$layout$2f$PageLayout$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                dir: "rtl"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$BreadCrumbs$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    variant: "pill",
                    items: breadcrumbs
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/CreateQuestion.jsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$PagesHeader$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                    title: "إنشاء اختبار جديد",
                    subtitle: "صمم اختبار لطلابك"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/Questions/CreateQuestion.jsx",
                    lineNumber: 62,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$Questions$2f$ExamMainData$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        examData: examData,
                        setExamData: setExamData,
                        onAddSection: addSection
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/Questions/CreateQuestion.jsx",
                        lineNumber: 64,
                        columnNumber: 11
                    }, this)
                }, void 0, false)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/Questions/CreateQuestion.jsx",
            lineNumber: 59,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/Questions/CreateQuestion.jsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=Desktop_nartaqi_b6c8cc62._.js.map