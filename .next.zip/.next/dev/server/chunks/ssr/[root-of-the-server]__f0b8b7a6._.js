module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[project]/Desktop/nartaqi/components/layout/Header.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/menu.js [app-ssr] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/x.js [app-ssr] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/phone.js [app-ssr] (ecmascript) <export default as Phone>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/mail.js [app-ssr] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/map-pin.js [app-ssr] (ecmascript) <export default as MapPin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/clock.js [app-ssr] (ecmascript) <export default as Clock>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
"use client";
;
;
;
;
function Header() {
    const [mobileOpen, setMobileOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [scrolled, setScrolled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const handleScroll = ()=>{
            setScrolled(window.scrollY > 20);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, []);
    const navItems = [
        {
            href: "#features",
            label: "Features"
        },
        {
            href: "#how-it-works",
            label: "How It Works"
        },
        {
            href: "#pricing",
            label: "Pricing"
        },
        {
            href: "#faq",
            label: "FAQ"
        }
    ];
    const contactInfo = [
        {
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"],
            text: "+1 (555) 123-4567",
            href: "tel:+15551234567"
        },
        {
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"],
            text: "hello@medgap.com",
            href: "mailto:hello@medgap.com"
        },
        {
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$map$2d$pin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MapPin$3e$__["MapPin"],
            text: "New York, NY",
            href: "#"
        },
        {
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$clock$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Clock$3e$__["Clock"],
            text: "Mon-Fri 9AM-6PM",
            href: "#"
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: `sticky top-0 w-full z-50 transition-all duration-300 ${scrolled ? "bg-white/95 backdrop-blur-md shadow-lg" : "bg-white shadow-sm"}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `bg-gradient-to-r from-indigo-900 via-purple-900 to-pink-900 text-white transition-all duration-500 relative overflow-hidden ${scrolled ? "max-h-0 opacity-0" : "max-h-20 opacity-100"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.05"%3E%3Ccircle cx="30" cy="30" r="2"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] animate-pulse`
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                            lineNumber: 49,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                        lineNumber: 48,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "container mx-auto px-6 lg:px-8 relative z-10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between py-3 text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "hidden md:flex items-center gap-8",
                                    children: contactInfo.slice(0, 2).map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: item.href,
                                            className: "flex items-center gap-2 hover:text-cyan-300 transition-all duration-300 group",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "p-1 rounded-full bg-white/10 group-hover:bg-white/20 transition-all duration-300",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(item.icon, {
                                                        size: 14
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 64,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 63,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-medium",
                                                    children: item.text
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 66,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, index, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                            lineNumber: 58,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                    lineNumber: 56,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "hidden lg:flex items-center gap-8",
                                    children: contactInfo.slice(2).map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2 text-purple-200 group",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "p-1 rounded-full bg-white/10 group-hover:bg-white/20 transition-all duration-300",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(item.icon, {
                                                        size: 14
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 79,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 78,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-medium",
                                                    children: item.text
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 81,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, index, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                            lineNumber: 74,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                    lineNumber: 72,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "md:hidden flex items-center justify-center w-full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "tel:+15551234567",
                                        className: "flex items-center gap-3 hover:text-cyan-300 transition-all duration-300 group",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "p-2 rounded-full bg-white/15 group-hover:bg-white/25 transition-all duration-300",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                    size: 16
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 93,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                lineNumber: 92,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "font-semibold text-base",
                                                children: "+1 (555) 123-4567"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                lineNumber: 95,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                        lineNumber: 88,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                    lineNumber: 87,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "hidden md:flex items-center gap-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-purple-200 text-sm font-medium",
                                            children: "Follow us:"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                            lineNumber: 103,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "#",
                                                    className: "p-2 rounded-full bg-white/10 hover:bg-white/20 hover:text-cyan-300 transition-all duration-300 transform hover:scale-110",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-4 h-4",
                                                        fill: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            d: "M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 116,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 111,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 107,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "#",
                                                    className: "p-2 rounded-full bg-white/10 hover:bg-white/20 hover:text-cyan-300 transition-all duration-300 transform hover:scale-110",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-4 h-4",
                                                        fill: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            d: "M22.46 6c-.77.35-1.6.58-2.46.69.88-.53 1.56-1.37 1.88-2.38-.83.5-1.75.85-2.72 1.05C18.37 4.5 17.26 4 16 4c-2.35 0-4.27 1.92-4.27 4.29 0 .34.04.67.11.98C8.28 9.09 5.11 7.38 3 4.79c-.37.63-.58 1.37-.58 2.15 0 1.49.75 2.81 1.91 3.56-.71 0-1.37-.2-1.95-.5v.03c0 2.08 1.48 3.82 3.44 4.21a4.22 4.22 0 0 1-1.93.07 4.28 4.28 0 0 0 4 2.98 8.521 8.521 0 0 1-5.33 1.84c-.34 0-.68-.02-1.02-.06C3.44 20.29 5.7 21 8.12 21 16 21 20.33 14.46 20.33 8.79c0-.19 0-.37-.01-.56.84-.6 1.56-1.36 2.14-2.23z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 128,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 123,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 119,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "#",
                                                    className: "p-2 rounded-full bg-white/10 hover:bg-white/20 hover:text-cyan-300 transition-all duration-300 transform hover:scale-110",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-4 h-4",
                                                        fill: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            d: "M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 140,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 135,
                                                        columnNumber: 19
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 131,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                            lineNumber: 106,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                    lineNumber: 102,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                            lineNumber: 54,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                lineNumber: 42,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-white/95 backdrop-blur-md border-b py-3 border-gray-100/50 shadow-sm",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "container mx-auto px-6 lg:px-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between h-18 lg:h-22",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "/",
                                        className: "group flex items-center gap-4 transition-transform duration-300 hover:scale-105",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "w-12 h-12 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-2xl group-hover:shadow-purple-500/25 transition-all duration-300 transform group-hover:rotate-3",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-white font-bold text-xl",
                                                            children: "M"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 161,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 160,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "absolute -inset-2 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-2xl opacity-20 group-hover:opacity-40 transition-all duration-300 blur-lg"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 163,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "absolute inset-0 bg-gradient-to-br from-white/20 to-transparent rounded-2xl group-hover:from-white/30 transition-all duration-300"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 164,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                lineNumber: 159,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-3xl font-black bg-gradient-to-r from-gray-900 via-purple-800 to-blue-800 bg-clip-text text-transparent",
                                                        children: "MedGap"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 167,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-xs text-gray-500 font-medium tracking-wider uppercase",
                                                        children: "Healthcare Solutions"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 170,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                lineNumber: 166,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                        lineNumber: 155,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                    lineNumber: 154,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                    className: "hidden lg:flex items-center gap-2",
                                    children: navItems.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: item.href,
                                            className: "relative px-5 py-3 text-gray-700 hover:text-gray-900 font-semibold transition-all duration-300 group rounded-xl hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50",
                                            children: [
                                                item.label,
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "absolute inset-x-5 bottom-2 h-0.5 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-center rounded-full"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 186,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute inset-0 bg-gradient-to-r from-blue-600/5 to-purple-600/5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 187,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, item.href, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                            lineNumber: 180,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "hidden lg:flex items-center gap-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: "/login",
                                            className: "px-5 py-2.5 text-gray-700 hover:text-gray-900 font-semibold transition-all duration-300 rounded-xl hover:bg-gray-50",
                                            children: "Login"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                            lineNumber: 194,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: "/signup",
                                            className: "relative px-8 py-3 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white font-bold rounded-2xl overflow-hidden group transition-all duration-300 hover:shadow-2xl hover:shadow-purple-500/25 transform hover:scale-105",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "relative z-10",
                                                    children: "Get Started"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 204,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute inset-0 bg-gradient-to-r from-blue-700 via-purple-700 to-pink-700 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 205,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 206,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                            lineNumber: 200,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                    lineNumber: 193,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "lg:hidden p-3 rounded-2xl bg-gradient-to-r from-gray-50 to-gray-100 hover:from-gray-100 hover:to-gray-150 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 shadow-md hover:shadow-lg transform hover:scale-105",
                                    onClick: ()=>setMobileOpen(!mobileOpen),
                                    "aria-label": mobileOpen ? "Close menu" : "Open menu",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative w-6 h-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                                size: 24,
                                                className: `absolute inset-0 transform transition-all duration-300 text-gray-700 ${mobileOpen ? "rotate-180 opacity-0" : "rotate-0 opacity-100"}`
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                lineNumber: 217,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                size: 24,
                                                className: `absolute inset-0 transform transition-all duration-300 text-gray-700 ${mobileOpen ? "rotate-0 opacity-100" : "rotate-180 opacity-0"}`
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                lineNumber: 223,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                        lineNumber: 216,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                    lineNumber: 211,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                            lineNumber: 152,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: `lg:hidden overflow-hidden transition-all duration-500 ease-in-out ${mobileOpen ? "max-h-screen opacity-100" : "max-h-0 opacity-0"}`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "py-6 border-t border-gradient-to-r from-gray-100 to-gray-200",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-6 mx-4 p-4 bg-gradient-to-r from-blue-50 via-purple-50 to-pink-50 rounded-2xl border border-purple-100",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "grid grid-cols-2 gap-4 text-sm",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "tel:+15551234567",
                                                    className: "flex items-center gap-3 text-gray-700 hover:text-purple-600 transition-colors duration-300 group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "p-2 rounded-xl bg-white shadow-sm group-hover:shadow-md transition-all duration-300",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                                size: 16,
                                                                className: "text-purple-600"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                                lineNumber: 248,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 247,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "font-semibold",
                                                            children: "Call us"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 250,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 243,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "mailto:hello@medgap.com",
                                                    className: "flex items-center gap-3 text-gray-700 hover:text-purple-600 transition-colors duration-300 group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "p-2 rounded-xl bg-white shadow-sm group-hover:shadow-md transition-all duration-300",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                                size: 16,
                                                                className: "text-purple-600"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                                lineNumber: 257,
                                                                columnNumber: 23
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 256,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "font-semibold",
                                                            children: "Email us"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 259,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 252,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                            lineNumber: 242,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                        lineNumber: 241,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "py-4 border-t border-gray-100",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mb-4 p-4 bg-gray-50 rounded-lg",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid grid-cols-2 gap-3 text-sm",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                            href: "tel:+15551234567",
                                                            className: "flex items-center gap-2 text-gray-600 hover:text-blue-600",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$phone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Phone$3e$__["Phone"], {
                                                                    size: 14
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                                    lineNumber: 271,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Call us"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                                    lineNumber: 272,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 267,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                            href: "mailto:hello@medgap.com",
                                                            className: "flex items-center gap-2 text-gray-600 hover:text-blue-600",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                                    size: 14
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                                    lineNumber: 278,
                                                                    columnNumber: 23
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: "Email us"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                                    lineNumber: 279,
                                                                    columnNumber: 23
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 274,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                    lineNumber: 266,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                lineNumber: 265,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                                className: "flex flex-col space-y-1",
                                                children: [
                                                    navItems.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                            href: item.href,
                                                            className: `px-4 py-3 text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-lg font-medium transition-all duration-200 transform ${mobileOpen ? "translate-x-0 opacity-100" : "translate-x-4 opacity-0"}`,
                                                            style: {
                                                                transitionDelay: mobileOpen ? `${index * 50}ms` : "0ms"
                                                            },
                                                            onClick: ()=>setMobileOpen(false),
                                                            children: item.label
                                                        }, item.href, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                            lineNumber: 286,
                                                            columnNumber: 21
                                                        }, this)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "pt-4 space-y-3",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                href: "/login",
                                                                className: `block px-4 py-3 text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-lg font-medium transition-all duration-200 transform ${mobileOpen ? "translate-x-0 opacity-100" : "translate-x-4 opacity-0"}`,
                                                                style: {
                                                                    transitionDelay: mobileOpen ? `${navItems.length * 50}ms` : "0ms"
                                                                },
                                                                onClick: ()=>setMobileOpen(false),
                                                                children: "Login"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                                lineNumber: 304,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                href: "/signup",
                                                                className: `block mx-4 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-center font-semibold rounded-full hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-200 transform ${mobileOpen ? "translate-x-0 opacity-100" : "translate-x-4 opacity-0"}`,
                                                                style: {
                                                                    transitionDelay: mobileOpen ? `${(navItems.length + 1) * 50}ms` : "0ms"
                                                                },
                                                                onClick: ()=>setMobileOpen(false),
                                                                children: "Get Started"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                                lineNumber: 320,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                        lineNumber: 303,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                                lineNumber: 284,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                        lineNumber: 263,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                                lineNumber: 239,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                            lineNumber: 234,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                    lineNumber: 151,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
                lineNumber: 150,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/layout/Header.jsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/layout/Footer.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArabicLearningBanner",
    ()=>ArabicLearningBanner,
    "default",
    ()=>AnimatedFooter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/facebook.js [app-ssr] (ecmascript) <export default as Facebook>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/instagram.js [app-ssr] (ecmascript) <export default as Instagram>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/twitter.js [app-ssr] (ecmascript) <export default as Twitter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$youtube$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Youtube$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/youtube.js [app-ssr] (ecmascript) <export default as Youtube>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/mail.js [app-ssr] (ecmascript) <export default as Mail>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/arrow-right.js [app-ssr] (ecmascript) <export default as ArrowRight>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/sparkles.js [app-ssr] (ecmascript) <export default as Sparkles>");
"use client";
;
;
;
;
function AnimatedFooter() {
    const [isVisible, setIsVisible] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [emailFocused, setEmailFocused] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [hoveredLink, setHoveredLink] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setIsVisible(true);
    }, []);
    const socialIcons = [
        {
            Icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$facebook$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Facebook$3e$__["Facebook"],
            color: "hover:bg-blue-600",
            delay: "delay-100"
        },
        {
            Icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$instagram$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Instagram$3e$__["Instagram"],
            color: "hover:bg-gradient-to-br from-purple-600 to-pink-600",
            delay: "delay-200"
        },
        {
            Icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$twitter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Twitter$3e$__["Twitter"],
            color: "hover:bg-sky-500",
            delay: "delay-300"
        },
        {
            Icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$youtube$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Youtube$3e$__["Youtube"],
            color: "hover:bg-red-600",
            delay: "delay-400"
        }
    ];
    const supportLinks = [
        "Help Center",
        "My Account",
        "Ticket Support",
        "FAQs",
        "Contact us"
    ];
    const companyLinks = [
        "About us",
        "Instructors",
        "Careers",
        "Article & News",
        "Legal Notice"
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "jsx-4cc569a42d3f38b3" + " " + "relative bg-background ",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-4cc569a42d3f38b3" + " " + "absolute inset-0",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-4cc569a42d3f38b3" + " " + "absolute top-10 left-10 w-20 h-20 bg-teal-200 rounded-full opacity-20 animate-pulse"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-4cc569a42d3f38b3" + " " + "absolute top-40 right-20 w-16 h-16 bg-orange-200 rounded-full opacity-30 animate-bounce delay-1000"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-4cc569a42d3f38b3" + " " + "absolute bottom-20 left-1/4 w-12 h-12 bg-blue-200 rounded-full opacity-25 animate-ping delay-2000"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                        lineNumber: 59,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-4cc569a42d3f38b3" + " " + "absolute top-20 right-1/3 w-8 h-8 bg-purple-200 rounded-full opacity-30 animate-pulse delay-500"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                        lineNumber: 60,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                lineNumber: 56,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-4cc569a42d3f38b3" + " " + "absolute inset-0 overflow-hidden",
                children: [
                    ...Array(12)
                ].map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            left: `${Math.random() * 100}%`,
                            top: `${Math.random() * 100}%`,
                            animationDelay: `${Math.random() * 5}s`,
                            animationDuration: `${3 + Math.random() * 4}s`
                        },
                        className: "jsx-4cc569a42d3f38b3" + " " + "absolute animate-float opacity-20",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sparkles$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sparkles$3e$__["Sparkles"], {
                            className: "w-4 h-4 text-teal-500"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                            lineNumber: 76,
                            columnNumber: 13
                        }, this)
                    }, i, false, {
                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                        lineNumber: 66,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-4cc569a42d3f38b3" + " " + "relative z-10 max-w-7xl mx-auto px-6 py-16",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-4cc569a42d3f38b3" + " " + `grid grid-cols-1 lg:grid-cols-4 gap-12 transition-all duration-1000 transform ${isVisible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-4cc569a42d3f38b3" + " " + "lg:col-span-1 space-y-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-4cc569a42d3f38b3" + " " + "flex items-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: "/",
                                            className: "jsx-4cc569a42d3f38b3" + " " + "group flex items-center gap-4 transition-transform duration-300 hover:scale-105",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "jsx-4cc569a42d3f38b3" + " " + "relative",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4cc569a42d3f38b3" + " " + "w-12 h-12 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:shadow-2xl group-hover:shadow-purple-500/25 transition-all duration-300 transform group-hover:rotate-3",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "jsx-4cc569a42d3f38b3" + " " + "text-white font-bold text-xl",
                                                                children: "M"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                                lineNumber: 98,
                                                                columnNumber: 21
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                            lineNumber: 97,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4cc569a42d3f38b3" + " " + "absolute -inset-2 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 rounded-2xl opacity-20 group-hover:opacity-40 transition-all duration-300 blur-lg"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                            lineNumber: 100,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4cc569a42d3f38b3" + " " + "absolute inset-0 bg-gradient-to-br from-white/20 to-transparent rounded-2xl group-hover:from-white/30 transition-all duration-300"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                            lineNumber: 101,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                    lineNumber: 96,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "jsx-4cc569a42d3f38b3",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-4cc569a42d3f38b3" + " " + "text-3xl font-black bg-gradient-to-r from-gray-900 via-purple-800 to-blue-800 bg-clip-text text-transparent",
                                                            children: "MedGap"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                            lineNumber: 104,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "jsx-4cc569a42d3f38b3" + " " + "text-xs text-gray-500 font-medium tracking-wider uppercase",
                                                            children: "Healthcare Solutions"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                            lineNumber: 107,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                    lineNumber: 103,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                            lineNumber: 92,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                        lineNumber: 91,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-4cc569a42d3f38b3" + " " + "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "jsx-4cc569a42d3f38b3" + " " + "text-gray-700 leading-relaxed group-hover:text-gray-900 transition-colors duration-300",
                                                children: "We help you learn Arabic in a fun and interactive way, no matter your level. Join us and experience a learning journey tailored just for you!"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                lineNumber: 115,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-4cc569a42d3f38b3" + " " + "flex gap-3",
                                                children: socialIcons.map(({ Icon, color, delay }, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        style: {
                                                            animationDelay: `${index * 150}ms`
                                                        },
                                                        className: "jsx-4cc569a42d3f38b3" + " " + `relative group transition-all duration-500 transform hover:scale-110 ${delay}`,
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "jsx-4cc569a42d3f38b3" + " " + `absolute inset-0 bg-gradient-to-r from-teal-400 to-blue-500 rounded-xl blur opacity-0 group-hover:opacity-50 transition-opacity duration-300`
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                                lineNumber: 129,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: "jsx-4cc569a42d3f38b3" + " " + `relative w-12 h-12 bg-white rounded-xl shadow-md ${color} hover:text-white transition-all duration-300 flex items-center justify-center group-hover:shadow-xl`,
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                                    className: "jsx-4cc569a42d3f38b3" + " " + "w-5 h-5"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                                    lineNumber: 135,
                                                                    columnNumber: 23
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                                lineNumber: 132,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, index, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                        lineNumber: 124,
                                                        columnNumber: 19
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                lineNumber: 122,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                        lineNumber: 114,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                lineNumber: 89,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-4cc569a42d3f38b3" + " " + `transition-all duration-700 delay-300 transform ${isVisible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "jsx-4cc569a42d3f38b3" + " " + "text-2xl font-bold text-accent mb-6 relative",
                                        children: [
                                            "Support",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-4cc569a42d3f38b3" + " " + "absolute -bottom-2 left-0 w-12 h-1 bg-gradient-to-r from-teal-500 to-blue-500 rounded-full"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                lineNumber: 153,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                        lineNumber: 151,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "jsx-4cc569a42d3f38b3" + " " + "space-y-3",
                                        children: supportLinks.map((link, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "jsx-4cc569a42d3f38b3",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "#",
                                                    onMouseEnter: ()=>setHoveredLink(`support-${index}`),
                                                    onMouseLeave: ()=>setHoveredLink(null),
                                                    className: "jsx-4cc569a42d3f38b3" + " " + "group flex items-center text-gray-600 hover:text-accent transition-all duration-300",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                            className: `w-4 h-4 mr-2 transition-all duration-300 ${hoveredLink === `support-${index}` ? "translate-x-1 text-teal-500" : "translate-x-0 opacity-0"}`
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                            lineNumber: 164,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-4cc569a42d3f38b3" + " " + "group-hover:translate-x-2 transition-transform duration-300",
                                                            children: link
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                            lineNumber: 171,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                    lineNumber: 158,
                                                    columnNumber: 19
                                                }, this)
                                            }, index, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                lineNumber: 157,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                        lineNumber: 155,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                lineNumber: 144,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-4cc569a42d3f38b3" + " " + `transition-all duration-700 delay-500 transform ${isVisible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "jsx-4cc569a42d3f38b3" + " " + "text-2xl font-bold text-accent mb-6 relative",
                                        children: [
                                            "Company",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-4cc569a42d3f38b3" + " " + "absolute -bottom-2 left-0 w-12 h-1 bg-gradient-to-r from-teal-500 to-blue-500 rounded-full"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                lineNumber: 190,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                        lineNumber: 188,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "jsx-4cc569a42d3f38b3" + " " + "space-y-3",
                                        children: companyLinks.map((link, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "jsx-4cc569a42d3f38b3",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    href: "#",
                                                    onMouseEnter: ()=>setHoveredLink(`company-${index}`),
                                                    onMouseLeave: ()=>setHoveredLink(null),
                                                    className: "jsx-4cc569a42d3f38b3" + " " + "group flex items-center text-gray-600 hover:text-accent transition-all duration-300",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                            className: `w-4 h-4 mr-2 transition-all duration-300 ${hoveredLink === `company-${index}` ? "translate-x-1 text-teal-500" : "translate-x-0 opacity-0"}`
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                            lineNumber: 201,
                                                            columnNumber: 21
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "jsx-4cc569a42d3f38b3" + " " + "group-hover:translate-x-2 transition-transform duration-300",
                                                            children: link
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                            lineNumber: 208,
                                                            columnNumber: 21
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                    lineNumber: 195,
                                                    columnNumber: 19
                                                }, this)
                                            }, index, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                lineNumber: 194,
                                                columnNumber: 17
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                        lineNumber: 192,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                lineNumber: 181,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-4cc569a42d3f38b3" + " " + `transition-all duration-700 delay-700 transform ${isVisible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "jsx-4cc569a42d3f38b3" + " " + "text-2xl font-bold text-accent mb-6 relative",
                                        children: [
                                            "Newsletter",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-4cc569a42d3f38b3" + " " + "absolute -bottom-2 left-0 w-12 h-1 bg-gradient-to-r from-teal-500 to-blue-500 rounded-full"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                lineNumber: 227,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                        lineNumber: 225,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "jsx-4cc569a42d3f38b3" + " " + "text-gray-600 mb-6 leading-relaxed",
                                        children: "Sign up our newsletter to get update information, news and free insight."
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                        lineNumber: 229,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-4cc569a42d3f38b3" + " " + "space-y-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-4cc569a42d3f38b3" + " " + `relative transition-all duration-500 ${emailFocused ? "scale-105" : "scale-100"}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-4cc569a42d3f38b3" + " " + `absolute inset-0 bg-gradient-to-r from-teal-400 to-blue-500 rounded-2xl transition-all duration-300 ${emailFocused ? "blur-md opacity-30" : "blur-sm opacity-0"}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                        lineNumber: 240,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-4cc569a42d3f38b3" + " " + "relative",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$mail$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Mail$3e$__["Mail"], {
                                                                className: `absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 transition-all duration-300 ${emailFocused ? "text-teal-500" : "text-gray-400"}`
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                                lineNumber: 246,
                                                                columnNumber: 19
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                type: "email",
                                                                placeholder: "Email",
                                                                onFocus: ()=>setEmailFocused(true),
                                                                onBlur: ()=>setEmailFocused(false),
                                                                className: "jsx-4cc569a42d3f38b3" + " " + "w-full pl-12 pr-4 py-4 bg-white rounded-2xl border-2 border-transparent focus:border-teal-400 focus:outline-none transition-all duration-300 shadow-lg focus:shadow-xl"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                                lineNumber: 251,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                        lineNumber: 245,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                lineNumber: 235,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "jsx-4cc569a42d3f38b3" + " " + "group relative w-full py-4 bg-gradient-to-r from-teal-500 to-blue-600 text-white font-semibold rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 overflow-hidden",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-4cc569a42d3f38b3" + " " + "absolute inset-0 bg-gradient-to-r from-blue-600 to-teal-500 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                        lineNumber: 262,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-4cc569a42d3f38b3" + " " + "relative flex items-center justify-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "jsx-4cc569a42d3f38b3" + " " + "group-hover:scale-105 transition-transform duration-300",
                                                                children: "SIGN UP"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                                lineNumber: 264,
                                                                columnNumber: 19
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$arrow$2d$right$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRight$3e$__["ArrowRight"], {
                                                                className: "w-5 h-5 group-hover:translate-x-1 transition-transform duration-300"
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                                lineNumber: 267,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                        lineNumber: 263,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-4cc569a42d3f38b3" + " " + "absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-500"
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                        lineNumber: 269,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                lineNumber: 261,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                        lineNumber: 234,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                lineNumber: 218,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                        lineNumber: 83,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "jsx-4cc569a42d3f38b3" + " " + `mt-16 pt-8 border-t border-teal-200 transition-all duration-1000 delay-1000 transform ${isVisible ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"}`,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "jsx-4cc569a42d3f38b3" + " " + "flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "jsx-4cc569a42d3f38b3" + " " + "text-gray-600 text-center md:text-left",
                                    children: [
                                        "Copyright© ",
                                        new Date().getFullYear(),
                                        " MedGap, All rights reserved. Powered by",
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "jsx-4cc569a42d3f38b3" + " " + "font-semibold text-accent hover:text-teal-800 transition-colors duration-300 cursor-pointer",
                                            children: "Camp Coding"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                            lineNumber: 284,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                    lineNumber: 282,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "jsx-4cc569a42d3f38b3" + " " + "flex flex-wrap justify-center md:justify-end gap-6 text-sm",
                                    children: [
                                        "Term of use",
                                        "Privacy Policy",
                                        "Cookie Policy"
                                    ].map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: "#",
                                            className: "jsx-4cc569a42d3f38b3" + " " + "text-gray-600 hover:text-accent transition-all duration-300 relative group",
                                            children: [
                                                item,
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "jsx-4cc569a42d3f38b3" + " " + "absolute -bottom-1 left-0 w-0 h-0.5 bg-teal-500 group-hover:w-full transition-all duration-300"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                                    lineNumber: 298,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, index, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                            lineNumber: 292,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                                    lineNumber: 289,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                            lineNumber: 281,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                        lineNumber: 276,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                lineNumber: 81,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "4cc569a42d3f38b3",
                children: "@keyframes float{0%,to{transform:translateY(0)rotate(0)}50%{transform:translateY(-20px)rotate(180deg)}}.animate-float.jsx-4cc569a42d3f38b3{animation:6s ease-in-out infinite float}"
            }, void 0, false, void 0, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
function ArabicLearningBanner() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-teal-500 text-white py-6 px-4 md:px-12 shadow-md relative overflow-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute right-0 top-0 h-full w-1/3 bg-teal-400 rounded-l-full opacity-60",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute bottom-4 right-4 w-24 h-24 border-2 border-dashed border-white rounded-full"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                    lineNumber: 330,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                lineNumber: 329,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative z-10 text-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-xl md:text-2xl font-semibold tracking-wide",
                    children: "Speak Arabic with Confidence – Join Our Personalized Learning Experience"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                    lineNumber: 334,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
                lineNumber: 333,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/layout/Footer.jsx",
        lineNumber: 327,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "apiRoutes",
    ()=>apiRoutes
]);
const apiRoutes = {
    login: "admins/login",
    // blogs
    add_blog: "admin/blogs/add_blog",
    edit_blog: "admin/blogs/update_blog",
    delete_blog: "admin/blogs/delete_blog",
    show_hide_blog: "admin/blogs/show_blog",
    getBlogs: "admin/blogs",
    getBlogComments: "admin/blogs/comments",
    delete_blog_comment: "admin/blogs/delete_comment",
    show_hide_blog_comment: "admin/blogs/show_comment",
    // teams
    getTeams: "admin/team",
    add_team: "admin/team/add_member",
    edit_team: "admin/team/update_member",
    show_hide_team: "admin/team/show_member",
    // faqs 
    getFaqs: "admin/faqs",
    add_faq: "admin/faqs/add_faq",
    edit_faq: "admin/faqs/update_faq",
    show_hide_faq: "admin/faqs/show_faq",
    // marketers
    get_marketeres: "admin/marketers",
    generate_code: "admin/marketers/generate_code",
    // rounds
    get_rounds: "admin/rounds/get_all_rounds",
    get_source_rounds: "admin/rounds/getsourceRound",
    add_basic_round: "admin/rounds/store_round",
    edit_basic_round: "admin/rounds/edit_round",
    active_round: "admin/rounds/active_round",
    copy_round: "admin/rounds/makeCopyRoundWithAllData",
    delete_round: "admin/rounds/delete_round",
    // categories
    get_applications: "admin/certificates/applications",
    get_categories: "admin/categories/get_all_course_categories",
    add_category: "admin/categories/store_course_category",
    edit_category: "admin/categories/edit_course_category",
    delete_category: "admin/categories/delete_course_category",
    active_category: "admin/categories/active_course_category",
    // parts
    get_parts: "admin/categories/parts/get_category_parts_by_course_category_id",
    add_part: "admin/categories/parts/add_category_part",
    edit_part: "admin/categories/parts/edit_category_part",
    delete_part: "admin/categories/parts/delete_category_part",
    // teachers
    get_teacher: "admin/teachers/getTeachers",
    add_teacher: "admin/teachers/add_teacher",
    edit_teacher: "admin/teachers/edit_teacher",
    delete_teacher: "admin/teachers/delete_teacher",
    // resources
    get_resources: "admin/rounds-resources/getRoundResources",
    add_resources: "admin/rounds-resources/addRoundResource",
    edit_resources: "admin/rounds-resources/editRoundResource",
    delete_resource: "admin/rounds-resources/deleteRoundResource",
    //certificates
    get_certificates: "admin/certificates/applications",
    add_certificates: "admin/certificates/generate",
    edit_certificate: "",
    delete_certificate: "",
    // badges
    get_badges: "admin/badges",
    add_badge: "admin/badges/create_badge",
    edit_badge: "admin/badges/update_badge",
    delete_badge: "admin/badges/delete_badge",
    studuent_badges: "admin/badges/student_badges",
    assign_page_to_student: 'admin/badges/assign_badge_to_student',
    //exams
    get_exams: "admin/exams/getAllExams",
    add_exam: "admin/exams/store_exam",
    edit_exam: "admin/exams/edit_exam",
    delete_exam: "admin/exams/delete_exam",
    get_exam_sections: "admin/exams/exam-sections/GetAllExamSectionsByExamId",
    add_exam_sections: "admin/exams/exam-sections/store_exam_section",
    delete_exam_sections: "admin/exams/exam-sections/delete_exam_section",
    update_exam_sections: "admin/exams/exam-sections/edit_exam_section",
    assign_exam: "admin/exams/assign_exam_round",
    //exam attached
    add_exam_pdf: "admin/exams/add_exam_pdf",
    edit_exam_pdf: "admin/exams/edit_exam_pdf",
    delete_exam_pdf: "admin/exams/delete_exam_pdf",
    add_exam_video: "admin/exams/add_exam_video",
    edit_exam_video: "admin/exams/edit_exam_video",
    delete_exam_video: "admin/exams/delete_exam_video",
    //exam questions
    get_questions: "admin/questions/get_questions",
    store_question: "admin/questions/StoreQuestionWithAnswers",
    //lessons
    get_lessons: "admin/contents/lessons/get_all_lessons",
    add_lesson: "admin/contents/lessons/store_lesson",
    edit_lesson: "admin/contents/lessons/edit_lesson",
    delete_lesson: "admin/contents/lessons/delete_lesson",
    //video
    get_videos: "admin/contents/lessons/videos/get_all_videos",
    add_video: "admin/contents/lessons/videos/add_video",
    delete_video: "admin/contents/lessons/videos/delete_video",
    edit_video: "admin/contents/lessons/videos/edit_video",
    //features
    get_features: "admin/rounds/features/get_all_round_features",
    add_feature: "admin/rounds/features/add_round_feature",
    edit_feature: "admin/rounds/features/edit_round_feature",
    delete_feature: "admin/rounds/features/delete_round_feature",
    //store
    get_store: "",
    add_store: "user/store/addStoreItem",
    edit_store: "",
    delete_store: "",
    //lives
    get_lives: "admin/roundsLives/get_all_round_lives",
    store_live: "admin/roundsLives/store_round_live",
    edit_live: "admin/roundsLives/edit_round_live",
    delete_live: "admin/roundsLives/delete_round_live",
    active_live: "admin/roundsLives/active_in_active_round_live",
    mark_live: "admin/roundsLives/makeLiveFinished",
    //studens 
    get_students: "admin/students/get_all_students",
    get_student_round: "admin/students/get_student_rounds",
    inroll_student_round: "admin/students/inroll_in_round",
    cancel_student_round: "admin/students/cancel_inroll_from_round",
    get_student_by_phone: "admin/students/get_student_by_phone"
};
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/Desktop/nartaqi/lib/shared/handleResponse.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "handleRespons",
    ()=>handleRespons
]);
const handleRespons = (response)=>{
    return {
        status: response?.status,
        data: response?.data,
        message: response?.message,
        error: response,
        pagination: response?.pagination
    };
};
}),
"[project]/Desktop/nartaqi/configs/index.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "configs",
    ()=>configs
]);
const configs = {
    tokenKey: "nartaqeexToken",
    userKey: "nartaqeeUser",
    refreshTokenKey: "nartaqeeRefreshToken",
    AUTH_COOKIE_NAME: "AUTH_NARTAQI_COOKIE_NAME"
};
}),
"[project]/Desktop/nartaqi/lib/shared/requestOptions.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "requestOptions",
    ()=>requestOptions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$configs$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/configs/index.jsx [app-ssr] (ecmascript)");
;
const requestOptions = ({ method = "GET", body = {}, headers = {}, isFile = null })=>{
    const localToken = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : '';
    const isValidToken = !!localToken && localToken !== 'undefined' && localToken !== 'null';
    const baseHeaders = {
        ...headers,
        "Content-Type": isFile ? "multipart/form-data" : "application/json"
    };
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const options = {
        method: method,
        headers: baseHeaders
    };
    options.body = body;
    return options;
};
}),
"[project]/Desktop/nartaqi/constants/index.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "base_url",
    ()=>base_url
]);
const base_url = "https://camp-coding.site/nartaqi/public/api/";
}),
"[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// api/index.js
__turbopack_context__.s([
    "api",
    ()=>api
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$handleResponse$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/handleResponse.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$requestOptions$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/requestOptions.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$constants$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/constants/index.jsx [app-ssr] (ecmascript)");
;
;
;
;
const rawRequest = (method, endpoint, options = {}, new_base_url = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$constants$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["base_url"])=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])({
        url: `${new_base_url}${endpoint}`,
        method,
        data: options.body,
        params: options.params,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$requestOptions$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestOptions"])({
            method,
            ...options
        })
    });
// Keep if you still want to redirect on 401 elsewhere
const safeRedirectToLogin = ()=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
};
// 🔴 NEW: global Axios interceptor to catch 401s
__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].interceptors.response.use((response)=>response, (error)=>{
    console.log(error);
    const status = error?.response?.status;
    if (status === 401) {
        safeRedirectToLogin();
    }
    // Keep the rejection so Redux thunks / callers still see an error
    return error;
});
const api = {
    get: async (endpoint, options = {}, new_base_url = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$constants$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["base_url"])=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$handleResponse$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleRespons"])(await rawRequest("GET", endpoint, {
            ...options,
            body: null
        }, new_base_url)),
    post: async (endpoint, options = {}, new_base_url = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$constants$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["base_url"])=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$handleResponse$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleRespons"])(await rawRequest("POST", endpoint, options, new_base_url)),
    put: async (endpoint, options = {}, new_base_url = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$constants$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["base_url"])=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$handleResponse$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleRespons"])(await rawRequest("PUT", endpoint, options, new_base_url)),
    patch: async (endpoint, options = {}, new_base_url = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$constants$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["base_url"])=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$handleResponse$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleRespons"])(await rawRequest("PATCH", endpoint, options, new_base_url)),
    delete: async (endpoint, options = {}, new_base_url = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$constants$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["base_url"])=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$handleResponse$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleRespons"])(await rawRequest("DELETE", endpoint, options, new_base_url))
};
}),
"[project]/Desktop/nartaqi/lib/features/authSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "authSlice",
    ()=>authSlice,
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleSubmitLogin",
    ()=>handleSubmitLogin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    loading: false,
    login_data: []
};
const handleSubmitLogin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("authSlice/handleLogin", async ({ body })=>{
    console.log(body);
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].login, {
        body
    });
    return response;
});
const authSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "authSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleSubmitLogin.pending, (state)=>{
            state.loading = true;
        }).addCase(handleSubmitLogin.fulfilled, (state, action)=>{
            state.loading = false;
            state.login_data = action.payload;
        }).addCase(handleSubmitLogin.rejected, (state)=>{
            state.loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = authSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/blogSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "blogSlice",
    ()=>blogSlice,
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddBlog",
    ()=>handleAddBlog,
    "handleDeleteBlog",
    ()=>handleDeleteBlog,
    "handleDeleteBlogComment",
    ()=>handleDeleteBlogComment,
    "handleEditBlog",
    ()=>handleEditBlog,
    "handleGetAllBlogs",
    ()=>handleGetAllBlogs,
    "handleGetBlogComments",
    ()=>handleGetBlogComments,
    "handleShowHideBlog",
    ()=>handleShowHideBlog,
    "handleShowHideBlogComment",
    ()=>handleShowHideBlogComment
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    add_blog_loading: false,
    edit_blog_loading: false,
    delete_blog_loading: false,
    show_hide_blog_loading: false,
    blogs_loading: false,
    blogs_data: [],
    blog_comments_loading: false,
    blog_comments_data: [],
    blog_comment_delete_loading: false,
    blog_comment_show_hide_loading: false
};
const handleGetAllBlogs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("blogSlice/handleGetAllBlogs", async ()=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].getBlogs);
    return response;
});
const handleAddBlog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("blogSlice/handleAddBlog", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_blog, {
        body,
        isFile: true
    });
    return response;
});
const handleDeleteBlog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("blogSlice/handleDeleteBlog", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_blog, {
        body
    });
    return response;
});
const handleEditBlog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("blogSlice/handleEditBlog", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_blog, {
        body,
        isFile: true
    });
    return response;
});
const handleShowHideBlog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("blogSlice/handleShowHideBlog", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].show_hide_blog, {
        body
    });
    return response;
});
const handleGetBlogComments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("blogSlice/handleGetBlogComments", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].getBlogComments, {
        body
    });
    return response;
});
const handleDeleteBlogComment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("blogSlice/handleDeleteBlogComment", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_blog_comment, {
        body
    });
    return response;
});
const handleShowHideBlogComment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("blogSlice/handleShowHideBlogComment", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].show_hide_blog_comment, {
        body
    });
    return response;
});
const blogSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "blogSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllBlogs.pending, (state)=>{
            state.blogs_loading = true;
        }).addCase(handleGetAllBlogs.fulfilled, (state, action)=>{
            state.blogs_loading = false;
            state.blogs_data = action.payload;
        }).addCase(handleGetAllBlogs.rejected, (state)=>{
            state.blogs_loading = false;
        }).addCase(handleAddBlog.pending, (state)=>{
            state.add_blog_loading = true;
        }).addCase(handleAddBlog.fulfilled, (state, action)=>{
            state.add_blog_loading = false;
        }).addCase(handleAddBlog.rejected, (state)=>{
            state.add_blog_loading = false;
        }).addCase(handleEditBlog.pending, (state)=>{
            state.edit_blog_loading = true;
        }).addCase(handleEditBlog.fulfilled, (state, action)=>{
            state.edit_blog_loading = false;
        }).addCase(handleEditBlog.rejected, (state)=>{
            state.edit_blog_loading = false;
        }).addCase(handleDeleteBlog.pending, (state)=>{
            state.delete_blog_loading = true;
        }).addCase(handleDeleteBlog.fulfilled, (state, action)=>{
            state.delete_blog_loading = false;
        }).addCase(handleDeleteBlog.rejected, (state)=>{
            state.delete_blog_loading = false;
        }).addCase(handleShowHideBlog.pending, (state)=>{
            state.show_hide_blog_loading = true;
        }).addCase(handleShowHideBlog.fulfilled, (state, action)=>{
            state.show_hide_blog_loading = false;
        }).addCase(handleShowHideBlog.rejected, (state)=>{
            state.show_hide_blog_loading = false;
        }).addCase(handleGetBlogComments.pending, (state)=>{
            state.blog_comments_loading = true;
        }).addCase(handleGetBlogComments.fulfilled, (state, action)=>{
            state.blog_comments_loading = false;
            state.blog_comments_data = action.payload;
        }).addCase(handleGetBlogComments.rejected, (state)=>{
            state.blog_comments_loading = false;
        }).addCase(handleDeleteBlogComment.pending, (state)=>{
            state.blog_comment_delete_loading = true;
        }).addCase(handleDeleteBlogComment.fulfilled, (state, action)=>{
            state.blog_comment_delete_loading = false;
        }).addCase(handleDeleteBlogComment.rejected, (state)=>{
            state.blog_comment_delete_loading = false;
        }).addCase(handleShowHideBlogComment.pending, (state)=>{
            state.blog_comment_show_hide_loading = true;
        }).addCase(handleShowHideBlogComment.fulfilled, (state, action)=>{
            state.blog_comment_show_hide_loading = false;
        }).addCase(handleShowHideBlogComment.rejected, (state)=>{
            state.blog_comment_show_hide_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = blogSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/teamSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddTeamMember",
    ()=>handleAddTeamMember,
    "handleGetAllTeams",
    ()=>handleGetAllTeams,
    "handleShowHideTeamMember",
    ()=>handleShowHideTeamMember,
    "handleUpdateTeamMember",
    ()=>handleUpdateTeamMember,
    "teamSlice",
    ()=>teamSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    team_list: [],
    team_loading: false,
    add_team_loading: false,
    edit_team_loading: false,
    show_hide_team_loading: false
};
const handleGetAllTeams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("teamSlice/handleGetAllTeams", async ()=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].getTeams);
    return response;
});
const handleAddTeamMember = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("teamSlice/handleAddTeamMember", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_team, {
        body,
        isFile: true
    });
    return response;
});
const handleUpdateTeamMember = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("teamSlice/handleUpdateTeamMember", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_team, {
        body,
        isFile: true
    });
    return response;
});
const handleShowHideTeamMember = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("teamSlice/handleShowHideTeamMember", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].show_hide_team, {
        body
    });
    return response;
});
const teamSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "teamSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllTeams.pending, (state)=>{
            state.team_loading = true;
        }).addCase(handleGetAllTeams.fulfilled, (state, action)=>{
            state.team_loading = false;
            state.team_list = action.payload;
        }).addCase(handleGetAllTeams.rejected, (state)=>{
            state.team_loading = false;
        }).addCase(handleAddTeamMember.pending, (state)=>{
            state.add_team_loading = true;
        }).addCase(handleAddTeamMember.fulfilled, (state, action)=>{
            state.add_team_loading = false;
        }).addCase(handleAddTeamMember.rejected, (state)=>{
            state.add_team_loading = false;
        }).addCase(handleUpdateTeamMember.pending, (state)=>{
            state.edit_team_loading = true;
        }).addCase(handleUpdateTeamMember.fulfilled, (state, action)=>{
            state.edit_team_loading = false;
        }).addCase(handleUpdateTeamMember.rejected, (state)=>{
            state.edit_team_loading = false;
        }).addCase(handleShowHideTeamMember.pending, (state)=>{
            state.show_hide_team_loading = true;
        }).addCase(handleShowHideTeamMember.fulfilled, (state, action)=>{
            state.show_hide_team_loading = false;
        }).addCase(handleShowHideTeamMember.rejected, (state)=>{
            state.show_hide_team_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = teamSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/faqSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "faqSlice",
    ()=>faqSlice,
    "handleAddFaq",
    ()=>handleAddFaq,
    "handleEditFaq",
    ()=>handleEditFaq,
    "handleGetAllFaqs",
    ()=>handleGetAllFaqs,
    "handleShowHideFaq",
    ()=>handleShowHideFaq
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    faq_list: [],
    faq_loading: false,
    add_faq_loading: false,
    edit_faq_loading: false,
    show_hide_faq_loading: false
};
const handleGetAllFaqs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("faqSlice/handleGetAllFaqs", async ()=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].getFaqs);
    return response;
});
const handleAddFaq = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("faqSlice/handleAddFaq", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_faq, {
        body
    });
    return response;
});
const handleEditFaq = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("faqSlice/handleEditFaq", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_faq, {
        body
    });
    return response;
});
const handleShowHideFaq = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("faqSlice/handleShowHideFaq", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].show_hide_faq, {
        body
    });
    return response;
});
const faqSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "faqSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllFaqs.pending, (state)=>{
            state.faq_loading = true;
        }).addCase(handleGetAllFaqs.fulfilled, (state, action)=>{
            state.faq_loading = false;
            state.faq_list = action.payload;
        }).addCase(handleGetAllFaqs.rejected, (state)=>{
            state.faq_loading = false;
        }).addCase(handleAddFaq.pending, (state)=>{
            state.add_faq_loading = true;
        }).addCase(handleAddFaq.fulfilled, (state, action)=>{
            state.add_faq_loading = false;
        }).addCase(handleAddFaq.rejected, (state)=>{
            state.add_faq_loading = false;
        }).addCase(handleEditFaq.pending, (state)=>{
            state.edit_faq_loading = true;
        }).addCase(handleEditFaq.fulfilled, (state, action)=>{
            state.edit_faq_loading = false;
        }).addCase(handleEditFaq.rejected, (state)=>{
            state.edit_faq_loading = false;
        }).addCase(handleShowHideFaq.pending, (state)=>{
            state.show_hide_faq_loading = true;
        }).addCase(handleShowHideFaq.fulfilled, (state, action)=>{
            state.show_hide_faq_loading = false;
        }).addCase(handleShowHideFaq.rejected, (state)=>{
            state.show_hide_faq_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = faqSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/marketersSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleGenerateMarketersCode",
    ()=>handleGenerateMarketersCode,
    "handleGetAllMarketers",
    ()=>handleGetAllMarketers,
    "marketersSlice",
    ()=>marketersSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    marketers_list: [],
    marketers_loading: false,
    generate_code_loading: false,
    generate_code_list: []
};
const handleGetAllMarketers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("marketersSlice/handleGetAllMarketers", async ()=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_marketeres);
    return response;
});
const handleGenerateMarketersCode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("marketersSlice/handleGenerateMarketersCode", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].generate_code, {
        body
    });
    return response;
});
const marketersSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "marketersSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllMarketers.pending, (state)=>{
            state.marketers_loading = true;
        }).addCase(handleGetAllMarketers.fulfilled, (state, action)=>{
            state.marketers_loading = false;
            state.marketers_list = action.payload;
        }).addCase(handleGetAllMarketers.rejected, (state)=>{
            state.marketers_loading = false;
        }).addCase(handleGenerateMarketersCode.pending, (state)=>{
            state.generate_code_loading = true;
        }).addCase(handleGenerateMarketersCode.fulfilled, (state, action)=>{
            state.generate_code_loading = false;
        }).addCase(handleGenerateMarketersCode.rejected, (state)=>{
            state.generate_code_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = marketersSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/roundsSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "add_round_data",
    ()=>add_round_data,
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleActiveRound",
    ()=>handleActiveRound,
    "handleAddBaiskRound",
    ()=>handleAddBaiskRound,
    "handleCopyRound",
    ()=>handleCopyRound,
    "handleDeleteRound",
    ()=>handleDeleteRound,
    "handleEditBaiskRound",
    ()=>handleEditBaiskRound,
    "handleGetAllRounds",
    ()=>handleGetAllRounds,
    "handleGetRoundLessons",
    ()=>handleGetRoundLessons,
    "handleGetRoundResources",
    ()=>handleGetRoundResources,
    "handleGetSourceRound",
    ()=>handleGetSourceRound,
    "roundsSlice",
    ()=>roundsSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    rounds_list: [],
    rounds_loading: false,
    source_round_list: [],
    source_round_loading: false,
    add_round_loading: false,
    store_round: [],
    edit_round_loading: false,
    active_round_loading: false,
    copy_round_loading: false,
    delet_round_loading: false,
    round_resources_list: [],
    round_resources_loading: false,
    all_round_lessons: [],
    all_round_lessons_loading: false
};
const handleGetAllRounds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundesSlice/handleGetAllRounds", async ({ course_category_id, per_page, page } = {})=>{
    if (page && per_page) {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_rounds}?course_category_id=${course_category_id}&per_page=${per_page}&page=${page}`);
        return response;
    } else {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_rounds}?course_category_id=${course_category_id}`);
        return response;
    }
});
const handleGetSourceRound = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundesSlice/handleGetSourceRound", async ({ page = 1, per_page = 100000 } = {})=>{
    // لو بعت page و per_page استخدمهم في الكويري
    if (page && per_page) {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_source_rounds}?page=${page}&per_page=${per_page}`);
        return response;
    }
    // لو مبعتهمش خالص أو ناقصين هيرجع الداتا الديفولت من غير pagination params
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_source_rounds);
    return response;
});
const handleGetRoundLessons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundesSlice/handleGetRoundLessons", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(`admin/contents/lessons/get_all_lessons`, {
        body
    });
    return response;
});
const handleAddBaiskRound = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundesSlice/handleAddBaiskRound", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"]?.add_basic_round, {
        body,
        isFile: true
    });
    return response;
});
const handleEditBaiskRound = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundesSlice/handleEditBaiskRound", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_basic_round, {
        body,
        isFile: true
    });
    return response;
});
const handleActiveRound = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundesSlice/handleActiveRound", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].active_round, {
        body,
        isFile: true
    });
    return response;
});
const handleCopyRound = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundesSlice/handleCopyRound", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].copy_round, {
        body
    });
    return response;
});
const handleDeleteRound = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundesSlice/handleDeleteRound", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_round, {
        body
    });
    return response;
});
const handleGetRoundResources = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundesSlice/handleGetRoundResources", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_resources, {
        body
    });
    return response;
});
const roundsSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "roundesSlice",
    initialState,
    reducers: {
        add_round_data: (state, action)=>{
            state.store_round = action.payload;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllRounds.pending, (state)=>{
            state.rounds_loading = true;
        }).addCase(handleGetAllRounds.fulfilled, (state, action)=>{
            state.rounds_loading = false;
            state.rounds_list = action.payload;
        }).addCase(handleGetAllRounds.rejected, (state)=>{
            state.rounds_loading = false;
        }).addCase(handleGetSourceRound.pending, (state)=>{
            state.source_round_loading = true;
        }).addCase(handleGetSourceRound.fulfilled, (state, action)=>{
            state.source_round_loading = false;
            state.source_round_list = action.payload;
        }).addCase(handleGetSourceRound.rejected, (state)=>{
            state.source_round_loading = false;
        }).addCase(handleAddBaiskRound.pending, (state)=>{
            state.add_round_loading = true;
        }).addCase(handleAddBaiskRound.fulfilled, (state, action)=>{
            state.add_round_loading = false;
        }).addCase(handleAddBaiskRound.rejected, (state)=>{
            state.add_round_loading = false;
        }).addCase(handleActiveRound.pending, (state)=>{
            state.active_round_loading = true;
        }).addCase(handleActiveRound.fulfilled, (state, action)=>{
            state.active_round_loading = false;
        }).addCase(handleActiveRound.rejected, (state)=>{
            state.active_round_loading = false;
        }).addCase(handleCopyRound.pending, (state)=>{
            state.copy_round_loading = true;
        }).addCase(handleCopyRound.fulfilled, (state, action)=>{
            state.copy_round_loading = false;
        }).addCase(handleCopyRound.rejected, (state)=>{
            state.copy_round_loading = false;
        }).addCase(handleDeleteRound.pending, (state)=>{
            state.delet_round_loading = true;
        }).addCase(handleDeleteRound.fulfilled, (state, action)=>{
            state.delet_round_loading = false;
        }).addCase(handleDeleteRound.rejected, (state)=>{
            state.delet_round_loading = false;
        }).addCase(handleGetRoundLessons.pending, (state)=>{
            state.all_round_lessons_loading = true;
        }).addCase(handleGetRoundLessons.fulfilled, (state, action)=>{
            state.all_round_lessons_loading = false;
            state.all_round_lessons = action.payload;
        }).addCase(handleGetRoundLessons.rejected, (state)=>{
            state.all_round_lessons_loading = false;
        }).addCase(handleEditBaiskRound.pending, (state)=>{
            state.edit_round_loading = true;
        }).addCase(handleEditBaiskRound.fulfilled, (state, action)=>{
            state.edit_round_loading = false;
        }).addCase(handleEditBaiskRound.rejected, (state)=>{
            state.edit_round_loading = false;
        });
    }
});
const { add_round_data } = roundsSlice.actions;
const __TURBOPACK__default__export__ = roundsSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/categoriesSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "categoriesSlice",
    ()=>categoriesSlice,
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddCategory",
    ()=>handleAddCategory,
    "handleAddCategoryPart",
    ()=>handleAddCategoryPart,
    "handleDeleteCategory",
    ()=>handleDeleteCategory,
    "handleDeleteCategoryPart",
    ()=>handleDeleteCategoryPart,
    "handleEditCategory",
    ()=>handleEditCategory,
    "handleEditCategoryPart",
    ()=>handleEditCategoryPart,
    "handleGetAllCoursesCategories",
    ()=>handleGetAllCoursesCategories,
    "handleGetCategoryParts",
    ()=>handleGetCategoryParts,
    "handleShowHideCategory",
    ()=>handleShowHideCategory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    all_courses_categories_list: [],
    all_courses_categories_loading: false,
    add_course_category_loading: false,
    edit_course_category_loading: false,
    delete_course_category_loading: false,
    active_course_category_loading: false,
    get_categories_parts_list: [],
    get_categories_parts_loading: false,
    add_categories_parts: false,
    edit_categories_parts: false,
    delete_categories_parts: false
};
const handleGetAllCoursesCategories = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("categoriesSlice/handleGetAllCoursesCategories", async ({ per_page, page } = {})=>{
    if (page && per_page) {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_categories}?per_page=${per_page}&page=${page}`);
        return response;
    }
    // fallback if page/per_page not valid
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(`${__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_categories}`);
    return response;
});
const handleAddCategory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("categoriesSlice/handleAddCategory", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_category, {
        body,
        isFile: true
    });
    return response;
});
const handleEditCategory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("categoriesSlice/handleEditCategory", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_category, {
        body,
        isFile: true
    });
    return response;
});
const handleDeleteCategory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("categoriesSlice/handleDeleteCategory", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_category, {
        body,
        isFile: true
    });
    return response;
});
const handleShowHideCategory = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("categoriesSlice/handleShowHideCategory", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].active_category, {
        body,
        isFile: true
    });
    return response;
});
const handleGetCategoryParts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("categoriesSlice/handleGetCategoryParts", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_parts, {
        body
    });
    return response;
});
const handleAddCategoryPart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("categoriesSlice/handleAddCategoryPart", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_part, {
        body,
        isFile: true
    });
    return response;
});
const handleEditCategoryPart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("categoriesSlice/handleEditCategoryPart", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_part, {
        body,
        isFile: true
    });
    return response;
});
const handleDeleteCategoryPart = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("categoriesSlice/handleDeleteCategoryPart", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_part, {
        body
    });
    return response;
});
const categoriesSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "categoriesSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllCoursesCategories.pending, (state)=>{
            state.all_courses_categories_loading = true;
        }).addCase(handleGetAllCoursesCategories.fulfilled, (state, action)=>{
            state.all_courses_categories_list = action.payload;
            state.all_courses_categories_loading = false;
        }).addCase(handleGetAllCoursesCategories.rejected, (state)=>{
            state.all_courses_categories_loading = false;
        }).addCase(handleAddCategory.pending, (state)=>{
            state.add_course_category_loading = true;
        }).addCase(handleAddCategory.fulfilled, (state, action)=>{
            state.add_course_category_loading = false;
        }).addCase(handleAddCategory.rejected, (state)=>{
            state.add_course_category_loading = false;
        }).addCase(handleEditCategory.pending, (state)=>{
            state.edit_course_category_loading = true;
        }).addCase(handleEditCategory.fulfilled, (state, action)=>{
            state.edit_course_category_loading = false;
        }).addCase(handleEditCategory.rejected, (state)=>{
            state.edit_course_category_loading = false;
        }).addCase(handleDeleteCategory.pending, (state)=>{
            state.delete_course_category_loading = true;
        }).addCase(handleDeleteCategory.fulfilled, (state, action)=>{
            state.delete_course_category_loading = false;
        }).addCase(handleDeleteCategory.rejected, (state)=>{
            state.delete_course_category_loading = false;
        }).addCase(handleShowHideCategory.pending, (state)=>{
            state.active_course_category_loading = true;
        }).addCase(handleShowHideCategory.fulfilled, (state, action)=>{
            state.active_course_category_loading = false;
        }).addCase(handleShowHideCategory.rejected, (state)=>{
            state.active_course_category_loading = false;
        }).addCase(handleGetCategoryParts.pending, (state)=>{
            state.get_categories_parts_loading = true;
        }).addCase(handleGetCategoryParts.fulfilled, (state, action)=>{
            state.get_categories_parts_loading = false;
            state.get_categories_parts_list = action.payload;
        }).addCase(handleGetCategoryParts.rejected, (state)=>{
            state.get_categories_parts_loading = false;
        }).addCase(handleAddCategoryPart.pending, (state)=>{
            state.add_categories_parts = true;
        }).addCase(handleAddCategoryPart.fulfilled, (state, action)=>{
            state.add_categories_parts = false;
        }).addCase(handleAddCategoryPart.rejected, (state)=>{
            state.add_categories_parts = false;
        }).addCase(handleEditCategoryPart.pending, (state)=>{
            state.edit_categories_parts = true;
        }).addCase(handleEditCategoryPart.fulfilled, (state, action)=>{
            state.edit_categories_parts = false;
        }).addCase(handleEditCategoryPart.rejected, (state)=>{
            state.edit_categories_parts = false;
        }).addCase(handleDeleteCategoryPart.pending, (state)=>{
            state.delete_categories_parts = true;
        }).addCase(handleDeleteCategoryPart.fulfilled, (state, action)=>{
            state.delete_categories_parts = false;
        }).addCase(handleDeleteCategoryPart.rejected, (state)=>{
            state.delete_categories_parts = false;
        });
    }
});
const __TURBOPACK__default__export__ = categoriesSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/teacherSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddTeacher",
    ()=>handleAddTeacher,
    "handleDeleteTeacher",
    ()=>handleDeleteTeacher,
    "handleEditTeacher",
    ()=>handleEditTeacher,
    "handleGetAllTeachers",
    ()=>handleGetAllTeachers,
    "teacherSlice",
    ()=>teacherSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    teachers_list: [],
    teachers_loading: false,
    add_teacher_loading: false,
    edit_teacher_loading: false,
    delete_teahcer_loading: false
};
const handleGetAllTeachers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("teahcerSlice/handleGetAllTeachers", async ()=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_teacher);
    return response;
});
const handleAddTeacher = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("teahcerSlice/handleAddTeacher", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_teacher, {
        body,
        isFile: true
    });
    return response;
});
const handleEditTeacher = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("teahcerSlice/handleEditTeacher", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_teacher, {
        body,
        isFile: true
    });
    return response;
});
const handleDeleteTeacher = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("teahcerSlice/handleDeleteTeacher", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_teacher, {
        body
    });
    return response;
});
const teacherSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "teahcerSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllTeachers.pending, (state)=>{
            state.teachers_loading = true;
        }).addCase(handleGetAllTeachers.fulfilled, (state, action)=>{
            state.teachers_loading = false;
            state.teachers_list = action.payload;
        }).addCase(handleGetAllTeachers.rejected, (state)=>{
            state.teachers_loading = false;
        }).addCase(handleAddTeacher.pending, (state)=>{
            state.add_teacher_loading = true;
        }).addCase(handleAddTeacher.fulfilled, (state, action)=>{
            state.add_teacher_loading = false;
            state.teachers_list = action.payload;
        }).addCase(handleAddTeacher.rejected, (state)=>{
            state.add_teacher_loading = false;
        }).addCase(handleEditTeacher.pending, (state)=>{
            state.edit_teacher_loading = true;
        }).addCase(handleEditTeacher.fulfilled, (state, action)=>{
            state.edit_teacher_loading = false;
            state.teachers_list = action.payload;
        }).addCase(handleEditTeacher.rejected, (state)=>{
            state.edit_teacher_loading = false;
        }).addCase(handleDeleteTeacher.pending, (state)=>{
            state.delete_teahcer_loading = true;
        }).addCase(handleDeleteTeacher.fulfilled, (state, action)=>{
            state.delete_teahcer_loading = false;
            state.teachers_list = action.payload;
        }).addCase(handleDeleteTeacher.rejected, (state)=>{
            state.delete_teahcer_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = teacherSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/certificateSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "certificateSlice",
    ()=>certificateSlice,
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddCertificate",
    ()=>handleAddCertificate,
    "handleDeleteCertificate",
    ()=>handleDeleteCertificate,
    "handleEditCertificate",
    ()=>handleEditCertificate,
    "handleGetAllApplications",
    ()=>handleGetAllApplications
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    certificate_list: [],
    certificate_loading: false,
    applications_list: [],
    applications_loading: false,
    add_certificate_loading: false,
    edit_certificate_loading: false,
    delete_certificate_loading: false
};
const handleGetAllApplications = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("certificateSlice/handleGetAllApplications", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_certificates, {
        body
    });
    return response;
});
const handleAddCertificate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("certificateSlice/handleAddCertificate", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_certificates, {
        body
    });
    return response;
});
const handleEditCertificate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("certificateSlice/handleEditCertificate", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_certificate, {
        body
    });
    return response;
});
const handleDeleteCertificate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("certificateSlice/handleDeleteCertificate", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_certificate, {
        body
    });
    return response;
});
const certificateSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "certificateSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllApplications.pending, (state)=>{
            state.applications_loading = true;
        }).addCase(handleGetAllApplications.fulfilled, (state, action)=>{
            state.applications_list = action.payload;
            state.applications_loading = false;
        }).addCase(handleGetAllApplications.rejected, (state)=>{
            state.applications_loading = false;
        }).addCase(handleAddCertificate.pending, (state)=>{
            state.add_certificate_loading = true;
        }).addCase(handleAddCertificate.fulfilled, (state, action)=>{
            state.add_certificate_loading = false;
        }).addCase(handleAddCertificate.rejected, (state)=>{
            state.add_certificate_loading = false;
        }).addCase(handleEditCertificate.pending, (state)=>{
            state.edit_certificate_loading = true;
        }).addCase(handleEditCertificate.fulfilled, (state, action)=>{
            state.edit_certificate_loading = false;
        }).addCase(handleEditCertificate.rejected, (state)=>{
            state.edit_certificate_loading = false;
        }).addCase(handleDeleteCertificate.pending, (state)=>{
            state.delete_certificate_loading = true;
        }).addCase(handleDeleteCertificate.fulfilled, (state, action)=>{
            state.delete_certificate_loading = false;
        }).addCase(handleDeleteCertificate.rejected, (state)=>{
            state.delete_certificate_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = certificateSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/badgeSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "badgeSlice",
    ()=>badgeSlice,
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAssignBadgeToStudent",
    ()=>handleAssignBadgeToStudent,
    "handleCreateBadge",
    ()=>handleCreateBadge,
    "handleDeleteBadge",
    ()=>handleDeleteBadge,
    "handleEditBadge",
    ()=>handleEditBadge,
    "handleGetAllBadges",
    ()=>handleGetAllBadges,
    "handleGetAllStudentBadges",
    ()=>handleGetAllStudentBadges
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    badges_list: [],
    badges_loading: false,
    all_badges_list: [],
    all_badges_loading: false,
    student_badges_loading: false,
    student_badges_list: [],
    assign_badge_loading: false,
    create_badge_loading: false,
    edit_badge_loading: false,
    delete_badge_loading: false
};
const handleGetAllBadges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("badgeSlice/handleGetAllBadges", async ()=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_badges);
    return response;
});
const handleCreateBadge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("badgeSlice/handleCreateBadge", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_badge, {
        body,
        isFile: true
    });
    return response;
});
const handleGetAllStudentBadges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("badgeSlice/handleGetAllStudentBadges", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].studuent_badges, {
        body
    });
    return response;
});
const handleEditBadge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('badgeSlice/handleEditBadge', async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_badge, {
        body,
        isFile: true
    });
    return response;
});
const handleDeleteBadge = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])('badgeSlice/handleDeleteBadge', async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_badge, {
        body
    });
    return response;
});
const handleAssignBadgeToStudent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("badgeSlice/handleAssignBadgeToStudent", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].assign_page_to_student, {
        body
    });
    return response;
});
const badgeSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "badgeSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllBadges.pending, (state)=>{
            state.all_badges_loading = true;
        }).addCase(handleGetAllBadges.fulfilled, (state, action)=>{
            state.all_badges_loading = false;
            state.all_badges_list = action.payload;
        }).addCase(handleGetAllBadges.rejected, (state)=>{
            state.all_badges_loading = false;
        }).addCase(handleCreateBadge.pending, (state)=>{
            state.create_badge_loading = true;
        }).addCase(handleCreateBadge.fulfilled, (state, action)=>{
            state.create_badge_loading = false;
        }).addCase(handleCreateBadge.rejected, (state)=>{
            state.create_badge_loading = false;
        }).addCase(handleEditBadge.pending, (state)=>{
            state.edit_badge_loading = true;
        }).addCase(handleEditBadge.fulfilled, (state, action)=>{
            state.edit_badge_loading = false;
        }).addCase(handleEditBadge.rejected, (state)=>{
            state.edit_badge_loading = false;
        }).addCase(handleDeleteBadge.pending, (state)=>{
            state.delete_badge_loading = true;
        }).addCase(handleDeleteBadge.fulfilled, (state, action)=>{
            state.delete_badge_loading = false;
        }).addCase(handleDeleteBadge.rejected, (state)=>{
            state.delete_badge_loading = false;
        }).addCase(handleGetAllStudentBadges.pending, (state)=>{
            state.student_badges_loading = true;
        }).addCase(handleGetAllStudentBadges.fulfilled, (state, action)=>{
            state.student_badges_loading = false;
            state.student_badges_list = action.payload;
        }).addCase(handleGetAllStudentBadges.rejected, (state)=>{
            state.student_badges_loading = false;
        }).addCase(handleAssignBadgeToStudent.pending, (state)=>{
            state.assign_badge_loading = true;
        }).addCase(handleAssignBadgeToStudent.fulfilled, (state)=>{
            state.assign_badge_loading = false;
        }).addCase(handleAssignBadgeToStudent.rejected, (state)=>{
            state.assign_badge_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = badgeSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/resourcesSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddRoundResource",
    ()=>handleAddRoundResource,
    "handleDeleteRoundResource",
    ()=>handleDeleteRoundResource,
    "handleEditRoundResource",
    ()=>handleEditRoundResource,
    "handleGetAllRoundResources",
    ()=>handleGetAllRoundResources,
    "resourcesSlice",
    ()=>resourcesSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    all_resources_list: [],
    all_resources_loading: false,
    add_resource_loading: false,
    edit_resource_loading: false,
    delete_resource_loading: false
};
const handleGetAllRoundResources = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("resourcesSlice/handleGetAllRoundResources", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_resources, {
        body
    });
    return response;
});
const handleAddRoundResource = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("resourcesSlice/handleAddRoundResource", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_resources, {
        body,
        isFile: true
    });
    return response;
});
const handleEditRoundResource = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("resourcesSlice/handleEditRoundResource", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_resources, {
        body,
        isFile: true
    });
    return response;
});
const handleDeleteRoundResource = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("resourcesSlice/handleDeleteRoundResource", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_resource, {
        body
    });
    return response;
});
const resourcesSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "resourcesSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllRoundResources.pending, (state)=>{
            state.all_resources_loading = true;
        }).addCase(handleGetAllRoundResources.fulfilled, (state, action)=>{
            state.all_resources_loading = false;
            state.all_resources_list = action.payload;
        }).addCase(handleGetAllRoundResources.rejected, (state)=>{
            state.all_resources_loading = false;
        }).addCase(handleAddRoundResource.pending, (state)=>{
            state.add_resource_loading = true;
        }).addCase(handleAddRoundResource.fulfilled, (state, action)=>{
            state.add_resource_loading = false;
        }).addCase(handleAddRoundResource.rejected, (state)=>{
            state.add_resource_loading = false;
        }).addCase(handleEditRoundResource.pending, (state)=>{
            state.edit_resource_loading = true;
        }).addCase(handleEditRoundResource.fulfilled, (state, action)=>{
            state.edit_resource_loading = false;
        }).addCase(handleEditRoundResource.rejected, (state)=>{
            state.edit_resource_loading = false;
        }).addCase(handleDeleteRoundResource.pending, (state)=>{
            state.delete_resource_loading = true;
        }).addCase(handleDeleteRoundResource.fulfilled, (state, action)=>{
            state.delete_resource_loading = false;
        }).addCase(handleDeleteRoundResource.rejected, (state)=>{
            state.delete_resource_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = resourcesSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "examSlice",
    ()=>examSlice,
    "handleAddExamPdf",
    ()=>handleAddExamPdf,
    "handleAddExamVideo",
    ()=>handleAddExamVideo,
    "handleAddQuestion",
    ()=>handleAddQuestion,
    "handleAssignExam",
    ()=>handleAssignExam,
    "handleCreateExam",
    ()=>handleCreateExam,
    "handleCreateExamSection",
    ()=>handleCreateExamSection,
    "handleDeleteExam",
    ()=>handleDeleteExam,
    "handleDeleteExamPdf",
    ()=>handleDeleteExamPdf,
    "handleDeleteExamQuestions",
    ()=>handleDeleteExamQuestions,
    "handleDeleteExamSection",
    ()=>handleDeleteExamSection,
    "handleDeleteExamVideo",
    ()=>handleDeleteExamVideo,
    "handleEditExam",
    ()=>handleEditExam,
    "handleEditExamPdf",
    ()=>handleEditExamPdf,
    "handleEditExamPdfFile",
    ()=>handleEditExamPdfFile,
    "handleEditExamSection",
    ()=>handleEditExamSection,
    "handleEditExamVideo",
    ()=>handleEditExamVideo,
    "handleGetAllExamData",
    ()=>handleGetAllExamData,
    "handleGetAllExamSections",
    ()=>handleGetAllExamSections,
    "handleGetAllExams",
    ()=>handleGetAllExams,
    "handleGetExamDetails",
    ()=>handleGetExamDetails,
    "handleGetExamQuestions",
    ()=>handleGetExamQuestions,
    "handleUpdateExamQuestions",
    ()=>handleUpdateExamQuestions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    all_exam_list: [],
    all_exam_loading: false,
    add_exam_loading: false,
    edit_exam_loading: false,
    delete_exam_loading: false,
    add_exam_section_loading: false,
    edit_exam_section_loading: false,
    delete_exam_section_loading: false,
    get_exam_sections_list: [],
    get_exam_sections_loading: false,
    assign_exam_loading: false,
    get_exam_questions_list: [],
    get_exam_question_loading: false,
    add_question_loading: false,
    get_exam_details_loading: false,
    edit_question_loading: false,
    delete_question_loading: false,
    exam_details: [],
    add_exam_video_loading: false,
    edit_exam_video_loading: false,
    delete_exam_video_loading: false,
    add_exam_pdf: false,
    edit_exam_pdf: false,
    delete_exam_pdf: false,
    all_exam_data_list: [],
    all_exam_data_loading: false
};
const handleGetAllExams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleGetAllExams", async ({ page, per_page })=>{
    if (page && per_page) {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_exams, {
            body: {
                page,
                per_page
            }
        });
        return response;
    } else {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_exams);
        return response;
    }
});
const handleCreateExam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleCreateExam", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_exam, {
        body
    });
    return response;
});
const handleEditExam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleEditExam", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_exam, {
        body
    });
    return response;
});
const handleDeleteExam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleDeleteExam", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_exam, {
        body
    });
    return response;
});
const handleGetAllExamSections = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleGetAllExamSections", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_exam_sections, {
        body
    });
    return response;
});
const handleCreateExamSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleCreateExamSection", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_exam_sections, {
        body
    });
    return response;
});
const handleEditExamSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleEditExamSection", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post("admin/exams/exam-sections/edit_exam_section", {
        body
    });
    return response;
});
const handleDeleteExamSection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleDeleteExamSection", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_exam_sections, {
        body
    });
    return response;
});
const handleAssignExam = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleAssignExam", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].assign_exam, {
        body
    });
    return response;
});
const handleGetExamQuestions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleGetExamQuestions", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_questions, {
        body
    });
    return response;
});
const handleUpdateExamQuestions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleUpdateExamQuestions", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(`admin/questions/edit_question`, {
        body
    });
    return response;
});
const handleDeleteExamQuestions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleDeleteExamQuestions", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(`admin/questions/delete_question`, {
        body
    });
    return response;
});
const handleGetAllExamData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleGetAllExamData", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post("admin/exams/get_exam_all_data_by_id", {
        body
    });
    return response;
});
const handleAddQuestion = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleAddQuestion", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].store_question, {
        body
    });
    return response;
});
const handleGetExamDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleGetExamDetails", async ({ exam_id })=>{
    const body = {
        exam_id
    };
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_exam_sections, {
        body
    });
    return response;
});
const handleAddExamPdf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleAddExamPdf", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_exam_pdf, {
        body,
        isFile: true
    });
    return response;
});
const handleEditExamPdf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleEditExamPdf", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_exam_pdf, {
        body,
        isFile: true
    });
    return response;
});
const handleDeleteExamPdf = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleDeleteExamPdf", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_exam_pdf, {
        body
    });
    return response;
});
const handleEditExamPdfFile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleEditExamPdfFile", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_exam_pdf, {
        body,
        isFile: true
    });
    return response;
});
const handleAddExamVideo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleAddExamVideo", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_exam_video, {
        body
    });
    return response;
});
const handleEditExamVideo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleEditExamVideo", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_exam_video, {
        body
    });
    return response;
});
const handleDeleteExamVideo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("examSlice/handleDeleteExamVideo", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_exam_video, {
        body
    });
    return response;
});
const examSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "examSlice",
    initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllExams.pending, (state)=>{
            state.all_exam_loading = true;
        }).addCase(handleGetAllExams.fulfilled, (state, action)=>{
            state.all_exam_loading = false;
            state.all_exam_list = action.payload;
        }).addCase(handleGetAllExams.rejected, (state)=>{
            state.all_exam_loading = false;
        }).addCase(handleCreateExam.pending, (state)=>{
            state.add_exam_loading = true;
        }).addCase(handleCreateExam.fulfilled, (state, action)=>{
            state.add_exam_loading = false;
        }).addCase(handleCreateExam.rejected, (state)=>{
            state.add_exam_loading = false;
        }).addCase(handleEditExam.pending, (state)=>{
            state.edit_exam_loading = true;
        }).addCase(handleEditExam.fulfilled, (state, action)=>{
            state.edit_exam_loading = false;
        }).addCase(handleEditExam.rejected, (state)=>{
            state.edit_exam_loading = false;
        }).addCase(handleDeleteExam.pending, (state)=>{
            state.delete_exam_loading = true;
        }).addCase(handleDeleteExam.fulfilled, (state, action)=>{
            state.delete_exam_loading = false;
        }).addCase(handleDeleteExam.rejected, (state)=>{
            state.delete_exam_loading = false;
        }).addCase(handleCreateExamSection.pending, (state)=>{
            state.add_exam_section_loading = true;
        }).addCase(handleCreateExamSection.fulfilled, (state, action)=>{
            state.add_exam_section_loading = false;
        }).addCase(handleCreateExamSection.rejected, (state)=>{
            state.add_exam_section_loading = false;
        }).addCase(handleAssignExam.pending, (state)=>{
            state.assign_exam_loading = true;
        }).addCase(handleAssignExam.fulfilled, (state, action)=>{
            state.assign_exam_loading = false;
        }).addCase(handleAssignExam.rejected, (state)=>{
            state.assign_exam_loading = false;
        }).addCase(handleEditExamSection.pending, (state)=>{
            state.edit_exam_section_loading = true;
        }).addCase(handleEditExamSection.fulfilled, (state, action)=>{
            state.edit_exam_section_loading = false;
        }).addCase(handleEditExamSection.rejected, (state)=>{
            state.edit_exam_section_loading = false;
        }).addCase(handleDeleteExamSection.pending, (state)=>{
            state.delete_exam_section_loading = true;
        }).addCase(handleDeleteExamSection.fulfilled, (state, action)=>{
            state.delete_exam_section_loading = false;
        }).addCase(handleDeleteExamSection.rejected, (state)=>{
            state.delete_exam_section_loading = false;
        }).addCase(handleGetAllExamSections.pending, (state)=>{
            state.get_exam_sections_loading = true;
        }).addCase(handleGetAllExamSections.fulfilled, (state, action)=>{
            state.get_exam_sections_loading = false;
            state.get_exam_sections_list = action.payload;
        }).addCase(handleGetAllExamSections.rejected, (state)=>{
            state.get_exam_sections_loading = false;
        }).addCase(handleGetExamQuestions.pending, (state)=>{
            state.get_exam_question_loading = true;
        }).addCase(handleGetExamQuestions.fulfilled, (state, action)=>{
            state.get_exam_question_loading = false;
            state.get_exam_questions_list = action.payload;
        }).addCase(handleGetExamQuestions.rejected, (state)=>{
            state.get_exam_question_loading = false;
        }).addCase(handleAddQuestion.pending, (state)=>{
            state.add_question_loading = true;
        }).addCase(handleAddQuestion.fulfilled, (state, action)=>{
            state.add_question_loading = false;
        }).addCase(handleAddQuestion.rejected, (state)=>{
            state.add_question_loading = false;
        }).addCase(handleUpdateExamQuestions.pending, (state)=>{
            state.edit_question_loading = true;
        }).addCase(handleUpdateExamQuestions.fulfilled, (state, action)=>{
            state.edit_question_loading = false;
        }).addCase(handleUpdateExamQuestions.rejected, (state)=>{
            state.edit_question_loading = false;
        }).addCase(handleDeleteExamQuestions.pending, (state)=>{
            state.delete_question_loading = true;
        }).addCase(handleDeleteExamQuestions.fulfilled, (state, action)=>{
            state.delete_question_loading = false;
        }).addCase(handleDeleteExamQuestions.rejected, (state)=>{
            state.delete_question_loading = false;
        }).addCase(handleGetExamDetails.pending, (state)=>{
            state.get_exam_details_loading = true;
        }).addCase(handleGetExamDetails.fulfilled, (state, action)=>{
            state.get_exam_details_loading = false;
            state.exam_details = action.payload;
        }).addCase(handleGetExamDetails.rejected, (state)=>{
            state.get_exam_details_loading = false;
        }).addCase(handleAddExamPdf.pending, (state)=>{
            state.add_exam_pdf = true;
        }).addCase(handleAddExamPdf.fulfilled, (state, action)=>{
            state.add_exam_pdf = false;
        }).addCase(handleAddExamPdf.rejected, (state)=>{
            state.add_exam_pdf = false;
        }).addCase(handleEditExamPdf.pending, (state)=>{
            state.edit_exam_pdf = true;
        }).addCase(handleEditExamPdf.fulfilled, (state, action)=>{
            state.edit_exam_pdf = false;
        }).addCase(handleEditExamPdf.rejected, (state)=>{
            state.edit_exam_pdf = false;
        }).addCase(handleDeleteExamPdf.pending, (state)=>{
            state.delete_exam_pdf = true;
        }).addCase(handleDeleteExamPdf.fulfilled, (state, action)=>{
            state.delete_exam_pdf = false;
        }).addCase(handleDeleteExamPdf.rejected, (state)=>{
            state.delete_exam_pdf = false;
        }).addCase(handleAddExamVideo.pending, (state)=>{
            state.add_exam_video_loading = true;
        }).addCase(handleAddExamVideo.fulfilled, (state, action)=>{
            state.add_exam_video_loading = false;
        }).addCase(handleAddExamVideo.rejected, (state)=>{
            state.add_exam_video_loading = false;
        }).addCase(handleEditExamVideo.pending, (state)=>{
            state.edit_exam_video_loading = true;
        }).addCase(handleEditExamVideo.fulfilled, (state, action)=>{
            state.edit_exam_video_loading = false;
        }).addCase(handleEditExamVideo.rejected, (state)=>{
            state.edit_exam_video_loading = false;
        }).addCase(handleDeleteExamVideo.pending, (state)=>{
            state.delete_exam_video_loading = true;
        }).addCase(handleDeleteExamVideo.fulfilled, (state, action)=>{
            state.delete_exam_video_loading = false;
        }).addCase(handleDeleteExamVideo.rejected, (state)=>{
            state.delete_exam_video_loading = false;
        }).addCase(handleGetAllExamData.pending, (state)=>{
            state.all_exam_data_loading = true;
        }).addCase(handleGetAllExamData.fulfilled, (state, action)=>{
            state.all_exam_data_loading = false;
            state.all_exam_data_list = action.payload;
        }).addCase(handleGetAllExamData.rejected, (state)=>{
            state.all_exam_data_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = examSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/roundContentSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddRoundContent",
    ()=>handleAddRoundContent,
    "handleDeleteContent",
    ()=>handleDeleteContent,
    "handleEditRoundContent",
    ()=>handleEditRoundContent,
    "handleGetAllRoundContent",
    ()=>handleGetAllRoundContent,
    "roundContentSlice",
    ()=>roundContentSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
;
;
const initialState = {
    all_content_list: [],
    all_content_loading: false,
    store_content_loading: false,
    edit_content_loading: false,
    delete_content_loading: false
};
const handleGetAllRoundContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundContentSlice/handleGetAllRoundContent", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(`admin/rounds-contents/get_all_round_contents`, {
        body
    });
    return response;
});
const handleAddRoundContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundContentSlice/handleAddRoundContent", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(`admin/rounds-contents/store_round_content`, {
        body
    });
    return response;
});
const handleEditRoundContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundContentSlice/handleEditRoundContent", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(`admin/rounds-contents/edit_round_content`, {
        body
    });
    return response;
});
const handleDeleteContent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("roundContentSlice/handleDeleteContent", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post("admin/rounds-contents/delete_round_content", {
        body
    });
    return response;
});
const roundContentSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "roundContentSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllRoundContent.pending, (state)=>{
            state.all_content_loading = true;
        }).addCase(handleGetAllRoundContent.fulfilled, (state, action)=>{
            state.all_content_loading = false;
            state.all_content_list = action.payload;
        }).addCase(handleGetAllRoundContent.rejected, (state)=>{
            state.all_content_loading = false;
        }).addCase(handleAddRoundContent.pending, (state)=>{
            state.store_content_loading = true;
        }).addCase(handleAddRoundContent.fulfilled, (state, action)=>{
            state.store_content_loading = false;
        }).addCase(handleAddRoundContent.rejected, (state)=>{
            state.store_content_loading = false;
        }).addCase(handleEditRoundContent.pending, (state)=>{
            state.edit_content_loading = true;
        }).addCase(handleEditRoundContent.fulfilled, (state, action)=>{
            state.edit_content_loading = false;
        }).addCase(handleEditRoundContent.rejected, (state)=>{
            state.edit_content_loading = false;
        }).addCase(handleDeleteContent.pending, (state)=>{
            state.delete_content_loading = true;
        }).addCase(handleDeleteContent.fulfilled, (state, action)=>{
            state.delete_content_loading = false;
        }).addCase(handleDeleteContent.rejected, (state)=>{
            state.delete_content_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = roundContentSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/lessonSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddRoundLessons",
    ()=>handleAddRoundLessons,
    "handleDeleteRoundLessons",
    ()=>handleDeleteRoundLessons,
    "handleEditRoundLessons",
    ()=>handleEditRoundLessons,
    "handleGetAllRoundLessons",
    ()=>handleGetAllRoundLessons,
    "lessonSlice",
    ()=>lessonSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    all_lessons_list: [],
    all_lessons_loading: false,
    add_lesson_loading: false,
    edit_lesson_loading: false,
    delete_lesson_loading: false
};
const handleGetAllRoundLessons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("lessonSlice/handleGetAllRoundLessons", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_lessons, {
        body
    });
    return response;
});
const handleAddRoundLessons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("lessonSlice/handleAddRoundLessons", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_lesson, {
        body
    });
    return response;
});
const handleEditRoundLessons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("lessonSlice/handleEditRoundLessons", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_lesson, {
        body
    });
    return response;
});
const handleDeleteRoundLessons = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("lessonSlice/handleDeleteRoundLessons", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_lesson, {
        body
    });
    return response;
});
const lessonSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "lessonSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllRoundLessons.pending, (state)=>{
            state.all_lessons_loading = true;
        }).addCase(handleGetAllRoundLessons.fulfilled, (state, action)=>{
            state.all_lessons_loading = false;
            state.all_lessons_list = action.payload;
        }).addCase(handleGetAllRoundLessons.rejected, (state)=>{
            state.all_lessons_loading = false;
        }).addCase(handleAddRoundLessons.pending, (state)=>{
            state.add_lesson_loading = true;
        }).addCase(handleAddRoundLessons.fulfilled, (state, action)=>{
            state.add_lesson_loading = false;
        }).addCase(handleAddRoundLessons.rejected, (state)=>{
            state.add_lesson_loading = false;
        }).addCase(handleEditRoundLessons.pending, (state)=>{
            state.edit_lesson_loading = true;
        }).addCase(handleEditRoundLessons.fulfilled, (state, action)=>{
            state.edit_lesson_loading = false;
        }).addCase(handleEditRoundLessons.rejected, (state)=>{
            state.edit_lesson_loading = false;
        }).addCase(handleDeleteRoundLessons.pending, (state)=>{
            state.delete_lesson_loading = true;
        }).addCase(handleDeleteRoundLessons.fulfilled, (state, action)=>{
            state.delete_lesson_loading = false;
        }).addCase(handleDeleteRoundLessons.rejected, (state)=>{
            state.delete_lesson_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = lessonSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/videoSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddLessonVideo",
    ()=>handleAddLessonVideo,
    "handleDeleteLessonVideo",
    ()=>handleDeleteLessonVideo,
    "handleEditLessonVideo",
    ()=>handleEditLessonVideo,
    "handleGetAllLessonVideo",
    ()=>handleGetAllLessonVideo,
    "videoSlice",
    ()=>videoSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    all_videos_list: [],
    all_videos_loading: false,
    add_video_loading: false,
    edit_video_laoding: false,
    delete_video_loading: false
};
const handleGetAllLessonVideo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("videoSlice/handleGetAllLessonVideo", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_videos, {
        body
    });
    return response;
});
const handleAddLessonVideo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("videoSlice/handleAddLessonVideo", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_video, {
        body
    });
    return response;
});
const handleEditLessonVideo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("videoSlice/handleEditLessonVideo", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_video, {
        body
    });
    return response;
});
const handleDeleteLessonVideo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("videoSlice/handleDeleteLessonVideo", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_video, {
        body
    });
    return response;
});
const videoSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "videoSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllLessonVideo.pending, (state)=>{
            state.all_videos_loading = true;
        }).addCase(handleGetAllLessonVideo.fulfilled, (state, action)=>{
            state.all_videos_loading = false;
            state.all_videos_list = action.payload;
        }).addCase(handleGetAllLessonVideo.rejected, (state)=>{
            state.all_videos_loading = false;
        }).addCase(handleAddLessonVideo.pending, (state)=>{
            state.add_video_loading = true;
        }).addCase(handleAddLessonVideo.fulfilled, (state, action)=>{
            state.add_video_loading = false;
        }).addCase(handleAddLessonVideo.rejected, (state)=>{
            state.add_video_loading = false;
        }).addCase(handleEditLessonVideo.pending, (state)=>{
            state.edit_video_laoding = true;
        }).addCase(handleEditLessonVideo.fulfilled, (state, action)=>{
            state.edit_video_laoding = false;
        }).addCase(handleEditLessonVideo.rejected, (state)=>{
            state.edit_video_laoding = false;
        }).addCase(handleDeleteLessonVideo.pending, (state)=>{
            state.delete_video_loading = true;
        }).addCase(handleDeleteLessonVideo.fulfilled, (state, action)=>{
            state.delete_video_loading = false;
        }).addCase(handleDeleteLessonVideo.rejected, (state)=>{
            state.delete_video_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = videoSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/featuresSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "featuresSlice",
    ()=>featuresSlice,
    "handleAddRoundFeatures",
    ()=>handleAddRoundFeatures,
    "handleDeleteRoundFeatures",
    ()=>handleDeleteRoundFeatures,
    "handleEditRoundFeatures",
    ()=>handleEditRoundFeatures,
    "handleGetAllRoundFeatures",
    ()=>handleGetAllRoundFeatures
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    all_features_list: [],
    all_features_loading: false,
    add_feature_loading: false,
    edit_feature_loading: false,
    delete_feature_loading: false
};
const handleGetAllRoundFeatures = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("featuresSlice/handleGetAllRoundFeatures", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_features, {
        body
    });
    return response;
});
const handleAddRoundFeatures = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("featuresSlice/handleAddRoundFeatures", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_feature, {
        body,
        isFile: true
    });
    return response;
});
const handleEditRoundFeatures = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("featuresSlice/handleEditRoundFeatures", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_feature, {
        body,
        isFile: true
    });
    return response;
});
const handleDeleteRoundFeatures = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("featuresSlice/handleDeleteRoundFeatures", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_feature, {
        body
    });
    return response;
});
const featuresSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "featuresSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllRoundFeatures.pending, (state)=>{
            state.all_features_loading = true;
        }).addCase(handleGetAllRoundFeatures.fulfilled, (state, action)=>{
            state.all_features_loading = false;
            state.all_features_list = action.payload;
        }).addCase(handleGetAllRoundFeatures.rejected, (state)=>{
            state.all_features_loading = false;
        }).addCase(handleAddRoundFeatures.pending, (state)=>{
            state.add_feature_loading = true;
        }).addCase(handleAddRoundFeatures.fulfilled, (state, action)=>{
            state.add_feature_loading = false;
        }).addCase(handleAddRoundFeatures.rejected, (state)=>{
            state.add_feature_loading = false;
        }).addCase(handleEditRoundFeatures.pending, (state)=>{
            state.edit_feature_loading = true;
        }).addCase(handleEditRoundFeatures.fulfilled, (state, action)=>{
            state.edit_feature_loading = false;
        }).addCase(handleEditRoundFeatures.rejected, (state)=>{
            state.edit_feature_loading = false;
        }).addCase(handleDeleteRoundFeatures.pending, (state)=>{
            state.delete_feature_loading = true;
        }).addCase(handleDeleteRoundFeatures.fulfilled, (state, action)=>{
            state.delete_feature_loading = false;
        }).addCase(handleDeleteRoundFeatures.rejected, (state)=>{
            state.delete_feature_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = featuresSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/storeSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddStoreData",
    ()=>handleAddStoreData,
    "handleDeleteStoreData",
    ()=>handleDeleteStoreData,
    "handleEditStoreData",
    ()=>handleEditStoreData,
    "handleGetAllStoreData",
    ()=>handleGetAllStoreData,
    "storeSlice",
    ()=>storeSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    add_store_loading: false,
    edit_store_loading: false,
    delete_store_loading: false,
    all_store_list: [],
    all_store_loading: false
};
const handleGetAllStoreData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("storeSlice/handleGetAllStoreData", async ()=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].get(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_store);
    return response;
});
const handleAddStoreData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("storeSlice/handleAddStoreData", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].add_store, {
        body,
        isFile: true
    });
    return response;
});
const handleEditStoreData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("storeSlice/handleEditStoreData", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_store, {
        body,
        isFile: true
    });
    return response;
});
const handleDeleteStoreData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("storeSlice/handleDeleteStoreData", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_store, {
        body,
        isFile: true
    });
    return response;
});
const storeSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "storeSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleAddStoreData.pending, (state)=>{
            state.add_store_loading = true;
        }).addCase(handleAddStoreData.fulfilled, (state)=>{
            state.add_store_loading = false;
        }).addCase(handleAddStoreData.rejected, (state)=>{
            state.add_store_loading = false;
        }).addCase(handleEditStoreData.pending, (state)=>{
            state.edit_store_loading = true;
        }).addCase(handleEditStoreData.fulfilled, (state)=>{
            state.edit_store_loading = false;
        }).addCase(handleEditStoreData.rejected, (state)=>{
            state.edit_store_loading = false;
        }).addCase(handleDeleteStoreData.pending, (state)=>{
            state.delete_store_loading = true;
        }).addCase(handleDeleteStoreData.fulfilled, (state)=>{
            state.delete_store_loading = false;
        }).addCase(handleDeleteStoreData.rejected, (state)=>{
            state.delete_store_loading = false;
        }).addCase(handleGetAllStoreData.pending, (state)=>{
            state.all_store_loading = true;
        }).addCase(handleGetAllStoreData.fulfilled, (state, action)=>{
            state.all_store_loading = false;
            state.all_store_list = action.payload;
        }).addCase(handleGetAllStoreData.rejected, (state)=>{
            state.all_store_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = storeSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/studentSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleCancelStudentRound",
    ()=>handleCancelStudentRound,
    "handleGetAllStudents",
    ()=>handleGetAllStudents,
    "handleGetStudentDetails",
    ()=>handleGetStudentDetails,
    "handleGetStudentRounds",
    ()=>handleGetStudentRounds,
    "handleInrollStudentRound",
    ()=>handleInrollStudentRound,
    "studentSlice",
    ()=>studentSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    get_students_list: [],
    get_students_loading: false,
    get_student_rounds_list: [],
    get_student_rounds_loading: false,
    cancel_student_round_loading: false,
    inroll_student_round_loading: false,
    get_student_by_phone_list: [],
    get_student_by_phone_loading: false
};
const handleGetAllStudents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("studentSlice/handleGetAllStudents", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_students, {
        body
    });
    return response;
});
const handleGetStudentDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("studentSlice/handleGetStudentDetails", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_student_by_phone, {
        body
    });
    return response;
});
const handleGetStudentRounds = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("studentSlice/handleGetStudentRounds", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_student_round, {
        body
    });
    return response;
});
const handleInrollStudentRound = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("studentSlice/handleInrollStudentRound", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].inroll_student_round, {
        body
    });
    return response;
});
const handleCancelStudentRound = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("studentSlice/handleCancelStudentRound", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].cancel_student_round, {
        body
    });
    return response;
});
const studentSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "studentSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllStudents.pending, (state)=>{
            state.get_students_loading = true;
        }).addCase(handleGetAllStudents.fulfilled, (state, action)=>{
            state.get_students_loading = false;
            state.get_students_list = action.payload;
        }).addCase(handleGetAllStudents.rejected, (state)=>{
            state.get_students_loading = false;
        }).addCase(handleGetStudentDetails.pending, (state)=>{
            state.get_student_by_phone_loading = true;
        }).addCase(handleGetStudentDetails.fulfilled, (state, action)=>{
            state.get_student_by_phone_loading = false;
            state.get_student_by_phone_list = action.payload;
        }).addCase(handleGetStudentDetails.rejected, (state)=>{
            state.get_student_by_phone_loading = false;
        }).addCase(handleInrollStudentRound.pending, (state)=>{
            state.inroll_student_round_loading = true;
        }).addCase(handleInrollStudentRound.fulfilled, (state, action)=>{
            state.inroll_student_round_loading = false;
        }).addCase(handleInrollStudentRound.rejected, (state)=>{
            state.inroll_student_round_loading = false;
        }).addCase(handleCancelStudentRound.pending, (state)=>{
            state.cancel_student_round_loading = true;
        }).addCase(handleCancelStudentRound.fulfilled, (state, action)=>{
            state.cancel_student_round_loading = false;
        }).addCase(handleCancelStudentRound.rejected, (state)=>{
            state.cancel_student_round_loading = false;
        }).addCase(handleGetStudentRounds.pending, (state)=>{
            state.get_student_rounds_loading = true;
        }).addCase(handleGetStudentRounds.fulfilled, (state, action)=>{
            state.get_student_rounds_loading = false;
            state.get_student_rounds_list = action.payload;
        }).addCase(handleGetStudentRounds.rejected, (state)=>{
            state.get_student_rounds_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = studentSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/livesSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleActiveLive",
    ()=>handleActiveLive,
    "handleDeleteLive",
    ()=>handleDeleteLive,
    "handleEditLive",
    ()=>handleEditLive,
    "handleGetAllLives",
    ()=>handleGetAllLives,
    "handleMarkLiveAsFinish",
    ()=>handleMarkLiveAsFinish,
    "handleStoreLive",
    ()=>handleStoreLive,
    "livesSlice",
    ()=>livesSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/routes.jsx [app-ssr] (ecmascript)");
;
;
;
const initialState = {
    all_lives_list: [],
    all_lives_loading: false,
    store_live_loading: false,
    edit_live_loading: false,
    delete_live_loading: false,
    active_live_loading: false,
    mark_live_finish_loading: false
};
const handleGetAllLives = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("livesSlice/handleGetAllLives", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].get_lives, {
        body
    });
    return response;
});
const handleStoreLive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("livesSlice/handleStoreLive", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].store_live, {
        body
    });
    return response;
});
const handleEditLive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("livesSlice/handleEditLive", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].edit_live, {
        body
    });
    return response;
});
const handleDeleteLive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("livesSlice/handleDeleteLive", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].delete_live, {
        body
    });
    return response;
});
const handleActiveLive = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("livesSlice/handleActiveLive", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].active_live, {
        body
    });
    return response;
});
const handleMarkLiveAsFinish = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("livesSlice/handleMarkLiveAsFinish", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$routes$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["apiRoutes"].mark_live, {
        body
    });
    return response;
});
const livesSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "livesSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleGetAllLives.pending, (state)=>{
            state.all_lives_loading = true;
        }).addCase(handleGetAllLives.fulfilled, (state, action)=>{
            state.all_lives_loading = false;
            state.all_lives_list = action.payload;
        }).addCase(handleGetAllLives.rejected, (state)=>{
            state.all_lives_loading = false;
        }).addCase(handleStoreLive.pending, (state)=>{
            state.store_live_loading = true;
        }).addCase(handleStoreLive.fulfilled, (state, action)=>{
            state.store_live_loading = false;
        }).addCase(handleStoreLive.rejected, (state)=>{
            state.store_live_loading = false;
        }).addCase(handleEditLive.pending, (state)=>{
            state.edit_live_loading = true;
        }).addCase(handleEditLive.fulfilled, (state, action)=>{
            state.edit_live_loading = false;
        }).addCase(handleEditLive.rejected, (state)=>{
            state.edit_live_loading = false;
        }).addCase(handleActiveLive.pending, (state)=>{
            state.active_live_loading = true;
        }).addCase(handleActiveLive.fulfilled, (state, action)=>{
            state.active_live_loading = false;
        }).addCase(handleActiveLive.rejected, (state)=>{
            state.active_live_loading = false;
        }).addCase(handleMarkLiveAsFinish.pending, (state)=>{
            state.mark_live_finish_loading = true;
        }).addCase(handleMarkLiveAsFinish.fulfilled, (state, action)=>{
            state.mark_live_finish_loading = false;
        }).addCase(handleMarkLiveAsFinish.rejected, (state)=>{
            state.mark_live_finish_loading = false;
        }).addCase(handleDeleteLive.pending, (state)=>{
            state.delete_live_loading = true;
        }).addCase(handleDeleteLive.fulfilled, (state, action)=>{
            state.delete_live_loading = false;
        }).addCase(handleDeleteLive.rejected, (state)=>{
            state.delete_live_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = livesSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/features/termsConditionSlice.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "handleAddTerms",
    ()=>handleAddTerms,
    "handleDeleteTerms",
    ()=>handleDeleteTerms,
    "handleEditTerms",
    ()=>handleEditTerms,
    "termsConditionSlice",
    ()=>termsConditionSlice
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/shared/api.jsx [app-ssr] (ecmascript)");
;
;
const initialState = {
    add_terms_loading: false,
    edit_terms_loading: false,
    delete_terms_loading: false
};
const handleAddTerms = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("termsConditionSlice/handleAddTerms", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post("admin/rounds/addRoundTerm", {
        body
    });
    return response;
});
const handleEditTerms = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("termsConditionSlice/handleEditTerms", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post("admin/rounds/editRoundTerm", {
        body
    });
    return response;
});
const handleDeleteTerms = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createAsyncThunk"])("termsConditionSlice/handleDeleteTerms", async ({ body })=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$shared$2f$api$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"].post("admin/rounds/deleteRoundTerm", {
        body
    });
    return response;
});
const termsConditionSlice = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createSlice"])({
    name: "termsConditionSlice",
    initialState,
    extraReducers: (builder)=>{
        builder.addCase(handleAddTerms.pending, (state)=>{
            state.add_terms_loading = true;
        }).addCase(handleAddTerms.fulfilled, (state)=>{
            state.add_terms_loading = false;
        }).addCase(handleAddTerms.rejected, (state)=>{
            state.add_terms_loading = false;
        }).addCase(handleEditTerms.pending, (state)=>{
            state.edit_terms_loading = true;
        }).addCase(handleEditTerms.fulfilled, (state)=>{
            state.edit_terms_loading = false;
        }).addCase(handleEditTerms.rejected, (state)=>{
            state.edit_terms_loading = false;
        }).addCase(handleDeleteTerms.pending, (state)=>{
            state.delete_terms_loading = true;
        }).addCase(handleDeleteTerms.fulfilled, (state)=>{
            state.delete_terms_loading = false;
        }).addCase(handleDeleteTerms.rejected, (state)=>{
            state.delete_terms_loading = false;
        });
    }
});
const __TURBOPACK__default__export__ = termsConditionSlice.reducer;
}),
"[project]/Desktop/nartaqi/lib/store/rootReducer.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "rootReducer",
    ()=>rootReducer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$redux$2f$dist$2f$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/redux/dist/redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$authSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/authSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$blogSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/blogSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$teamSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/teamSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$faqSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/faqSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$marketersSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/marketersSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundsSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$categoriesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/categoriesSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$teacherSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/teacherSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$certificateSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/certificateSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$badgeSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/badgeSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$resourcesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/resourcesSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/examSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundContentSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$lessonSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/lessonSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$videoSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/videoSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/featuresSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$storeSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/storeSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$studentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/studentSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$livesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/livesSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$termsConditionSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/termsConditionSlice.jsx [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const rootReducer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$redux$2f$dist$2f$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["combineReducers"])({
    auth: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$authSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    blogs: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$blogSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    team: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$teamSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    faq: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$faqSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    marketer: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$marketersSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    rounds: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    categories: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$categoriesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    teachers: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$teacherSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    certificate: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$certificateSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    badges: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$badgeSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    resource: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$resourcesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    exam: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$examSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    content: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundContentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    lesson: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$lessonSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    videos: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$videoSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    features: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    store: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$storeSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    students: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$studentSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    lives: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$livesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    terms: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$termsConditionSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
});
}),
"[project]/Desktop/nartaqi/lib/store/index.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "store",
    ()=>store
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$store$2f$rootReducer$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/store/rootReducer.jsx [app-ssr] (ecmascript)");
;
;
const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$reduxjs$2f$toolkit$2f$dist$2f$redux$2d$toolkit$2e$modern$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["configureStore"])({
    reducer: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$store$2f$rootReducer$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["rootReducer"]
});
}),
"[project]/Desktop/nartaqi/components/LayoutProvider.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LayoutProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$store$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/store/index.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$configs$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/configs/index.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
/**
 * Public routes that shouldn't require auth.
 * Add more as needed: "/register", "/forgot-password", etc.
 */ const PUBLIC_PREFIXES = [
    "/login",
    "/register",
    "/forgot-password"
];
function useAuthState(tokenKey) {
    const read = ()=>{
        if ("TURBOPACK compile-time truthy", 1) return false;
        //TURBOPACK unreachable
        ;
        const v = undefined;
    };
    const [isLoggedIn, setIsLoggedIn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(()=>{
        if ("TURBOPACK compile-time truthy", 1) return false;
        //TURBOPACK unreachable
        ;
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        // Check auth state on mount and when tokenKey changes
        setIsLoggedIn(read());
        const onStorage = (e)=>{
            if (e.key === tokenKey) {
                setIsLoggedIn(read());
            }
        };
        const onFocus = ()=>{
            setIsLoggedIn(read());
        };
        // Custom event listener for immediate updates (when login happens in same tab)
        const onAuthChange = ()=>{
            setIsLoggedIn(read());
        };
        // Listen for custom auth change events (can be dispatched from login page)
        window.addEventListener("auth-state-changed", onAuthChange);
        window.addEventListener("storage", onStorage);
        window.addEventListener("focus", onFocus);
        return ()=>{
            window.removeEventListener("auth-state-changed", onAuthChange);
            window.removeEventListener("storage", onStorage);
            window.removeEventListener("focus", onFocus);
        };
    }, [
        tokenKey
    ]);
    return isLoggedIn;
}
function LayoutProvider({ children }) {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePathname"])();
    // Use your configured key name (not the value), fallback to "token"
    const tokenKey = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$configs$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["configs"]?.tokenKey || __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$configs$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["configs"]?.AUTH_COOKIE_NAME || "token";
    const isLoggedIn = useAuthState(tokenKey);
    // Is current path public?
    const isPublic = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>PUBLIC_PREFIXES.some((p)=>pathname?.startsWith(p)), [
        pathname
    ]);
    // Redirect decisions happen in an effect (not during render!)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!pathname) return;
        // If NOT logged in and trying to access a protected route -> /login
        if (!isLoggedIn && !isPublic) {
            router.replace("/login");
            return;
        }
    // If logged in and on a public auth page (like /login) -> redirect to home
    // if (isLoggedIn && isPublic) {
    //   router.replace("/");
    //   return;
    // }
    }, [
        isLoggedIn,
        isPublic,
        pathname,
        router
    ]);
    if (!isLoggedIn && !isPublic) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Provider"], {
        store: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$store$2f$index$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["store"],
        children: [
            children,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToastContainer"], {}, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/LayoutProvider.jsx",
                lineNumber: 100,
                columnNumber: 3
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/LayoutProvider.jsx",
        lineNumber: 99,
        columnNumber: 10
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__f0b8b7a6._.js.map