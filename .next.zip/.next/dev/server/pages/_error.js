var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/e9609_1aff668e._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/e9609_b129f15b._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/e9609_next_91469b4b._.js")
R.m("[project]/Desktop/nartaqi/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/nartaqi/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/nartaqi/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/nartaqi/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/Desktop/nartaqi/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/nartaqi/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/nartaqi/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/nartaqi/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
