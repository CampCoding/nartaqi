module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(admin)/saudi_source_course/add-data/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=68041_server_app_%28admin%29_saudi_source_course_add-data_page_actions_bf526d91.js.map