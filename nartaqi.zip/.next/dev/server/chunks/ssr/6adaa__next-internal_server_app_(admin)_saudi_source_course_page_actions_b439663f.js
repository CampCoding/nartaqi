module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(admin)/saudi_source_course/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=6adaa__next-internal_server_app_%28admin%29_saudi_source_course_page_actions_b439663f.js.map