module.exports = [
"[project]/Desktop/nartaqi/node_modules/ckeditor5-classic-with-mathtype/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2d$classic$2d$with$2d$mathtype$2f$build$2f$ckeditor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5-classic-with-mathtype/build/ckeditor.js [app-ssr] (ecmascript)");
;
}),
];

//# sourceMappingURL=e9609_ckeditor5-classic-with-mathtype_index_5253af76.js.map