module.exports = [
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/controller/editingcontroller.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/controller/editingcontroller
 */ __turbopack_context__.s([
    "default",
    ()=>EditingController
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/observablemixin.js [app-ssr] (ecmascript) <export default as ObservableMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/env.js [app-ssr] (ecmascript) <export default as env>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rooteditableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/rooteditableelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/view.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$mapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/mapper.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcastdispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/downcastdispatcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/downcasthelpers.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/upcasthelpers.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$selection$2d$post$2d$fixer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/selection-post-fixer.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
class EditingController extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])() {
    /**
     * Creates an editing controller instance.
     *
     * @param model Editing model.
     * @param stylesProcessor The styles processor instance.
     */ constructor(model, stylesProcessor){
        super();
        this.model = model;
        this.view = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](stylesProcessor);
        this.mapper = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$mapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        this.downcastDispatcher = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcastdispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
            mapper: this.mapper,
            schema: model.schema
        });
        const doc = this.model.document;
        const selection = doc.selection;
        const markers = this.model.markers;
        // When plugins listen on model changes (on selection change, post fixers, etc.) and change the view as a result of
        // the model's change, they might trigger view rendering before the conversion is completed (e.g. before the selection
        // is converted). We disable rendering for the length of the outermost model change() block to prevent that.
        //
        // See https://github.com/ckeditor/ckeditor5-engine/issues/1528
        this.listenTo(this.model, '_beforeChanges', ()=>{
            this.view._disableRendering(true);
        }, {
            priority: 'highest'
        });
        this.listenTo(this.model, '_afterChanges', ()=>{
            this.view._disableRendering(false);
        }, {
            priority: 'lowest'
        });
        // Whenever model document is changed, convert those changes to the view (using model.Document#differ).
        // Do it on 'low' priority, so changes are converted after other listeners did their job.
        // Also convert model selection.
        this.listenTo(doc, 'change', ()=>{
            this.view.change((writer)=>{
                this.downcastDispatcher.convertChanges(doc.differ, markers, writer);
                this.downcastDispatcher.convertSelection(selection, markers, writer);
            });
        }, {
            priority: 'low'
        });
        // Convert selection from the view to the model when it changes in the view.
        this.listenTo(this.view.document, 'selectionChange', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["convertSelectionChange"])(this.model, this.mapper));
        // Fix `beforeinput` target ranges so that they map to the valid model ranges.
        this.listenTo(this.view.document, 'beforeinput', fixTargetRanges(this.mapper, this.model.schema, this.view), {
            priority: 'high'
        });
        // Attach default model converters.
        this.downcastDispatcher.on('insert:$text', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["insertText"])(), {
            priority: 'lowest'
        });
        this.downcastDispatcher.on('insert', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["insertAttributesAndChildren"])(), {
            priority: 'lowest'
        });
        this.downcastDispatcher.on('remove', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["remove"])(), {
            priority: 'low'
        });
        // Attach default model selection converters.
        this.downcastDispatcher.on('cleanSelection', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cleanSelection"])());
        this.downcastDispatcher.on('selection', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["convertRangeSelection"])(), {
            priority: 'low'
        });
        this.downcastDispatcher.on('selection', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["convertCollapsedSelection"])(), {
            priority: 'low'
        });
        // Binds {@link module:engine/view/document~Document#roots view roots collection} to
        // {@link module:engine/model/document~Document#roots model roots collection} so creating
        // model root automatically creates corresponding view root.
        this.view.document.roots.bindTo(this.model.document.roots).using((root)=>{
            // $graveyard is a special root that has no reflection in the view.
            if (root.rootName == '$graveyard') {
                return null;
            }
            const viewRoot = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rooteditableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.view.document, root.name);
            viewRoot.rootName = root.rootName;
            this.mapper.bindElements(root, viewRoot);
            return viewRoot;
        });
    // @if CK_DEBUG_ENGINE // initDocumentDumping( this.model.document );
    // @if CK_DEBUG_ENGINE // initDocumentDumping( this.view.document );
    // @if CK_DEBUG_ENGINE // dumpTrees( this.model.document, this.model.document.version );
    // @if CK_DEBUG_ENGINE // dumpTrees( this.view.document, this.model.document.version );
    // @if CK_DEBUG_ENGINE // this.model.document.on( 'change', () => {
    // @if CK_DEBUG_ENGINE //	dumpTrees( this.view.document, this.model.document.version );
    // @if CK_DEBUG_ENGINE // }, { priority: 'lowest' } );
    }
    /**
     * Removes all event listeners attached to the `EditingController`. Destroys all objects created
     * by `EditingController` that need to be destroyed.
     */ destroy() {
        this.view.destroy();
        this.stopListening();
    }
    /**
     * Calling this method will refresh the marker by triggering the downcast conversion for it.
     *
     * Reconverting the marker is useful when you want to change its {@link module:engine/view/element~Element view element}
     * without changing any marker data. For instance:
     *
     * ```ts
     * let isCommentActive = false;
     *
     * model.conversion.markerToHighlight( {
     * 	model: 'comment',
     * 	view: data => {
     * 		const classes = [ 'comment-marker' ];
     *
     * 		if ( isCommentActive ) {
     * 			classes.push( 'comment-marker--active' );
     * 		}
     *
     * 		return { classes };
     * 	}
     * } );
     *
     * // ...
     *
     * // Change the property that indicates if marker is displayed as active or not.
     * isCommentActive = true;
     *
     * // Reconverting will downcast and synchronize the marker with the new isCommentActive state value.
     * editor.editing.reconvertMarker( 'comment' );
     * ```
     *
     * **Note**: If you want to reconvert a model item, use {@link #reconvertItem} instead.
     *
     * @param markerOrName Name of a marker to update, or a marker instance.
     */ reconvertMarker(markerOrName) {
        const markerName = typeof markerOrName == 'string' ? markerOrName : markerOrName.name;
        const currentMarker = this.model.markers.get(markerName);
        if (!currentMarker) {
            /**
             * The marker with the provided name does not exist and cannot be reconverted.
             *
             * @error editingcontroller-reconvertmarker-marker-not-exist
             * @param {String} markerName The name of the reconverted marker.
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('editingcontroller-reconvertmarker-marker-not-exist', this, {
                markerName
            });
        }
        this.model.change(()=>{
            this.model.markers._refresh(currentMarker);
        });
    }
    /**
     * Calling this method will downcast a model item on demand (by requesting a refresh in the {@link module:engine/model/differ~Differ}).
     *
     * You can use it if you want the view representation of a specific item updated as a response to external modifications. For instance,
     * when the view structure depends not only on the associated model data but also on some external state.
     *
     * **Note**: If you want to reconvert a model marker, use {@link #reconvertMarker} instead.
     *
     * @param item Item to refresh.
     */ reconvertItem(item) {
        this.model.change(()=>{
            this.model.document.differ._refreshItem(item);
        });
    }
}
/**
 * Checks whether the target ranges provided by the `beforeInput` event can be properly mapped to model ranges and fixes them if needed.
 *
 * This is using the same logic as the selection post-fixer.
 */ function fixTargetRanges(mapper, schema, view) {
    return (evt, data)=>{
        // The Renderer is disabled while composing on non-android browsers, so we can't be sure that target ranges
        // could be properly mapped to view and model because the DOM and view tree drifted apart.
        if (view.document.isComposing && !__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid) {
            return;
        }
        for(let i = 0; i < data.targetRanges.length; i++){
            const viewRange = data.targetRanges[i];
            const modelRange = mapper.toModelRange(viewRange);
            const correctedRange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$selection$2d$post$2d$fixer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["tryFixingRange"])(modelRange, schema);
            if (!correctedRange || correctedRange.isEqual(modelRange)) {
                continue;
            }
            data.targetRanges[i] = mapper.toViewRange(correctedRange);
        }
    };
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/controller/datacontroller.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/controller/datacontroller
 */ __turbopack_context__.s([
    "default",
    ()=>DataController
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/observablemixin.js [app-ssr] (ecmascript) <export default as ObservableMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$mapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/mapper.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcastdispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/downcastdispatcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/downcasthelpers.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcastdispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/upcastdispatcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/upcasthelpers.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/document.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$downcastwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/downcastwriter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$autoparagraphing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/autoparagraphing.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$htmldataprocessor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dataprocessor/htmldataprocessor.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
class DataController extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])() {
    /**
     * Creates a data controller instance.
     *
     * @param model Data model.
     * @param stylesProcessor The styles processor instance.
     */ constructor(model, stylesProcessor){
        super();
        this.model = model;
        this.mapper = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$mapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        this.downcastDispatcher = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcastdispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
            mapper: this.mapper,
            schema: model.schema
        });
        this.downcastDispatcher.on('insert:$text', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["insertText"])(), {
            priority: 'lowest'
        });
        this.downcastDispatcher.on('insert', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["insertAttributesAndChildren"])(), {
            priority: 'lowest'
        });
        this.upcastDispatcher = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcastdispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
            schema: model.schema
        });
        this.viewDocument = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](stylesProcessor);
        this.stylesProcessor = stylesProcessor;
        this.htmlProcessor = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$htmldataprocessor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.viewDocument);
        this.processor = this.htmlProcessor;
        this._viewWriter = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$downcastwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.viewDocument);
        // Define default converters for text and elements.
        //
        // Note that if there is no default converter for the element it will be skipped, for instance `<b>foo</b>` will be
        // converted to nothing. We therefore add `convertToModelFragment` as a last converter so it converts children of that
        // element to the document fragment so `<b>foo</b>` will still be converted to `foo` even if there is no converter for `<b>`.
        this.upcastDispatcher.on('text', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["convertText"])(), {
            priority: 'lowest'
        });
        this.upcastDispatcher.on('element', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["convertToModelFragment"])(), {
            priority: 'lowest'
        });
        this.upcastDispatcher.on('documentFragment', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["convertToModelFragment"])(), {
            priority: 'lowest'
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])().prototype.decorate.call(this, 'init');
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])().prototype.decorate.call(this, 'set');
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])().prototype.decorate.call(this, 'get');
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])().prototype.decorate.call(this, 'toView');
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])().prototype.decorate.call(this, 'toModel');
        // Fire the `ready` event when the initialization has completed. Such low-level listener offers the possibility
        // to plug into the initialization pipeline without interrupting the initialization flow.
        this.on('init', ()=>{
            this.fire('ready');
        }, {
            priority: 'lowest'
        });
        // Fix empty roots after DataController is 'ready' (note that the init method could be decorated and stopped).
        // We need to handle this event because initial data could be empty and the post-fixer would not get triggered.
        this.on('ready', ()=>{
            this.model.enqueueChange({
                isUndoable: false
            }, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$autoparagraphing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["autoParagraphEmptyRoots"]);
        }, {
            priority: 'lowest'
        });
    }
    /**
     * Returns the model's data converted by downcast dispatchers attached to {@link #downcastDispatcher} and
     * formatted by the {@link #processor data processor}.
     *
     * A warning is logged when you try to retrieve data for a detached root, as most probably this is a mistake. A detached root should
     * be treated like it is removed, and you should not save its data. Note, that the detached root data is always an empty string.
     *
     * @fires get
     * @param options Additional configuration for the retrieved data. `DataController` provides two optional
     * properties: `rootName` and `trim`. Other properties of this object are specified by various editor features.
     * @param options.rootName Root name. Default 'main'.
     * @param options.trim Whether returned data should be trimmed. This option is set to `empty` by default,
     * which means whenever editor content is considered empty, an empty string will be returned. To turn off trimming completely
     * use `'none'`. In such cases the exact content will be returned (for example a `<p>&nbsp;</p>` for an empty editor).
     * @returns Output data.
     */ get(options = {}) {
        const { rootName = 'main', trim = 'empty' } = options;
        if (!this._checkIfRootsExists([
            rootName
        ])) {
            /**
             * Cannot get data from a non-existing root. This error is thrown when
             * {@link module:engine/controller/datacontroller~DataController#get `DataController#get()` method}
             * is called with a non-existent root name. For example, if there is an editor instance with only `main` root,
             * calling {@link module:engine/controller/datacontroller~DataController#get} like:
             *
             * ```ts
             * data.get( { rootName: 'root2' } );
             * ```
             *
             * will throw this error.
             *
             * @error datacontroller-get-non-existent-root
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('datacontroller-get-non-existent-root', this);
        }
        const root = this.model.document.getRoot(rootName);
        if (!root.isAttached()) {
            /**
             * Retrieving document data for a detached root.
             *
             * This usually indicates an error as a detached root should be considered "removed" and should not be included in the
             * document data.
             *
             * @error datacontroller-get-detached-root
             */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('datacontroller-get-detached-root', this);
        }
        if (trim === 'empty' && !this.model.hasContent(root, {
            ignoreWhitespaces: true
        })) {
            return '';
        }
        return this.stringify(root, options);
    }
    /**
     * Returns the content of the given {@link module:engine/model/element~Element model's element} or
     * {@link module:engine/model/documentfragment~DocumentFragment model document fragment} converted by the downcast converters
     * attached to the {@link #downcastDispatcher} and formatted by the {@link #processor data processor}.
     *
     * @param modelElementOrFragment The element whose content will be stringified.
     * @param options Additional configuration passed to the conversion process.
     * @returns Output data.
     */ stringify(modelElementOrFragment, options = {}) {
        // Model -> view.
        const viewDocumentFragment = this.toView(modelElementOrFragment, options);
        // View -> data.
        return this.processor.toData(viewDocumentFragment);
    }
    /**
     * Returns the content of the given {@link module:engine/model/element~Element model element} or
     * {@link module:engine/model/documentfragment~DocumentFragment model document fragment} converted by the downcast
     * converters attached to {@link #downcastDispatcher} into a
     * {@link module:engine/view/documentfragment~DocumentFragment view document fragment}.
     *
     * @fires toView
     * @param modelElementOrFragment Element or document fragment whose content will be converted.
     * @param options Additional configuration that will be available through the
     * {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi#options} during the conversion process.
     * @returns Output view DocumentFragment.
     */ toView(modelElementOrFragment, options = {}) {
        const viewDocument = this.viewDocument;
        const viewWriter = this._viewWriter;
        // Clear bindings so the call to this method returns correct results.
        this.mapper.clearBindings();
        // First, convert elements.
        const modelRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(modelElementOrFragment);
        const viewDocumentFragment = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewDocument);
        this.mapper.bindElements(modelElementOrFragment, viewDocumentFragment);
        // Prepare list of markers.
        // For document fragment, simply take the markers assigned to this document fragment.
        // For model root, all markers in that root will be taken.
        // For model element, we need to check which markers are intersecting with this element and relatively modify the markers' ranges.
        // Collapsed markers at element boundary, although considered as not intersecting with the element, will also be returned.
        const markers = modelElementOrFragment.is('documentFragment') ? modelElementOrFragment.markers : _getMarkersRelativeToElement(modelElementOrFragment);
        this.downcastDispatcher.convert(modelRange, markers, viewWriter, options);
        return viewDocumentFragment;
    }
    /**
     * Sets the initial input data parsed by the {@link #processor data processor} and
     * converted by the {@link #upcastDispatcher view-to-model converters}.
     * Initial data can be only set to a document whose {@link module:engine/model/document~Document#version} is equal 0.
     *
     * **Note** This method is {@link module:utils/observablemixin~Observable#decorate decorated} which is
     * used by e.g. collaborative editing plugin that syncs remote data on init.
     *
     * When data is passed as a string, it is initialized on the default `main` root:
     *
     * ```ts
     * dataController.init( '<p>Foo</p>' ); // Initializes data on the `main` root only, as no other is specified.
     * ```
     *
     * To initialize data on a different root or multiple roots at once, an object containing `rootName` - `data` pairs should be passed:
     *
     * ```ts
     * dataController.init( { main: '<p>Foo</p>', title: '<h1>Bar</h1>' } ); // Initializes data on both the `main` and `title` roots.
     * ```
     *
     * @fires init
     * @param data Input data as a string or an object containing the `rootName` - `data`
     * pairs to initialize data on multiple roots at once.
     * @returns Promise that is resolved after the data is set on the editor.
     */ init(data) {
        if (this.model.document.version) {
            /**
             * Cannot set initial data to a non-empty {@link module:engine/model/document~Document}.
             * Initial data should be set once, during the {@link module:core/editor/editor~Editor} initialization,
             * when the {@link module:engine/model/document~Document#version} is equal 0.
             *
             * @error datacontroller-init-document-not-empty
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('datacontroller-init-document-not-empty', this);
        }
        let initialData = {};
        if (typeof data === 'string') {
            initialData.main = data; // Default root is 'main'. To initiate data on a different root, object should be passed.
        } else {
            initialData = data;
        }
        if (!this._checkIfRootsExists(Object.keys(initialData))) {
            /**
             * Cannot init data on a non-existent root. This error is thrown when
             * {@link module:engine/controller/datacontroller~DataController#init DataController#init() method}
             * is called with non-existent root name. For example, if there is an editor instance with only `main` root,
             * calling {@link module:engine/controller/datacontroller~DataController#init} like:
             *
             * ```ts
             * data.init( { main: '<p>Foo</p>', root2: '<p>Bar</p>' } );
             * ```
             *
             * will throw this error.
             *
             * @error datacontroller-init-non-existent-root
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('datacontroller-init-non-existent-root', this);
        }
        this.model.enqueueChange({
            isUndoable: false
        }, (writer)=>{
            for (const rootName of Object.keys(initialData)){
                const modelRoot = this.model.document.getRoot(rootName);
                writer.insert(this.parse(initialData[rootName], modelRoot), modelRoot, 0);
            }
        });
        return Promise.resolve();
    }
    /**
     * Sets the input data parsed by the {@link #processor data processor} and
     * converted by the {@link #upcastDispatcher view-to-model converters}.
     * This method can be used any time to replace existing editor data with the new one without clearing the
     * {@link module:engine/model/document~Document#history document history}.
     *
     * This method also creates a batch with all the changes applied. If all you need is to parse data, use
     * the {@link #parse} method.
     *
     * When data is passed as a string it is set on the default `main` root:
     *
     * ```ts
     * dataController.set( '<p>Foo</p>' ); // Sets data on the `main` root, as no other is specified.
     * ```
     *
     * To set data on a different root or multiple roots at once, an object containing `rootName` - `data` pairs should be passed:
     *
     * ```ts
     * dataController.set( { main: '<p>Foo</p>', title: '<h1>Bar</h1>' } ); // Sets data on the `main` and `title` roots as specified.
     * ```
     *
     * To set the data with a preserved undo stack and add the change to the undo stack, set `{ isUndoable: true }` as a `batchType` option.
     *
     * ```ts
     * dataController.set( '<p>Foo</p>', { batchType: { isUndoable: true } } );
     * ```
     *
     * @fires set
     * @param data Input data as a string or an object containing the `rootName` - `data`
     * pairs to set data on multiple roots at once.
     * @param options Options for setting data.
     * @param options.batchType The batch type that will be used to create a batch for the changes applied by this method.
     * By default, the batch will be set as {@link module:engine/model/batch~Batch#isUndoable not undoable} and the undo stack will be
     * cleared after the new data is applied (all undo steps will be removed). If the batch type `isUndoable` flag is be set to `true`,
     * the undo stack will be preserved instead and not cleared when new data is applied.
     */ set(data, options = {}) {
        let newData = {};
        if (typeof data === 'string') {
            newData.main = data; // The default root is 'main'. To set data on a different root, an object should be passed.
        } else {
            newData = data;
        }
        if (!this._checkIfRootsExists(Object.keys(newData))) {
            /**
             * Cannot set data on a non-existent root. This error is thrown when the
             * {@link module:engine/controller/datacontroller~DataController#set DataController#set() method}
             * is called with non-existent root name. For example, if there is an editor instance with only the default `main` root,
             * calling {@link module:engine/controller/datacontroller~DataController#set} like:
             *
             * ```ts
             * data.set( { main: '<p>Foo</p>', root2: '<p>Bar</p>' } );
             * ```
             *
             * will throw this error.
             *
             * @error datacontroller-set-non-existent-root
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('datacontroller-set-non-existent-root', this);
        }
        this.model.enqueueChange(options.batchType || {}, (writer)=>{
            writer.setSelection(null);
            writer.removeSelectionAttribute(this.model.document.selection.getAttributeKeys());
            for (const rootName of Object.keys(newData)){
                // Save to model.
                const modelRoot = this.model.document.getRoot(rootName);
                writer.remove(writer.createRangeIn(modelRoot));
                writer.insert(this.parse(newData[rootName], modelRoot), modelRoot, 0);
            }
        });
    }
    /**
     * Returns the data parsed by the {@link #processor data processor} and then converted by upcast converters
     * attached to the {@link #upcastDispatcher}.
     *
     * @see #set
     * @param data Data to parse.
     * @param context Base context in which the view will be converted to the model.
     * See: {@link module:engine/conversion/upcastdispatcher~UpcastDispatcher#convert}.
     * @returns Parsed data.
     */ parse(data, context = '$root') {
        // data -> view
        const viewDocumentFragment = this.processor.toView(data);
        // view -> model
        return this.toModel(viewDocumentFragment, context);
    }
    /**
     * Returns the result of the given {@link module:engine/view/element~Element view element} or
     * {@link module:engine/view/documentfragment~DocumentFragment view document fragment} converted by the
     * {@link #upcastDispatcher view-to-model converters}, wrapped by {@link module:engine/model/documentfragment~DocumentFragment}.
     *
     * When marker elements were converted during the conversion process, it will be set as a document fragment's
     * {@link module:engine/model/documentfragment~DocumentFragment#markers static markers map}.
     *
     * @fires toModel
     * @param viewElementOrFragment The element or document fragment whose content will be converted.
     * @param context Base context in which the view will be converted to the model.
     * See: {@link module:engine/conversion/upcastdispatcher~UpcastDispatcher#convert}.
     * @returns Output document fragment.
     */ toModel(viewElementOrFragment, context = '$root') {
        return this.model.change((writer)=>{
            return this.upcastDispatcher.convert(viewElementOrFragment, writer, context);
        });
    }
    /**
     * Adds the style processor normalization rules.
     *
     * You can implement your own rules as well as use one of the available processor rules:
     *
     * * background: {@link module:engine/view/styles/background~addBackgroundRules}
     * * border: {@link module:engine/view/styles/border~addBorderRules}
     * * margin: {@link module:engine/view/styles/margin~addMarginRules}
     * * padding: {@link module:engine/view/styles/padding~addPaddingRules}
     */ addStyleProcessorRules(callback) {
        callback(this.stylesProcessor);
    }
    /**
     * Registers a {@link module:engine/view/matcher~MatcherPattern} on an {@link #htmlProcessor htmlProcessor}
     * and a {@link #processor processor} for view elements whose content should be treated as raw data
     * and not processed during the conversion from DOM to view elements.
     *
     * The raw data can be later accessed by the {@link module:engine/view/element~Element#getCustomProperty view element custom property}
     * `"$rawContent"`.
     *
     * @param pattern Pattern matching all view elements whose content should be treated as a raw data.
     */ registerRawContentMatcher(pattern) {
        // No need to register the pattern if both the `htmlProcessor` and `processor` are the same instances.
        if (this.processor && this.processor !== this.htmlProcessor) {
            this.processor.registerRawContentMatcher(pattern);
        }
        this.htmlProcessor.registerRawContentMatcher(pattern);
    }
    /**
     * Removes all event listeners set by the DataController.
     */ destroy() {
        this.stopListening();
    }
    /**
     * Checks whether all provided root names are actually existing editor roots.
     *
     * @param rootNames Root names to check.
     * @returns Whether all provided root names are existing editor roots.
     */ _checkIfRootsExists(rootNames) {
        for (const rootName of rootNames){
            if (!this.model.document.getRoot(rootName)) {
                return false;
            }
        }
        return true;
    }
}
/**
 * Helper function for downcast conversion.
 *
 * Takes a document element (element that is added to a model document) and checks which markers are inside it. If the marker is collapsed
 * at element boundary, it is considered as contained inside the element and marker range is returned. Otherwise, if the marker is
 * intersecting with the element, the intersection is returned.
 */ function _getMarkersRelativeToElement(element) {
    const result = [];
    const doc = element.root.document;
    if (!doc) {
        return new Map();
    }
    const elementRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(element);
    for (const marker of doc.model.markers){
        const markerRange = marker.getRange();
        const isMarkerCollapsed = markerRange.isCollapsed;
        const isMarkerAtElementBoundary = markerRange.start.isEqual(elementRange.start) || markerRange.end.isEqual(elementRange.end);
        if (isMarkerCollapsed && isMarkerAtElementBoundary) {
            result.push([
                marker.name,
                markerRange
            ]);
        } else {
            const updatedMarkerRange = elementRange.getIntersection(markerRange);
            if (updatedMarkerRange) {
                result.push([
                    marker.name,
                    updatedMarkerRange
                ]);
            }
        }
    }
    // Sort the markers in a stable fashion to ensure that the order in which they are
    // added to the model's marker collection does not affect how they are
    // downcast. One particular use case that we are targeting here, is one where
    // two markers are adjacent but not overlapping, such as an insertion/deletion
    // suggestion pair representing the replacement of a range of text. In this
    // case, putting the markers in DOM order causes the first marker's end to be
    // serialized right after the second marker's start, while putting the markers
    // in reverse DOM order causes it to be right before the second marker's
    // start. So, we sort these in a way that ensures non-intersecting ranges are in
    // reverse DOM order, and intersecting ranges are in something approximating
    // reverse DOM order (since reverse DOM order doesn't have a precise meaning
    // when working with intersecting ranges).
    result.sort(([n1, r1], [n2, r2])=>{
        if (r1.end.compareWith(r2.start) !== 'after') {
            // m1.end <= m2.start -- m1 is entirely <= m2
            return 1;
        } else if (r1.start.compareWith(r2.end) !== 'before') {
            // m1.start >= m2.end -- m1 is entirely >= m2
            return -1;
        } else {
            // they overlap, so use their start positions as the primary sort key and
            // end positions as the secondary sort key
            switch(r1.start.compareWith(r2.start)){
                case 'before':
                    return 1;
                case 'after':
                    return -1;
                default:
                    switch(r1.end.compareWith(r2.end)){
                        case 'before':
                            return 1;
                        case 'after':
                            return -1;
                        default:
                            return n2.localeCompare(n1);
                    }
            }
        }
    });
    return new Map(result);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/controller/datacontroller.js [app-ssr] (ecmascript) <export default as DataController>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DataController",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$controller$2f$datacontroller$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$controller$2f$datacontroller$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/controller/datacontroller.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/controller/editingcontroller.js [app-ssr] (ecmascript) <export default as EditingController>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EditingController",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$controller$2f$editingcontroller$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$controller$2f$editingcontroller$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/controller/editingcontroller.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dataprocessor/basichtmlwriter.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "default",
    ()=>BasicHtmlWriter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$global$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__global$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/global.js [app-ssr] (ecmascript) <export default as global>");
;
class BasicHtmlWriter {
    /**
     * Returns an HTML string created from the document fragment.
     */ getHtml(fragment) {
        const doc = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$global$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__global$3e$__["global"].document.implementation.createHTMLDocument('');
        const container = doc.createElement('div');
        container.appendChild(fragment);
        return container.innerHTML;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dataprocessor/htmldataprocessor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/dataprocessor/htmldataprocessor
 */ /* globals DOMParser */ __turbopack_context__.s([
    "default",
    ()=>HtmlDataProcessor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$basichtmlwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dataprocessor/basichtmlwriter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$domconverter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/domconverter.js [app-ssr] (ecmascript)");
;
;
class HtmlDataProcessor {
    /**
     * Creates a new instance of the HTML data processor class.
     *
     * @param document The view document instance.
     */ constructor(document){
        this.skipComments = true;
        this.domParser = new DOMParser();
        this.domConverter = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$domconverter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](document, {
            renderingMode: 'data'
        });
        this.htmlWriter = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$basichtmlwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    }
    /**
     * Converts a provided {@link module:engine/view/documentfragment~DocumentFragment document fragment}
     * to data format &ndash; in this case to an HTML string.
     *
     * @returns HTML string.
     */ toData(viewFragment) {
        // Convert view DocumentFragment to DOM DocumentFragment.
        const domFragment = this.domConverter.viewToDom(viewFragment);
        // Convert DOM DocumentFragment to HTML output.
        return this.htmlWriter.getHtml(domFragment);
    }
    /**
     * Converts the provided HTML string to a view tree.
     *
     * @param data An HTML string.
     * @returns A converted view element.
     */ toView(data) {
        // Convert input HTML data to DOM DocumentFragment.
        const domFragment = this._toDom(data);
        // Convert DOM DocumentFragment to view DocumentFragment.
        return this.domConverter.domToView(domFragment, {
            skipComments: this.skipComments
        });
    }
    /**
     * Registers a {@link module:engine/view/matcher~MatcherPattern} for view elements whose content should be treated as raw data
     * and not processed during the conversion from the DOM to the view elements.
     *
     * The raw data can be later accessed by a
     * {@link module:engine/view/element~Element#getCustomProperty custom property of a view element} called `"$rawContent"`.
     *
     * @param pattern Pattern matching all view elements whose content should be treated as raw data.
     */ registerRawContentMatcher(pattern) {
        this.domConverter.registerRawContentMatcher(pattern);
    }
    /**
     * If the processor is set to use marked fillers, it will insert `&nbsp;` fillers wrapped in `<span>` elements
     * (`<span data-cke-filler="true">&nbsp;</span>`) instead of regular `&nbsp;` characters.
     *
     * This mode allows for a more precise handling of the block fillers (so they do not leak into the editor content) but
     * bloats the editor data with additional markup.
     *
     * This mode may be required by some features and will be turned on by them automatically.
     *
     * @param type Whether to use the default or the marked `&nbsp;` block fillers.
     */ useFillerType(type) {
        this.domConverter.blockFillerMode = type == 'marked' ? 'markedNbsp' : 'nbsp';
    }
    /**
     * Converts an HTML string to its DOM representation. Returns a document fragment containing nodes parsed from
     * the provided data.
     */ _toDom(data) {
        // Wrap data with a <body> tag so leading non-layout nodes (like <script>, <style>, HTML comment)
        // will be preserved in the body collection.
        // Do it only for data that is not a full HTML document.
        if (!data.match(/<(?:html|body|head|meta)(?:\s[^>]*)?>/i)) {
            data = `<body>${data}</body>`;
        }
        const document = this.domParser.parseFromString(data, 'text/html');
        const fragment = document.createDocumentFragment();
        const bodyChildNodes = document.body.childNodes;
        while(bodyChildNodes.length > 0){
            fragment.appendChild(bodyChildNodes[0]);
        }
        return fragment;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dataprocessor/xmldataprocessor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/dataprocessor/xmldataprocessor
 */ /* globals DOMParser */ __turbopack_context__.s([
    "default",
    ()=>XmlDataProcessor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$basichtmlwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dataprocessor/basichtmlwriter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$domconverter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/domconverter.js [app-ssr] (ecmascript)");
;
;
class XmlDataProcessor {
    /**
     * Creates a new instance of the XML data processor class.
     *
     * @param document The view document instance.
     * @param options Configuration options.
     * @param options.namespaces A list of namespaces allowed to use in the XML input.
     */ constructor(document, options = {}){
        this.skipComments = true;
        this.namespaces = options.namespaces || [];
        this.domParser = new DOMParser();
        this.domConverter = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$domconverter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](document, {
            renderingMode: 'data'
        });
        this.htmlWriter = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$basichtmlwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    }
    /**
     * Converts the provided {@link module:engine/view/documentfragment~DocumentFragment document fragment}
     * to data format &ndash; in this case an XML string.
     *
     * @returns An XML string.
     */ toData(viewFragment) {
        // Convert view DocumentFragment to DOM DocumentFragment.
        const domFragment = this.domConverter.viewToDom(viewFragment);
        // Convert DOM DocumentFragment to XML output.
        // There is no need to use dedicated for XML serializing method because BasicHtmlWriter works well in this case.
        return this.htmlWriter.getHtml(domFragment);
    }
    /**
     * Converts the provided XML string to a view tree.
     *
     * @param data An XML string.
     * @returns A converted view element.
     */ toView(data) {
        // Convert input XML data to DOM DocumentFragment.
        const domFragment = this._toDom(data);
        // Convert DOM DocumentFragment to view DocumentFragment.
        return this.domConverter.domToView(domFragment, {
            keepOriginalCase: true,
            skipComments: this.skipComments
        });
    }
    /**
     * Registers a {@link module:engine/view/matcher~MatcherPattern} for view elements whose content should be treated as raw data
     * and not processed during the conversion from XML to view elements.
     *
     * The raw data can be later accessed by a
     * {@link module:engine/view/element~Element#getCustomProperty custom property of a view element} called `"$rawContent"`.
     *
     * @param pattern Pattern matching all view elements whose content should be treated as raw data.
     */ registerRawContentMatcher(pattern) {
        this.domConverter.registerRawContentMatcher(pattern);
    }
    /**
     * If the processor is set to use marked fillers, it will insert `&nbsp;` fillers wrapped in `<span>` elements
     * (`<span data-cke-filler="true">&nbsp;</span>`) instead of regular `&nbsp;` characters.
     *
     * This mode allows for a more precise handling of block fillers (so they do not leak into editor content) but
     * bloats the editor data with additional markup.
     *
     * This mode may be required by some features and will be turned on by them automatically.
     *
     * @param type Whether to use the default or the marked `&nbsp;` block fillers.
     */ useFillerType(type) {
        this.domConverter.blockFillerMode = type == 'marked' ? 'markedNbsp' : 'nbsp';
    }
    /**
     * Converts an XML string to its DOM representation. Returns a document fragment containing nodes parsed from
     * the provided data.
     */ _toDom(data) {
        // Stringify namespaces.
        const namespaces = this.namespaces.map((nsp)=>`xmlns:${nsp}="nsp"`).join(' ');
        // Wrap data into root element with optional namespace definitions.
        data = `<xml ${namespaces}>${data}</xml>`;
        const parsedDocument = this.domParser.parseFromString(data, 'text/xml');
        // Parse validation.
        const parserError = parsedDocument.querySelector('parsererror');
        if (parserError) {
            throw new Error('Parse error - ' + parserError.textContent);
        }
        const fragment = parsedDocument.createDocumentFragment();
        const nodes = parsedDocument.documentElement.childNodes;
        while(nodes.length > 0){
            fragment.appendChild(nodes[0]);
        }
        return fragment;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dev-utils/view.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/dev-utils/view
 */ /* globals document */ /**
 * Collection of methods for manipulating the {@link module:engine/view/view view} for testing purposes.
 */ __turbopack_context__.s([
    "getData",
    ()=>getData,
    "parse",
    ()=>parse,
    "setData",
    ()=>setData,
    "stringify",
    ()=>stringify
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/view.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/document.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$xmldataprocessor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dataprocessor/xmldataprocessor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/attributeelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/containerelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$emptyelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/emptyelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/uielement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rawelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/rawelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/stylesmap.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const ELEMENT_RANGE_START_TOKEN = '[';
const ELEMENT_RANGE_END_TOKEN = ']';
const TEXT_RANGE_START_TOKEN = '{';
const TEXT_RANGE_END_TOKEN = '}';
const allowedTypes = {
    'container': __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    'attribute': __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    'empty': __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$emptyelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    'ui': __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    'raw': __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rawelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
};
// Returns simplified implementation of {@link module:engine/view/domconverter~DomConverter#setContentOf DomConverter.setContentOf} method.
// Used to render UIElement and RawElement.
const domConverterStub = {
    setContentOf: (node, html)=>{
        node.innerHTML = html;
    }
};
function getData(view, options = {}) {
    if (!(view instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
        throw new TypeError('View needs to be an instance of module:engine/view/view~View.');
    }
    const document1 = view.document;
    const withoutSelection = !!options.withoutSelection;
    const rootName = options.rootName || 'main';
    const root = document1.getRoot(rootName);
    const stringifyOptions = {
        showType: options.showType,
        showPriority: options.showPriority,
        renderUIElements: options.renderUIElements,
        renderRawElements: options.renderRawElements,
        ignoreRoot: true,
        domConverter: options.domConverter
    };
    return withoutSelection ? getData._stringify(root, null, stringifyOptions) : getData._stringify(root, document1.selection, stringifyOptions);
}
// Set stringify as getData private method - needed for testing/spying.
getData._stringify = stringify;
function setData(view, data, options = {}) {
    if (!(view instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
        throw new TypeError('View needs to be an instance of module:engine/view/view~View.');
    }
    const document1 = view.document;
    const rootName = options.rootName || 'main';
    const root = document1.getRoot(rootName);
    view.change((writer)=>{
        const result = setData._parse(data, {
            rootElement: root
        });
        if (result.view && result.selection) {
            writer.setSelection(result.selection);
        }
    });
}
// Set parse as setData private method - needed for testing/spying.
setData._parse = parse;
function stringify(node, selectionOrPositionOrRange = null, options = {}) {
    let selection;
    if (selectionOrPositionOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || selectionOrPositionOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        selection = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selectionOrPositionOrRange);
    } else {
        selection = selectionOrPositionOrRange;
    }
    const viewStringify = new ViewStringify(node, selection, options);
    return viewStringify.stringify();
}
function parse(data, options = {}) {
    const viewDocument = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["StylesProcessor"]());
    options.order = options.order || [];
    const rangeParser = new RangeParser({
        sameSelectionCharacters: options.sameSelectionCharacters
    });
    const processor = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$xmldataprocessor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewDocument, {
        namespaces: Object.keys(allowedTypes)
    });
    // Convert data to view.
    let view = processor.toView(data);
    // At this point we have a view tree with Elements that could have names like `attribute:b:1`. In the next step
    // we need to parse Element's names and convert them to AttributeElements and ContainerElements.
    view = _convertViewElements(view);
    // If custom root is provided - move all nodes there.
    if (options.rootElement) {
        const root = options.rootElement;
        const nodes = view._removeChildren(0, view.childCount);
        root._removeChildren(0, root.childCount);
        root._appendChild(nodes);
        view = root;
    }
    // Parse ranges included in view text nodes.
    const ranges = rangeParser.parse(view, options.order);
    // If only one element is returned inside DocumentFragment - return that element.
    if (view.is('documentFragment') && view.childCount === 1) {
        view = view.getChild(0);
    }
    // When ranges are present - return object containing view, and selection.
    if (ranges.length) {
        const selection = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](ranges, {
            backward: !!options.lastRangeBackward
        });
        return {
            view,
            selection
        };
    }
    // If single element is returned without selection - remove it from parent and return detached element.
    if (view.parent) {
        view._remove();
    }
    return view;
}
/**
 * Private helper class used for converting ranges represented as text inside view {@link module:engine/view/text~Text text nodes}.
 */ class RangeParser {
    /**
     * Creates a range parser instance.
     *
     * @param options The range parser configuration.
     * @param options.sameSelectionCharacters When set to `true`, the selection inside the text is marked as
     * `{` and `}` and the selection outside the text as `[` and `]`. When set to `false`, both are marked as `[` and `]`.
     */ constructor(options){
        this.sameSelectionCharacters = !!options.sameSelectionCharacters;
    }
    /**
     * Parses the view and returns ranges represented inside {@link module:engine/view/text~Text text nodes}.
     * The method will remove all occurrences of `{`, `}`, `[` and `]` from found text nodes. If a text node is empty after
     * the process, it will be removed, too.
     *
     * @param node The starting node.
     * @param order The order of ranges. Each element should represent the desired position of the range after
     * sorting. For example: `[2, 3, 1]` means that the first range will be placed as the second, the second as the third and the third
     * as the first.
     * @returns An array with ranges found.
     */ parse(node, order) {
        this._positions = [];
        // Remove all range brackets from view nodes and save their positions.
        this._getPositions(node);
        // Create ranges using gathered positions.
        let ranges = this._createRanges();
        // Sort ranges if needed.
        if (order.length) {
            if (order.length != ranges.length) {
                throw new Error(`Parse error - there are ${ranges.length} ranges found, but ranges order array contains ${order.length} elements.`);
            }
            ranges = this._sortRanges(ranges, order);
        }
        return ranges;
    }
    /**
     * Gathers positions of brackets inside the view tree starting from the provided node. The method will remove all occurrences of
     * `{`, `}`, `[` and `]` from found text nodes. If a text node is empty after the process, it will be removed, too.
     *
     * @param node Staring node.
     */ _getPositions(node) {
        if (node.is('documentFragment') || node.is('element')) {
            // Copy elements into the array, when nodes will be removed from parent node this array will still have all the
            // items needed for iteration.
            const children = [
                ...node.getChildren()
            ];
            for (const child of children){
                this._getPositions(child);
            }
        }
        if (node.is('$text')) {
            const regexp = new RegExp(`[${TEXT_RANGE_START_TOKEN}${TEXT_RANGE_END_TOKEN}\\${ELEMENT_RANGE_END_TOKEN}\\${ELEMENT_RANGE_START_TOKEN}]`, 'g');
            let text = node.data;
            let match;
            let offset = 0;
            const brackets = [];
            // Remove brackets from text and store info about offset inside text node.
            while(match = regexp.exec(text)){
                const index = match.index;
                const bracket = match[0];
                brackets.push({
                    bracket,
                    textOffset: index - offset
                });
                offset++;
            }
            text = text.replace(regexp, '');
            node._data = text;
            const index = node.index;
            const parent = node.parent;
            // Remove empty text nodes.
            if (!text) {
                node._remove();
            }
            for (const item of brackets){
                // Non-empty text node.
                if (text) {
                    if (this.sameSelectionCharacters || !this.sameSelectionCharacters && (item.bracket == TEXT_RANGE_START_TOKEN || item.bracket == TEXT_RANGE_END_TOKEN)) {
                        // Store information about text range delimiter.
                        this._positions.push({
                            bracket: item.bracket,
                            position: new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, item.textOffset)
                        });
                    } else {
                        // Check if element range delimiter is not placed inside text node.
                        if (!this.sameSelectionCharacters && item.textOffset !== 0 && item.textOffset !== text.length) {
                            throw new Error(`Parse error - range delimiter '${item.bracket}' is placed inside text node.`);
                        }
                        // If bracket is placed at the end of the text node - it should be positioned after it.
                        const offset = item.textOffset === 0 ? index : index + 1;
                        // Store information about element range delimiter.
                        this._positions.push({
                            bracket: item.bracket,
                            position: new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, offset)
                        });
                    }
                } else {
                    if (!this.sameSelectionCharacters && item.bracket == TEXT_RANGE_START_TOKEN || item.bracket == TEXT_RANGE_END_TOKEN) {
                        throw new Error(`Parse error - text range delimiter '${item.bracket}' is placed inside empty text node. `);
                    }
                    // Store information about element range delimiter.
                    this._positions.push({
                        bracket: item.bracket,
                        position: new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, index)
                    });
                }
            }
        }
    }
    /**
     * Sorts ranges in a given order. Range order should be an array and each element should represent the desired position
     * of the range after sorting.
     * For example: `[2, 3, 1]` means that the first range will be placed as the second, the second as the third and the third
     * as the first.
     *
     * @param ranges Ranges to sort.
     * @param rangesOrder An array with new range order.
     * @returns Sorted ranges array.
     */ _sortRanges(ranges, rangesOrder) {
        const sortedRanges = [];
        let index = 0;
        for (const newPosition of rangesOrder){
            if (ranges[newPosition - 1] === undefined) {
                throw new Error('Parse error - provided ranges order is invalid.');
            }
            sortedRanges[newPosition - 1] = ranges[index];
            index++;
        }
        return sortedRanges;
    }
    /**
     * Uses all found bracket positions to create ranges from them.
     */ _createRanges() {
        const ranges = [];
        let range = null;
        for (const item of this._positions){
            // When end of range is found without opening.
            if (!range && (item.bracket == ELEMENT_RANGE_END_TOKEN || item.bracket == TEXT_RANGE_END_TOKEN)) {
                throw new Error(`Parse error - end of range was found '${item.bracket}' but range was not started before.`);
            }
            // When second start of range is found when one is already opened - selection does not allow intersecting
            // ranges.
            if (range && (item.bracket == ELEMENT_RANGE_START_TOKEN || item.bracket == TEXT_RANGE_START_TOKEN)) {
                throw new Error(`Parse error - start of range was found '${item.bracket}' but one range is already started.`);
            }
            if (item.bracket == ELEMENT_RANGE_START_TOKEN || item.bracket == TEXT_RANGE_START_TOKEN) {
                range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](item.position, item.position);
            } else {
                range.end = item.position;
                ranges.push(range);
                range = null;
            }
        }
        // Check if all ranges have proper ending.
        if (range !== null) {
            throw new Error('Parse error - range was started but no end delimiter was found.');
        }
        return ranges;
    }
}
/**
 * Private helper class used for converting the view tree to a string.
 */ class ViewStringify {
    /**
     * Creates a view stringify instance.
     *
     * @param selection A selection whose ranges should also be converted to a string.
     * @param options An options object.
     * @param options.showType When set to `true`, the type of elements will be printed (`<container:p>`
     * instead of `<p>`, `<attribute:b>` instead of `<b>` and `<empty:img>` instead of `<img>`).
     * @param options.showPriority When set to `true`, the attribute element's priority will be printed.
     * @param options.ignoreRoot When set to `true`, the root's element opening and closing tag will not
     * be outputted.
     * @param options.sameSelectionCharacters When set to `true`, the selection inside the text is marked as
     * `{` and `}` and the selection outside the text as `[` and `]`. When set to `false`, both are marked as `[` and `]`.
     * @param options.renderUIElements When set to `true`, the inner content of each
     * {@link module:engine/view/uielement~UIElement} will be printed.
     * @param options.renderRawElements When set to `true`, the inner content of each
     * @param options.domConverter When set to an actual {@link module:engine/view/domconverter~DomConverter DomConverter}
     * instance, it lets the conversion go through exactly the same flow the editing view is going through,
     * i.e. with view data filtering. Otherwise the simple stub is used.
     * {@link module:engine/view/rawelement~RawElement} will be printed.
     */ constructor(root, selection, options){
        this.root = root;
        this.selection = selection;
        this.ranges = [];
        if (selection) {
            this.ranges = [
                ...selection.getRanges()
            ];
        }
        this.showType = !!options.showType;
        this.showPriority = !!options.showPriority;
        this.showAttributeElementId = !!options.showAttributeElementId;
        this.ignoreRoot = !!options.ignoreRoot;
        this.sameSelectionCharacters = !!options.sameSelectionCharacters;
        this.renderUIElements = !!options.renderUIElements;
        this.renderRawElements = !!options.renderRawElements;
        this.domConverter = options.domConverter || domConverterStub;
    }
    /**
     * Converts the view to a string.
     *
     * @returns String representation of the view elements.
     */ stringify() {
        let result = '';
        this._walkView(this.root, (chunk)=>{
            result += chunk;
        });
        return result;
    }
    /**
     * Executes a simple walker that iterates over all elements in the view tree starting from the root element.
     * Calls the `callback` with parsed chunks of string data.
     */ _walkView(root, callback) {
        const ignore = this.ignoreRoot && this.root === root;
        if (root.is('element') || root.is('documentFragment')) {
            if (root.is('element') && !ignore) {
                callback(this._stringifyElementOpen(root));
            }
            if (this.renderUIElements && root.is('uiElement')) {
                callback(root.render(document, this.domConverter).innerHTML);
            } else if (this.renderRawElements && root.is('rawElement')) {
                // There's no DOM element for "root" to pass to render(). Creating
                // a surrogate container to render the children instead.
                const rawContentContainer = document.createElement('div');
                root.render(rawContentContainer, this.domConverter);
                callback(rawContentContainer.innerHTML);
            } else {
                let offset = 0;
                callback(this._stringifyElementRanges(root, offset));
                for (const child of root.getChildren()){
                    this._walkView(child, callback);
                    offset++;
                    callback(this._stringifyElementRanges(root, offset));
                }
            }
            if (root.is('element') && !ignore) {
                callback(this._stringifyElementClose(root));
            }
        }
        if (root.is('$text')) {
            callback(this._stringifyTextRanges(root));
        }
    }
    /**
     * Checks if a given {@link module:engine/view/element~Element element} has a {@link module:engine/view/range~Range#start range start}
     * or a {@link module:engine/view/range~Range#start range end} placed at a given offset and returns its string representation.
     */ _stringifyElementRanges(element, offset) {
        let start = '';
        let end = '';
        let collapsed = '';
        for (const range of this.ranges){
            if (range.start.parent == element && range.start.offset === offset) {
                if (range.isCollapsed) {
                    collapsed += ELEMENT_RANGE_START_TOKEN + ELEMENT_RANGE_END_TOKEN;
                } else {
                    start += ELEMENT_RANGE_START_TOKEN;
                }
            }
            if (range.end.parent === element && range.end.offset === offset && !range.isCollapsed) {
                end += ELEMENT_RANGE_END_TOKEN;
            }
        }
        return end + collapsed + start;
    }
    /**
     * Checks if a given {@link module:engine/view/element~Element Text node} has a
     * {@link module:engine/view/range~Range#start range start} or a
     * {@link module:engine/view/range~Range#start range end} placed somewhere inside. Returns a string representation of text
     * with range delimiters placed inside.
     */ _stringifyTextRanges(node) {
        const length = node.data.length;
        const data = node.data.split('');
        let rangeStartToken, rangeEndToken;
        if (this.sameSelectionCharacters) {
            rangeStartToken = ELEMENT_RANGE_START_TOKEN;
            rangeEndToken = ELEMENT_RANGE_END_TOKEN;
        } else {
            rangeStartToken = TEXT_RANGE_START_TOKEN;
            rangeEndToken = TEXT_RANGE_END_TOKEN;
        }
        // Add one more element for ranges ending after last character in text.
        data[length] = '';
        // Represent each letter as object with information about opening/closing ranges at each offset.
        const result = data.map((letter)=>{
            return {
                letter,
                start: '',
                end: '',
                collapsed: ''
            };
        });
        for (const range of this.ranges){
            const start = range.start;
            const end = range.end;
            if (start.parent == node && start.offset >= 0 && start.offset <= length) {
                if (range.isCollapsed) {
                    result[end.offset].collapsed += rangeStartToken + rangeEndToken;
                } else {
                    result[start.offset].start += rangeStartToken;
                }
            }
            if (end.parent == node && end.offset >= 0 && end.offset <= length && !range.isCollapsed) {
                result[end.offset].end += rangeEndToken;
            }
        }
        return result.map((item)=>item.end + item.collapsed + item.start + item.letter).join('');
    }
    /**
     * Converts the passed {@link module:engine/view/element~Element element} to an opening tag.
     *
     * Depending on the current configuration, the opening tag can be simple (`<a>`), contain a type prefix (`<container:p>`,
     * `<attribute:a>` or `<empty:img>`), contain priority information ( `<attribute:a view-priority="20">` ),
     * or contain element id ( `<attribute:span view-id="foo">` ). Element attributes will also be included
     * (`<a href="https://ckeditor.com" name="foobar">`).
     */ _stringifyElementOpen(element) {
        const priority = this._stringifyElementPriority(element);
        const id = this._stringifyElementId(element);
        const type = this._stringifyElementType(element);
        const name = [
            type,
            element.name
        ].filter((i)=>i !== '').join(':');
        const attributes = this._stringifyElementAttributes(element);
        const parts = [
            name,
            priority,
            id,
            attributes
        ];
        return `<${parts.filter((i)=>i !== '').join(' ')}>`;
    }
    /**
     * Converts the passed {@link module:engine/view/element~Element element} to a closing tag.
     * Depending on the current configuration, the closing tag can be simple (`</a>`) or contain a type prefix (`</container:p>`,
     * `</attribute:a>` or `</empty:img>`).
     */ _stringifyElementClose(element) {
        const type = this._stringifyElementType(element);
        const name = [
            type,
            element.name
        ].filter((i)=>i !== '').join(':');
        return `</${name}>`;
    }
    /**
     * Converts the passed {@link module:engine/view/element~Element element's} type to its string representation
     *
     * Returns:
     * * 'attribute' for {@link module:engine/view/attributeelement~AttributeElement attribute elements},
     * * 'container' for {@link module:engine/view/containerelement~ContainerElement container elements},
     * * 'empty' for {@link module:engine/view/emptyelement~EmptyElement empty elements},
     * * 'ui' for {@link module:engine/view/uielement~UIElement UI elements},
     * * 'raw' for {@link module:engine/view/rawelement~RawElement raw elements},
     * * an empty string when the current configuration is preventing showing elements' types.
     */ _stringifyElementType(element) {
        if (this.showType) {
            for(const type in allowedTypes){
                if (element instanceof allowedTypes[type]) {
                    return type;
                }
            }
        }
        return '';
    }
    /**
     * Converts the passed {@link module:engine/view/element~Element element} to its priority representation.
     *
     * The priority string representation will be returned when the passed element is an instance of
     * {@link module:engine/view/attributeelement~AttributeElement attribute element} and the current configuration allows to show the
     * priority. Otherwise returns an empty string.
     */ _stringifyElementPriority(element) {
        if (this.showPriority && element.is('attributeElement')) {
            return `view-priority="${element.priority}"`;
        }
        return '';
    }
    /**
     * Converts the passed {@link module:engine/view/element~Element element} to its id representation.
     *
     * The id string representation will be returned when the passed element is an instance of
     * {@link module:engine/view/attributeelement~AttributeElement attribute element}, the element has an id
     * and the current configuration allows to show the id. Otherwise returns an empty string.
     */ _stringifyElementId(element) {
        if (this.showAttributeElementId && element.is('attributeElement') && element.id) {
            return `view-id="${element.id}"`;
        }
        return '';
    }
    /**
     * Converts the passed {@link module:engine/view/element~Element element} attributes to their string representation.
     * If an element has no attributes, an empty string is returned.
     */ _stringifyElementAttributes(element) {
        const attributes = [];
        const keys = [
            ...element.getAttributeKeys()
        ].sort();
        for (const attribute of keys){
            let attributeValue;
            if (attribute === 'class') {
                attributeValue = [
                    ...element.getClassNames()
                ].sort().join(' ');
            } else if (attribute === 'style') {
                attributeValue = [
                    ...element.getStyleNames()
                ].sort().map((style)=>`${style}:${element.getStyle(style).replace(/"/g, '&quot;')}`).join(';');
            } else {
                attributeValue = element.getAttribute(attribute);
            }
            attributes.push(`${attribute}="${attributeValue}"`);
        }
        return attributes.join(' ');
    }
}
/**
 * Converts {@link module:engine/view/element~Element elements} to
 * {@link module:engine/view/attributeelement~AttributeElement attribute elements},
 * {@link module:engine/view/containerelement~ContainerElement container elements},
 * {@link module:engine/view/emptyelement~EmptyElement empty elements} or
 * {@link module:engine/view/uielement~UIElement UI elements}.
 * It converts the whole tree starting from the `rootNode`. The conversion is based on element names.
 * See the `_convertElement` method for more details.
 *
 * @param rootNode The root node to convert.
 * @returns The root node of converted elements.
 */ function _convertViewElements(rootNode) {
    if (rootNode.is('element') || rootNode.is('documentFragment')) {
        // Convert element or leave document fragment.
        const convertedElement = rootNode.is('documentFragment') ? new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](rootNode.document) : _convertElement(rootNode.document, rootNode);
        // Convert all child nodes.
        // Cache the nodes in array. Otherwise, we would skip some nodes because during iteration we move nodes
        // from `rootNode` to `convertedElement`. This would interfere with iteration.
        for (const child of [
            ...rootNode.getChildren()
        ]){
            if (convertedElement.is('emptyElement')) {
                throw new Error('Parse error - cannot parse inside EmptyElement.');
            } else if (convertedElement.is('uiElement')) {
                throw new Error('Parse error - cannot parse inside UIElement.');
            } else if (convertedElement.is('rawElement')) {
                throw new Error('Parse error - cannot parse inside RawElement.');
            }
            convertedElement._appendChild(_convertViewElements(child));
        }
        return convertedElement;
    }
    return rootNode;
}
/**
 * Converts an {@link module:engine/view/element~Element element} to
 * {@link module:engine/view/attributeelement~AttributeElement attribute element},
 * {@link module:engine/view/containerelement~ContainerElement container element},
 * {@link module:engine/view/emptyelement~EmptyElement empty element} or
 * {@link module:engine/view/uielement~UIElement UI element}.
 * If the element's name is in the format of `attribute:b`, it will be converted to
 * an {@link module:engine/view/attributeelement~AttributeElement attribute element} with a priority of 11.
 * Additionally, attribute elements may have specified priority (for example `view-priority="11"`) and/or
 * id (for example `view-id="foo"`).
 * If the element's name is in the format of `container:p`, it will be converted to
 * a {@link module:engine/view/containerelement~ContainerElement container element}.
 * If the element's name is in the format of `empty:img`, it will be converted to
 * an {@link module:engine/view/emptyelement~EmptyElement empty element}.
 * If the element's name is in the format of `ui:span`, it will be converted to
 * a {@link module:engine/view/uielement~UIElement UI element}.
 * If the element's name does not contain any additional information, a {@link module:engine/view/element~Element view Element} will be
 * returned.
 *
 * @param viewElement A view element to convert.
 * @returns A tree view element converted according to its name.
 */ function _convertElement(viewDocument, viewElement) {
    const info = _convertElementNameAndInfo(viewElement);
    const ElementConstructor = allowedTypes[info.type];
    const newElement = ElementConstructor ? new ElementConstructor(viewDocument, info.name) : new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewDocument, info.name);
    if (newElement.is('attributeElement')) {
        if (info.priority !== null) {
            newElement._priority = info.priority;
        }
        if (info.id !== null) {
            newElement._id = info.id;
        }
    }
    // Move attributes.
    for (const attributeKey of viewElement.getAttributeKeys()){
        newElement._setAttribute(attributeKey, viewElement.getAttribute(attributeKey));
    }
    return newElement;
}
/**
 * Converts the `view-priority` attribute and the {@link module:engine/view/element~Element#name element's name} information needed for
 * creating {@link module:engine/view/attributeelement~AttributeElement attribute element},
 * {@link module:engine/view/containerelement~ContainerElement container element},
 * {@link module:engine/view/emptyelement~EmptyElement empty element} or
 * {@link module:engine/view/uielement~UIElement UI element}.
 * The name can be provided in two formats: as a simple element's name (`div`), or as a type and name (`container:div`,
 * `attribute:span`, `empty:img`, `ui:span`);
 *
 * @param viewElement The element whose name should be converted.
 * @returns An object with parsed information:
 * * `name` The parsed name of the element.
 * * `type` The parsed type of the element. It can be `attribute`, `container` or `empty`.
 * * `priority` The parsed priority of the element.
 */ function _convertElementNameAndInfo(viewElement) {
    const parts = viewElement.name.split(':');
    const priority = _convertPriority(viewElement.getAttribute('view-priority'));
    const id = viewElement.hasAttribute('view-id') ? viewElement.getAttribute('view-id') : null;
    viewElement._removeAttribute('view-priority');
    viewElement._removeAttribute('view-id');
    if (parts.length == 1) {
        return {
            name: parts[0],
            type: priority !== null ? 'attribute' : null,
            priority,
            id
        };
    }
    // Check if type and name: container:div.
    const type = _convertType(parts[0]);
    if (type) {
        return {
            name: parts[1],
            type,
            priority,
            id
        };
    }
    throw new Error(`Parse error - cannot parse element's name: ${viewElement.name}.`);
}
/**
 * Checks if the element's type is allowed. Returns `attribute`, `container`, `empty` or `null`.
 */ function _convertType(type) {
    return type in allowedTypes ? type : null;
}
/**
 * Checks if a given priority is allowed. Returns null if the priority cannot be converted.
 */ function _convertPriority(priorityString) {
    const priority = parseInt(priorityString, 10);
    if (!isNaN(priority)) {
        return priority;
    }
    return null;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dev-utils/model.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/dev-utils/model
 */ /**
 * Collection of methods for manipulating the {@link module:engine/model/model model} for testing purposes.
 */ __turbopack_context__.s([
    "getData",
    ()=>getData,
    "parse",
    ()=>parse,
    "setData",
    ()=>setData,
    "stringify",
    ()=>stringify
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$rootelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/rootelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/model.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/selection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/view.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/containerelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rooteditableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/rooteditableelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dev-utils/view.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$mapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/mapper.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/downcasthelpers.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/stylesmap.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcastdispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/downcastdispatcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcastdispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/upcastdispatcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/tomap.js [app-ssr] (ecmascript) <export default as toMap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/isPlainObject.js [app-ssr] (ecmascript) <export default as isPlainObject>");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function getData(model, options = {}) {
    if (!(model instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
        throw new TypeError('Model needs to be an instance of module:engine/model/model~Model.');
    }
    const rootName = options.rootName || 'main';
    const root = model.document.getRoot(rootName);
    return getData._stringify(root, options.withoutSelection ? null : model.document.selection, options.convertMarkers ? model.markers : null);
}
// Set stringify as getData private method - needed for testing/spying.
getData._stringify = stringify;
function setData(model, data, options = {}) {
    if (!(model instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
        throw new TypeError('Model needs to be an instance of module:engine/model/model~Model.');
    }
    let modelDocumentFragment;
    let selection = null;
    const modelRoot = model.document.getRoot(options.rootName || 'main');
    // Parse data string to model.
    const parsedResult = setData._parse(data, model.schema, {
        lastRangeBackward: options.lastRangeBackward,
        selectionAttributes: options.selectionAttributes,
        context: [
            modelRoot.name
        ]
    });
    // Retrieve DocumentFragment and Selection from parsed model.
    if ('model' in parsedResult) {
        modelDocumentFragment = parsedResult.model;
        selection = parsedResult.selection;
    } else {
        modelDocumentFragment = parsedResult;
    }
    if (options.batchType !== undefined) {
        model.enqueueChange(options.batchType, writeToModel);
    } else {
        model.change(writeToModel);
    }
    function writeToModel(writer) {
        // Replace existing model in document by new one.
        writer.remove(writer.createRangeIn(modelRoot));
        writer.insert(modelDocumentFragment, modelRoot);
        // Clean up previous document selection.
        writer.setSelection(null);
        writer.removeSelectionAttribute(model.document.selection.getAttributeKeys());
        // Update document selection if specified.
        if (selection) {
            const ranges = [];
            for (const range of selection.getRanges()){
                const start = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](modelRoot, range.start.path);
                const end = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](modelRoot, range.end.path);
                ranges.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end));
            }
            writer.setSelection(ranges, {
                backward: selection.isBackward
            });
            if (options.selectionAttributes) {
                writer.setSelectionAttribute(selection.getAttributes());
            }
        }
    }
}
// Set parse as setData private method - needed for testing/spying.
setData._parse = parse;
function stringify(node, selectionOrPositionOrRange = null, markers = null) {
    const model = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    const mapper = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$mapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    let selection = null;
    let range;
    // Create a range witch wraps passed node.
    if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$rootelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        range = model.createRangeIn(node);
    } else {
        // Node is detached - create new document fragment.
        if (!node.parent) {
            const fragment = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node);
            range = model.createRangeIn(fragment);
        } else {
            range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](model.createPositionBefore(node), model.createPositionAfter(node));
        }
    }
    // Get selection from passed selection or position or range if at least one is specified.
    if (selectionOrPositionOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        selection = selectionOrPositionOrRange;
    } else if (selectionOrPositionOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        selection = selectionOrPositionOrRange;
    } else if (selectionOrPositionOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        selection = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selectionOrPositionOrRange);
    } else if (selectionOrPositionOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        selection = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selectionOrPositionOrRange);
    }
    // Set up conversion.
    // Create a temporary view controller.
    const stylesProcessor = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["StylesProcessor"]();
    const view = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](stylesProcessor);
    const viewDocument = view.document;
    const viewRoot = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rooteditableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewDocument, 'div');
    // Create a temporary root element in view document.
    viewRoot.rootName = 'main';
    viewDocument.roots.add(viewRoot);
    // Create and setup downcast dispatcher.
    const downcastDispatcher = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcastdispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
        mapper,
        schema: model.schema
    });
    // Bind root elements.
    mapper.bindElements(node.root, viewRoot);
    downcastDispatcher.on('insert:$text', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["insertText"])());
    downcastDispatcher.on('insert', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["insertAttributesAndChildren"])(), {
        priority: 'lowest'
    });
    downcastDispatcher.on('attribute', (evt, data, conversionApi)=>{
        if (data.item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || data.item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || data.item.is('$textProxy')) {
            const converter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["wrap"])((modelAttributeValue, { writer })=>{
                return writer.createAttributeElement('model-text-with-attributes', {
                    [data.attributeKey]: stringifyAttributeValue(modelAttributeValue)
                });
            });
            converter(evt, data, conversionApi);
        }
    });
    downcastDispatcher.on('insert', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["insertElement"])((modelItem)=>{
        // Stringify object types values for properly display as an output string.
        const attributes = convertAttributes(modelItem.getAttributes(), stringifyAttributeValue);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewDocument, modelItem.name, attributes);
    }));
    downcastDispatcher.on('selection', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["convertRangeSelection"])());
    downcastDispatcher.on('selection', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["convertCollapsedSelection"])());
    downcastDispatcher.on('addMarker', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["insertUIElement"])((data, { writer })=>{
        const name = data.markerName + ':' + (data.isOpening ? 'start' : 'end');
        return writer.createUIElement(name);
    }));
    const markersMap = new Map();
    if (markers) {
        // To provide stable results, sort markers by name.
        for (const marker of Array.from(markers).sort((a, b)=>a.name < b.name ? 1 : -1)){
            markersMap.set(marker.name, marker.getRange());
        }
    }
    // Convert model to view.
    const writer = view._writer;
    downcastDispatcher.convert(range, markersMap, writer);
    // Convert model selection to view selection.
    if (selection) {
        downcastDispatcher.convertSelection(selection, markers || model.markers, writer);
    }
    // Parse view to data string.
    let data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["stringify"])(viewRoot, viewDocument.selection, {
        sameSelectionCharacters: true
    });
    // Removing unnecessary <div> and </div> added because `viewRoot` was also stringified alongside input data.
    data = data.substr(5, data.length - 11);
    view.destroy();
    // Replace valid XML `model-text-with-attributes` element name to `$text`.
    return data.replace(new RegExp('model-text-with-attributes', 'g'), '$text');
}
function parse(data, schema, options = {}) {
    const mapper = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$mapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    // Replace not accepted by XML `$text` tag name by valid one `model-text-with-attributes`.
    data = data.replace(new RegExp('\\$text', 'g'), 'model-text-with-attributes');
    // Parse data to view using view utils.
    const parsedResult = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parse"])(data, {
        sameSelectionCharacters: true,
        lastRangeBackward: !!options.lastRangeBackward
    });
    // Retrieve DocumentFragment and Selection from parsed view.
    let viewDocumentFragment;
    let viewSelection = null;
    let selection = null;
    if ('view' in parsedResult && 'selection' in parsedResult) {
        viewDocumentFragment = parsedResult.view;
        viewSelection = parsedResult.selection;
    } else {
        viewDocumentFragment = parsedResult;
    }
    // Set up upcast dispatcher.
    const modelController = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    const upcastDispatcher = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcastdispatcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
        schema
    });
    upcastDispatcher.on('documentFragment', convertToModelFragment(mapper));
    upcastDispatcher.on('element:model-text-with-attributes', convertToModelText());
    upcastDispatcher.on('element', convertToModelElement(mapper));
    upcastDispatcher.on('text', convertToModelText());
    // Convert view to model.
    let model = modelController.change((writer)=>upcastDispatcher.convert(viewDocumentFragment.root, writer, options.context || '$root'));
    mapper.bindElements(model, viewDocumentFragment.root);
    // If root DocumentFragment contains only one element - return that element.
    if (model.childCount == 1) {
        model = model.getChild(0);
    }
    // Convert view selection to model selection.
    if (viewSelection) {
        const ranges = [];
        // Convert ranges.
        for (const viewRange of viewSelection.getRanges()){
            ranges.push(mapper.toModelRange(viewRange));
        }
        // Create new selection.
        selection = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](ranges, {
            backward: viewSelection.isBackward
        });
        // Set attributes to selection if specified.
        for (const [key, value] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__["toMap"])(options.selectionAttributes || [])){
            selection.setAttribute(key, value);
        }
    }
    // Return model end selection when selection was specified.
    if (selection) {
        return {
            model,
            selection
        };
    }
    // Otherwise return model only.
    return model;
}
// -- Converters view -> model -----------------------------------------------------
function convertToModelFragment(mapper) {
    return (evt, data, conversionApi)=>{
        const childrenResult = conversionApi.convertChildren(data.viewItem, data.modelCursor);
        mapper.bindElements(data.modelCursor.parent, data.viewItem);
        data = Object.assign(data, childrenResult);
        evt.stop();
    };
}
function convertToModelElement(mapper) {
    return (evt, data, conversionApi)=>{
        const elementName = data.viewItem.name;
        if (!conversionApi.schema.checkChild(data.modelCursor, elementName)) {
            throw new Error(`Element '${elementName}' was not allowed in given position.`);
        }
        // View attribute value is a string so we want to typecast it to the original type.
        // E.g. `bold="true"` - value will be parsed from string `"true"` to boolean `true`.
        const attributes = convertAttributes(data.viewItem.getAttributes(), parseAttributeValue);
        const element = conversionApi.writer.createElement(data.viewItem.name, attributes);
        conversionApi.writer.insert(element, data.modelCursor);
        mapper.bindElements(element, data.viewItem);
        conversionApi.convertChildren(data.viewItem, element);
        data.modelRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(element);
        data.modelCursor = data.modelRange.end;
        evt.stop();
    };
}
function convertToModelText() {
    return (evt, data, conversionApi)=>{
        if (!conversionApi.schema.checkChild(data.modelCursor, '$text')) {
            throw new Error('Text was not allowed in given position.');
        }
        let node;
        if (data.viewItem.is('element')) {
            // View attribute value is a string so we want to typecast it to the original type.
            // E.g. `bold="true"` - value will be parsed from string `"true"` to boolean `true`.
            const attributes = convertAttributes(data.viewItem.getAttributes(), parseAttributeValue);
            const viewText = data.viewItem.getChild(0);
            node = conversionApi.writer.createText(viewText.data, attributes);
        } else {
            node = conversionApi.writer.createText(data.viewItem.data);
        }
        conversionApi.writer.insert(node, data.modelCursor);
        data.modelRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(data.modelCursor, node.offsetSize);
        data.modelCursor = data.modelRange.end;
        evt.stop();
    };
}
// Tries to get original type of attribute value using JSON parsing:
//
//		`'true'` => `true`
//		`'1'` => `1`
//		`'{"x":1,"y":2}'` => `{ x: 1, y: 2 }`
//
// Parse error means that value should be a string:
//
//		`'foobar'` => `'foobar'`
function parseAttributeValue(attribute) {
    try {
        return JSON.parse(attribute);
    } catch (e) {
        return attribute;
    }
}
// When value is an Object stringify it.
function stringifyAttributeValue(data) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__["isPlainObject"])(data)) {
        return JSON.stringify(data);
    }
    return data;
}
// Loop trough attributes map and converts each value by passed converter.
function* convertAttributes(attributes, converter) {
    for (const [key, value] of attributes){
        yield [
            key,
            converter(value)
        ];
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine
 */ __turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$placeholder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/placeholder.js [app-ssr] (ecmascript)");
// Controller.
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$controller$2f$editingcontroller$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/controller/editingcontroller.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$controller$2f$datacontroller$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/controller/datacontroller.js [app-ssr] (ecmascript)");
// Conversion.
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$conversion$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/conversion.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$htmldataprocessor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dataprocessor/htmldataprocessor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/insertoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/moveoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/mergeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/splitoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/markeroperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operationfactory$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operationfactory.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/attributeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/renameoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootattributeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/nooperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$transform$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/transform.js [app-ssr] (ecmascript)");
// Model.
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liverange.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liveposition.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/model.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/treewalker.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$history$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/history.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/textproxy.js [app-ssr] (ecmascript)");
// View.
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$datatransfer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/datatransfer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$domconverter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/domconverter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$renderer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/renderer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/view.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/document.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/containerelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$editableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/editableelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rooteditableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/rooteditableelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/attributeelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$emptyelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/emptyelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rawelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/rawelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/uielement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/treewalker.js [app-ssr] (ecmascript)");
// View / Observer.
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$clickobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/clickobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$mouseobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/mouseobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$tabobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/tabobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$focusobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/focusobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$downcastwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/downcastwriter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$upcastwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/upcastwriter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/matcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingeventinfo.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventdata$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventdata.js [app-ssr] (ecmascript)");
// View / Styles.
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/stylesmap.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$background$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/background.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$border$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/border.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$margin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/margin.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$padding$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/padding.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/utils.js [app-ssr] (ecmascript)");
// Development / testing utils.
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dev-utils/model.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dev-utils/view.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AttributeElement",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "AttributeOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "BubblingEventInfo",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ClickObserver",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$clickobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "Conversion",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$conversion$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "DataController",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$controller$2f$datacontroller$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "DataTransfer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$datatransfer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "DocumentFragment",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "DocumentSelection",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "DomConverter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$domconverter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "DomEventData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventdata$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "DomEventObserver",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "DowncastWriter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$downcastwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "EditingController",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$controller$2f$editingcontroller$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "EditingView",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "Element",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "FocusObserver",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$focusobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "History",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$history$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "HtmlDataProcessor",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$htmldataprocessor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "InsertOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "LivePosition",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "LiveRange",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "MarkerOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "Matcher",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "MergeOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "Model",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "MouseObserver",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$mouseobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "MoveOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "NoOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "Observer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "OperationFactory",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operationfactory$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "Position",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "Range",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "RenameOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "Renderer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$renderer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "RootAttributeOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "RootOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "SplitOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "StylesMap",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "StylesProcessor",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["StylesProcessor"],
    "TabObserver",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$tabobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "Text",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "TextProxy",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "TreeWalker",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "UpcastWriter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$upcastwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewAttributeElement",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewContainerElement",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewDocument",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewDocumentFragment",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewEditableElement",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$editableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewElement",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewEmptyElement",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$emptyelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewRawElement",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rawelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewRootEditableElement",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rooteditableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewText",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewTreeWalker",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ViewUIElement",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "_getModelData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getData"],
    "_getViewData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getData"],
    "_parseModel",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parse"],
    "_parseView",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parse"],
    "_setModelData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setData"],
    "_setViewData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setData"],
    "_stringifyModel",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["stringify"],
    "_stringifyView",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["stringify"],
    "addBackgroundRules",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$background$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["addBackgroundRules"],
    "addBorderRules",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$border$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["addBorderRules"],
    "addMarginRules",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$margin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["addMarginRules"],
    "addPaddingRules",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$padding$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["addPaddingRules"],
    "disablePlaceholder",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$placeholder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["disablePlaceholder"],
    "enablePlaceholder",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$placeholder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["enablePlaceholder"],
    "getBoxSidesShorthandValue",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesShorthandValue"],
    "getBoxSidesValueReducer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValueReducer"],
    "getBoxSidesValues",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValues"],
    "getFillerOffset",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFillerOffset"],
    "getPositionShorthandNormalizer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getPositionShorthandNormalizer"],
    "getShorthandValues",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getShorthandValues"],
    "hidePlaceholder",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$placeholder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["hidePlaceholder"],
    "isAttachment",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isAttachment"],
    "isColor",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isColor"],
    "isLength",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isLength"],
    "isLineStyle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isLineStyle"],
    "isPercentage",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isPercentage"],
    "isPosition",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isPosition"],
    "isRepeat",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isRepeat"],
    "isURL",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isURL"],
    "needsPlaceholder",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$placeholder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["needsPlaceholder"],
    "showPlaceholder",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$placeholder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["showPlaceholder"],
    "transformSets",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$transform$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["transformSets"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$placeholder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/placeholder.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$controller$2f$editingcontroller$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/controller/editingcontroller.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$controller$2f$datacontroller$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/controller/datacontroller.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$conversion$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/conversion.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dataprocessor$2f$htmldataprocessor$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dataprocessor/htmldataprocessor.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/insertoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/moveoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/mergeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/splitoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/markeroperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operationfactory$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operationfactory.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/attributeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/renameoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootattributeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/nooperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$transform$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/transform.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liverange.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liveposition.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/model.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/treewalker.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$history$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/history.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/textproxy.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$datatransfer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/datatransfer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$domconverter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/domconverter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$renderer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/renderer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/view.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/document.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/containerelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$editableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/editableelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rooteditableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/rooteditableelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/attributeelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$emptyelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/emptyelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rawelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/rawelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/uielement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/treewalker.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$clickobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/clickobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$mouseobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/mouseobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$tabobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/tabobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$focusobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/focusobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$downcastwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/downcastwriter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$upcastwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/upcastwriter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/matcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingeventinfo.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventdata$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventdata.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/stylesmap.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$background$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/background.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$border$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/border.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$margin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/margin.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$padding$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/padding.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dev-utils/model.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$dev$2d$utils$2f$view$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/dev-utils/view.js [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=e9609_%40ckeditor_ckeditor5-engine_src_ad0b0abf._.js.map