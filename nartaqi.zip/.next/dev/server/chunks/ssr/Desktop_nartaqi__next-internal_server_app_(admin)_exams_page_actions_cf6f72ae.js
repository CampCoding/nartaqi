module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(admin)/exams/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_nartaqi__next-internal_server_app_%28admin%29_exams_page_actions_cf6f72ae.js.map