module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(admin)/students/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_nartaqi__next-internal_server_app_%28admin%29_students_%5Bid%5D_page_actions_f1ee7fb3.js.map