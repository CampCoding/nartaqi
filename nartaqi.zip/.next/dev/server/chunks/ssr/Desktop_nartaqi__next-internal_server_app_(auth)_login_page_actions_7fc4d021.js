module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(auth)/login/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_nartaqi__next-internal_server_app_%28auth%29_login_page_actions_7fc4d021.js.map