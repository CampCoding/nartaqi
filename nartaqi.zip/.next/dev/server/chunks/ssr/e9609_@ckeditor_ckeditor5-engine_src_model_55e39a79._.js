module.exports = [
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/typecheckable.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "default",
    ()=>TypeCheckable
]);
class TypeCheckable {
    /* istanbul ignore next -- @preserve */ is() {
        // There are a lot of overloads above.
        // Overriding method in derived classes remove them and only `is( type: string ): boolean` is visible which we don't want.
        // One option would be to copy them all to all classes, but that's ugly.
        // It's best when TypeScript compiler doesn't see those overloads, except the one in the top base class.
        // To overload a method, but not let the compiler see it, do after class definition:
        // `MyClass.prototype.is = function( type: string ) {...}`
        throw new Error('is() method is abstract');
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/node.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /* eslint-disable @typescript-eslint/no-unused-vars */ /**
 * @module engine/model/node
 */ __turbopack_context__.s([
    "default",
    ()=>Node
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/comparearrays.js [app-ssr] (ecmascript) <export default as compareArrays>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/tomap.js [app-ssr] (ecmascript) <export default as toMap>");
;
;
class Node extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a model node.
     *
     * This is an abstract class, so this constructor should not be used directly.
     *
     * @param attrs Node's attributes. See {@link module:utils/tomap~toMap} for a list of accepted values.
     */ constructor(attrs){
        super();
        /**
         * Parent of this node. It could be {@link module:engine/model/element~Element}
         * or {@link module:engine/model/documentfragment~DocumentFragment}.
         * Equals to `null` if the node has no parent.
         */ this.parent = null;
        this._attrs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__["toMap"])(attrs);
    }
    /**
     * {@link module:engine/model/document~Document Document} that owns this root element.
     */ get document() {
        return null;
    }
    /**
     * Index of this node in its parent or `null` if the node has no parent.
     *
     * Accessing this property throws an error if this node's parent element does not contain it.
     * This means that model tree got broken.
     */ get index() {
        let pos;
        if (!this.parent) {
            return null;
        }
        if ((pos = this.parent.getChildIndex(this)) === null) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-node-not-found-in-parent', this);
        }
        return pos;
    }
    /**
     * Offset at which this node starts in its parent. It is equal to the sum of {@link #offsetSize offsetSize}
     * of all its previous siblings. Equals to `null` if node has no parent.
     *
     * Accessing this property throws an error if this node's parent element does not contain it.
     * This means that model tree got broken.
     */ get startOffset() {
        let pos;
        if (!this.parent) {
            return null;
        }
        if ((pos = this.parent.getChildStartOffset(this)) === null) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-node-not-found-in-parent', this);
        }
        return pos;
    }
    /**
     * Offset size of this node. Represents how much "offset space" is occupied by the node in it's parent.
     * It is important for {@link module:engine/model/position~Position position}. When node has `offsetSize` greater than `1`, position
     * can be placed between that node start and end. `offsetSize` greater than `1` is for nodes that represents more
     * than one entity, i.e. {@link module:engine/model/text~Text text node}.
     */ get offsetSize() {
        return 1;
    }
    /**
     * Offset at which this node ends in it's parent. It is equal to the sum of this node's
     * {@link module:engine/model/node~Node#startOffset start offset} and {@link #offsetSize offset size}.
     * Equals to `null` if the node has no parent.
     */ get endOffset() {
        if (!this.parent) {
            return null;
        }
        return this.startOffset + this.offsetSize;
    }
    /**
     * Node's next sibling or `null` if the node is a last child of it's parent or if the node has no parent.
     */ get nextSibling() {
        const index = this.index;
        return index !== null && this.parent.getChild(index + 1) || null;
    }
    /**
     * Node's previous sibling or `null` if the node is a first child of it's parent or if the node has no parent.
     */ get previousSibling() {
        const index = this.index;
        return index !== null && this.parent.getChild(index - 1) || null;
    }
    /**
     * The top-most ancestor of the node. If node has no parent it is the root itself. If the node is a part
     * of {@link module:engine/model/documentfragment~DocumentFragment}, it's `root` is equal to that `DocumentFragment`.
     */ get root() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias, consistent-this
        let root = this;
        while(root.parent){
            root = root.parent;
        }
        return root;
    }
    /**
     * Returns `true` if the node is inside a document root that is attached to the document.
     */ isAttached() {
        // If the node has no parent it means that it is a root.
        // But this is not a `RootElement`, so it means that it is not attached.
        //
        // If this is not the root, check if this element's root is attached.
        return this.parent === null ? false : this.root.isAttached();
    }
    /**
     * Gets path to the node. The path is an array containing starting offsets of consecutive ancestors of this node,
     * beginning from {@link module:engine/model/node~Node#root root}, down to this node's starting offset. The path can be used to
     * create {@link module:engine/model/position~Position Position} instance.
     *
     * ```ts
     * const abc = new Text( 'abc' );
     * const foo = new Text( 'foo' );
     * const h1 = new Element( 'h1', null, new Text( 'header' ) );
     * const p = new Element( 'p', null, [ abc, foo ] );
     * const div = new Element( 'div', null, [ h1, p ] );
     * foo.getPath(); // Returns [ 1, 3 ]. `foo` is in `p` which is in `div`. `p` starts at offset 1, while `foo` at 3.
     * h1.getPath(); // Returns [ 0 ].
     * div.getPath(); // Returns [].
     * ```
     */ getPath() {
        const path = [];
        // eslint-disable-next-line @typescript-eslint/no-this-alias, consistent-this
        let node = this;
        while(node.parent){
            path.unshift(node.startOffset);
            node = node.parent;
        }
        return path;
    }
    /**
     * Returns ancestors array of this node.
     *
     * @param options Options object.
     * @param options.includeSelf When set to `true` this node will be also included in parent's array.
     * @param options.parentFirst When set to `true`, array will be sorted from node's parent to root element,
     * otherwise root element will be the first item in the array.
     * @returns Array with ancestors.
     */ getAncestors(options = {}) {
        const ancestors = [];
        let parent = options.includeSelf ? this : this.parent;
        while(parent){
            ancestors[options.parentFirst ? 'push' : 'unshift'](parent);
            parent = parent.parent;
        }
        return ancestors;
    }
    /**
     * Returns a {@link module:engine/model/element~Element} or {@link module:engine/model/documentfragment~DocumentFragment}
     * which is a common ancestor of both nodes.
     *
     * @param node The second node.
     * @param options Options object.
     * @param options.includeSelf When set to `true` both nodes will be considered "ancestors" too.
     * Which means that if e.g. node A is inside B, then their common ancestor will be B.
     */ getCommonAncestor(node, options = {}) {
        const ancestorsA = this.getAncestors(options);
        const ancestorsB = node.getAncestors(options);
        let i = 0;
        while(ancestorsA[i] == ancestorsB[i] && ancestorsA[i]){
            i++;
        }
        return i === 0 ? null : ancestorsA[i - 1];
    }
    /**
     * Returns whether this node is before given node. `false` is returned if nodes are in different trees (for example,
     * in different {@link module:engine/model/documentfragment~DocumentFragment}s).
     *
     * @param node Node to compare with.
     */ isBefore(node) {
        // Given node is not before this node if they are same.
        if (this == node) {
            return false;
        }
        // Return `false` if it is impossible to compare nodes.
        if (this.root !== node.root) {
            return false;
        }
        const thisPath = this.getPath();
        const nodePath = node.getPath();
        const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(thisPath, nodePath);
        switch(result){
            case 'prefix':
                return true;
            case 'extension':
                return false;
            default:
                return thisPath[result] < nodePath[result];
        }
    }
    /**
     * Returns whether this node is after given node. `false` is returned if nodes are in different trees (for example,
     * in different {@link module:engine/model/documentfragment~DocumentFragment}s).
     *
     * @param node Node to compare with.
     */ isAfter(node) {
        // Given node is not before this node if they are same.
        if (this == node) {
            return false;
        }
        // Return `false` if it is impossible to compare nodes.
        if (this.root !== node.root) {
            return false;
        }
        // In other cases, just check if the `node` is before, and return the opposite.
        return !this.isBefore(node);
    }
    /**
     * Checks if the node has an attribute with given key.
     *
     * @param key Key of attribute to check.
     * @returns `true` if attribute with given key is set on node, `false` otherwise.
     */ hasAttribute(key) {
        return this._attrs.has(key);
    }
    /**
     * Gets an attribute value for given key or `undefined` if that attribute is not set on node.
     *
     * @param key Key of attribute to look for.
     * @returns Attribute value or `undefined`.
     */ getAttribute(key) {
        return this._attrs.get(key);
    }
    /**
     * Returns iterator that iterates over this node's attributes.
     *
     * Attributes are returned as arrays containing two items. First one is attribute key and second is attribute value.
     * This format is accepted by native `Map` object and also can be passed in `Node` constructor.
     */ getAttributes() {
        return this._attrs.entries();
    }
    /**
     * Returns iterator that iterates over this node's attribute keys.
     */ getAttributeKeys() {
        return this._attrs.keys();
    }
    /**
     * Converts `Node` to plain object and returns it.
     *
     * @returns `Node` converted to plain object.
     */ toJSON() {
        const json = {};
        // Serializes attributes to the object.
        // attributes = { a: 'foo', b: 1, c: true }.
        if (this._attrs.size) {
            json.attributes = Array.from(this._attrs).reduce((result, attr)=>{
                result[attr[0]] = attr[1];
                return result;
            }, {});
        }
        return json;
    }
    /**
     * Creates a copy of this node, that is a node with exactly same attributes, and returns it.
     *
     * @internal
     * @returns Node with same attributes as this node.
     */ _clone(_deep) {
        return new this.constructor(this._attrs);
    }
    /**
     * Removes this node from it's parent.
     *
     * @internal
     * @see module:engine/model/writer~Writer#remove
     */ _remove() {
        this.parent._removeChildren(this.index);
    }
    /**
     * Sets attribute on the node. If attribute with the same key already is set, it's value is overwritten.
     *
     * @see module:engine/model/writer~Writer#setAttribute
     * @internal
     * @param key Key of attribute to set.
     * @param value Attribute value.
     */ _setAttribute(key, value) {
        this._attrs.set(key, value);
    }
    /**
     * Removes all attributes from the node and sets given attributes.
     *
     * @see module:engine/model/writer~Writer#setAttributes
     * @internal
     * @param attrs Attributes to set. See {@link module:utils/tomap~toMap} for a list of accepted values.
     */ _setAttributesTo(attrs) {
        this._attrs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__["toMap"])(attrs);
    }
    /**
     * Removes an attribute with given key from the node.
     *
     * @see module:engine/model/writer~Writer#removeAttribute
     * @internal
     * @param key Key of attribute to remove.
     * @returns `true` if the attribute was set on the element, `false` otherwise.
     */ _removeAttribute(key) {
        return this._attrs.delete(key);
    }
    /**
     * Removes all attributes from the node.
     *
     * @see module:engine/model/writer~Writer#clearAttributes
     * @internal
     */ _clearAttributes() {
        this._attrs.clear();
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Node.prototype.is = function(type) {
    return type === 'node' || type === 'model:node';
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/nodelist.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/nodelist
 */ __turbopack_context__.s([
    "default",
    ()=>NodeList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/node.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$splicearray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__spliceArray$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/splicearray.js [app-ssr] (ecmascript) <export default as spliceArray>");
;
;
class NodeList {
    /**
     * Creates an empty node list.
     *
     * @internal
     * @param nodes Nodes contained in this node list.
     */ constructor(nodes){
        /**
         * Nodes contained in this node list.
         */ this._nodes = [];
        if (nodes) {
            this._insertNodes(0, nodes);
        }
    }
    /**
     * Iterable interface.
     *
     * Iterates over all nodes contained inside this node list.
     */ [Symbol.iterator]() {
        return this._nodes[Symbol.iterator]();
    }
    /**
     * Number of nodes contained inside this node list.
     */ get length() {
        return this._nodes.length;
    }
    /**
     * Sum of {@link module:engine/model/node~Node#offsetSize offset sizes} of all nodes contained inside this node list.
     */ get maxOffset() {
        return this._nodes.reduce((sum, node)=>sum + node.offsetSize, 0);
    }
    /**
     * Gets the node at the given index. Returns `null` if incorrect index was passed.
     */ getNode(index) {
        return this._nodes[index] || null;
    }
    /**
     * Returns an index of the given node. Returns `null` if given node is not inside this node list.
     */ getNodeIndex(node) {
        const index = this._nodes.indexOf(node);
        return index == -1 ? null : index;
    }
    /**
     * Returns the starting offset of given node. Starting offset is equal to the sum of
     * {@link module:engine/model/node~Node#offsetSize offset sizes} of all nodes that are before this node in this node list.
     */ getNodeStartOffset(node) {
        const index = this.getNodeIndex(node);
        return index === null ? null : this._nodes.slice(0, index).reduce((sum, node)=>sum + node.offsetSize, 0);
    }
    /**
     * Converts index to offset in node list.
     *
     * Returns starting offset of a node that is at given index. Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError}
     * `model-nodelist-index-out-of-bounds` if given index is less than `0` or more than {@link #length}.
     */ indexToOffset(index) {
        if (index == this._nodes.length) {
            return this.maxOffset;
        }
        const node = this._nodes[index];
        if (!node) {
            /**
             * Given index cannot be found in the node list.
             *
             * @error model-nodelist-index-out-of-bounds
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-nodelist-index-out-of-bounds', this);
        }
        return this.getNodeStartOffset(node);
    }
    /**
     * Converts offset in node list to index.
     *
     * Returns index of a node that occupies given offset. Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError}
     * `model-nodelist-offset-out-of-bounds` if given offset is less than `0` or more than {@link #maxOffset}.
     */ offsetToIndex(offset) {
        let totalOffset = 0;
        for (const node of this._nodes){
            if (offset >= totalOffset && offset < totalOffset + node.offsetSize) {
                return this.getNodeIndex(node);
            }
            totalOffset += node.offsetSize;
        }
        if (totalOffset != offset) {
            /**
             * Given offset cannot be found in the node list.
             *
             * @error model-nodelist-offset-out-of-bounds
             * @param offset
             * @param nodeList Stringified node list.
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-nodelist-offset-out-of-bounds', this, {
                offset,
                nodeList: this
            });
        }
        return this.length;
    }
    /**
     * Inserts given nodes at given index.
     *
     * @internal
     * @param index Index at which nodes should be inserted.
     * @param nodes Nodes to be inserted.
     */ _insertNodes(index, nodes) {
        // Validation.
        for (const node of nodes){
            if (!(node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
                /**
                 * Trying to insert an object which is not a Node instance.
                 *
                 * @error model-nodelist-insertnodes-not-node
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-nodelist-insertnodes-not-node', this);
            }
        }
        this._nodes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$splicearray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__spliceArray$3e$__["spliceArray"])(this._nodes, Array.from(nodes), index, 0);
    }
    /**
     * Removes one or more nodes starting at the given index.
     *
     * @internal
     * @param indexStart Index of the first node to remove.
     * @param howMany Number of nodes to remove.
     * @returns Array containing removed nodes.
     */ _removeNodes(indexStart, howMany = 1) {
        return this._nodes.splice(indexStart, howMany);
    }
    /**
     * Converts `NodeList` instance to an array containing nodes that were inserted in the node list. Nodes
     * are also converted to their plain object representation.
     *
     * @returns `NodeList` instance converted to `Array`.
     */ toJSON() {
        return this._nodes.map((node)=>node.toJSON());
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/text
 */ __turbopack_context__.s([
    "default",
    ()=>Text
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/node.js [app-ssr] (ecmascript)");
;
class Text extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a text node.
     *
     * **Note:** Constructor of this class shouldn't be used directly in the code.
     * Use the {@link module:engine/model/writer~Writer#createText} method instead.
     *
     * @internal
     * @param data Node's text.
     * @param attrs Node's attributes. See {@link module:utils/tomap~toMap} for a list of accepted values.
     */ constructor(data, attrs){
        super(attrs);
        this._data = data || '';
    }
    /**
     * @inheritDoc
     */ get offsetSize() {
        return this.data.length;
    }
    /**
     * Returns a text data contained in the node.
     */ get data() {
        return this._data;
    }
    /**
     * Converts `Text` instance to plain object and returns it.
     *
     * @returns`Text` instance converted to plain object.
     */ toJSON() {
        const json = super.toJSON();
        json.data = this.data;
        return json;
    }
    /**
     * Creates a copy of this text node and returns it. Created text node has same text data and attributes as original text node.
     *
     * @internal
     * @returns `Text` instance created using given plain object.
     */ _clone() {
        return new Text(this.data, this.getAttributes());
    }
    /**
     * Creates a `Text` instance from given plain object (i.e. parsed JSON string).
     *
     * @param json Plain object to be converted to `Text`.
     * @returns `Text` instance created using given plain object.
     */ static fromJSON(json) {
        return new Text(json.data, json.attributes);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Text.prototype.is = function(type) {
    return type === '$text' || type === 'model:$text' || // This are legacy values kept for backward compatibility.
    type === 'text' || type === 'model:text' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
    type === 'node' || type === 'model:node';
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/textproxy.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/textproxy
 */ __turbopack_context__.s([
    "default",
    ()=>TextProxy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
class TextProxy extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a text proxy.
     *
     * @internal
     * @param textNode Text node which part is represented by this text proxy.
     * @param offsetInText Offset in {@link module:engine/model/textproxy~TextProxy#textNode text node} from which the text proxy
     * starts.
     * @param length Text proxy length, that is how many text node's characters, starting from `offsetInText` it represents.
     */ constructor(textNode, offsetInText, length){
        super();
        this.textNode = textNode;
        if (offsetInText < 0 || offsetInText > textNode.offsetSize) {
            /**
             * Given `offsetInText` value is incorrect.
             *
             * @error model-textproxy-wrong-offsetintext
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-textproxy-wrong-offsetintext', this);
        }
        if (length < 0 || offsetInText + length > textNode.offsetSize) {
            /**
             * Given `length` value is incorrect.
             *
             * @error model-textproxy-wrong-length
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-textproxy-wrong-length', this);
        }
        this.data = textNode.data.substring(offsetInText, offsetInText + length);
        this.offsetInText = offsetInText;
    }
    /**
     * Offset at which this text proxy starts in it's parent.
     *
     * @see module:engine/model/node~Node#startOffset
     */ get startOffset() {
        return this.textNode.startOffset !== null ? this.textNode.startOffset + this.offsetInText : null;
    }
    /**
     * Offset size of this text proxy. Equal to the number of characters represented by the text proxy.
     *
     * @see module:engine/model/node~Node#offsetSize
     */ get offsetSize() {
        return this.data.length;
    }
    /**
     * Offset at which this text proxy ends in it's parent.
     *
     * @see module:engine/model/node~Node#endOffset
     */ get endOffset() {
        return this.startOffset !== null ? this.startOffset + this.offsetSize : null;
    }
    /**
     * Flag indicating whether `TextProxy` instance covers only part of the original {@link module:engine/model/text~Text text node}
     * (`true`) or the whole text node (`false`).
     *
     * This is `false` when text proxy starts at the very beginning of {@link module:engine/model/textproxy~TextProxy#textNode textNode}
     * ({@link module:engine/model/textproxy~TextProxy#offsetInText offsetInText} equals `0`) and text proxy sizes is equal to
     * text node size.
     */ get isPartial() {
        return this.offsetSize !== this.textNode.offsetSize;
    }
    /**
     * Parent of this text proxy, which is same as parent of text node represented by this text proxy.
     */ get parent() {
        return this.textNode.parent;
    }
    /**
     * Root of this text proxy, which is same as root of text node represented by this text proxy.
     */ get root() {
        return this.textNode.root;
    }
    /**
     * Gets path to this text proxy.
     *
     * @see module:engine/model/node~Node#getPath
     */ getPath() {
        const path = this.textNode.getPath();
        if (path.length > 0) {
            path[path.length - 1] += this.offsetInText;
        }
        return path;
    }
    /**
     * Returns ancestors array of this text proxy.
     *
     * @param options Options object.
     * @param options.includeSelf When set to `true` this text proxy will be also included in parent's array.
     * @param options.parentFirst When set to `true`, array will be sorted from text proxy parent to root element,
     * otherwise root element will be the first item in the array.
     * @returns Array with ancestors.
     */ getAncestors(options = {}) {
        const ancestors = [];
        let parent = options.includeSelf ? this : this.parent;
        while(parent){
            ancestors[options.parentFirst ? 'push' : 'unshift'](parent);
            parent = parent.parent;
        }
        return ancestors;
    }
    /**
     * Checks if this text proxy has an attribute for given key.
     *
     * @param key Key of attribute to check.
     * @returns `true` if attribute with given key is set on text proxy, `false` otherwise.
     */ hasAttribute(key) {
        return this.textNode.hasAttribute(key);
    }
    /**
     * Gets an attribute value for given key or `undefined` if that attribute is not set on text proxy.
     *
     * @param key Key of attribute to look for.
     * @returns Attribute value or `undefined`.
     */ getAttribute(key) {
        return this.textNode.getAttribute(key);
    }
    /**
     * Returns iterator that iterates over this node's attributes. Attributes are returned as arrays containing two
     * items. First one is attribute key and second is attribute value.
     *
     * This format is accepted by native `Map` object and also can be passed in `Node` constructor.
     */ getAttributes() {
        return this.textNode.getAttributes();
    }
    /**
     * Returns iterator that iterates over this node's attribute keys.
     */ getAttributeKeys() {
        return this.textNode.getAttributeKeys();
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
TextProxy.prototype.is = function(type) {
    return type === '$textProxy' || type === 'model:$textProxy' || // This are legacy values kept for backward compatibility.
    type === 'textProxy' || type === 'model:textProxy';
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/element
 */ __turbopack_context__.s([
    "default",
    ()=>Element
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/node.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$nodelist$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/nodelist.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/textproxy.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/isiterable.js [app-ssr] (ecmascript) <export default as isIterable>");
;
;
;
;
;
class Element extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a model element.
     *
     * **Note:** Constructor of this class shouldn't be used directly in the code.
     * Use the {@link module:engine/model/writer~Writer#createElement} method instead.
     *
     * @internal
     * @param name Element's name.
     * @param attrs Element's attributes. See {@link module:utils/tomap~toMap} for a list of accepted values.
     * @param children One or more nodes to be inserted as children of created element.
     */ constructor(name, attrs, children){
        super(attrs);
        /**
         * List of children nodes.
         */ this._children = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$nodelist$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        this.name = name;
        if (children) {
            this._insertChild(0, children);
        }
    }
    /**
     * Number of this element's children.
     */ get childCount() {
        return this._children.length;
    }
    /**
     * Sum of {@link module:engine/model/node~Node#offsetSize offset sizes} of all of this element's children.
     */ get maxOffset() {
        return this._children.maxOffset;
    }
    /**
     * Is `true` if there are no nodes inside this element, `false` otherwise.
     */ get isEmpty() {
        return this.childCount === 0;
    }
    /**
     * Gets the child at the given index.
     */ getChild(index) {
        return this._children.getNode(index);
    }
    /**
     * Returns an iterator that iterates over all of this element's children.
     */ getChildren() {
        return this._children[Symbol.iterator]();
    }
    /**
     * Returns an index of the given child node. Returns `null` if given node is not a child of this element.
     *
     * @param node Child node to look for.
     * @returns Child node's index in this element.
     */ getChildIndex(node) {
        return this._children.getNodeIndex(node);
    }
    /**
     * Returns the starting offset of given child. Starting offset is equal to the sum of
     * {@link module:engine/model/node~Node#offsetSize offset sizes} of all node's siblings that are before it. Returns `null` if
     * given node is not a child of this element.
     *
     * @param node Child node to look for.
     * @returns Child node's starting offset.
     */ getChildStartOffset(node) {
        return this._children.getNodeStartOffset(node);
    }
    /**
     * Returns index of a node that occupies given offset. If given offset is too low, returns `0`. If given offset is
     * too high, returns {@link module:engine/model/element~Element#getChildIndex index after last child}.
     *
     * ```ts
     * const textNode = new Text( 'foo' );
     * const pElement = new Element( 'p' );
     * const divElement = new Element( [ textNode, pElement ] );
     * divElement.offsetToIndex( -1 ); // Returns 0, because offset is too low.
     * divElement.offsetToIndex( 0 ); // Returns 0, because offset 0 is taken by `textNode` which is at index 0.
     * divElement.offsetToIndex( 1 ); // Returns 0, because `textNode` has `offsetSize` equal to 3, so it occupies offset 1 too.
     * divElement.offsetToIndex( 2 ); // Returns 0.
     * divElement.offsetToIndex( 3 ); // Returns 1.
     * divElement.offsetToIndex( 4 ); // Returns 2. There are no nodes at offset 4, so last available index is returned.
     * ```
     */ offsetToIndex(offset) {
        return this._children.offsetToIndex(offset);
    }
    /**
     * Returns a descendant node by its path relative to this element.
     *
     * ```ts
     * // <this>a<b>c</b></this>
     * this.getNodeByPath( [ 0 ] );     // -> "a"
     * this.getNodeByPath( [ 1 ] );     // -> <b>
     * this.getNodeByPath( [ 1, 0 ] );  // -> "c"
     * ```
     *
     * @param relativePath Path of the node to find, relative to this element.
     */ getNodeByPath(relativePath) {
        // eslint-disable-next-line @typescript-eslint/no-this-alias, consistent-this
        let node = this;
        for (const index of relativePath){
            node = node.getChild(node.offsetToIndex(index));
        }
        return node;
    }
    /**
     * Returns the parent element of the given name. Returns null if the element is not inside the desired parent.
     *
     * @param parentName The name of the parent element to find.
     * @param options Options object.
     * @param options.includeSelf When set to `true` this node will be also included while searching.
     */ findAncestor(parentName, options = {}) {
        let parent = options.includeSelf ? this : this.parent;
        while(parent){
            if (parent.name === parentName) {
                return parent;
            }
            parent = parent.parent;
        }
        return null;
    }
    /**
     * Converts `Element` instance to plain object and returns it. Takes care of converting all of this element's children.
     *
     * @returns `Element` instance converted to plain object.
     */ toJSON() {
        const json = super.toJSON();
        json.name = this.name;
        if (this._children.length > 0) {
            json.children = [];
            for (const node of this._children){
                json.children.push(node.toJSON());
            }
        }
        return json;
    }
    /**
     * Creates a copy of this element and returns it. Created element has the same name and attributes as the original element.
     * If clone is deep, the original element's children are also cloned. If not, then empty element is returned.
     *
     * @internal
     * @param deep If set to `true` clones element and all its children recursively. When set to `false`,
     * element will be cloned without any child.
     */ _clone(deep = false) {
        const children = deep ? Array.from(this._children).map((node)=>node._clone(true)) : undefined;
        return new Element(this.name, this.getAttributes(), children);
    }
    /**
     * {@link module:engine/model/element~Element#_insertChild Inserts} one or more nodes at the end of this element.
     *
     * @see module:engine/model/writer~Writer#append
     * @internal
     * @param nodes Nodes to be inserted.
     */ _appendChild(nodes) {
        this._insertChild(this.childCount, nodes);
    }
    /**
     * Inserts one or more nodes at the given index and sets {@link module:engine/model/node~Node#parent parent} of these nodes
     * to this element.
     *
     * @see module:engine/model/writer~Writer#insert
     * @internal
     * @param index Index at which nodes should be inserted.
     * @param items Items to be inserted.
     */ _insertChild(index, items) {
        const nodes = normalize(items);
        for (const node of nodes){
            // If node that is being added to this element is already inside another element, first remove it from the old parent.
            if (node.parent !== null) {
                node._remove();
            }
            node.parent = this;
        }
        this._children._insertNodes(index, nodes);
    }
    /**
     * Removes one or more nodes starting at the given index and sets
     * {@link module:engine/model/node~Node#parent parent} of these nodes to `null`.
     *
     * @see module:engine/model/writer~Writer#remove
     * @internal
     * @param index Index of the first node to remove.
     * @param howMany Number of nodes to remove.
     * @returns Array containing removed nodes.
     */ _removeChildren(index, howMany = 1) {
        const nodes = this._children._removeNodes(index, howMany);
        for (const node of nodes){
            node.parent = null;
        }
        return nodes;
    }
    /**
     * Creates an `Element` instance from given plain object (i.e. parsed JSON string).
     * Converts `Element` children to proper nodes.
     *
     * @param json Plain object to be converted to `Element`.
     * @returns `Element` instance created using given plain object.
     */ static fromJSON(json) {
        let children;
        if (json.children) {
            children = [];
            for (const child of json.children){
                if (child.name) {
                    // If child has name property, it is an Element.
                    children.push(Element.fromJSON(child));
                } else {
                    // Otherwise, it is a Text node.
                    children.push(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(child));
                }
            }
        }
        return new Element(json.name, json.attributes, children);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Element.prototype.is = function(type, name) {
    if (!name) {
        return type === 'element' || type === 'model:element' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'node' || type === 'model:node';
    }
    return name === this.name && (type === 'element' || type === 'model:element');
};
/**
 * Converts strings to Text and non-iterables to arrays.
 */ function normalize(nodes) {
    // Separate condition because string is iterable.
    if (typeof nodes == 'string') {
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodes)
        ];
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__["isIterable"])(nodes)) {
        nodes = [
            nodes
        ];
    }
    // Array.from to enable .map() on non-arrays.
    return Array.from(nodes).map((node)=>{
        if (typeof node == 'string') {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node);
        }
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node.data, node.getAttributes());
        }
        return node;
    });
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/treewalker.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/treewalker
 */ __turbopack_context__.s([
    "default",
    ()=>TreeWalker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/textproxy.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
;
;
;
class TreeWalker {
    /**
     * Creates a range iterator. All parameters are optional, but you have to specify either `boundaries` or `startPosition`.
     *
     * @param options Object with configuration.
     */ constructor(options){
        if (!options || !options.boundaries && !options.startPosition) {
            /**
             * Neither boundaries nor starting position of a `TreeWalker` have been defined.
             *
             * @error model-tree-walker-no-start-position
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-tree-walker-no-start-position', null);
        }
        const direction = options.direction || 'forward';
        if (direction != 'forward' && direction != 'backward') {
            /**
             * Only `backward` and `forward` direction allowed.
             *
             * @error model-tree-walker-unknown-direction
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-tree-walker-unknown-direction', options, {
                direction
            });
        }
        this.direction = direction;
        this.boundaries = options.boundaries || null;
        if (options.startPosition) {
            this._position = options.startPosition.clone();
        } else {
            this._position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(this.boundaries[this.direction == 'backward' ? 'end' : 'start']);
        }
        // Reset position stickiness in case it was set to other value, as the stickiness is kept after cloning.
        this.position.stickiness = 'toNone';
        this.singleCharacters = !!options.singleCharacters;
        this.shallow = !!options.shallow;
        this.ignoreElementEnd = !!options.ignoreElementEnd;
        this._boundaryStartParent = this.boundaries ? this.boundaries.start.parent : null;
        this._boundaryEndParent = this.boundaries ? this.boundaries.end.parent : null;
        this._visitedParent = this.position.parent;
    }
    /**
     * Iterable interface.
     *
     * @returns {Iterable.<module:engine/model/treewalker~TreeWalkerValue>}
     */ [Symbol.iterator]() {
        return this;
    }
    /**
     * Iterator position. This is always static position, even if the initial position was a
     * {@link module:engine/model/liveposition~LivePosition live position}. If start position is not defined then position depends
     * on {@link #direction}. If direction is `'forward'` position starts form the beginning, when direction
     * is `'backward'` position starts from the end.
     */ get position() {
        return this._position;
    }
    /**
     * Moves {@link #position} in the {@link #direction} skipping values as long as the callback function returns `true`.
     *
     * For example:
     *
     * ```ts
     * walker.skip( value => value.type == 'text' ); // <paragraph>[]foo</paragraph> -> <paragraph>foo[]</paragraph>
     * walker.skip( () => true ); // Move the position to the end: <paragraph>[]foo</paragraph> -> <paragraph>foo</paragraph>[]
     * walker.skip( () => false ); // Do not move the position.
     * ```
     *
     * @param skip Callback function. Gets {@link module:engine/model/treewalker~TreeWalkerValue} and should
     * return `true` if the value should be skipped or `false` if not.
     */ skip(skip) {
        let done, value, prevPosition, prevVisitedParent;
        do {
            prevPosition = this.position;
            prevVisitedParent = this._visitedParent;
            ({ done, value } = this.next());
        }while (!done && skip(value))
        if (!done) {
            this._position = prevPosition;
            this._visitedParent = prevVisitedParent;
        }
    }
    /**
     * Gets the next tree walker's value.
     */ next() {
        if (this.direction == 'forward') {
            return this._next();
        } else {
            return this._previous();
        }
    }
    /**
     * Makes a step forward in model. Moves the {@link #position} to the next position and returns the encountered value.
     */ _next() {
        const previousPosition = this.position;
        const position = this.position.clone();
        const parent = this._visitedParent;
        // We are at the end of the root.
        if (parent.parent === null && position.offset === parent.maxOffset) {
            return {
                done: true,
                value: undefined
            };
        }
        // We reached the walker boundary.
        if (parent === this._boundaryEndParent && position.offset == this.boundaries.end.offset) {
            return {
                done: true,
                value: undefined
            };
        }
        // Get node just after the current position.
        // Use a highly optimized version instead of checking the text node first and then getting the node after. See #6582.
        const textNodeAtPosition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTextNodeAtPosition"])(position, parent);
        const node = textNodeAtPosition || (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getNodeAfterPosition"])(position, parent, textNodeAtPosition);
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            if (!this.shallow) {
                // Manual operations on path internals for optimization purposes. Here and in the rest of the method.
                position.path.push(0);
                this._visitedParent = node;
            } else {
                // We are past the walker boundaries.
                if (this.boundaries && this.boundaries.end.isBefore(position)) {
                    return {
                        done: true,
                        value: undefined
                    };
                }
                position.offset++;
            }
            this._position = position;
            return formatReturnValue('elementStart', node, previousPosition, position, 1);
        }
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            let charactersCount;
            if (this.singleCharacters) {
                charactersCount = 1;
            } else {
                let offset = node.endOffset;
                if (this._boundaryEndParent == parent && this.boundaries.end.offset < offset) {
                    offset = this.boundaries.end.offset;
                }
                charactersCount = offset - position.offset;
            }
            const offsetInTextNode = position.offset - node.startOffset;
            const item = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, offsetInTextNode, charactersCount);
            position.offset += charactersCount;
            this._position = position;
            return formatReturnValue('text', item, previousPosition, position, charactersCount);
        }
        // `node` is not set, we reached the end of current `parent`.
        position.path.pop();
        position.offset++;
        this._position = position;
        this._visitedParent = parent.parent;
        if (this.ignoreElementEnd) {
            return this._next();
        }
        return formatReturnValue('elementEnd', parent, previousPosition, position);
    }
    /**
     * Makes a step backward in model. Moves the {@link #position} to the previous position and returns the encountered value.
     */ _previous() {
        const previousPosition = this.position;
        const position = this.position.clone();
        const parent = this._visitedParent;
        // We are at the beginning of the root.
        if (parent.parent === null && position.offset === 0) {
            return {
                done: true,
                value: undefined
            };
        }
        // We reached the walker boundary.
        if (parent == this._boundaryStartParent && position.offset == this.boundaries.start.offset) {
            return {
                done: true,
                value: undefined
            };
        }
        // Get node just before the current position.
        // Use a highly optimized version instead of checking the text node first and then getting the node before. See #6582.
        const positionParent = position.parent;
        const textNodeAtPosition = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getTextNodeAtPosition"])(position, positionParent);
        const node = textNodeAtPosition || (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getNodeBeforePosition"])(position, positionParent, textNodeAtPosition);
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            position.offset--;
            if (this.shallow) {
                this._position = position;
                return formatReturnValue('elementStart', node, previousPosition, position, 1);
            }
            position.path.push(node.maxOffset);
            this._position = position;
            this._visitedParent = node;
            if (this.ignoreElementEnd) {
                return this._previous();
            }
            return formatReturnValue('elementEnd', node, previousPosition, position);
        }
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            let charactersCount;
            if (this.singleCharacters) {
                charactersCount = 1;
            } else {
                let offset = node.startOffset;
                if (this._boundaryStartParent == parent && this.boundaries.start.offset > offset) {
                    offset = this.boundaries.start.offset;
                }
                charactersCount = position.offset - offset;
            }
            const offsetInTextNode = position.offset - node.startOffset;
            const item = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, offsetInTextNode - charactersCount, charactersCount);
            position.offset -= charactersCount;
            this._position = position;
            return formatReturnValue('text', item, previousPosition, position, charactersCount);
        }
        // `node` is not set, we reached the beginning of current `parent`.
        position.path.pop();
        this._position = position;
        this._visitedParent = parent.parent;
        return formatReturnValue('elementStart', parent, previousPosition, position, 1);
    }
}
function formatReturnValue(type, item, previousPosition, nextPosition, length) {
    return {
        done: false,
        value: {
            type,
            item,
            previousPosition,
            nextPosition,
            length
        }
    };
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/position
 */ __turbopack_context__.s([
    "default",
    ()=>Position,
    "getNodeAfterPosition",
    ()=>getNodeAfterPosition,
    "getNodeBeforePosition",
    ()=>getNodeBeforePosition,
    "getTextNodeAtPosition",
    ()=>getTextNodeAtPosition
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/treewalker.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/comparearrays.js [app-ssr] (ecmascript) <export default as compareArrays>");
;
;
;
class Position extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a position.
     *
     * @param root Root of the position.
     * @param path Position path. See {@link module:engine/model/position~Position#path}.
     * @param stickiness Position stickiness. See {@link module:engine/model/position~PositionStickiness}.
     */ constructor(root, path, stickiness = 'toNone'){
        super();
        if (!root.is('element') && !root.is('documentFragment')) {
            /**
             * Position root is invalid.
             *
             * Positions can only be anchored in elements or document fragments.
             *
             * @error model-position-root-invalid
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-position-root-invalid', root);
        }
        if (!(path instanceof Array) || path.length === 0) {
            /**
             * Position path must be an array with at least one item.
             *
             * @error model-position-path-incorrect-format
             * @param path
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-position-path-incorrect-format', root, {
                path
            });
        }
        // Normalize the root and path when element (not root) is passed.
        if (root.is('rootElement')) {
            path = path.slice();
        } else {
            path = [
                ...root.getPath(),
                ...path
            ];
            root = root.root;
        }
        this.root = root;
        this.path = path;
        this.stickiness = stickiness;
    }
    /**
     * Offset at which this position is located in its {@link module:engine/model/position~Position#parent parent}. It is equal
     * to the last item in position {@link module:engine/model/position~Position#path path}.
     *
     * @type {Number}
     */ get offset() {
        return this.path[this.path.length - 1];
    }
    set offset(newOffset) {
        this.path[this.path.length - 1] = newOffset;
    }
    /**
     * Parent element of this position.
     *
     * Keep in mind that `parent` value is calculated when the property is accessed.
     * If {@link module:engine/model/position~Position#path position path}
     * leads to a non-existing element, `parent` property will throw error.
     *
     * Also it is a good idea to cache `parent` property if it is used frequently in an algorithm (i.e. in a long loop).
     */ get parent() {
        let parent = this.root;
        for(let i = 0; i < this.path.length - 1; i++){
            parent = parent.getChild(parent.offsetToIndex(this.path[i]));
            if (!parent) {
                /**
                 * The position's path is incorrect. This means that a position does not point to
                 * a correct place in the tree and hence, some of its methods and getters cannot work correctly.
                 *
                 * **Note**: Unlike DOM and view positions, in the model, the
                 * {@link module:engine/model/position~Position#parent position's parent} is always an element or a document fragment.
                 * The last offset in the {@link module:engine/model/position~Position#path position's path} is the point in this element
                 * where this position points.
                 *
                 * Read more about model positions and offsets in
                 * the {@glink framework/architecture/editing-engine#indexes-and-offsets Editing engine architecture} guide.
                 *
                 * @error model-position-path-incorrect
                 * @param position The incorrect position.
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-position-path-incorrect', this, {
                    position: this
                });
            }
        }
        if (parent.is('$text')) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-position-path-incorrect', this, {
                position: this
            });
        }
        return parent;
    }
    /**
     * Position {@link module:engine/model/position~Position#offset offset} converted to an index in position's parent node. It is
     * equal to the {@link module:engine/model/node~Node#index index} of a node after this position. If position is placed
     * in text node, position index is equal to the index of that text node.
     */ get index() {
        return this.parent.offsetToIndex(this.offset);
    }
    /**
     * Returns {@link module:engine/model/text~Text text node} instance in which this position is placed or `null` if this
     * position is not in a text node.
     */ get textNode() {
        return getTextNodeAtPosition(this, this.parent);
    }
    /**
     * Node directly after this position or `null` if this position is in text node.
     */ get nodeAfter() {
        // Cache the parent and reuse for performance reasons. See #6579 and #6582.
        const parent = this.parent;
        return getNodeAfterPosition(this, parent, getTextNodeAtPosition(this, parent));
    }
    /**
     * Node directly before this position or `null` if this position is in text node.
     */ get nodeBefore() {
        // Cache the parent and reuse for performance reasons. See #6579 and #6582.
        const parent = this.parent;
        return getNodeBeforePosition(this, parent, getTextNodeAtPosition(this, parent));
    }
    /**
     * Is `true` if position is at the beginning of its {@link module:engine/model/position~Position#parent parent}, `false` otherwise.
     */ get isAtStart() {
        return this.offset === 0;
    }
    /**
     * Is `true` if position is at the end of its {@link module:engine/model/position~Position#parent parent}, `false` otherwise.
     */ get isAtEnd() {
        return this.offset == this.parent.maxOffset;
    }
    /**
     * Checks whether this position is before or after given position.
     *
     * This method is safe to use it on non-existing positions (for example during operational transformation).
     */ compareWith(otherPosition) {
        if (this.root != otherPosition.root) {
            return 'different';
        }
        const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(this.path, otherPosition.path);
        switch(result){
            case 'same':
                return 'same';
            case 'prefix':
                return 'before';
            case 'extension':
                return 'after';
            default:
                return this.path[result] < otherPosition.path[result] ? 'before' : 'after';
        }
    }
    /**
     * Gets the farthest position which matches the callback using
     * {@link module:engine/model/treewalker~TreeWalker TreeWalker}.
     *
     * For example:
     *
     * ```ts
     * getLastMatchingPosition( value => value.type == 'text' );
     * // <paragraph>[]foo</paragraph> -> <paragraph>foo[]</paragraph>
     *
     * getLastMatchingPosition( value => value.type == 'text', { direction: 'backward' } );
     * // <paragraph>foo[]</paragraph> -> <paragraph>[]foo</paragraph>
     *
     * getLastMatchingPosition( value => false );
     * // Do not move the position.
     * ```
     *
     * @param skip Callback function. Gets {@link module:engine/model/treewalker~TreeWalkerValue} and should
     * return `true` if the value should be skipped or `false` if not.
     * @param options Object with configuration options. See {@link module:engine/model/treewalker~TreeWalker}.
     *
     * @returns The position after the last item which matches the `skip` callback test.
     */ getLastMatchingPosition(skip, options = {}) {
        options.startPosition = this;
        const treeWalker = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](options);
        treeWalker.skip(skip);
        return treeWalker.position;
    }
    /**
     * Returns a path to this position's parent. Parent path is equal to position {@link module:engine/model/position~Position#path path}
     * but without the last item.
     *
     * This method is safe to use it on non-existing positions (for example during operational transformation).
     *
     * @returns Path to the parent.
     */ getParentPath() {
        return this.path.slice(0, -1);
    }
    /**
     * Returns ancestors array of this position, that is this position's parent and its ancestors.
     *
     * @returns Array with ancestors.
     */ getAncestors() {
        const parent = this.parent;
        if (parent.is('documentFragment')) {
            return [
                parent
            ];
        } else {
            return parent.getAncestors({
                includeSelf: true
            });
        }
    }
    /**
     * Returns the parent element of the given name. Returns null if the position is not inside the desired parent.
     *
     * @param parentName The name of the parent element to find.
     */ findAncestor(parentName) {
        const parent = this.parent;
        if (parent.is('element')) {
            return parent.findAncestor(parentName, {
                includeSelf: true
            });
        }
        return null;
    }
    /**
     * Returns the slice of two position {@link #path paths} which is identical. The {@link #root roots}
     * of these two paths must be identical.
     *
     * This method is safe to use it on non-existing positions (for example during operational transformation).
     *
     * @param position The second position.
     * @returns The common path.
     */ getCommonPath(position) {
        if (this.root != position.root) {
            return [];
        }
        // We find on which tree-level start and end have the lowest common ancestor
        const cmp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(this.path, position.path);
        // If comparison returned string it means that arrays are same.
        const diffAt = typeof cmp == 'string' ? Math.min(this.path.length, position.path.length) : cmp;
        return this.path.slice(0, diffAt);
    }
    /**
     * Returns an {@link module:engine/model/element~Element} or {@link module:engine/model/documentfragment~DocumentFragment}
     * which is a common ancestor of both positions. The {@link #root roots} of these two positions must be identical.
     *
     * @param position The second position.
     */ getCommonAncestor(position) {
        const ancestorsA = this.getAncestors();
        const ancestorsB = position.getAncestors();
        let i = 0;
        while(ancestorsA[i] == ancestorsB[i] && ancestorsA[i]){
            i++;
        }
        return i === 0 ? null : ancestorsA[i - 1];
    }
    /**
     * Returns a new instance of `Position`, that has same {@link #parent parent} but it's offset
     * is shifted by `shift` value (can be a negative value).
     *
     * This method is safe to use it on non-existing positions (for example during operational transformation).
     *
     * @param shift Offset shift. Can be a negative value.
     * @returns Shifted position.
     */ getShiftedBy(shift) {
        const shifted = this.clone();
        const offset = shifted.offset + shift;
        shifted.offset = offset < 0 ? 0 : offset;
        return shifted;
    }
    /**
     * Checks whether this position is after given position.
     *
     * This method is safe to use it on non-existing positions (for example during operational transformation).
     *
     * @see module:engine/model/position~Position#isBefore
     * @param  otherPosition Position to compare with.
     * @returns True if this position is after given position.
     */ isAfter(otherPosition) {
        return this.compareWith(otherPosition) == 'after';
    }
    /**
     * Checks whether this position is before given position.
     *
     * **Note:** watch out when using negation of the value returned by this method, because the negation will also
     * be `true` if positions are in different roots and you might not expect this. You should probably use
     * `a.isAfter( b ) || a.isEqual( b )` or `!a.isBefore( p ) && a.root == b.root` in most scenarios. If your
     * condition uses multiple `isAfter` and `isBefore` checks, build them so they do not use negated values, i.e.:
     *
     * ```ts
     * if ( a.isBefore( b ) && c.isAfter( d ) ) {
     * 	// do A.
     * } else {
     * 	// do B.
     * }
     * ```
     *
     * or, if you have only one if-branch:
     *
     * ```ts
     * if ( !( a.isBefore( b ) && c.isAfter( d ) ) {
     * 	// do B.
     * }
     * ```
     *
     * rather than:
     *
     * ```ts
     * if ( !a.isBefore( b ) || && !c.isAfter( d ) ) {
     * 	// do B.
     * } else {
     * 	// do A.
     * }
     * ```
     *
     * This method is safe to use it on non-existing positions (for example during operational transformation).
     *
     * @param otherPosition Position to compare with.
     * @returns True if this position is before given position.
     */ isBefore(otherPosition) {
        return this.compareWith(otherPosition) == 'before';
    }
    /**
     * Checks whether this position is equal to given position.
     *
     * This method is safe to use it on non-existing positions (for example during operational transformation).
     *
     * @param otherPosition Position to compare with.
     * @returns True if positions are same.
     */ isEqual(otherPosition) {
        return this.compareWith(otherPosition) == 'same';
    }
    /**
     * Checks whether this position is touching given position. Positions touch when there are no text nodes
     * or empty nodes in a range between them. Technically, those positions are not equal but in many cases
     * they are very similar or even indistinguishable.
     *
     * @param otherPosition Position to compare with.
     * @returns True if positions touch.
     */ isTouching(otherPosition) {
        if (this.root !== otherPosition.root) {
            return false;
        }
        const commonLevel = Math.min(this.path.length, otherPosition.path.length);
        for(let level = 0; level < commonLevel; level++){
            const diff = this.path[level] - otherPosition.path[level];
            // Positions are spread by a node, so they are not touching.
            if (diff < -1 || diff > 1) {
                return false;
            } else if (diff === 1) {
                // `otherPosition` is on the left.
                // `this` is on the right.
                return checkTouchingBranch(otherPosition, this, level);
            } else if (diff === -1) {
                // `this` is on the left.
                // `otherPosition` is on the right.
                return checkTouchingBranch(this, otherPosition, level);
            }
        // `diff === 0`.
        // Positions are inside the same element on this level, compare deeper.
        }
        // If we ended up here, it means that positions paths have the same beginning.
        // If the paths have the same length, then it means that they are identical, so the positions are same.
        if (this.path.length === otherPosition.path.length) {
            return true;
        } else if (this.path.length > otherPosition.path.length) {
            return checkOnlyZeroes(this.path, commonLevel);
        } else {
            return checkOnlyZeroes(otherPosition.path, commonLevel);
        }
    }
    /**
     * Checks if two positions are in the same parent.
     *
     * This method is safe to use it on non-existing positions (for example during operational transformation).
     *
     * @param position Position to compare with.
     * @returns `true` if positions have the same parent, `false` otherwise.
     */ hasSameParentAs(position) {
        if (this.root !== position.root) {
            return false;
        }
        const thisParentPath = this.getParentPath();
        const posParentPath = position.getParentPath();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(thisParentPath, posParentPath) == 'same';
    }
    /**
     * Returns a copy of this position that is transformed by given `operation`.
     *
     * The new position's parameters are updated accordingly to the effect of the `operation`.
     *
     * For example, if `n` nodes are inserted before the position, the returned position {@link ~Position#offset} will be
     * increased by `n`. If the position was in a merged element, it will be accordingly moved to the new element, etc.
     *
     * This method is safe to use it on non-existing positions (for example during operational transformation).
     *
     * @param operation Operation to transform by.
     * @returns Transformed position.
     */ getTransformedByOperation(operation) {
        let result;
        switch(operation.type){
            case 'insert':
                result = this._getTransformedByInsertOperation(operation);
                break;
            case 'move':
            case 'remove':
            case 'reinsert':
                result = this._getTransformedByMoveOperation(operation);
                break;
            case 'split':
                result = this._getTransformedBySplitOperation(operation);
                break;
            case 'merge':
                result = this._getTransformedByMergeOperation(operation);
                break;
            default:
                result = Position._createAt(this);
                break;
        }
        return result;
    }
    /**
     * Returns a copy of this position transformed by an insert operation.
     *
     * @internal
     */ _getTransformedByInsertOperation(operation) {
        return this._getTransformedByInsertion(operation.position, operation.howMany);
    }
    /**
     * Returns a copy of this position transformed by a move operation.
     *
     * @internal
     */ _getTransformedByMoveOperation(operation) {
        return this._getTransformedByMove(operation.sourcePosition, operation.targetPosition, operation.howMany);
    }
    /**
     * Returns a copy of this position transformed by a split operation.
     *
     * @internal
     */ _getTransformedBySplitOperation(operation) {
        const movedRange = operation.movedRange;
        const isContained = movedRange.containsPosition(this) || movedRange.start.isEqual(this) && this.stickiness == 'toNext';
        if (isContained) {
            return this._getCombined(operation.splitPosition, operation.moveTargetPosition);
        } else {
            if (operation.graveyardPosition) {
                return this._getTransformedByMove(operation.graveyardPosition, operation.insertionPosition, 1);
            } else {
                return this._getTransformedByInsertion(operation.insertionPosition, 1);
            }
        }
    }
    /**
     * Returns a copy of this position transformed by merge operation.
     *
     * @internal
     */ _getTransformedByMergeOperation(operation) {
        const movedRange = operation.movedRange;
        const isContained = movedRange.containsPosition(this) || movedRange.start.isEqual(this);
        let pos;
        if (isContained) {
            pos = this._getCombined(operation.sourcePosition, operation.targetPosition);
            if (operation.sourcePosition.isBefore(operation.targetPosition)) {
                // Above happens during OT when the merged element is moved before the merged-to element.
                pos = pos._getTransformedByDeletion(operation.deletionPosition, 1);
            }
        } else if (this.isEqual(operation.deletionPosition)) {
            pos = Position._createAt(operation.deletionPosition);
        } else {
            pos = this._getTransformedByMove(operation.deletionPosition, operation.graveyardPosition, 1);
        }
        return pos;
    }
    /**
     * Returns a copy of this position that is updated by removing `howMany` nodes starting from `deletePosition`.
     * It may happen that this position is in a removed node. If that is the case, `null` is returned instead.
     *
     * @internal
     * @param deletePosition Position before the first removed node.
     * @param howMany How many nodes are removed.
     * @returns Transformed position or `null`.
     */ _getTransformedByDeletion(deletePosition, howMany) {
        const transformed = Position._createAt(this);
        // This position can't be affected if deletion was in a different root.
        if (this.root != deletePosition.root) {
            return transformed;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(deletePosition.getParentPath(), this.getParentPath()) == 'same') {
            // If nodes are removed from the node that is pointed by this position...
            if (deletePosition.offset < this.offset) {
                // And are removed from before an offset of that position...
                if (deletePosition.offset + howMany > this.offset) {
                    // Position is in removed range, it's no longer in the tree.
                    return null;
                } else {
                    // Decrement the offset accordingly.
                    transformed.offset -= howMany;
                }
            }
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(deletePosition.getParentPath(), this.getParentPath()) == 'prefix') {
            // If nodes are removed from a node that is on a path to this position...
            const i = deletePosition.path.length - 1;
            if (deletePosition.offset <= this.path[i]) {
                // And are removed from before next node of that path...
                if (deletePosition.offset + howMany > this.path[i]) {
                    // If the next node of that path is removed return null
                    // because the node containing this position got removed.
                    return null;
                } else {
                    // Otherwise, decrement index on that path.
                    transformed.path[i] -= howMany;
                }
            }
        }
        return transformed;
    }
    /**
     * Returns a copy of this position that is updated by inserting `howMany` nodes at `insertPosition`.
     *
     * @internal
     * @param insertPosition Position where nodes are inserted.
     * @param howMany How many nodes are inserted.
     * @returns Transformed position.
     */ _getTransformedByInsertion(insertPosition, howMany) {
        const transformed = Position._createAt(this);
        // This position can't be affected if insertion was in a different root.
        if (this.root != insertPosition.root) {
            return transformed;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(insertPosition.getParentPath(), this.getParentPath()) == 'same') {
            // If nodes are inserted in the node that is pointed by this position...
            if (insertPosition.offset < this.offset || insertPosition.offset == this.offset && this.stickiness != 'toPrevious') {
                // And are inserted before an offset of that position...
                // "Push" this positions offset.
                transformed.offset += howMany;
            }
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(insertPosition.getParentPath(), this.getParentPath()) == 'prefix') {
            // If nodes are inserted in a node that is on a path to this position...
            const i = insertPosition.path.length - 1;
            if (insertPosition.offset <= this.path[i]) {
                // And are inserted before next node of that path...
                // "Push" the index on that path.
                transformed.path[i] += howMany;
            }
        }
        return transformed;
    }
    /**
     * Returns a copy of this position that is updated by moving `howMany` nodes from `sourcePosition` to `targetPosition`.
     *
     * @internal
     * @param sourcePosition Position before the first element to move.
     * @param targetPosition Position where moved elements will be inserted.
     * @param howMany How many consecutive nodes to move, starting from `sourcePosition`.
     * @returns Transformed position.
     */ _getTransformedByMove(sourcePosition, targetPosition, howMany) {
        // Update target position, as it could be affected by nodes removal.
        targetPosition = targetPosition._getTransformedByDeletion(sourcePosition, howMany);
        if (sourcePosition.isEqual(targetPosition)) {
            // If `targetPosition` is equal to `sourcePosition` this isn't really any move. Just return position as it is.
            return Position._createAt(this);
        }
        // Moving a range removes nodes from their original position. We acknowledge this by proper transformation.
        const transformed = this._getTransformedByDeletion(sourcePosition, howMany);
        const isMoved = transformed === null || sourcePosition.isEqual(this) && this.stickiness == 'toNext' || sourcePosition.getShiftedBy(howMany).isEqual(this) && this.stickiness == 'toPrevious';
        if (isMoved) {
            // This position is inside moved range (or sticks to it).
            // In this case, we calculate a combination of this position, move source position and target position.
            return this._getCombined(sourcePosition, targetPosition);
        } else {
            // This position is not inside a removed range.
            //
            // In next step, we simply reflect inserting `howMany` nodes, which might further affect the position.
            return transformed._getTransformedByInsertion(targetPosition, howMany);
        }
    }
    /**
     * Returns a new position that is a combination of this position and given positions.
     *
     * The combined position is a copy of this position transformed by moving a range starting at `source` position
     * to the `target` position. It is expected that this position is inside the moved range.
     *
     * Example:
     *
     * ```ts
     * let original = model.createPositionFromPath( root, [ 2, 3, 1 ] );
     * let source = model.createPositionFromPath( root, [ 2, 2 ] );
     * let target = model.createPositionFromPath( otherRoot, [ 1, 1, 3 ] );
     * original._getCombined( source, target ); // path is [ 1, 1, 4, 1 ], root is `otherRoot`
     * ```
     *
     * Explanation:
     *
     * We have a position `[ 2, 3, 1 ]` and move some nodes from `[ 2, 2 ]` to `[ 1, 1, 3 ]`. The original position
     * was inside moved nodes and now should point to the new place. The moved nodes will be after
     * positions `[ 1, 1, 3 ]`, `[ 1, 1, 4 ]`, `[ 1, 1, 5 ]`. Since our position was in the second moved node,
     * the transformed position will be in a sub-tree of a node at `[ 1, 1, 4 ]`. Looking at original path, we
     * took care of `[ 2, 3 ]` part of it. Now we have to add the rest of the original path to the transformed path.
     * Finally, the transformed position will point to `[ 1, 1, 4, 1 ]`.
     *
     * @internal
     * @param source Beginning of the moved range.
     * @param target Position where the range is moved.
     * @returns Combined position.
     */ _getCombined(source, target) {
        const i = source.path.length - 1;
        // The first part of a path to combined position is a path to the place where nodes were moved.
        const combined = Position._createAt(target);
        combined.stickiness = this.stickiness;
        // Then we have to update the rest of the path.
        // Fix the offset because this position might be after `from` position and we have to reflect that.
        combined.offset = combined.offset + this.path[i] - source.offset;
        // Then, add the rest of the path.
        // If this position is at the same level as `from` position nothing will get added.
        combined.path = [
            ...combined.path,
            ...this.path.slice(i + 1)
        ];
        return combined;
    }
    /**
     * @inheritDoc
     */ toJSON() {
        return {
            root: this.root.toJSON(),
            path: Array.from(this.path),
            stickiness: this.stickiness
        };
    }
    /**
     * Returns a new position that is equal to current position.
     */ clone() {
        return new this.constructor(this.root, this.path, this.stickiness);
    }
    /**
     * Creates position at the given location. The location can be specified as:
     *
     * * a {@link module:engine/model/position~Position position},
     * * parent element and offset (offset defaults to `0`),
     * * parent element and `'end'` (sets position at the end of that element),
     * * {@link module:engine/model/item~Item model item} and `'before'` or `'after'` (sets position before or after given model item).
     *
     * This method is a shortcut to other factory methods such as:
     *
     * * {@link module:engine/model/position~Position._createBefore},
     * * {@link module:engine/model/position~Position._createAfter}.
     *
     * @internal
     * @param offset Offset or one of the flags. Used only when the first parameter is a {@link module:engine/model/item~Item model item}.
     * @param stickiness Position stickiness. Used only when the first parameter is a {@link module:engine/model/item~Item model item}.
     */ static _createAt(itemOrPosition, offset, stickiness = 'toNone') {
        if (itemOrPosition instanceof Position) {
            return new Position(itemOrPosition.root, itemOrPosition.path, itemOrPosition.stickiness);
        } else {
            const node = itemOrPosition;
            if (offset == 'end') {
                offset = node.maxOffset;
            } else if (offset == 'before') {
                return this._createBefore(node, stickiness);
            } else if (offset == 'after') {
                return this._createAfter(node, stickiness);
            } else if (offset !== 0 && !offset) {
                /**
                 * {@link module:engine/model/model~Model#createPositionAt `Model#createPositionAt()`}
                 * requires the offset to be specified when the first parameter is a model item.
                 *
                 * @error model-createpositionat-offset-required
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-createpositionat-offset-required', [
                    this,
                    itemOrPosition
                ]);
            }
            if (!node.is('element') && !node.is('documentFragment')) {
                /**
                 * Position parent have to be a model element or model document fragment.
                 *
                 * @error model-position-parent-incorrect
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-position-parent-incorrect', [
                    this,
                    itemOrPosition
                ]);
            }
            const path = node.getPath();
            path.push(offset);
            return new this(node.root, path, stickiness);
        }
    }
    /**
     * Creates a new position, after given {@link module:engine/model/item~Item model item}.
     *
     * @internal
     * @param item Item after which the position should be placed.
     * @param stickiness Position stickiness.
     */ static _createAfter(item, stickiness) {
        if (!item.parent) {
            /**
             * You can not make a position after a root element.
             *
             * @error model-position-after-root
             * @param root
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-position-after-root', [
                this,
                item
            ], {
                root: item
            });
        }
        return this._createAt(item.parent, item.endOffset, stickiness);
    }
    /**
     * Creates a new position, before the given {@link module:engine/model/item~Item model item}.
     *
     * @internal
     * @param item Item before which the position should be placed.
     * @param stickiness Position stickiness.
     */ static _createBefore(item, stickiness) {
        if (!item.parent) {
            /**
             * You can not make a position before a root element.
             *
             * @error model-position-before-root
             * @param root
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-position-before-root', item, {
                root: item
            });
        }
        return this._createAt(item.parent, item.startOffset, stickiness);
    }
    /**
     * Creates a `Position` instance from given plain object (i.e. parsed JSON string).
     *
     * @param json Plain object to be converted to `Position`.
     * @param doc Document object that will be position owner.
     * @returns `Position` instance created using given plain object.
     */ static fromJSON(json, doc) {
        if (json.root === '$graveyard') {
            const pos = new Position(doc.graveyard, json.path);
            pos.stickiness = json.stickiness;
            return pos;
        }
        if (!doc.getRoot(json.root)) {
            /**
             * Cannot create position for document. Root with specified name does not exist.
             *
             * @error model-position-fromjson-no-root
             * @param rootName
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-position-fromjson-no-root', doc, {
                rootName: json.root
            });
        }
        return new Position(doc.getRoot(json.root), json.path, json.stickiness);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Position.prototype.is = function(type) {
    return type === 'position' || type === 'model:position';
};
function getTextNodeAtPosition(position, positionParent) {
    const node = positionParent.getChild(positionParent.offsetToIndex(position.offset));
    if (node && node.is('$text') && node.startOffset < position.offset) {
        return node;
    }
    return null;
}
function getNodeAfterPosition(position, positionParent, textNode) {
    if (textNode !== null) {
        return null;
    }
    return positionParent.getChild(positionParent.offsetToIndex(position.offset));
}
function getNodeBeforePosition(position, positionParent, textNode) {
    if (textNode !== null) {
        return null;
    }
    return positionParent.getChild(positionParent.offsetToIndex(position.offset) - 1);
}
/**
 * This is a helper function for `Position#isTouching()`.
 *
 * It checks whether to given positions are touching, considering that they have the same root and paths
 * until given level, and at given level they differ by 1 (so they are branching at `level` point).
 *
 * The exact requirements for touching positions are described in `Position#isTouching()` and also
 * in the body of this function.
 *
 * @param left Position "on the left" (it is before `right`).
 * @param right Position "on the right" (it is after `left`).
 * @param level Level on which the positions are different.
 */ function checkTouchingBranch(left, right, level) {
    if (level + 1 === left.path.length) {
        // Left position does not have any more entries after the point where the positions differ.
        // [ 2 ] vs [ 3 ]
        // [ 2 ] vs [ 3, 0, 0 ]
        // The positions are spread by node at [ 2 ].
        return false;
    }
    if (!checkOnlyZeroes(right.path, level + 1)) {
        // Right position does not have only zeroes, so we have situation like:
        // [ 2, maxOffset ] vs [ 3, 1 ]
        // [ 2, maxOffset ] vs [ 3, 1, 0, 0 ]
        // The positions are spread by node at [ 3, 0 ].
        return false;
    }
    if (!checkOnlyMaxOffset(left, level + 1)) {
        // Left position does not have only max offsets, so we have situation like:
        // [ 2, 4 ] vs [ 3 ]
        // [ 2, 4 ] vs [ 3, 0, 0 ]
        // The positions are spread by node at [ 2, 5 ].
        return false;
    }
    // Left position has only max offsets and right position has only zeroes or nothing.
    // [ 2, maxOffset ] vs [ 3 ]
    // [ 2, maxOffset, maxOffset ] vs [ 3, 0 ]
    // There are not elements between positions. The positions are touching.
    return true;
}
/**
 * Checks whether for given array, starting from given index until the end of the array, all items are `0`s.
 *
 * This is a helper function for `Position#isTouching()`.
 */ function checkOnlyZeroes(arr, idx) {
    while(idx < arr.length){
        if (arr[idx] !== 0) {
            return false;
        }
        idx++;
    }
    return true;
}
/**
 * Checks whether for given position, starting from given path level, whether the position is at the end of
 * its parent and whether each element on the path to the position is also at at the end of its parent.
 *
 * This is a helper function for `Position#isTouching()`.
 */ function checkOnlyMaxOffset(pos, level) {
    let parent = pos.parent;
    let idx = pos.path.length - 1;
    let add = 0;
    while(idx >= level){
        if (pos.path[idx] + add !== parent.maxOffset) {
            return false;
        }
        // After the first check, we "go up", and check whether the position's parent-parent is the last element.
        // However, we need to add 1 to the value in the path to "simulate" moving the path after the parent.
        // It happens just once.
        add = 1;
        idx--;
        parent = parent.parent;
    }
    return true;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/range
 */ __turbopack_context__.s([
    "default",
    ()=>Range
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/treewalker.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/comparearrays.js [app-ssr] (ecmascript) <export default as compareArrays>");
;
;
;
;
class Range extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a range spanning from `start` position to `end` position.
     *
     * @param start The start position.
     * @param end The end position. If not set, the range will be collapsed at the `start` position.
     */ constructor(start, end){
        super();
        this.start = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(start);
        this.end = end ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(end) : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(start);
        // If the range is collapsed, treat in a similar way as a position and set its boundaries stickiness to 'toNone'.
        // In other case, make the boundaries stick to the "inside" of the range.
        this.start.stickiness = this.isCollapsed ? 'toNone' : 'toNext';
        this.end.stickiness = this.isCollapsed ? 'toNone' : 'toPrevious';
    }
    /**
     * Iterable interface.
     *
     * Iterates over all {@link module:engine/model/item~Item items} that are in this range and returns
     * them together with additional information like length or {@link module:engine/model/position~Position positions},
     * grouped as {@link module:engine/model/treewalker~TreeWalkerValue}.
     * It iterates over all {@link module:engine/model/textproxy~TextProxy text contents} that are inside the range
     * and all the {@link module:engine/model/element~Element}s that are entered into when iterating over this range.
     *
     * This iterator uses {@link module:engine/model/treewalker~TreeWalker} with `boundaries` set to this range
     * and `ignoreElementEnd` option set to `true`.
     */ *[Symbol.iterator]() {
        yield* new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
            boundaries: this,
            ignoreElementEnd: true
        });
    }
    /**
     * Describes whether the range is collapsed, that is if {@link #start} and
     * {@link #end} positions are equal.
     */ get isCollapsed() {
        return this.start.isEqual(this.end);
    }
    /**
     * Describes whether this range is flat, that is if {@link #start} position and
     * {@link #end} position are in the same {@link module:engine/model/position~Position#parent}.
     */ get isFlat() {
        const startParentPath = this.start.getParentPath();
        const endParentPath = this.end.getParentPath();
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(startParentPath, endParentPath) == 'same';
    }
    /**
     * Range root element.
     */ get root() {
        return this.start.root;
    }
    /**
     * Checks whether this range contains given {@link module:engine/model/position~Position position}.
     *
     * @param position Position to check.
     * @returns `true` if given {@link module:engine/model/position~Position position} is contained
     * in this range,`false` otherwise.
     */ containsPosition(position) {
        return position.isAfter(this.start) && position.isBefore(this.end);
    }
    /**
     * Checks whether this range contains given {@link ~Range range}.
     *
     * @param otherRange Range to check.
     * @param loose Whether the check is loose or strict. If the check is strict (`false`), compared range cannot
     * start or end at the same position as this range boundaries. If the check is loose (`true`), compared range can start, end or
     * even be equal to this range. Note that collapsed ranges are always compared in strict mode.
     * @returns {Boolean} `true` if given {@link ~Range range} boundaries are contained by this range, `false` otherwise.
     */ containsRange(otherRange, loose = false) {
        if (otherRange.isCollapsed) {
            loose = false;
        }
        const containsStart = this.containsPosition(otherRange.start) || loose && this.start.isEqual(otherRange.start);
        const containsEnd = this.containsPosition(otherRange.end) || loose && this.end.isEqual(otherRange.end);
        return containsStart && containsEnd;
    }
    /**
     * Checks whether given {@link module:engine/model/item~Item} is inside this range.
     */ containsItem(item) {
        const pos = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item);
        return this.containsPosition(pos) || this.start.isEqual(pos);
    }
    /**
     * Two ranges are equal if their {@link #start} and {@link #end} positions are equal.
     *
     * @param otherRange Range to compare with.
     * @returns `true` if ranges are equal, `false` otherwise.
     */ isEqual(otherRange) {
        return this.start.isEqual(otherRange.start) && this.end.isEqual(otherRange.end);
    }
    /**
     * Checks and returns whether this range intersects with given range.
     *
     * @param otherRange Range to compare with.
     * @returns `true` if ranges intersect, `false` otherwise.
     */ isIntersecting(otherRange) {
        return this.start.isBefore(otherRange.end) && this.end.isAfter(otherRange.start);
    }
    /**
     * Computes which part(s) of this {@link ~Range range} is not a part of given {@link ~Range range}.
     * Returned array contains zero, one or two {@link ~Range ranges}.
     *
     * Examples:
     *
     * ```ts
     * let range = model.createRange(
     * 	model.createPositionFromPath( root, [ 2, 7 ] ),
     * 	model.createPositionFromPath( root, [ 4, 0, 1 ] )
     * );
     * let otherRange = model.createRange( model.createPositionFromPath( root, [ 1 ] ), model.createPositionFromPath( root, [ 5 ] ) );
     * let transformed = range.getDifference( otherRange );
     * // transformed array has no ranges because `otherRange` contains `range`
     *
     * otherRange = model.createRange( model.createPositionFromPath( root, [ 1 ] ), model.createPositionFromPath( root, [ 3 ] ) );
     * transformed = range.getDifference( otherRange );
     * // transformed array has one range: from [ 3 ] to [ 4, 0, 1 ]
     *
     * otherRange = model.createRange( model.createPositionFromPath( root, [ 3 ] ), model.createPositionFromPath( root, [ 4 ] ) );
     * transformed = range.getDifference( otherRange );
     * // transformed array has two ranges: from [ 2, 7 ] to [ 3 ] and from [ 4 ] to [ 4, 0, 1 ]
     * ```
     *
     * @param otherRange Range to differentiate against.
     * @returns The difference between ranges.
     */ getDifference(otherRange) {
        const ranges = [];
        if (this.isIntersecting(otherRange)) {
            // Ranges intersect.
            if (this.containsPosition(otherRange.start)) {
                // Given range start is inside this range. This means that we have to
                // add shrunken range - from the start to the middle of this range.
                ranges.push(new Range(this.start, otherRange.start));
            }
            if (this.containsPosition(otherRange.end)) {
                // Given range end is inside this range. This means that we have to
                // add shrunken range - from the middle of this range to the end.
                ranges.push(new Range(otherRange.end, this.end));
            }
        } else {
            // Ranges do not intersect, return the original range.
            ranges.push(new Range(this.start, this.end));
        }
        return ranges;
    }
    /**
     * Returns an intersection of this {@link ~Range range} and given {@link ~Range range}.
     * Intersection is a common part of both of those ranges. If ranges has no common part, returns `null`.
     *
     * Examples:
     *
     * ```ts
     * let range = model.createRange(
     * 	model.createPositionFromPath( root, [ 2, 7 ] ),
     * 	model.createPositionFromPath( root, [ 4, 0, 1 ] )
     * );
     * let otherRange = model.createRange( model.createPositionFromPath( root, [ 1 ] ), model.createPositionFromPath( root, [ 2 ] ) );
     * let transformed = range.getIntersection( otherRange ); // null - ranges have no common part
     *
     * otherRange = model.createRange( model.createPositionFromPath( root, [ 3 ] ), model.createPositionFromPath( root, [ 5 ] ) );
     * transformed = range.getIntersection( otherRange ); // range from [ 3 ] to [ 4, 0, 1 ]
     * ```
     *
     * @param otherRange Range to check for intersection.
     * @returns A common part of given ranges or `null` if ranges have no common part.
     */ getIntersection(otherRange) {
        if (this.isIntersecting(otherRange)) {
            // Ranges intersect, so a common range will be returned.
            // At most, it will be same as this range.
            let commonRangeStart = this.start;
            let commonRangeEnd = this.end;
            if (this.containsPosition(otherRange.start)) {
                // Given range start is inside this range. This means thaNt we have to
                // shrink common range to the given range start.
                commonRangeStart = otherRange.start;
            }
            if (this.containsPosition(otherRange.end)) {
                // Given range end is inside this range. This means that we have to
                // shrink common range to the given range end.
                commonRangeEnd = otherRange.end;
            }
            return new Range(commonRangeStart, commonRangeEnd);
        }
        // Ranges do not intersect, so they do not have common part.
        return null;
    }
    /**
     * Returns a range created by joining this {@link ~Range range} with the given {@link ~Range range}.
     * If ranges have no common part, returns `null`.
     *
     * Examples:
     *
     * ```ts
     * let range = model.createRange(
     * 	model.createPositionFromPath( root, [ 2, 7 ] ),
     * 	model.createPositionFromPath( root, [ 4, 0, 1 ] )
     * );
     * let otherRange = model.createRange(
     * 	model.createPositionFromPath( root, [ 1 ] ),
     * 	model.createPositionFromPath( root, [ 2 ] )
     * );
     * let transformed = range.getJoined( otherRange ); // null - ranges have no common part
     *
     * otherRange = model.createRange(
     * 	model.createPositionFromPath( root, [ 3 ] ),
     * 	model.createPositionFromPath( root, [ 5 ] )
     * );
     * transformed = range.getJoined( otherRange ); // range from [ 2, 7 ] to [ 5 ]
     * ```
     *
     * @param otherRange Range to be joined.
     * @param loose Whether the intersection check is loose or strict. If the check is strict (`false`),
     * ranges are tested for intersection or whether start/end positions are equal. If the check is loose (`true`),
     * compared range is also checked if it's {@link module:engine/model/position~Position#isTouching touching} current range.
     * @returns A sum of given ranges or `null` if ranges have no common part.
     */ getJoined(otherRange, loose = false) {
        let shouldJoin = this.isIntersecting(otherRange);
        if (!shouldJoin) {
            if (this.start.isBefore(otherRange.start)) {
                shouldJoin = loose ? this.end.isTouching(otherRange.start) : this.end.isEqual(otherRange.start);
            } else {
                shouldJoin = loose ? otherRange.end.isTouching(this.start) : otherRange.end.isEqual(this.start);
            }
        }
        if (!shouldJoin) {
            return null;
        }
        let startPosition = this.start;
        let endPosition = this.end;
        if (otherRange.start.isBefore(startPosition)) {
            startPosition = otherRange.start;
        }
        if (otherRange.end.isAfter(endPosition)) {
            endPosition = otherRange.end;
        }
        return new Range(startPosition, endPosition);
    }
    /**
     * Computes and returns the smallest set of {@link #isFlat flat} ranges, that covers this range in whole.
     *
     * See an example of a model structure (`[` and `]` are range boundaries):
     *
     * ```
     * root                                                            root
     *  |- element DIV                         DIV             P2              P3             DIV
     *  |   |- element H                   H        P1        f o o           b a r       H         P4
     *  |   |   |- "fir[st"             fir[st     lorem                               se]cond     ipsum
     *  |   |- element P1
     *  |   |   |- "lorem"                                              ||
     *  |- element P2                                                   ||
     *  |   |- "foo"                                                    VV
     *  |- element P3
     *  |   |- "bar"                                                   root
     *  |- element DIV                         DIV             [P2             P3]             DIV
     *  |   |- element H                   H       [P1]       f o o           b a r        H         P4
     *  |   |   |- "se]cond"            fir[st]    lorem                               [se]cond     ipsum
     *  |   |- element P4
     *  |   |   |- "ipsum"
     * ```
     *
     * As it can be seen, letters contained in the range are: `stloremfoobarse`, spread across different parents.
     * We are looking for minimal set of flat ranges that contains the same nodes.
     *
     * Minimal flat ranges for above range `( [ 0, 0, 3 ], [ 3, 0, 2 ] )` will be:
     *
     * ```
     * ( [ 0, 0, 3 ], [ 0, 0, 5 ] ) = "st"
     * ( [ 0, 1 ], [ 0, 2 ] ) = element P1 ("lorem")
     * ( [ 1 ], [ 3 ] ) = element P2, element P3 ("foobar")
     * ( [ 3, 0, 0 ], [ 3, 0, 2 ] ) = "se"
     * ```
     *
     * **Note:** if an {@link module:engine/model/element~Element element} is not wholly contained in this range, it won't be returned
     * in any of the returned flat ranges. See in the example how `H` elements at the beginning and at the end of the range
     * were omitted. Only their parts that were wholly in the range were returned.
     *
     * **Note:** this method is not returning flat ranges that contain no nodes.
     *
     * @returns Array of flat ranges covering this range.
     */ getMinimalFlatRanges() {
        const ranges = [];
        const diffAt = this.start.getCommonPath(this.end).length;
        const pos = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(this.start);
        let posParent = pos.parent;
        // Go up.
        while(pos.path.length > diffAt + 1){
            const howMany = posParent.maxOffset - pos.offset;
            if (howMany !== 0) {
                ranges.push(new Range(pos, pos.getShiftedBy(howMany)));
            }
            pos.path = pos.path.slice(0, -1);
            pos.offset++;
            posParent = posParent.parent;
        }
        // Go down.
        while(pos.path.length <= this.end.path.length){
            const offset = this.end.path[pos.path.length - 1];
            const howMany = offset - pos.offset;
            if (howMany !== 0) {
                ranges.push(new Range(pos, pos.getShiftedBy(howMany)));
            }
            pos.offset = offset;
            pos.path.push(0);
        }
        return ranges;
    }
    /**
     * Creates a {@link module:engine/model/treewalker~TreeWalker TreeWalker} instance with this range as a boundary.
     *
     * For example, to iterate over all items in the entire document root:
     *
     * ```ts
     * // Create a range spanning over the entire root content:
     * const range = editor.model.createRangeIn( editor.model.document.getRoot() );
     *
     * // Iterate over all items in this range:
     * for ( const value of range.getWalker() ) {
     * 	console.log( value.item );
     * }
     * ```
     *
     * @param options Object with configuration options. See {@link module:engine/model/treewalker~TreeWalker}.
     */ getWalker(options = {}) {
        options.boundaries = this;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](options);
    }
    /**
     * Returns an iterator that iterates over all {@link module:engine/model/item~Item items} that are in this range and returns
     * them.
     *
     * This method uses {@link module:engine/model/treewalker~TreeWalker} with `boundaries` set to this range and `ignoreElementEnd` option
     * set to `true`. However it returns only {@link module:engine/model/item~Item model items},
     * not {@link module:engine/model/treewalker~TreeWalkerValue}.
     *
     * You may specify additional options for the tree walker. See {@link module:engine/model/treewalker~TreeWalker} for
     * a full list of available options.
     *
     * @param options Object with configuration options. See {@link module:engine/model/treewalker~TreeWalker}.
     */ *getItems(options = {}) {
        options.boundaries = this;
        options.ignoreElementEnd = true;
        const treeWalker = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](options);
        for (const value of treeWalker){
            yield value.item;
        }
    }
    /**
     * Returns an iterator that iterates over all {@link module:engine/model/position~Position positions} that are boundaries or
     * contained in this range.
     *
     * This method uses {@link module:engine/model/treewalker~TreeWalker} with `boundaries` set to this range. However it returns only
     * {@link module:engine/model/position~Position positions}, not {@link module:engine/model/treewalker~TreeWalkerValue}.
     *
     * You may specify additional options for the tree walker. See {@link module:engine/model/treewalker~TreeWalker} for
     * a full list of available options.
     *
     * @param options Object with configuration options. See {@link module:engine/model/treewalker~TreeWalker}.
     */ *getPositions(options = {}) {
        options.boundaries = this;
        const treeWalker = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](options);
        yield treeWalker.position;
        for (const value of treeWalker){
            yield value.nextPosition;
        }
    }
    /**
     * Returns a range that is a result of transforming this range by given `operation`.
     *
     * **Note:** transformation may break one range into multiple ranges (for example, when a part of the range is
     * moved to a different part of document tree). For this reason, an array is returned by this method and it
     * may contain one or more `Range` instances.
     *
     * @param operation Operation to transform range by.
     * @returns Range which is the result of transformation.
     */ getTransformedByOperation(operation) {
        switch(operation.type){
            case 'insert':
                return this._getTransformedByInsertOperation(operation);
            case 'move':
            case 'remove':
            case 'reinsert':
                return this._getTransformedByMoveOperation(operation);
            case 'split':
                return [
                    this._getTransformedBySplitOperation(operation)
                ];
            case 'merge':
                return [
                    this._getTransformedByMergeOperation(operation)
                ];
        }
        return [
            new Range(this.start, this.end)
        ];
    }
    /**
     * Returns a range that is a result of transforming this range by multiple `operations`.
     *
     * @see ~Range#getTransformedByOperation
     * @param operations Operations to transform the range by.
     * @returns Range which is the result of transformation.
     */ getTransformedByOperations(operations) {
        const ranges = [
            new Range(this.start, this.end)
        ];
        for (const operation of operations){
            for(let i = 0; i < ranges.length; i++){
                const result = ranges[i].getTransformedByOperation(operation);
                ranges.splice(i, 1, ...result);
                i += result.length - 1;
            }
        }
        // It may happen that a range is split into two, and then the part of second "piece" is moved into first
        // "piece". In this case we will have incorrect third range, which should not be included in the result --
        // because it is already included in the first "piece". In this loop we are looking for all such ranges that
        // are inside other ranges and we simply remove them.
        for(let i = 0; i < ranges.length; i++){
            const range = ranges[i];
            for(let j = i + 1; j < ranges.length; j++){
                const next = ranges[j];
                if (range.containsRange(next) || next.containsRange(range) || range.isEqual(next)) {
                    ranges.splice(j, 1);
                }
            }
        }
        return ranges;
    }
    /**
     * Returns an {@link module:engine/model/element~Element} or {@link module:engine/model/documentfragment~DocumentFragment}
     * which is a common ancestor of the range's both ends (in which the entire range is contained).
     */ getCommonAncestor() {
        return this.start.getCommonAncestor(this.end);
    }
    /**
     * Returns an {@link module:engine/model/element~Element Element} contained by the range.
     * The element will be returned when it is the **only** node within the range and **fully–contained**
     * at the same time.
     */ getContainedElement() {
        if (this.isCollapsed) {
            return null;
        }
        const nodeAfterStart = this.start.nodeAfter;
        const nodeBeforeEnd = this.end.nodeBefore;
        if (nodeAfterStart && nodeAfterStart.is('element') && nodeAfterStart === nodeBeforeEnd) {
            return nodeAfterStart;
        }
        return null;
    }
    /**
     * Converts `Range` to plain object and returns it.
     *
     * @returns `Node` converted to plain object.
     */ toJSON() {
        return {
            start: this.start.toJSON(),
            end: this.end.toJSON()
        };
    }
    /**
     * Returns a new range that is equal to current range.
     */ clone() {
        return new this.constructor(this.start, this.end);
    }
    /**
     * Returns a result of transforming a copy of this range by insert operation.
     *
     * One or more ranges may be returned as a result of this transformation.
     *
     * @internal
     */ _getTransformedByInsertOperation(operation, spread = false) {
        return this._getTransformedByInsertion(operation.position, operation.howMany, spread);
    }
    /**
     * Returns a result of transforming a copy of this range by move operation.
     *
     * One or more ranges may be returned as a result of this transformation.
     *
     * @internal
     */ _getTransformedByMoveOperation(operation, spread = false) {
        const sourcePosition = operation.sourcePosition;
        const howMany = operation.howMany;
        const targetPosition = operation.targetPosition;
        return this._getTransformedByMove(sourcePosition, targetPosition, howMany, spread);
    }
    /**
     * Returns a result of transforming a copy of this range by split operation.
     *
     * Always one range is returned. The transformation is done in a way to not break the range.
     *
     * @internal
     */ _getTransformedBySplitOperation(operation) {
        const start = this.start._getTransformedBySplitOperation(operation);
        let end = this.end._getTransformedBySplitOperation(operation);
        if (this.end.isEqual(operation.insertionPosition)) {
            end = this.end.getShiftedBy(1);
        }
        // Below may happen when range contains graveyard element used by split operation.
        if (start.root != end.root) {
            // End position was next to the moved graveyard element and was moved with it.
            // Fix it by using old `end` which has proper `root`.
            end = this.end.getShiftedBy(-1);
        }
        return new Range(start, end);
    }
    /**
     * Returns a result of transforming a copy of this range by merge operation.
     *
     * Always one range is returned. The transformation is done in a way to not break the range.
     *
     * @internal
     */ _getTransformedByMergeOperation(operation) {
        // Special case when the marker is set on "the closing tag" of an element. Marker can be set like that during
        // transformations, especially when a content of a few block elements were removed. For example:
        //
        // {} is the transformed range, [] is the removed range.
        // <p>F[o{o</p><p>B}ar</p><p>Xy]z</p>
        //
        // <p>Fo{o</p><p>B}ar</p><p>z</p>
        // <p>F{</p><p>B}ar</p><p>z</p>
        // <p>F{</p>}<p>z</p>
        // <p>F{}z</p>
        //
        if (this.start.isEqual(operation.targetPosition) && this.end.isEqual(operation.deletionPosition)) {
            return new Range(this.start);
        }
        let start = this.start._getTransformedByMergeOperation(operation);
        let end = this.end._getTransformedByMergeOperation(operation);
        if (start.root != end.root) {
            // This happens when the end position was next to the merged (deleted) element.
            // Then, the end position was moved to the graveyard root. In this case we need to fix
            // the range cause its boundaries would be in different roots.
            end = this.end.getShiftedBy(-1);
        }
        if (start.isAfter(end)) {
            // This happens in three following cases:
            //
            // Case 1: Merge operation source position is before the target position (due to some transformations, OT, etc.)
            //         This means that start can be moved before the end of the range.
            //
            // Before: <p>a{a</p><p>b}b</p><p>cc</p>
            // Merge:  <p>b}b</p><p>cca{a</p>
            // Fix:    <p>{b}b</p><p>ccaa</p>
            //
            // Case 2: Range start is before merged node but not directly.
            //         Result should include all nodes that were in the original range.
            //
            // Before: <p>aa</p>{<p>cc</p><p>b}b</p>
            // Merge:  <p>aab}b</p>{<p>cc</p>
            // Fix:    <p>aa{bb</p><p>cc</p>}
            //
            //         The range is expanded by an additional `b` letter but it is better than dropping the whole `cc` paragraph.
            //
            // Case 3: Range start is directly before merged node.
            //         Resulting range should include only nodes from the merged element:
            //
            // Before: <p>aa</p>{<p>b}b</p><p>cc</p>
            // Merge:  <p>aab}b</p>{<p>cc</p>
            // Fix:    <p>aa{b}b</p><p>cc</p>
            //
            if (operation.sourcePosition.isBefore(operation.targetPosition)) {
                // Case 1.
                start = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(end);
                start.offset = 0;
            } else {
                if (!operation.deletionPosition.isEqual(start)) {
                    // Case 2.
                    end = operation.deletionPosition;
                }
                // In both case 2 and 3 start is at the end of the merge-to element.
                start = operation.targetPosition;
            }
            return new Range(start, end);
        }
        return new Range(start, end);
    }
    /**
     * Returns an array containing one or two {@link ~Range ranges} that are a result of transforming this
     * {@link ~Range range} by inserting `howMany` nodes at `insertPosition`. Two {@link ~Range ranges} are
     * returned if the insertion was inside this {@link ~Range range} and `spread` is set to `true`.
     *
     * Examples:
     *
     * ```ts
     * let range = model.createRange(
     * 	model.createPositionFromPath( root, [ 2, 7 ] ),
     * 	model.createPositionFromPath( root, [ 4, 0, 1 ] )
     * );
     * let transformed = range._getTransformedByInsertion( model.createPositionFromPath( root, [ 1 ] ), 2 );
     * // transformed array has one range from [ 4, 7 ] to [ 6, 0, 1 ]
     *
     * transformed = range._getTransformedByInsertion( model.createPositionFromPath( root, [ 4, 0, 0 ] ), 4 );
     * // transformed array has one range from [ 2, 7 ] to [ 4, 0, 5 ]
     *
     * transformed = range._getTransformedByInsertion( model.createPositionFromPath( root, [ 3, 2 ] ), 4 );
     * // transformed array has one range, which is equal to original range
     *
     * transformed = range._getTransformedByInsertion( model.createPositionFromPath( root, [ 3, 2 ] ), 4, true );
     * // transformed array has two ranges: from [ 2, 7 ] to [ 3, 2 ] and from [ 3, 6 ] to [ 4, 0, 1 ]
     * ```
     *
     * @internal
     * @param insertPosition Position where nodes are inserted.
     * @param howMany How many nodes are inserted.
     * @param spread Flag indicating whether this range should be spread if insertion
     * was inside the range. Defaults to `false`.
     * @returns Result of the transformation.
     */ _getTransformedByInsertion(insertPosition, howMany, spread = false) {
        if (spread && this.containsPosition(insertPosition)) {
            // Range has to be spread. The first part is from original start to the spread point.
            // The other part is from spread point to the original end, but transformed by
            // insertion to reflect insertion changes.
            return [
                new Range(this.start, insertPosition),
                new Range(insertPosition.getShiftedBy(howMany), this.end._getTransformedByInsertion(insertPosition, howMany))
            ];
        } else {
            const range = new Range(this.start, this.end);
            range.start = range.start._getTransformedByInsertion(insertPosition, howMany);
            range.end = range.end._getTransformedByInsertion(insertPosition, howMany);
            return [
                range
            ];
        }
    }
    /**
     * Returns an array containing {@link ~Range ranges} that are a result of transforming this
     * {@link ~Range range} by moving `howMany` nodes from `sourcePosition` to `targetPosition`.
     *
     * @internal
     * @param sourcePosition Position from which nodes are moved.
     * @param targetPosition Position to where nodes are moved.
     * @param howMany How many nodes are moved.
     * @param spread Whether the range should be spread if the move points inside the range.
     * @returns  Result of the transformation.
     */ _getTransformedByMove(sourcePosition, targetPosition, howMany, spread = false) {
        // Special case for transforming a collapsed range. Just transform it like a position.
        if (this.isCollapsed) {
            const newPos = this.start._getTransformedByMove(sourcePosition, targetPosition, howMany);
            return [
                new Range(newPos)
            ];
        }
        // Special case for transformation when a part of the range is moved towards the range.
        //
        // Examples:
        //
        // <div><p>ab</p><p>c[d</p></div><p>e]f</p> --> <div><p>ab</p></div><p>c[d</p><p>e]f</p>
        // <p>e[f</p><div><p>a]b</p><p>cd</p></div> --> <p>e[f</p><p>a]b</p><div><p>cd</p></div>
        //
        // Without this special condition, the default algorithm leaves an "artifact" range from one of `differenceSet` parts:
        //
        // <div><p>ab</p><p>c[d</p></div><p>e]f</p> --> <div><p>ab</p>{</div>}<p>c[d</p><p>e]f</p>
        //
        // This special case is applied only if the range is to be kept together (not spread).
        const moveRange = Range._createFromPositionAndShift(sourcePosition, howMany);
        const insertPosition = targetPosition._getTransformedByDeletion(sourcePosition, howMany);
        if (this.containsPosition(targetPosition) && !spread) {
            if (moveRange.containsPosition(this.start) || moveRange.containsPosition(this.end)) {
                const start = this.start._getTransformedByMove(sourcePosition, targetPosition, howMany);
                const end = this.end._getTransformedByMove(sourcePosition, targetPosition, howMany);
                return [
                    new Range(start, end)
                ];
            }
        }
        // Default algorithm.
        let result;
        const differenceSet = this.getDifference(moveRange);
        let difference = null;
        const common = this.getIntersection(moveRange);
        if (differenceSet.length == 1) {
            // `moveRange` and this range may intersect but may be separate.
            difference = new Range(differenceSet[0].start._getTransformedByDeletion(sourcePosition, howMany), differenceSet[0].end._getTransformedByDeletion(sourcePosition, howMany));
        } else if (differenceSet.length == 2) {
            // `moveRange` is inside this range.
            difference = new Range(this.start, this.end._getTransformedByDeletion(sourcePosition, howMany));
        } // else, `moveRange` contains this range.
        if (difference) {
            result = difference._getTransformedByInsertion(insertPosition, howMany, common !== null || spread);
        } else {
            result = [];
        }
        if (common) {
            const transformedCommon = new Range(common.start._getCombined(moveRange.start, insertPosition), common.end._getCombined(moveRange.start, insertPosition));
            if (result.length == 2) {
                result.splice(1, 0, transformedCommon);
            } else {
                result.push(transformedCommon);
            }
        }
        return result;
    }
    /**
     * Returns a copy of this range that is transformed by deletion of `howMany` nodes from `deletePosition`.
     *
     * If the deleted range is intersecting with the transformed range, the transformed range will be shrank.
     *
     * If the deleted range contains transformed range, `null` will be returned.
     *
     * @internal
     * @param deletionPosition Position from which nodes are removed.
     * @param howMany How many nodes are removed.
     * @returns Result of the transformation.
     */ _getTransformedByDeletion(deletePosition, howMany) {
        let newStart = this.start._getTransformedByDeletion(deletePosition, howMany);
        let newEnd = this.end._getTransformedByDeletion(deletePosition, howMany);
        if (newStart == null && newEnd == null) {
            return null;
        }
        if (newStart == null) {
            newStart = deletePosition;
        }
        if (newEnd == null) {
            newEnd = deletePosition;
        }
        return new Range(newStart, newEnd);
    }
    /**
     * Creates a new range, spreading from specified {@link module:engine/model/position~Position position} to a position moved by
     * given `shift`. If `shift` is a negative value, shifted position is treated as the beginning of the range.
     *
     * @internal
     * @param position Beginning of the range.
     * @param shift How long the range should be.
     */ static _createFromPositionAndShift(position, shift) {
        const start = position;
        const end = position.getShiftedBy(shift);
        return shift > 0 ? new this(start, end) : new this(end, start);
    }
    /**
     * Creates a range inside an {@link module:engine/model/element~Element element} which starts before the first child of
     * that element and ends after the last child of that element.
     *
     * @internal
     * @param element Element which is a parent for the range.
     */ static _createIn(element) {
        return new this(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(element, 0), __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(element, element.maxOffset));
    }
    /**
     * Creates a range that starts before given {@link module:engine/model/item~Item model item} and ends after it.
     *
     * @internal
     */ static _createOn(item) {
        return this._createFromPositionAndShift(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item), item.offsetSize);
    }
    /**
     * Combines all ranges from the passed array into a one range. At least one range has to be passed.
     * Passed ranges must not have common parts.
     *
     * The first range from the array is a reference range. If other ranges start or end on the exactly same position where
     * the reference range, they get combined into one range.
     *
     * ```
     * [  ][]  [    ][ ][             ][ ][]  [  ]  // Passed ranges, shown sorted
     * [    ]                                       // The result of the function if the first range was a reference range.
     *         [                           ]        // The result of the function if the third-to-seventh range was a reference range.
     *                                        [  ]  // The result of the function if the last range was a reference range.
     * ```
     *
     * @internal
     * @param ranges Ranges to combine.
     * @returns Combined range.
     */ static _createFromRanges(ranges) {
        if (ranges.length === 0) {
            /**
             * At least one range has to be passed to
             * {@link module:engine/model/range~Range._createFromRanges `Range._createFromRanges()`}.
             *
             * @error range-create-from-ranges-empty-array
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('range-create-from-ranges-empty-array', null);
        } else if (ranges.length == 1) {
            return ranges[0].clone();
        }
        // 1. Set the first range in `ranges` array as a reference range.
        // If we are going to return just a one range, one of the ranges need to be the reference one.
        // Other ranges will be stuck to that range, if possible.
        const ref = ranges[0];
        // 2. Sort all the ranges so it's easier to process them.
        ranges.sort((a, b)=>{
            return a.start.isAfter(b.start) ? 1 : -1;
        });
        // 3. Check at which index the reference range is now.
        const refIndex = ranges.indexOf(ref);
        // 4. At this moment we don't need the original range.
        // We are going to modify the result and we need to return a new instance of Range.
        // We have to create a copy of the reference range.
        const result = new this(ref.start, ref.end);
        // 5. Ranges should be checked and glued starting from the range that is closest to the reference range.
        // Since ranges are sorted, start with the range with index that is closest to reference range index.
        if (refIndex > 0) {
            // eslint-disable-next-line no-constant-condition
            for(let i = refIndex - 1; true; i++){
                if (ranges[i].end.isEqual(result.start)) {
                    result.start = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(ranges[i].start);
                } else {
                    break;
                }
            }
        }
        // 6. Ranges should be checked and glued starting from the range that is closest to the reference range.
        // Since ranges are sorted, start with the range with index that is closest to reference range index.
        for(let i = refIndex + 1; i < ranges.length; i++){
            if (ranges[i].start.isEqual(result.end)) {
                result.end = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(ranges[i].end);
            } else {
                break;
            }
        }
        return result;
    }
    /**
     * Creates a `Range` instance from given plain object (i.e. parsed JSON string).
     *
     * @param json Plain object to be converted to `Range`.
     * @param doc Document object that will be range owner.
     * @returns `Range` instance created using given plain object.
     */ static fromJSON(json, doc) {
        return new this(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.start, doc), __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.end, doc));
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Range.prototype.is = function(type) {
    return type === 'range' || type === 'model:range';
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/selection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/selection
 */ __turbopack_context__.s([
    "default",
    ()=>Selection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/node.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/isiterable.js [app-ssr] (ecmascript) <export default as isIterable>");
;
;
;
;
;
class Selection extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
    /**
     * Creates a new selection instance based on the given {@link module:engine/model/selection~Selectable selectable}
     * or creates an empty selection if no arguments were passed.
     *
     * ```ts
     * // Creates empty selection without ranges.
     * const selection = writer.createSelection();
     *
     * // Creates selection at the given range.
     * const range = writer.createRange( start, end );
     * const selection = writer.createSelection( range );
     *
     * // Creates selection at the given ranges
     * const ranges = [ writer.createRange( start1, end2 ), writer.createRange( star2, end2 ) ];
     * const selection = writer.createSelection( ranges );
     *
     * // Creates selection from the other selection.
     * // Note: It doesn't copy selection attributes.
     * const otherSelection = writer.createSelection();
     * const selection = writer.createSelection( otherSelection );
     *
     * // Creates selection from the given document selection.
     * // Note: It doesn't copy selection attributes.
     * const documentSelection = model.document.selection;
     * const selection = writer.createSelection( documentSelection );
     *
     * // Creates selection at the given position.
     * const position = writer.createPositionFromPath( root, path );
     * const selection = writer.createSelection( position );
     *
     * // Creates selection at the given offset in the given element.
     * const paragraph = writer.createElement( 'paragraph' );
     * const selection = writer.createSelection( paragraph, offset );
     *
     * // Creates a range inside an {@link module:engine/model/element~Element element} which starts before the
     * // first child of that element and ends after the last child of that element.
     * const selection = writer.createSelection( paragraph, 'in' );
     *
     * // Creates a range on an {@link module:engine/model/item~Item item} which starts before the item and ends
     * // just after the item.
     * const selection = writer.createSelection( paragraph, 'on' );
     * ```
     *
     * Selection's constructor allow passing additional options (`'backward'`) as the last argument.
     *
     * ```ts
     * // Creates backward selection.
     * const selection = writer.createSelection( range, { backward: true } );
     * ```
     *
     * @internal
     */ constructor(...args){
        super();
        /**
         * Specifies whether the last added range was added as a backward or forward range.
         */ this._lastRangeBackward = false;
        /**
         * List of attributes set on current selection.
         */ this._attrs = new Map();
        /** @internal */ this._ranges = [];
        if (args.length) {
            this.setTo(...args);
        }
    }
    /**
     * Selection anchor. Anchor is the position from which the selection was started. If a user is making a selection
     * by dragging the mouse, the anchor is where the user pressed the mouse button (the beginning of the selection).
     *
     * Anchor and {@link #focus} define the direction of the selection, which is important
     * when expanding/shrinking selection. The focus moves, while the anchor should remain in the same place.
     *
     * Anchor is always set to the {@link module:engine/model/range~Range#start start} or
     * {@link module:engine/model/range~Range#end end} position of the last of selection's ranges. Whether it is
     * the `start` or `end` depends on the specified `options.backward`. See the {@link #setTo `setTo()`} method.
     *
     * May be set to `null` if there are no ranges in the selection.
     *
     * @see #focus
     */ get anchor() {
        if (this._ranges.length > 0) {
            const range = this._ranges[this._ranges.length - 1];
            return this._lastRangeBackward ? range.end : range.start;
        }
        return null;
    }
    /**
     * Selection focus. Focus is the position where the selection ends. If a user is making a selection
     * by dragging the mouse, the focus is where the mouse cursor is.
     *
     * May be set to `null` if there are no ranges in the selection.
     *
     * @see #anchor
     */ get focus() {
        if (this._ranges.length > 0) {
            const range = this._ranges[this._ranges.length - 1];
            return this._lastRangeBackward ? range.start : range.end;
        }
        return null;
    }
    /**
     * Whether the selection is collapsed. Selection is collapsed when there is exactly one range in it
     * and it is collapsed.
     */ get isCollapsed() {
        const length = this._ranges.length;
        if (length === 1) {
            return this._ranges[0].isCollapsed;
        } else {
            return false;
        }
    }
    /**
     * Returns the number of ranges in the selection.
     */ get rangeCount() {
        return this._ranges.length;
    }
    /**
     * Specifies whether the selection's {@link #focus} precedes the selection's {@link #anchor}.
     */ get isBackward() {
        return !this.isCollapsed && this._lastRangeBackward;
    }
    /**
     * Checks whether this selection is equal to the given selection. Selections are equal if they have the same directions,
     * the same number of ranges and all ranges from one selection equal to ranges from the another selection.
     *
     * @param otherSelection Selection to compare with.
     * @returns `true` if selections are equal, `false` otherwise.
     */ isEqual(otherSelection) {
        if (this.rangeCount != otherSelection.rangeCount) {
            return false;
        } else if (this.rangeCount === 0) {
            return true;
        }
        if (!this.anchor.isEqual(otherSelection.anchor) || !this.focus.isEqual(otherSelection.focus)) {
            return false;
        }
        for (const thisRange of this._ranges){
            let found = false;
            for (const otherRange of otherSelection._ranges){
                if (thisRange.isEqual(otherRange)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }
    /**
     * Returns an iterable object that iterates over copies of selection ranges.
     */ *getRanges() {
        for (const range of this._ranges){
            yield new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range.start, range.end);
        }
    }
    /**
     * Returns a copy of the first range in the selection.
     * First range is the one which {@link module:engine/model/range~Range#start start} position
     * {@link module:engine/model/position~Position#isBefore is before} start position of all other ranges
     * (not to confuse with the first range added to the selection).
     *
     * Returns `null` if there are no ranges in selection.
     */ getFirstRange() {
        let first = null;
        for (const range of this._ranges){
            if (!first || range.start.isBefore(first.start)) {
                first = range;
            }
        }
        return first ? new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](first.start, first.end) : null;
    }
    /**
     * Returns a copy of the last range in the selection.
     * Last range is the one which {@link module:engine/model/range~Range#end end} position
     * {@link module:engine/model/position~Position#isAfter is after} end position of all other ranges (not to confuse with the range most
     * recently added to the selection).
     *
     * Returns `null` if there are no ranges in selection.
     */ getLastRange() {
        let last = null;
        for (const range of this._ranges){
            if (!last || range.end.isAfter(last.end)) {
                last = range;
            }
        }
        return last ? new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](last.start, last.end) : null;
    }
    /**
     * Returns the first position in the selection.
     * First position is the position that {@link module:engine/model/position~Position#isBefore is before}
     * any other position in the selection.
     *
     * Returns `null` if there are no ranges in selection.
     */ getFirstPosition() {
        const first = this.getFirstRange();
        return first ? first.start.clone() : null;
    }
    /**
     * Returns the last position in the selection.
     * Last position is the position that {@link module:engine/model/position~Position#isAfter is after}
     * any other position in the selection.
     *
     * Returns `null` if there are no ranges in selection.
     */ getLastPosition() {
        const lastRange = this.getLastRange();
        return lastRange ? lastRange.end.clone() : null;
    }
    /**
     * Sets this selection's ranges and direction to the specified location based on the given
     * {@link module:engine/model/selection~Selectable selectable}.
     *
     * ```ts
     * // Removes all selection's ranges.
     * selection.setTo( null );
     *
     * // Sets selection to the given range.
     * const range = writer.createRange( start, end );
     * selection.setTo( range );
     *
     * // Sets selection to given ranges.
     * const ranges = [ writer.createRange( start1, end2 ), writer.createRange( star2, end2 ) ];
     * selection.setTo( ranges );
     *
     * // Sets selection to other selection.
     * // Note: It doesn't copy selection attributes.
     * const otherSelection = writer.createSelection();
     * selection.setTo( otherSelection );
     *
     * // Sets selection to the given document selection.
     * // Note: It doesn't copy selection attributes.
     * const documentSelection = new DocumentSelection( doc );
     * selection.setTo( documentSelection );
     *
     * // Sets collapsed selection at the given position.
     * const position = writer.createPositionFromPath( root, path );
     * selection.setTo( position );
     *
     * // Sets collapsed selection at the position of the given node and an offset.
     * selection.setTo( paragraph, offset );
     * ```
     *
     * Creates a range inside an {@link module:engine/model/element~Element element} which starts before the first child of
     * that element and ends after the last child of that element.
     *
     * ```ts
     * selection.setTo( paragraph, 'in' );
     * ```
     *
     * Creates a range on an {@link module:engine/model/item~Item item} which starts before the item and ends just after the item.
     *
     * ```ts
     * selection.setTo( paragraph, 'on' );
     * ```
     *
     * `Selection#setTo()`' method allow passing additional options (`backward`) as the last argument.
     *
     * ```ts
     * // Sets backward selection.
     * const selection = writer.createSelection( range, { backward: true } );
     * ```
     */ setTo(...args) {
        let [selectable, placeOrOffset, options] = args;
        if (typeof placeOrOffset == 'object') {
            options = placeOrOffset;
            placeOrOffset = undefined;
        }
        if (selectable === null) {
            this._setRanges([]);
        } else if (selectable instanceof Selection) {
            this._setRanges(selectable.getRanges(), selectable.isBackward);
        } else if (selectable && typeof selectable.getRanges == 'function') {
            // We assume that the selectable is a DocumentSelection.
            // It can't be imported here, because it would lead to circular imports.
            this._setRanges(selectable.getRanges(), selectable.isBackward);
        } else if (selectable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            this._setRanges([
                selectable
            ], !!options && !!options.backward);
        } else if (selectable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            this._setRanges([
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selectable)
            ]);
        } else if (selectable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            const backward = !!options && !!options.backward;
            let range;
            if (placeOrOffset == 'in') {
                range = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(selectable);
            } else if (placeOrOffset == 'on') {
                range = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(selectable);
            } else if (placeOrOffset !== undefined) {
                range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(selectable, placeOrOffset));
            } else {
                /**
                 * selection.setTo requires the second parameter when the first parameter is a node.
                 *
                 * @error model-selection-setto-required-second-parameter
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-selection-setto-required-second-parameter', [
                    this,
                    selectable
                ]);
            }
            this._setRanges([
                range
            ], backward);
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__["isIterable"])(selectable)) {
            // We assume that the selectable is an iterable of ranges.
            this._setRanges(selectable, options && !!options.backward);
        } else {
            /**
             * Cannot set the selection to the given place.
             *
             * Invalid parameters were specified when setting the selection. Common issues:
             *
             * * A {@link module:engine/model/textproxy~TextProxy} instance was passed instead of
             * a real {@link module:engine/model/text~Text}.
             * * View nodes were passed instead of model nodes.
             * * `null`/`undefined` was passed.
             *
             * @error model-selection-setto-not-selectable
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-selection-setto-not-selectable', [
                this,
                selectable
            ]);
        }
    }
    /**
     * Replaces all ranges that were added to the selection with given array of ranges. Last range of the array
     * is treated like the last added range and is used to set {@link module:engine/model/selection~Selection#anchor} and
     * {@link module:engine/model/selection~Selection#focus}. Accepts a flag describing in which direction the selection is made.
     *
     * @fires change:range
     * @param newRanges Ranges to set.
     * @param isLastBackward Flag describing if last added range was selected forward - from start to end (`false`)
     * or backward - from end to start (`true`).
     */ _setRanges(newRanges, isLastBackward = false) {
        const ranges = Array.from(newRanges);
        // Check whether there is any range in new ranges set that is different than all already added ranges.
        const anyNewRange = ranges.some((newRange)=>{
            if (!(newRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
                /**
                 * Selection range set to an object that is not an instance of {@link module:engine/model/range~Range}.
                 *
                 * Only {@link module:engine/model/range~Range} instances can be used to set a selection.
                 * Common mistakes leading to this error are:
                 *
                 * * using DOM `Range` object,
                 * * incorrect CKEditor 5 installation with multiple `ckeditor5-engine` packages having different versions.
                 *
                 * @error model-selection-set-ranges-not-range
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-selection-set-ranges-not-range', [
                    this,
                    newRanges
                ]);
            }
            return this._ranges.every((oldRange)=>{
                return !oldRange.isEqual(newRange);
            });
        });
        // Don't do anything if nothing changed.
        if (ranges.length === this._ranges.length && !anyNewRange) {
            return;
        }
        this._replaceAllRanges(ranges);
        this._lastRangeBackward = !!isLastBackward;
        this.fire('change:range', {
            directChange: true
        });
    }
    /**
     * Moves {@link module:engine/model/selection~Selection#focus} to the specified location.
     *
     * The location can be specified in the same form as
     * {@link module:engine/model/writer~Writer#createPositionAt writer.createPositionAt()} parameters.
     *
     * @fires change:range
     * @param offset Offset or one of the flags. Used only when first parameter is a {@link module:engine/model/item~Item model item}.
     */ setFocus(itemOrPosition, offset) {
        if (this.anchor === null) {
            /**
             * Cannot set selection focus if there are no ranges in selection.
             *
             * @error model-selection-setfocus-no-ranges
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-selection-setfocus-no-ranges', [
                this,
                itemOrPosition
            ]);
        }
        const newFocus = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(itemOrPosition, offset);
        if (newFocus.compareWith(this.focus) == 'same') {
            return;
        }
        const anchor = this.anchor;
        if (this._ranges.length) {
            this._popRange();
        }
        if (newFocus.compareWith(anchor) == 'before') {
            this._pushRange(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](newFocus, anchor));
            this._lastRangeBackward = true;
        } else {
            this._pushRange(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](anchor, newFocus));
            this._lastRangeBackward = false;
        }
        this.fire('change:range', {
            directChange: true
        });
    }
    /**
     * Gets an attribute value for given key or `undefined` if that attribute is not set on the selection.
     *
     * @param key Key of attribute to look for.
     * @returns Attribute value or `undefined`.
     */ getAttribute(key) {
        return this._attrs.get(key);
    }
    /**
     * Returns iterable that iterates over this selection's attributes.
     *
     * Attributes are returned as arrays containing two items. First one is attribute key and second is attribute value.
     * This format is accepted by native `Map` object and also can be passed in `Node` constructor.
     */ getAttributes() {
        return this._attrs.entries();
    }
    /**
     * Returns iterable that iterates over this selection's attribute keys.
     */ getAttributeKeys() {
        return this._attrs.keys();
    }
    /**
     * Checks if the selection has an attribute for given key.
     *
     * @param key Key of attribute to check.
     * @returns `true` if attribute with given key is set on selection, `false` otherwise.
     */ hasAttribute(key) {
        return this._attrs.has(key);
    }
    /**
     * Removes an attribute with given key from the selection.
     *
     * If given attribute was set on the selection, fires the {@link #event:change:range} event with
     * removed attribute key.
     *
     * @fires change:attribute
     * @param key Key of attribute to remove.
     */ removeAttribute(key) {
        if (this.hasAttribute(key)) {
            this._attrs.delete(key);
            this.fire('change:attribute', {
                attributeKeys: [
                    key
                ],
                directChange: true
            });
        }
    }
    /**
     * Sets attribute on the selection. If attribute with the same key already is set, it's value is overwritten.
     *
     * If the attribute value has changed, fires the {@link #event:change:range} event with
     * the attribute key.
     *
     * @fires change:attribute
     * @param key Key of attribute to set.
     * @param value Attribute value.
     */ setAttribute(key, value) {
        if (this.getAttribute(key) !== value) {
            this._attrs.set(key, value);
            this.fire('change:attribute', {
                attributeKeys: [
                    key
                ],
                directChange: true
            });
        }
    }
    /**
     * Returns the selected element. {@link module:engine/model/element~Element Element} is considered as selected if there is only
     * one range in the selection, and that range contains exactly one element.
     * Returns `null` if there is no selected element.
     */ getSelectedElement() {
        if (this.rangeCount !== 1) {
            return null;
        }
        return this.getFirstRange().getContainedElement();
    }
    /**
     * Gets elements of type {@link module:engine/model/schema~Schema#isBlock "block"} touched by the selection.
     *
     * This method's result can be used for example to apply block styling to all blocks covered by this selection.
     *
     * **Note:** `getSelectedBlocks()` returns blocks that are nested in other non-block elements
     * but will not return blocks nested in other blocks.
     *
     * In this case the function will return exactly all 3 paragraphs (note: `<blockQuote>` is not a block itself):
     *
     * ```xml
     * <paragraph>[a</paragraph>
     * <blockQuote>
     * 	<paragraph>b</paragraph>
     * </blockQuote>
     * <paragraph>c]d</paragraph>
     * ```
     *
     * In this case the paragraph will also be returned, despite the collapsed selection:
     *
     * ```xml
     * <paragraph>[]a</paragraph>
     * ```
     *
     * In such a scenario, however, only blocks A, B & E will be returned as blocks C & D are nested in block B:
     *
     * ```xml
     * [<blockA></blockA>
     * <blockB>
     * 	<blockC></blockC>
     * 	<blockD></blockD>
     * </blockB>
     * <blockE></blockE>]
     * ```
     *
     * If the selection is inside a block all the inner blocks (A & B) are returned:
     *
     * ```xml
     * <block>
     * 	<blockA>[a</blockA>
     * 	<blockB>b]</blockB>
     * </block>
     * ```
     *
     * **Special case**: Selection ignores first and/or last blocks if nothing (from user perspective) is selected in them.
     *
     * ```xml
     * // Selection ends and the beginning of the last block.
     * <paragraph>[a</paragraph>
     * <paragraph>b</paragraph>
     * <paragraph>]c</paragraph> // This block will not be returned
     *
     * // Selection begins at the end of the first block.
     * <paragraph>a[</paragraph> // This block will not be returned
     * <paragraph>b</paragraph>
     * <paragraph>c]</paragraph>
     *
     * // Selection begings at the end of the first block and ends at the beginning of the last block.
     * <paragraph>a[</paragraph> // This block will not be returned
     * <paragraph>b</paragraph>
     * <paragraph>]c</paragraph> // This block will not be returned
     * ```
     */ *getSelectedBlocks() {
        const visited = new WeakSet();
        for (const range of this.getRanges()){
            // Get start block of range in case of a collapsed range.
            const startBlock = getParentBlock(range.start, visited);
            if (isStartBlockSelected(startBlock, range)) {
                yield startBlock;
            }
            for (const value of range.getWalker()){
                const block = value.item;
                if (value.type == 'elementEnd' && isUnvisitedTopBlock(block, visited, range)) {
                    yield block;
                }
            }
            const endBlock = getParentBlock(range.end, visited);
            if (isEndBlockSelected(endBlock, range)) {
                yield endBlock;
            }
        }
    }
    /**
     * Checks whether the selection contains the entire content of the given element. This means that selection must start
     * at a position {@link module:engine/model/position~Position#isTouching touching} the element's start and ends at position
     * touching the element's end.
     *
     * By default, this method will check whether the entire content of the selection's current root is selected.
     * Useful to check if e.g. the user has just pressed <kbd>Ctrl</kbd> + <kbd>A</kbd>.
     */ containsEntireContent(element = this.anchor.root) {
        const limitStartPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(element, 0);
        const limitEndPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(element, 'end');
        return limitStartPosition.isTouching(this.getFirstPosition()) && limitEndPosition.isTouching(this.getLastPosition());
    }
    /**
     * Adds given range to internal {@link #_ranges ranges array}. Throws an error
     * if given range is intersecting with any range that is already stored in this selection.
     */ _pushRange(range) {
        this._checkRange(range);
        this._ranges.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range.start, range.end));
    }
    /**
     * Checks if given range intersects with ranges that are already in the selection. Throws an error if it does.
     */ _checkRange(range) {
        for(let i = 0; i < this._ranges.length; i++){
            if (range.isIntersecting(this._ranges[i])) {
                /**
                 * Trying to add a range that intersects with another range in the selection.
                 *
                 * @error model-selection-range-intersects
                 * @param addedRange Range that was added to the selection.
                 * @param intersectingRange Range in the selection that intersects with `addedRange`.
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-selection-range-intersects', [
                    this,
                    range
                ], {
                    addedRange: range,
                    intersectingRange: this._ranges[i]
                });
            }
        }
    }
    /**
     * Replaces all the ranges by the given ones.
     * Uses {@link #_popRange _popRange} and {@link #_pushRange _pushRange} to ensure proper ranges removal and addition.
     */ _replaceAllRanges(ranges) {
        this._removeAllRanges();
        for (const range of ranges){
            this._pushRange(range);
        }
    }
    /**
     * Deletes ranges from internal range array. Uses {@link #_popRange _popRange} to
     * ensure proper ranges removal.
     */ _removeAllRanges() {
        while(this._ranges.length > 0){
            this._popRange();
        }
    }
    /**
     * Removes most recently added range from the selection.
     */ _popRange() {
        this._ranges.pop();
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Selection.prototype.is = function(type) {
    return type === 'selection' || type === 'model:selection';
};
/**
 * Checks whether the given element extends $block in the schema and has a parent (is not a root).
 * Marks it as already visited.
 */ function isUnvisitedBlock(element, visited) {
    if (visited.has(element)) {
        return false;
    }
    visited.add(element);
    return element.root.document.model.schema.isBlock(element) && !!element.parent;
}
/**
 * Checks if the given element is a $block was not previously visited and is a top block in a range.
 */ function isUnvisitedTopBlock(element, visited, range) {
    return isUnvisitedBlock(element, visited) && isTopBlockInRange(element, range);
}
/**
 * Finds the lowest element in position's ancestors which is a block.
 * It will search until first ancestor that is a limit element.
 * Marks all ancestors as already visited to not include any of them later on.
 */ function getParentBlock(position, visited) {
    const element = position.parent;
    const schema = element.root.document.model.schema;
    const ancestors = position.parent.getAncestors({
        parentFirst: true,
        includeSelf: true
    });
    let hasParentLimit = false;
    const block = ancestors.find((element)=>{
        // Stop searching after first parent node that is limit element.
        if (hasParentLimit) {
            return false;
        }
        hasParentLimit = schema.isLimit(element);
        return !hasParentLimit && isUnvisitedBlock(element, visited);
    });
    // Mark all ancestors of this position's parent, because find() might've stopped early and
    // the found block may be a child of another block.
    ancestors.forEach((element)=>visited.add(element));
    return block;
}
/**
 * Checks if the blocks is not nested in other block inside a range.
 */ function isTopBlockInRange(block, range) {
    const parentBlock = findAncestorBlock(block);
    if (!parentBlock) {
        return true;
    }
    // Add loose flag to check as parentRange can be equal to range.
    const isParentInRange = range.containsRange(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(parentBlock), true);
    return !isParentInRange;
}
/**
 * If a selection starts at the end of a block, that block is not returned as from the user's perspective this block wasn't selected.
 * See [#11585](https://github.com/ckeditor/ckeditor5/issues/11585) for more details.
 *
 * ```xml
 * <paragraph>a[</paragraph> // This block will not be returned
 * <paragraph>b</paragraph>
 * <paragraph>c]</paragraph>
 * ```
 *
 * Collapsed selection is not affected by it:
 *
 * ```xml
 * <paragraph>a[]</paragraph> // This block will be returned
 * ```
 */ function isStartBlockSelected(startBlock, range) {
    if (!startBlock) {
        return false;
    }
    if (range.isCollapsed || startBlock.isEmpty) {
        return true;
    }
    if (range.start.isTouching(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(startBlock, startBlock.maxOffset))) {
        return false;
    }
    return isTopBlockInRange(startBlock, range);
}
/**
 * If a selection ends at the beginning of a block, that block is not returned as from the user's perspective this block wasn't selected.
 * See [#984](https://github.com/ckeditor/ckeditor5-engine/issues/984) for more details.
 *
 * ```xml
 * <paragraph>[a</paragraph>
 * <paragraph>b</paragraph>
 * <paragraph>]c</paragraph> // this block will not be returned
 * ```
 *
 * Collapsed selection is not affected by it:
 *
 * ```xml
 * <paragraph>[]a</paragraph> // this block will be returned
 * ```
 */ function isEndBlockSelected(endBlock, range) {
    if (!endBlock) {
        return false;
    }
    if (range.isCollapsed || endBlock.isEmpty) {
        return true;
    }
    if (range.end.isTouching(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(endBlock, 0))) {
        return false;
    }
    return isTopBlockInRange(endBlock, range);
}
/**
 * Returns first ancestor block of a node.
 */ function findAncestorBlock(node) {
    const schema = node.root.document.model.schema;
    let parent = node.parent;
    while(parent){
        if (schema.isBlock(parent)) {
            return parent;
        }
        parent = parent.parent;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liverange.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/liverange
 */ __turbopack_context__.s([
    "default",
    ()=>LiveRange
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
;
;
class LiveRange extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
    /**
     * Creates a live range.
     *
     * @see module:engine/model/range~Range
     */ constructor(start, end){
        super(start, end);
        bindWithDocument.call(this);
    }
    /**
     * Unbinds all events previously bound by `LiveRange`. Use it whenever you don't need `LiveRange` instance
     * anymore (i.e. when leaving scope in which it was declared or before re-assigning variable that was
     * referring to it).
     */ detach() {
        this.stopListening();
    }
    /**
     * Creates a {@link module:engine/model/range~Range range instance} that is equal to this live range.
     */ toRange() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.start, this.end);
    }
    /**
     * Creates a `LiveRange` instance that is equal to the given range.
     */ static fromRange(range) {
        return new LiveRange(range.start, range.end);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
LiveRange.prototype.is = function(type) {
    return type === 'liveRange' || type === 'model:liveRange' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
    type == 'range' || type === 'model:range';
};
/**
 * Binds this `LiveRange` to the {@link module:engine/model/document~Document document}
 * that owns this range's {@link module:engine/model/range~Range#root root}.
 */ function bindWithDocument() {
    this.listenTo(this.root.document.model, 'applyOperation', (event, args)=>{
        const operation = args[0];
        if (!operation.isDocumentOperation) {
            return;
        }
        transform.call(this, operation);
    }, {
        priority: 'low'
    });
}
/**
 * Updates this range accordingly to the updates applied to the model. Bases on change events.
 */ function transform(operation) {
    // Transform the range by the operation. Join the result ranges if needed.
    const ranges = this.getTransformedByOperation(operation);
    const result = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromRanges(ranges);
    const boundariesChanged = !result.isEqual(this);
    const contentChanged = doesOperationChangeRangeContent(this, operation);
    let deletionPosition = null;
    if (boundariesChanged) {
        // If range boundaries have changed, fire `change:range` event.
        //
        if (result.root.rootName == '$graveyard') {
            // If the range was moved to the graveyard root, set `deletionPosition`.
            if (operation.type == 'remove') {
                deletionPosition = operation.sourcePosition;
            } else {
                // Merge operation.
                deletionPosition = operation.deletionPosition;
            }
        }
        const oldRange = this.toRange();
        this.start = result.start;
        this.end = result.end;
        this.fire('change:range', oldRange, {
            deletionPosition
        });
    } else if (contentChanged) {
        // If range boundaries have not changed, but there was change inside the range, fire `change:content` event.
        this.fire('change:content', this.toRange(), {
            deletionPosition
        });
    }
}
/**
 * Checks whether given operation changes something inside the range (even if it does not change boundaries).
 */ function doesOperationChangeRangeContent(range, operation) {
    switch(operation.type){
        case 'insert':
            return range.containsPosition(operation.position);
        case 'move':
        case 'remove':
        case 'reinsert':
        case 'merge':
            return range.containsPosition(operation.sourcePosition) || range.start.isEqual(operation.sourcePosition) || range.containsPosition(operation.targetPosition);
        case 'split':
            return range.containsPosition(operation.splitPosition) || range.containsPosition(operation.insertionPosition);
    }
    return false;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/documentselection
 */ __turbopack_context__.s([
    "default",
    ()=>DocumentSelection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liverange.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/selection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/textproxy.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$collection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Collection$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/collection.js [app-ssr] (ecmascript) <export default as Collection>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/tomap.js [app-ssr] (ecmascript) <export default as toMap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$uid$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__uid$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/uid.js [app-ssr] (ecmascript) <export default as uid>");
;
;
;
;
;
;
const storePrefix = 'selection:';
class DocumentSelection extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
    /**
     * Creates an empty live selection for given {@link module:engine/model/document~Document}.
     *
     * @param doc Document which owns this selection.
     */ constructor(doc){
        super();
        this._selection = new LiveSelection(doc);
        this._selection.delegate('change:range').to(this);
        this._selection.delegate('change:attribute').to(this);
        this._selection.delegate('change:marker').to(this);
    }
    /**
     * Describes whether the selection is collapsed. Selection is collapsed when there is exactly one range which is
     * collapsed.
     */ get isCollapsed() {
        return this._selection.isCollapsed;
    }
    /**
     * Selection anchor. Anchor may be described as a position where the most recent part of the selection starts.
     * Together with {@link #focus} they define the direction of selection, which is important
     * when expanding/shrinking selection. Anchor is always {@link module:engine/model/range~Range#start start} or
     * {@link module:engine/model/range~Range#end end} position of the most recently added range.
     *
     * Is set to `null` if there are no ranges in selection.
     *
     * @see #focus
     */ get anchor() {
        return this._selection.anchor;
    }
    /**
     * Selection focus. Focus is a position where the selection ends.
     *
     * Is set to `null` if there are no ranges in selection.
     *
     * @see #anchor
     */ get focus() {
        return this._selection.focus;
    }
    /**
     * Number of ranges in selection.
     */ get rangeCount() {
        return this._selection.rangeCount;
    }
    /**
     * Describes whether `Documentselection` has own range(s) set, or if it is defaulted to
     * {@link module:engine/model/document~Document#_getDefaultRange document's default range}.
     */ get hasOwnRange() {
        return this._selection.hasOwnRange;
    }
    /**
     * Specifies whether the {@link #focus}
     * precedes {@link #anchor}.
     *
     * @readonly
     * @type {Boolean}
     */ get isBackward() {
        return this._selection.isBackward;
    }
    /**
     * Describes whether the gravity is overridden (using {@link module:engine/model/writer~Writer#overrideSelectionGravity}) or not.
     *
     * Note that the gravity remains overridden as long as will not be restored the same number of times as it was overridden.
     */ get isGravityOverridden() {
        return this._selection.isGravityOverridden;
    }
    /**
     * A collection of selection {@link module:engine/model/markercollection~Marker markers}.
     * Marker is a selection marker when selection range is inside the marker range.
     *
     * **Note**: Only markers from {@link ~DocumentSelection#observeMarkers observed markers groups} are collected.
     */ get markers() {
        return this._selection.markers;
    }
    /**
     * Used for the compatibility with the {@link module:engine/model/selection~Selection#isEqual} method.
     *
     * @internal
     */ get _ranges() {
        return this._selection._ranges;
    }
    /**
     * Returns an iterable that iterates over copies of selection ranges.
     */ getRanges() {
        return this._selection.getRanges();
    }
    /**
     * Returns the first position in the selection.
     * First position is the position that {@link module:engine/model/position~Position#isBefore is before}
     * any other position in the selection.
     *
     * Returns `null` if there are no ranges in selection.
     */ getFirstPosition() {
        return this._selection.getFirstPosition();
    }
    /**
     * Returns the last position in the selection.
     * Last position is the position that {@link module:engine/model/position~Position#isAfter is after}
     * any other position in the selection.
     *
     * Returns `null` if there are no ranges in selection.
     */ getLastPosition() {
        return this._selection.getLastPosition();
    }
    /**
     * Returns a copy of the first range in the selection.
     * First range is the one which {@link module:engine/model/range~Range#start start} position
     * {@link module:engine/model/position~Position#isBefore is before} start position of all other ranges
     * (not to confuse with the first range added to the selection).
     *
     * Returns `null` if there are no ranges in selection.
     */ getFirstRange() {
        return this._selection.getFirstRange();
    }
    /**
     * Returns a copy of the last range in the selection.
     * Last range is the one which {@link module:engine/model/range~Range#end end} position
     * {@link module:engine/model/position~Position#isAfter is after} end position of all other ranges (not to confuse with the range most
     * recently added to the selection).
     *
     * Returns `null` if there are no ranges in selection.
     */ getLastRange() {
        return this._selection.getLastRange();
    }
    /**
     * Gets elements of type {@link module:engine/model/schema~Schema#isBlock "block"} touched by the selection.
     *
     * This method's result can be used for example to apply block styling to all blocks covered by this selection.
     *
     * **Note:** `getSelectedBlocks()` returns blocks that are nested in other non-block elements
     * but will not return blocks nested in other blocks.
     *
     * In this case the function will return exactly all 3 paragraphs (note: `<blockQuote>` is not a block itself):
     *
     * ```
     * <paragraph>[a</paragraph>
     * <blockQuote>
     * 	<paragraph>b</paragraph>
     * </blockQuote>
     * <paragraph>c]d</paragraph>
     * ```
     *
     * In this case the paragraph will also be returned, despite the collapsed selection:
     *
     * ```
     * <paragraph>[]a</paragraph>
     * ```
     *
     * In such a scenario, however, only blocks A, B & E will be returned as blocks C & D are nested in block B:
     *
     * ```
     * [<blockA></blockA>
     * <blockB>
     * 	<blockC></blockC>
     * 	<blockD></blockD>
     * </blockB>
     * <blockE></blockE>]
     * ```
     *
     * If the selection is inside a block all the inner blocks (A & B) are returned:
     *
     * ```
     * <block>
     * 	<blockA>[a</blockA>
     * 	<blockB>b]</blockB>
     * </block>
     * ```
     *
     * **Special case**: If a selection ends at the beginning of a block, that block is not returned as from user perspective
     * this block wasn't selected. See [#984](https://github.com/ckeditor/ckeditor5-engine/issues/984) for more details.
     *
     * ```
     * <paragraph>[a</paragraph>
     * <paragraph>b</paragraph>
     * <paragraph>]c</paragraph> // this block will not be returned
     * ```
     */ getSelectedBlocks() {
        return this._selection.getSelectedBlocks();
    }
    /**
     * Returns the selected element. {@link module:engine/model/element~Element Element} is considered as selected if there is only
     * one range in the selection, and that range contains exactly one element.
     * Returns `null` if there is no selected element.
     */ getSelectedElement() {
        return this._selection.getSelectedElement();
    }
    /**
     * Checks whether the selection contains the entire content of the given element. This means that selection must start
     * at a position {@link module:engine/model/position~Position#isTouching touching} the element's start and ends at position
     * touching the element's end.
     *
     * By default, this method will check whether the entire content of the selection's current root is selected.
     * Useful to check if e.g. the user has just pressed <kbd>Ctrl</kbd> + <kbd>A</kbd>.
     */ containsEntireContent(element) {
        return this._selection.containsEntireContent(element);
    }
    /**
     * Unbinds all events previously bound by document selection.
     */ destroy() {
        this._selection.destroy();
    }
    /**
     * Returns iterable that iterates over this selection's attribute keys.
     */ getAttributeKeys() {
        return this._selection.getAttributeKeys();
    }
    /**
     * Returns iterable that iterates over this selection's attributes.
     *
     * Attributes are returned as arrays containing two items. First one is attribute key and second is attribute value.
     * This format is accepted by native `Map` object and also can be passed in `Node` constructor.
     */ getAttributes() {
        return this._selection.getAttributes();
    }
    /**
     * Gets an attribute value for given key or `undefined` if that attribute is not set on the selection.
     *
     * @param key Key of attribute to look for.
     * @returns Attribute value or `undefined`.
     */ getAttribute(key) {
        return this._selection.getAttribute(key);
    }
    /**
     * Checks if the selection has an attribute for given key.
     *
     * @param key Key of attribute to check.
     * @returns `true` if attribute with given key is set on selection, `false` otherwise.
     */ hasAttribute(key) {
        return this._selection.hasAttribute(key);
    }
    /**
     * Refreshes selection attributes and markers according to the current position in the model.
     */ refresh() {
        this._selection.updateMarkers();
        this._selection._updateAttributes(false);
    }
    /**
     * Registers a marker group prefix or a marker name to be collected in the
     * {@link ~DocumentSelection#markers selection markers collection}.
     *
     * See also {@link module:engine/model/markercollection~MarkerCollection#getMarkersGroup `MarkerCollection#getMarkersGroup()`}.
     *
     * @param prefixOrName The marker group prefix or marker name.
     */ observeMarkers(prefixOrName) {
        this._selection.observeMarkers(prefixOrName);
    }
    /**
     * Moves {@link module:engine/model/documentselection~DocumentSelection#focus} to the specified location.
     * Should be used only within the {@link module:engine/model/writer~Writer#setSelectionFocus} method.
     *
     * The location can be specified in the same form as
     * {@link module:engine/model/writer~Writer#createPositionAt writer.createPositionAt()} parameters.
     *
     * @see module:engine/model/writer~Writer#setSelectionFocus
     * @internal
     * @param offset Offset or one of the flags. Used only when
     * first parameter is a {@link module:engine/model/item~Item model item}.
     */ _setFocus(itemOrPosition, offset) {
        this._selection.setFocus(itemOrPosition, offset);
    }
    /**
     * Sets this selection's ranges and direction to the specified location based on the given
     * {@link module:engine/model/selection~Selectable selectable}.
     * Should be used only within the {@link module:engine/model/writer~Writer#setSelection} method.
     *
     * @see module:engine/model/writer~Writer#setSelection
     * @internal
     */ _setTo(...args) {
        this._selection.setTo(...args);
    }
    /**
     * Sets attribute on the selection. If attribute with the same key already is set, it's value is overwritten.
     * Should be used only within the {@link module:engine/model/writer~Writer#setSelectionAttribute} method.
     *
     * @see module:engine/model/writer~Writer#setSelectionAttribute
     * @internal
     * @param key Key of the attribute to set.
     * @param value Attribute value.
     */ _setAttribute(key, value) {
        this._selection.setAttribute(key, value);
    }
    /**
     * Removes an attribute with given key from the selection.
     * If the given attribute was set on the selection, fires the {@link module:engine/model/selection~Selection#event:change:range}
     * event with removed attribute key.
     * Should be used only within the {@link module:engine/model/writer~Writer#removeSelectionAttribute} method.
     *
     * @see module:engine/model/writer~Writer#removeSelectionAttribute
     * @internal
     * @param key Key of the attribute to remove.
     */ _removeAttribute(key) {
        this._selection.removeAttribute(key);
    }
    /**
     * Returns an iterable that iterates through all selection attributes stored in current selection's parent.
     *
     * @internal
     */ _getStoredAttributes() {
        return this._selection.getStoredAttributes();
    }
    /**
     * Temporarily changes the gravity of the selection from the left to the right.
     *
     * The gravity defines from which direction the selection inherits its attributes. If it's the default left
     * gravity, the selection (after being moved by the the user) inherits attributes from its left hand side.
     * This method allows to temporarily override this behavior by forcing the gravity to the right.
     *
     * It returns an unique identifier which is required to restore the gravity. It guarantees the symmetry
     * of the process.
     *
     * @see module:engine/model/writer~Writer#overrideSelectionGravity
     * @internal
     * @returns The unique id which allows restoring the gravity.
     */ _overrideGravity() {
        return this._selection.overrideGravity();
    }
    /**
     * Restores the {@link ~DocumentSelection#_overrideGravity overridden gravity}.
     *
     * Restoring the gravity is only possible using the unique identifier returned by
     * {@link ~DocumentSelection#_overrideGravity}. Note that the gravity remains overridden as long as won't be restored
     * the same number of times it was overridden.
     *
     * @see module:engine/model/writer~Writer#restoreSelectionGravity
     * @internal
     * @param uid The unique id returned by {@link #_overrideGravity}.
     */ _restoreGravity(uid) {
        this._selection.restoreGravity(uid);
    }
    /**
     * Generates and returns an attribute key for selection attributes store, basing on original attribute key.
     *
     * @internal
     * @param key Attribute key to convert.
     * @returns Converted attribute key, applicable for selection store.
     */ static _getStoreAttributeKey(key) {
        return storePrefix + key;
    }
    /**
     * Checks whether the given attribute key is an attribute stored on an element.
     *
     * @internal
     */ static _isStoreAttributeKey(key) {
        return key.startsWith(storePrefix);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
DocumentSelection.prototype.is = function(type) {
    return type === 'selection' || type == 'model:selection' || type == 'documentSelection' || type == 'model:documentSelection';
};
/**
 * `LiveSelection` is used internally by {@link module:engine/model/documentselection~DocumentSelection} and shouldn't be used directly.
 *
 * LiveSelection` is automatically updated upon changes in the {@link module:engine/model/document~Document document}
 * to always contain valid ranges. Its attributes are inherited from the text unless set explicitly.
 *
 * Differences between {@link module:engine/model/selection~Selection} and `LiveSelection` are:
 * * there is always a range in `LiveSelection` - even if no ranges were added there is a "default range"
 * present in the selection,
 * * ranges added to this selection updates automatically when the document changes,
 * * attributes of `LiveSelection` are updated automatically according to selection ranges.
 */ class LiveSelection extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates an empty live selection for given {@link module:engine/model/document~Document}.
     *
     * @param doc Document which owns this selection.
     */ constructor(doc){
        super();
        /**
         * List of selection markers.
         * Marker is a selection marker when selection range is inside the marker range.
         */ this.markers = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$collection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Collection$3e$__["Collection"]({
            idProperty: 'name'
        });
        /**
         * Keeps mapping of attribute name to priority with which the attribute got modified (added/changed/removed)
         * last time. Possible values of priority are: `'low'` and `'normal'`.
         *
         * Priorities are used by internal `LiveSelection` mechanisms. All attributes set using `LiveSelection`
         * attributes API are set with `'normal'` priority.
         */ this._attributePriority = new Map();
        /**
         * Position to which the selection should be set if the last selection range was moved to the graveyard.
         */ this._selectionRestorePosition = null;
        /**
         * Flag that informs whether the selection ranges have changed. It is changed on true when `LiveRange#change:range` event is fired.
         */ this._hasChangedRange = false;
        /**
         * Each overriding gravity adds an UID to the set and each removal removes it.
         * Gravity is overridden when there's at least one UID in the set.
         * Gravity is restored when the set is empty.
         * This is to prevent conflicts when gravity is overridden by more than one feature at the same time.
         */ this._overriddenGravityRegister = new Set();
        /**
         * Prefixes of marker names that should affect `LiveSelection#markers` collection.
         */ this._observedMarkers = new Set();
        this._model = doc.model;
        this._document = doc;
        // Ensure selection is correct after each operation.
        this.listenTo(this._model, 'applyOperation', (evt, args)=>{
            const operation = args[0];
            if (!operation.isDocumentOperation || operation.type == 'marker' || operation.type == 'rename' || operation.type == 'noop') {
                return;
            }
            // Fix selection if the last range was removed from it and we have a position to which we can restore the selection.
            if (this._ranges.length == 0 && this._selectionRestorePosition) {
                this._fixGraveyardSelection(this._selectionRestorePosition);
            }
            // "Forget" the restore position even if it was not "used".
            this._selectionRestorePosition = null;
            if (this._hasChangedRange) {
                this._hasChangedRange = false;
                this.fire('change:range', {
                    directChange: false
                });
            }
        }, {
            priority: 'lowest'
        });
        // Ensure selection is correct and up to date after each range change.
        this.on('change:range', ()=>{
            this._validateSelectionRanges(this.getRanges());
        });
        // Update markers data stored by the selection after each marker change.
        // This handles only marker changes done through marker operations (not model tree changes).
        this.listenTo(this._model.markers, 'update', (evt, marker, oldRange, newRange)=>{
            this._updateMarker(marker, newRange);
        });
        // Ensure selection is up to date after each change block.
        this.listenTo(this._document, 'change', (evt, batch)=>{
            clearAttributesStoredInElement(this._model, batch);
        });
    }
    get isCollapsed() {
        const length = this._ranges.length;
        return length === 0 ? this._document._getDefaultRange().isCollapsed : super.isCollapsed;
    }
    get anchor() {
        return super.anchor || this._document._getDefaultRange().start;
    }
    get focus() {
        return super.focus || this._document._getDefaultRange().end;
    }
    get rangeCount() {
        return this._ranges.length ? this._ranges.length : 1;
    }
    /**
     * Describes whether `LiveSelection` has own range(s) set, or if it is defaulted to
     * {@link module:engine/model/document~Document#_getDefaultRange document's default range}.
     */ get hasOwnRange() {
        return this._ranges.length > 0;
    }
    /**
     * When set to `true` then selection attributes on node before the caret won't be taken
     * into consideration while updating selection attributes.
     */ get isGravityOverridden() {
        return !!this._overriddenGravityRegister.size;
    }
    /**
     * Unbinds all events previously bound by live selection.
     */ destroy() {
        for(let i = 0; i < this._ranges.length; i++){
            this._ranges[i].detach();
        }
        this.stopListening();
    }
    *getRanges() {
        if (this._ranges.length) {
            yield* super.getRanges();
        } else {
            yield this._document._getDefaultRange();
        }
    }
    getFirstRange() {
        return super.getFirstRange() || this._document._getDefaultRange();
    }
    getLastRange() {
        return super.getLastRange() || this._document._getDefaultRange();
    }
    setTo(...args) {
        super.setTo(...args);
        this._updateAttributes(true);
        this.updateMarkers();
    }
    setFocus(itemOrPosition, offset) {
        super.setFocus(itemOrPosition, offset);
        this._updateAttributes(true);
        this.updateMarkers();
    }
    setAttribute(key, value) {
        if (this._setAttribute(key, value)) {
            // Fire event with exact data.
            const attributeKeys = [
                key
            ];
            this.fire('change:attribute', {
                attributeKeys,
                directChange: true
            });
        }
    }
    removeAttribute(key) {
        if (this._removeAttribute(key)) {
            // Fire event with exact data.
            const attributeKeys = [
                key
            ];
            this.fire('change:attribute', {
                attributeKeys,
                directChange: true
            });
        }
    }
    overrideGravity() {
        const overrideUid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$uid$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__uid$3e$__["uid"])();
        // Remember that another overriding has been requested. It will need to be removed
        // before the gravity is to be restored.
        this._overriddenGravityRegister.add(overrideUid);
        if (this._overriddenGravityRegister.size === 1) {
            this._updateAttributes(true);
        }
        return overrideUid;
    }
    restoreGravity(uid) {
        if (!this._overriddenGravityRegister.has(uid)) {
            /**
             * Restoring gravity for an unknown UID is not possible. Make sure you are using a correct
             * UID obtained from the {@link module:engine/model/writer~Writer#overrideSelectionGravity} to restore.
             *
             * @error document-selection-gravity-wrong-restore
             * @param uid The unique identifier returned by
             * {@link module:engine/model/documentselection~DocumentSelection#_overrideGravity}.
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('document-selection-gravity-wrong-restore', this, {
                uid
            });
        }
        this._overriddenGravityRegister.delete(uid);
        // Restore gravity only when all overriding have been restored.
        if (!this.isGravityOverridden) {
            this._updateAttributes(true);
        }
    }
    observeMarkers(prefixOrName) {
        this._observedMarkers.add(prefixOrName);
        this.updateMarkers();
    }
    _replaceAllRanges(ranges) {
        this._validateSelectionRanges(ranges);
        super._replaceAllRanges(ranges);
    }
    _popRange() {
        this._ranges.pop().detach();
    }
    _pushRange(range) {
        const liveRange = this._prepareRange(range);
        // `undefined` is returned when given `range` is in graveyard root.
        if (liveRange) {
            this._ranges.push(liveRange);
        }
    }
    _validateSelectionRanges(ranges) {
        for (const range of ranges){
            if (!this._document._validateSelectionRange(range)) {
                /**
                 * Range from {@link module:engine/model/documentselection~DocumentSelection document selection}
                 * starts or ends at incorrect position.
                 *
                 * @error document-selection-wrong-position
                 * @param range
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('document-selection-wrong-position', this, {
                    range
                });
            }
        }
    }
    /**
     * Prepares given range to be added to selection. Checks if it is correct,
     * converts it to {@link module:engine/model/liverange~LiveRange LiveRange}
     * and sets listeners listening to the range's change event.
     */ _prepareRange(range) {
        this._checkRange(range);
        if (range.root == this._document.graveyard) {
            // @if CK_DEBUG // console.warn( 'Trying to add a Range that is in the graveyard root. Range rejected.' );
            return;
        }
        const liveRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromRange(range);
        // If selection range is moved to the graveyard remove it from the selection object.
        // Also, save some data that can be used to restore selection later, on `Model#applyOperation` event.
        liveRange.on('change:range', (evt, oldRange, data)=>{
            this._hasChangedRange = true;
            if (liveRange.root == this._document.graveyard) {
                this._selectionRestorePosition = data.deletionPosition;
                const index = this._ranges.indexOf(liveRange);
                this._ranges.splice(index, 1);
                liveRange.detach();
            }
        });
        return liveRange;
    }
    updateMarkers() {
        if (!this._observedMarkers.size) {
            return;
        }
        const markers = [];
        let changed = false;
        for (const marker of this._model.markers){
            const markerGroup = marker.name.split(':', 1)[0];
            if (!this._observedMarkers.has(markerGroup)) {
                continue;
            }
            const markerRange = marker.getRange();
            for (const selectionRange of this.getRanges()){
                if (markerRange.containsRange(selectionRange, !selectionRange.isCollapsed)) {
                    markers.push(marker);
                }
            }
        }
        const oldMarkers = Array.from(this.markers);
        for (const marker of markers){
            if (!this.markers.has(marker)) {
                this.markers.add(marker);
                changed = true;
            }
        }
        for (const marker of Array.from(this.markers)){
            if (!markers.includes(marker)) {
                this.markers.remove(marker);
                changed = true;
            }
        }
        if (changed) {
            this.fire('change:marker', {
                oldMarkers,
                directChange: false
            });
        }
    }
    _updateMarker(marker, markerRange) {
        const markerGroup = marker.name.split(':', 1)[0];
        if (!this._observedMarkers.has(markerGroup)) {
            return;
        }
        let changed = false;
        const oldMarkers = Array.from(this.markers);
        const hasMarker = this.markers.has(marker);
        if (!markerRange) {
            if (hasMarker) {
                this.markers.remove(marker);
                changed = true;
            }
        } else {
            let contained = false;
            for (const selectionRange of this.getRanges()){
                if (markerRange.containsRange(selectionRange, !selectionRange.isCollapsed)) {
                    contained = true;
                    break;
                }
            }
            if (contained && !hasMarker) {
                this.markers.add(marker);
                changed = true;
            } else if (!contained && hasMarker) {
                this.markers.remove(marker);
                changed = true;
            }
        }
        if (changed) {
            this.fire('change:marker', {
                oldMarkers,
                directChange: false
            });
        }
    }
    /**
     * Updates this selection attributes according to its ranges and the {@link module:engine/model/document~Document model document}.
     */ _updateAttributes(clearAll) {
        const newAttributes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__["toMap"])(this._getSurroundingAttributes());
        const oldAttributes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__["toMap"])(this.getAttributes());
        if (clearAll) {
            // If `clearAll` remove all attributes and reset priorities.
            this._attributePriority = new Map();
            this._attrs = new Map();
        } else {
            // If not, remove only attributes added with `low` priority.
            for (const [key, priority] of this._attributePriority){
                if (priority == 'low') {
                    this._attrs.delete(key);
                    this._attributePriority.delete(key);
                }
            }
        }
        this._setAttributesTo(newAttributes);
        // Let's evaluate which attributes really changed.
        const changed = [];
        // First, loop through all attributes that are set on selection right now.
        // Check which of them are different than old attributes.
        for (const [newKey, newValue] of this.getAttributes()){
            if (!oldAttributes.has(newKey) || oldAttributes.get(newKey) !== newValue) {
                changed.push(newKey);
            }
        }
        // Then, check which of old attributes got removed.
        for (const [oldKey] of oldAttributes){
            if (!this.hasAttribute(oldKey)) {
                changed.push(oldKey);
            }
        }
        // Fire event with exact data (fire only if anything changed).
        if (changed.length > 0) {
            this.fire('change:attribute', {
                attributeKeys: changed,
                directChange: false
            });
        }
    }
    /**
     * Internal method for setting `LiveSelection` attribute. Supports attribute priorities (through `directChange`
     * parameter).
     */ _setAttribute(key, value, directChange = true) {
        const priority = directChange ? 'normal' : 'low';
        if (priority == 'low' && this._attributePriority.get(key) == 'normal') {
            // Priority too low.
            return false;
        }
        const oldValue = super.getAttribute(key);
        // Don't do anything if value has not changed.
        if (oldValue === value) {
            return false;
        }
        this._attrs.set(key, value);
        // Update priorities map.
        this._attributePriority.set(key, priority);
        return true;
    }
    /**
     * Internal method for removing `LiveSelection` attribute. Supports attribute priorities (through `directChange`
     * parameter).
     *
     * NOTE: Even if attribute is not present in the selection but is provided to this method, it's priority will
     * be changed according to `directChange` parameter.
     */ _removeAttribute(key, directChange = true) {
        const priority = directChange ? 'normal' : 'low';
        if (priority == 'low' && this._attributePriority.get(key) == 'normal') {
            // Priority too low.
            return false;
        }
        // Update priorities map.
        this._attributePriority.set(key, priority);
        // Don't do anything if value has not changed.
        if (!super.hasAttribute(key)) {
            return false;
        }
        this._attrs.delete(key);
        return true;
    }
    /**
     * Internal method for setting multiple `LiveSelection` attributes. Supports attribute priorities (through
     * `directChange` parameter).
     */ _setAttributesTo(attrs) {
        const changed = new Set();
        for (const [oldKey, oldValue] of this.getAttributes()){
            // Do not remove attribute if attribute with same key and value is about to be set.
            if (attrs.get(oldKey) === oldValue) {
                continue;
            }
            // All rest attributes will be removed so changed attributes won't change .
            this._removeAttribute(oldKey, false);
        }
        for (const [key, value] of attrs){
            // Attribute may not be set because of attributes or because same key/value is already added.
            const gotAdded = this._setAttribute(key, value, false);
            if (gotAdded) {
                changed.add(key);
            }
        }
        return changed;
    }
    /**
     * Returns an iterable that iterates through all selection attributes stored in current selection's parent.
     */ *getStoredAttributes() {
        const selectionParent = this.getFirstPosition().parent;
        if (this.isCollapsed && selectionParent.isEmpty) {
            for (const key of selectionParent.getAttributeKeys()){
                if (key.startsWith(storePrefix)) {
                    const realKey = key.substr(storePrefix.length);
                    yield [
                        realKey,
                        selectionParent.getAttribute(key)
                    ];
                }
            }
        }
    }
    /**
     * Checks model text nodes that are closest to the selection's first position and returns attributes of first
     * found element. If there are no text nodes in selection's first position parent, it returns selection
     * attributes stored in that parent.
     */ _getSurroundingAttributes() {
        const position = this.getFirstPosition();
        const schema = this._model.schema;
        if (position.root.rootName == '$graveyard') {
            return null;
        }
        let attrs = null;
        if (!this.isCollapsed) {
            // 1. If selection is a range...
            const range = this.getFirstRange();
            // ...look for a first character node in that range and take attributes from it.
            for (const value of range){
                // If the item is an object, we don't want to get attributes from its children...
                if (value.item.is('element') && schema.isObject(value.item)) {
                    // ...but collect attributes from inline object.
                    attrs = getTextAttributes(value.item, schema);
                    break;
                }
                if (value.type == 'text') {
                    attrs = value.item.getAttributes();
                    break;
                }
            }
        } else {
            // 2. If the selection is a caret or the range does not contain a character node...
            const nodeBefore = position.textNode ? position.textNode : position.nodeBefore;
            const nodeAfter = position.textNode ? position.textNode : position.nodeAfter;
            // When gravity is overridden then don't take node before into consideration.
            if (!this.isGravityOverridden) {
                // ...look at the node before caret and take attributes from it if it is a character node.
                attrs = getTextAttributes(nodeBefore, schema);
            }
            // 3. If not, look at the node after caret...
            if (!attrs) {
                attrs = getTextAttributes(nodeAfter, schema);
            }
            // 4. If not, try to find the first character on the left, that is in the same node.
            // When gravity is overridden then don't take node before into consideration.
            if (!this.isGravityOverridden && !attrs) {
                let node = nodeBefore;
                while(node && !attrs){
                    node = node.previousSibling;
                    attrs = getTextAttributes(node, schema);
                }
            }
            // 5. If not found, try to find the first character on the right, that is in the same node.
            if (!attrs) {
                let node = nodeAfter;
                while(node && !attrs){
                    node = node.nextSibling;
                    attrs = getTextAttributes(node, schema);
                }
            }
            // 6. If not found, selection should retrieve attributes from parent.
            if (!attrs) {
                attrs = this.getStoredAttributes();
            }
        }
        return attrs;
    }
    /**
     * Fixes the selection after all its ranges got removed.
     * @param deletionPosition Position where the deletion happened.
     */ _fixGraveyardSelection(deletionPosition) {
        // Find a range that is a correct selection range and is closest to the position where the deletion happened.
        const selectionRange = this._model.schema.getNearestSelectionRange(deletionPosition);
        // If nearest valid selection range has been found - add it in the place of old range.
        if (selectionRange) {
            // Check the range, convert it to live range, bind events, etc.
            this._pushRange(selectionRange);
        }
    // If nearest valid selection range cannot be found don't add any range. Selection will be set to the default range.
    }
}
/**
 * Helper function for {@link module:engine/model/liveselection~LiveSelection#_updateAttributes}.
 *
 * It checks if the passed model item is a text node (or text proxy) and, if so, returns it's attributes.
 * If not, it checks if item is an inline object and does the same. Otherwise it returns `null`.
 */ function getTextAttributes(node, schema) {
    if (!node) {
        return null;
    }
    if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        return node.getAttributes();
    }
    if (!schema.isInline(node)) {
        return null;
    }
    // Stop on inline elements (such as `<softBreak>`) that are not objects (such as `<imageInline>` or `<mathml>`).
    if (!schema.isObject(node)) {
        return [];
    }
    const attributes = [];
    // Collect all attributes that can be applied to the text node.
    for (const [key, value] of node.getAttributes()){
        if (schema.checkAttribute('$text', key) && schema.getAttributeProperties(key).copyFromObject !== false) {
            attributes.push([
                key,
                value
            ]);
        }
    }
    return attributes;
}
/**
 * Removes selection attributes from element which is not empty anymore.
 */ function clearAttributesStoredInElement(model, batch) {
    const differ = model.document.differ;
    for (const entry of differ.getChanges()){
        if (entry.type != 'insert') {
            continue;
        }
        const changeParent = entry.position.parent;
        const isNoLongerEmpty = entry.length === changeParent.maxOffset;
        if (isNoLongerEmpty) {
            model.enqueueChange(batch, (writer)=>{
                const storedAttributes = Array.from(changeParent.getAttributeKeys()).filter((key)=>key.startsWith(storePrefix));
                for (const key of storedAttributes){
                    writer.removeAttribute(key, changeParent);
                }
            });
        }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/autoparagraphing.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/utils/autoparagraphing
 */ /**
 * Fixes all empty roots.
 *
 * @internal
 * @param writer The model writer.
 * @returns `true` if any change has been applied, `false` otherwise.
 */ __turbopack_context__.s([
    "autoParagraphEmptyRoots",
    ()=>autoParagraphEmptyRoots,
    "isParagraphable",
    ()=>isParagraphable,
    "wrapInParagraph",
    ()=>wrapInParagraph
]);
function autoParagraphEmptyRoots(writer) {
    const { schema, document } = writer.model;
    for (const root of document.getRoots()){
        if (root.isEmpty && !schema.checkChild(root, '$text')) {
            // If paragraph element is allowed in the root, create paragraph element.
            if (schema.checkChild(root, 'paragraph')) {
                writer.insertElement('paragraph', root);
                // Other roots will get fixed in the next post-fixer round. Those will be triggered
                // in the same batch no matter if this method was triggered by the post-fixing or not
                // (the above insertElement call will trigger the post-fixers).
                return true;
            }
        }
    }
    return false;
}
function isParagraphable(position, nodeOrType, schema) {
    const context = schema.createContext(position);
    // When paragraph is allowed in this context...
    if (!schema.checkChild(context, 'paragraph')) {
        return false;
    }
    // And a node would be allowed in this paragraph...
    if (!schema.checkChild(context.push('paragraph'), nodeOrType)) {
        return false;
    }
    return true;
}
function wrapInParagraph(position, writer) {
    const paragraph = writer.createElement('paragraph');
    writer.insert(paragraph, position);
    return writer.createPositionAt(paragraph, 0);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/selection-post-fixer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/utils/selection-post-fixer
 */ __turbopack_context__.s([
    "injectSelectionPostFixer",
    ()=>injectSelectionPostFixer,
    "mergeIntersectingRanges",
    ()=>mergeIntersectingRanges,
    "tryFixingRange",
    ()=>tryFixingRange
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
;
;
function injectSelectionPostFixer(model) {
    model.document.registerPostFixer((writer)=>selectionPostFixer(writer, model));
}
/**
 * The selection post-fixer.
 */ function selectionPostFixer(writer, model) {
    const selection = model.document.selection;
    const schema = model.schema;
    const ranges = [];
    let wasFixed = false;
    for (const modelRange of selection.getRanges()){
        // Go through all ranges in selection and try fixing each of them.
        // Those ranges might overlap but will be corrected later.
        const correctedRange = tryFixingRange(modelRange, schema);
        // "Selection fixing" algorithms sometimes get lost. In consequence, it may happen
        // that a new range is returned but, in fact, it has the same positions as the original
        // range anyway. If this range is not discarded, a new selection will be set and that,
        // for instance, would destroy the selection attributes. Let's make sure that the post-fixer
        // actually worked first before setting a new selection.
        //
        // https://github.com/ckeditor/ckeditor5/issues/6693
        if (correctedRange && !correctedRange.isEqual(modelRange)) {
            ranges.push(correctedRange);
            wasFixed = true;
        } else {
            ranges.push(modelRange);
        }
    }
    // If any of ranges were corrected update the selection.
    if (wasFixed) {
        writer.setSelection(mergeIntersectingRanges(ranges), {
            backward: selection.isBackward
        });
    }
    return false;
}
function tryFixingRange(range, schema) {
    if (range.isCollapsed) {
        return tryFixingCollapsedRange(range, schema);
    }
    return tryFixingNonCollapsedRage(range, schema);
}
/**
 * Tries to fix collapsed ranges.
 *
 * * Fixes situation when a range is in a place where $text is not allowed
 *
 * @param range Collapsed range to fix.
 * @returns Returns fixed range or null if range is valid.
 */ function tryFixingCollapsedRange(range, schema) {
    const originalPosition = range.start;
    const nearestSelectionRange = schema.getNearestSelectionRange(originalPosition);
    // This might be null, i.e. when the editor data is empty or the selection is inside a limit element
    // that doesn't allow text inside.
    // In the first case, there is no need to fix the selection range.
    // In the second, let's go up to the outer selectable element
    if (!nearestSelectionRange) {
        const ancestorObject = originalPosition.getAncestors().reverse().find((item)=>schema.isObject(item));
        if (ancestorObject) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(ancestorObject);
        }
        return null;
    }
    if (!nearestSelectionRange.isCollapsed) {
        return nearestSelectionRange;
    }
    const fixedPosition = nearestSelectionRange.start;
    // Fixed position is the same as original - no need to return corrected range.
    if (originalPosition.isEqual(fixedPosition)) {
        return null;
    }
    return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](fixedPosition);
}
/**
 * Tries to fix an expanded range.
 *
 * @param range Expanded range to fix.
 * @returns Returns fixed range or null if range is valid.
 */ function tryFixingNonCollapsedRage(range, schema) {
    const { start, end } = range;
    const isTextAllowedOnStart = schema.checkChild(start, '$text');
    const isTextAllowedOnEnd = schema.checkChild(end, '$text');
    const startLimitElement = schema.getLimitElement(start);
    const endLimitElement = schema.getLimitElement(end);
    // Ranges which both end are inside the same limit element (or root) might needs only minor fix.
    if (startLimitElement === endLimitElement) {
        // Range is valid when both position allows to place a text:
        // - <block>f[oobarba]z</block>
        // This would be "fixed" by a next check but as it will be the same it's better to return null so the selection stays the same.
        if (isTextAllowedOnStart && isTextAllowedOnEnd) {
            return null;
        }
        // Range that is on non-limit element (or is partially) must be fixed so it is placed inside the block around $text:
        // - [<block>foo</block>]    ->    <block>[foo]</block>
        // - [<block>foo]</block>    ->    <block>[foo]</block>
        // - <block>f[oo</block>]    ->    <block>f[oo]</block>
        // - [<block>foo</block><selectable></selectable>]    ->    <block>[foo</block><selectable></selectable>]
        if (checkSelectionOnNonLimitElements(start, end, schema)) {
            const isStartBeforeSelectable = start.nodeAfter && schema.isSelectable(start.nodeAfter);
            const fixedStart = isStartBeforeSelectable ? null : schema.getNearestSelectionRange(start, 'forward');
            const isEndAfterSelectable = end.nodeBefore && schema.isSelectable(end.nodeBefore);
            const fixedEnd = isEndAfterSelectable ? null : schema.getNearestSelectionRange(end, 'backward');
            // The schema.getNearestSelectionRange might return null - if that happens use original position.
            const rangeStart = fixedStart ? fixedStart.start : start;
            const rangeEnd = fixedEnd ? fixedEnd.end : end;
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](rangeStart, rangeEnd);
        }
    }
    const isStartInLimit = startLimitElement && !startLimitElement.is('rootElement');
    const isEndInLimit = endLimitElement && !endLimitElement.is('rootElement');
    // At this point we eliminated valid positions on text nodes so if one of range positions is placed inside a limit element
    // then the range crossed limit element boundaries and needs to be fixed.
    if (isStartInLimit || isEndInLimit) {
        const bothInSameParent = start.nodeAfter && end.nodeBefore && start.nodeAfter.parent === end.nodeBefore.parent;
        const expandStart = isStartInLimit && (!bothInSameParent || !isSelectable(start.nodeAfter, schema));
        const expandEnd = isEndInLimit && (!bothInSameParent || !isSelectable(end.nodeBefore, schema));
        // Although we've already found limit element on start/end positions we must find the outer-most limit element.
        // as limit elements might be nested directly inside (ie table > tableRow > tableCell).
        let fixedStart = start;
        let fixedEnd = end;
        if (expandStart) {
            fixedStart = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(findOutermostLimitAncestor(startLimitElement, schema));
        }
        if (expandEnd) {
            fixedEnd = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(findOutermostLimitAncestor(endLimitElement, schema));
        }
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](fixedStart, fixedEnd);
    }
    // Range was not fixed at this point so it is valid - ie it was placed around limit element already.
    return null;
}
/**
 * Finds the outer-most ancestor.
 */ function findOutermostLimitAncestor(startingNode, schema) {
    let isLimitNode = startingNode;
    let parent = isLimitNode;
    // Find outer most isLimit block as such blocks might be nested (ie. in tables).
    while(schema.isLimit(parent) && parent.parent){
        isLimitNode = parent;
        parent = parent.parent;
    }
    return isLimitNode;
}
/**
 * Checks whether any of range boundaries is placed around non-limit elements.
 */ function checkSelectionOnNonLimitElements(start, end, schema) {
    const startIsOnBlock = start.nodeAfter && !schema.isLimit(start.nodeAfter) || schema.checkChild(start, '$text');
    const endIsOnBlock = end.nodeBefore && !schema.isLimit(end.nodeBefore) || schema.checkChild(end, '$text');
    // We should fix such selection when one of those nodes needs fixing.
    return startIsOnBlock || endIsOnBlock;
}
function mergeIntersectingRanges(ranges) {
    const rangesToMerge = [
        ...ranges
    ];
    const rangeIndexesToRemove = new Set();
    let currentRangeIndex = 1;
    while(currentRangeIndex < rangesToMerge.length){
        const currentRange = rangesToMerge[currentRangeIndex];
        const previousRanges = rangesToMerge.slice(0, currentRangeIndex);
        for (const [previousRangeIndex, previousRange] of previousRanges.entries()){
            if (rangeIndexesToRemove.has(previousRangeIndex)) {
                continue;
            }
            if (currentRange.isEqual(previousRange)) {
                rangeIndexesToRemove.add(previousRangeIndex);
            } else if (currentRange.isIntersecting(previousRange)) {
                rangeIndexesToRemove.add(previousRangeIndex);
                rangeIndexesToRemove.add(currentRangeIndex);
                const mergedRange = currentRange.getJoined(previousRange);
                rangesToMerge.push(mergedRange);
            }
        }
        currentRangeIndex++;
    }
    const nonIntersectingRanges = rangesToMerge.filter((_, index)=>!rangeIndexesToRemove.has(index));
    return nonIntersectingRanges;
}
/**
 * Checks if node exists and if it's a selectable.
 */ function isSelectable(node, schema) {
    return node && schema.isSelectable(node);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/schema.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/schema
 */ __turbopack_context__.s([
    "SchemaContext",
    ()=>SchemaContext,
    "default",
    ()=>Schema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/treewalker.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$first$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__first$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/first.js [app-ssr] (ecmascript) <export default as first>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/observablemixin.js [app-ssr] (ecmascript) <export default as ObservableMixin>");
;
;
;
;
;
;
class Schema extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])() {
    /**
     * Creates a schema instance.
     */ constructor(){
        super();
        this._sourceDefinitions = {};
        /**
         * A dictionary containing attribute properties.
         */ this._attributeProperties = {};
        this.decorate('checkChild');
        this.decorate('checkAttribute');
        this.on('checkAttribute', (evt, args)=>{
            args[0] = new SchemaContext(args[0]);
        }, {
            priority: 'highest'
        });
        this.on('checkChild', (evt, args)=>{
            args[0] = new SchemaContext(args[0]);
            args[1] = this.getDefinition(args[1]);
        }, {
            priority: 'highest'
        });
    }
    /**
     * Registers a schema item. Can only be called once for every item name.
     *
     * ```ts
     * schema.register( 'paragraph', {
     * 	inheritAllFrom: '$block'
     * } );
     * ```
     */ register(itemName, definition) {
        if (this._sourceDefinitions[itemName]) {
            /**
             * A single item cannot be registered twice in the schema.
             *
             * This situation may happen when:
             *
             * * Two or more plugins called {@link module:engine/model/schema~Schema#register `register()`} with the same name.
             * This will usually mean that there is a collision between plugins which try to use the same element in the model.
             * Unfortunately, the only way to solve this is by modifying one of these plugins to use a unique model element name.
             * * A single plugin was loaded twice. This happens when it is installed by npm/yarn in two versions
             * and usually means one or more of the following issues:
             *     * a version mismatch (two of your dependencies require two different versions of this plugin),
             *     * incorrect imports (this plugin is somehow imported twice in a way which confuses webpack),
             *     * mess in `node_modules/` (`rm -rf node_modules/` may help).
             *
             * **Note:** Check the logged `itemName` to better understand which plugin was duplicated/conflicting.
             *
             * @param itemName The name of the model element that is being registered twice.
             * @error schema-cannot-register-item-twice
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('schema-cannot-register-item-twice', this, {
                itemName
            });
        }
        this._sourceDefinitions[itemName] = [
            Object.assign({}, definition)
        ];
        this._clearCache();
    }
    /**
     * Extends a {@link #register registered} item's definition.
     *
     * Extending properties such as `allowIn` will add more items to the existing properties,
     * while redefining properties such as `isBlock` will override the previously defined ones.
     *
     * ```ts
     * schema.register( 'foo', {
     * 	allowIn: '$root',
     * 	isBlock: true;
     * } );
     * schema.extend( 'foo', {
     * 	allowIn: 'blockQuote',
     * 	isBlock: false
     * } );
     *
     * schema.getDefinition( 'foo' );
     * //	{
     * //		allowIn: [ '$root', 'blockQuote' ],
     * // 		isBlock: false
     * //	}
     * ```
     */ extend(itemName, definition) {
        if (!this._sourceDefinitions[itemName]) {
            /**
             * Cannot extend an item which was not registered yet.
             *
             * This error happens when a plugin tries to extend the schema definition of an item which was not
             * {@link module:engine/model/schema~Schema#register registered} yet.
             *
             * @param itemName The name of the model element which is being extended.
             * @error schema-cannot-extend-missing-item
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('schema-cannot-extend-missing-item', this, {
                itemName
            });
        }
        this._sourceDefinitions[itemName].push(Object.assign({}, definition));
        this._clearCache();
    }
    /**
     * Returns data of all registered items.
     *
     * This method should normally be used for reflection purposes (e.g. defining a clone of a certain element,
     * checking a list of all block elements, etc).
     * Use specific methods (such as {@link #checkChild `checkChild()`} or {@link #isLimit `isLimit()`})
     * in other cases.
     */ getDefinitions() {
        if (!this._compiledDefinitions) {
            this._compile();
        }
        return this._compiledDefinitions;
    }
    /**
     * Returns a definition of the given item or `undefined` if an item is not registered.
     *
     * This method should normally be used for reflection purposes (e.g. defining a clone of a certain element,
     * checking a list of all block elements, etc).
     * Use specific methods (such as {@link #checkChild `checkChild()`} or {@link #isLimit `isLimit()`})
     * in other cases.
     */ getDefinition(item) {
        let itemName;
        if (typeof item == 'string') {
            itemName = item;
        } else if ('is' in item && (item.is('$text') || item.is('$textProxy'))) {
            itemName = '$text';
        } else {
            itemName = item.name;
        }
        return this.getDefinitions()[itemName];
    }
    /**
     * Returns `true` if the given item is registered in the schema.
     *
     * ```ts
     * schema.isRegistered( 'paragraph' ); // -> true
     * schema.isRegistered( editor.model.document.getRoot() ); // -> true
     * schema.isRegistered( 'foo' ); // -> false
     * ```
     */ isRegistered(item) {
        return !!this.getDefinition(item);
    }
    /**
     * Returns `true` if the given item is defined to be
     * a block by the {@link module:engine/model/schema~SchemaItemDefinition}'s `isBlock` property.
     *
     * ```ts
     * schema.isBlock( 'paragraph' ); // -> true
     * schema.isBlock( '$root' ); // -> false
     *
     * const paragraphElement = writer.createElement( 'paragraph' );
     * schema.isBlock( paragraphElement ); // -> true
     * ```
     *
     * See the {@glink framework/deep-dive/schema#block-elements Block elements} section of
     * the {@glink framework/deep-dive/schema Schema deep-dive} guide for more details.
     */ isBlock(item) {
        const def = this.getDefinition(item);
        return !!(def && def.isBlock);
    }
    /**
     * Returns `true` if the given item should be treated as a limit element.
     *
     * It considers an item to be a limit element if its
     * {@link module:engine/model/schema~SchemaItemDefinition}'s
     * {@link module:engine/model/schema~SchemaItemDefinition#isLimit `isLimit`} or
     * {@link module:engine/model/schema~SchemaItemDefinition#isObject `isObject`} property
     * was set to `true`.
     *
     * ```ts
     * schema.isLimit( 'paragraph' ); // -> false
     * schema.isLimit( '$root' ); // -> true
     * schema.isLimit( editor.model.document.getRoot() ); // -> true
     * schema.isLimit( 'imageBlock' ); // -> true
     * ```
     *
     * See the {@glink framework/deep-dive/schema#limit-elements Limit elements} section of
     * the {@glink framework/deep-dive/schema Schema deep-dive} guide for more details.
     */ isLimit(item) {
        const def = this.getDefinition(item);
        if (!def) {
            return false;
        }
        return !!(def.isLimit || def.isObject);
    }
    /**
     * Returns `true` if the given item should be treated as an object element.
     *
     * It considers an item to be an object element if its
     * {@link module:engine/model/schema~SchemaItemDefinition}'s
     * {@link module:engine/model/schema~SchemaItemDefinition#isObject `isObject`} property
     * was set to `true`.
     *
     * ```ts
     * schema.isObject( 'paragraph' ); // -> false
     * schema.isObject( 'imageBlock' ); // -> true
     *
     * const imageElement = writer.createElement( 'imageBlock' );
     * schema.isObject( imageElement ); // -> true
     * ```
     *
     * See the {@glink framework/deep-dive/schema#object-elements Object elements} section of
     * the {@glink framework/deep-dive/schema Schema deep-dive} guide for more details.
     */ isObject(item) {
        const def = this.getDefinition(item);
        if (!def) {
            return false;
        }
        // Note: Check out the implementation of #isLimit(), #isSelectable(), and #isContent()
        // to understand why these three constitute an object.
        return !!(def.isObject || def.isLimit && def.isSelectable && def.isContent);
    }
    /**
     * Returns `true` if the given item is defined to be
     * an inline element by the {@link module:engine/model/schema~SchemaItemDefinition}'s `isInline` property.
     *
     * ```ts
     * schema.isInline( 'paragraph' ); // -> false
     * schema.isInline( 'softBreak' ); // -> true
     *
     * const text = writer.createText( 'foo' );
     * schema.isInline( text ); // -> true
     * ```
     *
     * See the {@glink framework/deep-dive/schema#inline-elements Inline elements} section of
     * the {@glink framework/deep-dive/schema Schema deep-dive} guide for more details.
     */ isInline(item) {
        const def = this.getDefinition(item);
        return !!(def && def.isInline);
    }
    /**
     * Returns `true` if the given item is defined to be
     * a selectable element by the {@link module:engine/model/schema~SchemaItemDefinition}'s `isSelectable` property.
     *
     * ```ts
     * schema.isSelectable( 'paragraph' ); // -> false
     * schema.isSelectable( 'heading1' ); // -> false
     * schema.isSelectable( 'imageBlock' ); // -> true
     * schema.isSelectable( 'tableCell' ); // -> true
     *
     * const text = writer.createText( 'foo' );
     * schema.isSelectable( text ); // -> false
     * ```
     *
     * See the {@glink framework/deep-dive/schema#selectable-elements Selectable elements section} of
     * the {@glink framework/deep-dive/schema Schema deep-dive} guide for more details.
     */ isSelectable(item) {
        const def = this.getDefinition(item);
        if (!def) {
            return false;
        }
        return !!(def.isSelectable || def.isObject);
    }
    /**
     * Returns `true` if the given item is defined to be
     * a content by the {@link module:engine/model/schema~SchemaItemDefinition}'s `isContent` property.
     *
     * ```ts
     * schema.isContent( 'paragraph' ); // -> false
     * schema.isContent( 'heading1' ); // -> false
     * schema.isContent( 'imageBlock' ); // -> true
     * schema.isContent( 'horizontalLine' ); // -> true
     *
     * const text = writer.createText( 'foo' );
     * schema.isContent( text ); // -> true
     * ```
     *
     * See the {@glink framework/deep-dive/schema#content-elements Content elements section} of
     * the {@glink framework/deep-dive/schema Schema deep-dive} guide for more details.
     */ isContent(item) {
        const def = this.getDefinition(item);
        if (!def) {
            return false;
        }
        return !!(def.isContent || def.isObject);
    }
    /**
     * Checks whether the given node (`child`) can be a child of the given context.
     *
     * ```ts
     * schema.checkChild( model.document.getRoot(), paragraph ); // -> false
     *
     * schema.register( 'paragraph', {
     * 	allowIn: '$root'
     * } );
     * schema.checkChild( model.document.getRoot(), paragraph ); // -> true
     * ```
     *
     * Note: When verifying whether the given node can be a child of the given context, the
     * schema also verifies the entire context &ndash; from its root to its last element. Therefore, it is possible
     * for `checkChild()` to return `false` even though the context's last element can contain the checked child.
     * It happens if one of the context's elements does not allow its child.
     *
     * @fires checkChild
     * @param context The context in which the child will be checked.
     * @param def The child to check.
     */ checkChild(context, def) {
        // Note: context and child are already normalized here to a SchemaContext and SchemaCompiledItemDefinition.
        if (!def) {
            return false;
        }
        return this._checkContextMatch(def, context);
    }
    /**
     * Checks whether the given attribute can be applied in the given context (on the last
     * item of the context).
     *
     * ```ts
     * schema.checkAttribute( textNode, 'bold' ); // -> false
     *
     * schema.extend( '$text', {
     * 	allowAttributes: 'bold'
     * } );
     * schema.checkAttribute( textNode, 'bold' ); // -> true
     * ```
     *
     * @fires checkAttribute
     * @param context The context in which the attribute will be checked.
     */ checkAttribute(context, attributeName) {
        const def = this.getDefinition(context.last);
        if (!def) {
            return false;
        }
        return def.allowAttributes.includes(attributeName);
    }
    /**
     * Checks whether the given element (`elementToMerge`) can be merged with the specified base element (`positionOrBaseElement`).
     *
     * In other words &ndash; whether `elementToMerge`'s children {@link #checkChild are allowed} in the `positionOrBaseElement`.
     *
     * This check ensures that elements merged with {@link module:engine/model/writer~Writer#merge `Writer#merge()`}
     * will be valid.
     *
     * Instead of elements, you can pass the instance of the {@link module:engine/model/position~Position} class as the
     * `positionOrBaseElement`. It means that the elements before and after the position will be checked whether they can be merged.
     *
     * @param positionOrBaseElement The position or base element to which the `elementToMerge` will be merged.
     * @param elementToMerge The element to merge. Required if `positionOrBaseElement` is an element.
     */ checkMerge(positionOrBaseElement, elementToMerge) {
        if (positionOrBaseElement instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            const nodeBefore = positionOrBaseElement.nodeBefore;
            const nodeAfter = positionOrBaseElement.nodeAfter;
            if (!(nodeBefore instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
                /**
                 * The node before the merge position must be an element.
                 *
                 * @error schema-check-merge-no-element-before
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('schema-check-merge-no-element-before', this);
            }
            if (!(nodeAfter instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
                /**
                 * The node after the merge position must be an element.
                 *
                 * @error schema-check-merge-no-element-after
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('schema-check-merge-no-element-after', this);
            }
            return this.checkMerge(nodeBefore, nodeAfter);
        }
        for (const child of elementToMerge.getChildren()){
            if (!this.checkChild(positionOrBaseElement, child)) {
                return false;
            }
        }
        return true;
    }
    /**
     * Allows registering a callback to the {@link #checkChild} method calls.
     *
     * Callbacks allow you to implement rules which are not otherwise possible to achieve
     * by using the declarative API of {@link module:engine/model/schema~SchemaItemDefinition}.
     * For example, by using this method you can disallow elements in specific contexts.
     *
     * This method is a shorthand for using the {@link #event:checkChild} event. For even better control,
     * you can use that event instead.
     *
     * Example:
     *
     * ```ts
     * // Disallow heading1 directly inside a blockQuote.
     * schema.addChildCheck( ( context, childDefinition ) => {
     * 	if ( context.endsWith( 'blockQuote' ) && childDefinition.name == 'heading1' ) {
     * 		return false;
     * 	}
     * } );
     * ```
     *
     * Which translates to:
     *
     * ```ts
     * schema.on( 'checkChild', ( evt, args ) => {
     * 	const context = args[ 0 ];
     * 	const childDefinition = args[ 1 ];
     *
     * 	if ( context.endsWith( 'blockQuote' ) && childDefinition && childDefinition.name == 'heading1' ) {
     * 		// Prevent next listeners from being called.
     * 		evt.stop();
     * 		// Set the checkChild()'s return value.
     * 		evt.return = false;
     * 	}
     * }, { priority: 'high' } );
     * ```
     *
     * @param callback The callback to be called. It is called with two parameters:
     * {@link module:engine/model/schema~SchemaContext} (context) instance and
     * {@link module:engine/model/schema~SchemaCompiledItemDefinition} (child-to-check definition).
     * The callback may return `true/false` to override `checkChild()`'s return value. If it does not return
     * a boolean value, the default algorithm (or other callbacks) will define `checkChild()`'s return value.
     */ addChildCheck(callback) {
        this.on('checkChild', (evt, [ctx, childDef])=>{
            // checkChild() was called with a non-registered child.
            // In 99% cases such check should return false, so not to overcomplicate all callbacks
            // don't even execute them.
            if (!childDef) {
                return;
            }
            const retValue = callback(ctx, childDef);
            if (typeof retValue == 'boolean') {
                evt.stop();
                evt.return = retValue;
            }
        }, {
            priority: 'high'
        });
    }
    /**
     * Allows registering a callback to the {@link #checkAttribute} method calls.
     *
     * Callbacks allow you to implement rules which are not otherwise possible to achieve
     * by using the declarative API of {@link module:engine/model/schema~SchemaItemDefinition}.
     * For example, by using this method you can disallow attribute if node to which it is applied
     * is contained within some other element (e.g. you want to disallow `bold` on `$text` within `heading1`).
     *
     * This method is a shorthand for using the {@link #event:checkAttribute} event. For even better control,
     * you can use that event instead.
     *
     * Example:
     *
     * ```ts
     * // Disallow bold on $text inside heading1.
     * schema.addAttributeCheck( ( context, attributeName ) => {
     * 	if ( context.endsWith( 'heading1 $text' ) && attributeName == 'bold' ) {
     * 		return false;
     * 	}
     * } );
     * ```
     *
     * Which translates to:
     *
     * ```ts
     * schema.on( 'checkAttribute', ( evt, args ) => {
     * 	const context = args[ 0 ];
     * 	const attributeName = args[ 1 ];
     *
     * 	if ( context.endsWith( 'heading1 $text' ) && attributeName == 'bold' ) {
     * 		// Prevent next listeners from being called.
     * 		evt.stop();
     * 		// Set the checkAttribute()'s return value.
     * 		evt.return = false;
     * 	}
     * }, { priority: 'high' } );
     * ```
     *
     * @param callback The callback to be called. It is called with two parameters:
     * {@link module:engine/model/schema~SchemaContext} (context) instance and attribute name.
     * The callback may return `true/false` to override `checkAttribute()`'s return value. If it does not return
     * a boolean value, the default algorithm (or other callbacks) will define `checkAttribute()`'s return value.
     */ addAttributeCheck(callback) {
        this.on('checkAttribute', (evt, [ctx, attributeName])=>{
            const retValue = callback(ctx, attributeName);
            if (typeof retValue == 'boolean') {
                evt.stop();
                evt.return = retValue;
            }
        }, {
            priority: 'high'
        });
    }
    /**
     * This method allows assigning additional metadata to the model attributes. For example,
     * {@link module:engine/model/schema~AttributeProperties `AttributeProperties#isFormatting` property} is
     * used to mark formatting attributes (like `bold` or `italic`).
     *
     * ```ts
     * // Mark bold as a formatting attribute.
     * schema.setAttributeProperties( 'bold', {
     * 	isFormatting: true
     * } );
     *
     * // Override code not to be considered a formatting markup.
     * schema.setAttributeProperties( 'code', {
     * 	isFormatting: false
     * } );
     * ```
     *
     * Properties are not limited to members defined in the
     * {@link module:engine/model/schema~AttributeProperties `AttributeProperties` type} and you can also use custom properties:
     *
     * ```ts
     * schema.setAttributeProperties( 'blockQuote', {
     * 	customProperty: 'value'
     * } );
     * ```
     *
     * Subsequent calls with the same attribute will extend its custom properties:
     *
     * ```ts
     * schema.setAttributeProperties( 'blockQuote', {
     * 	one: 1
     * } );
     *
     * schema.setAttributeProperties( 'blockQuote', {
     * 	two: 2
     * } );
     *
     * console.log( schema.getAttributeProperties( 'blockQuote' ) );
     * // Logs: { one: 1, two: 2 }
     * ```
     *
     * @param attributeName A name of the attribute to receive the properties.
     * @param properties A dictionary of properties.
     */ setAttributeProperties(attributeName, properties) {
        this._attributeProperties[attributeName] = Object.assign(this.getAttributeProperties(attributeName), properties);
    }
    /**
     * Returns properties associated with a given model attribute. See {@link #setAttributeProperties `setAttributeProperties()`}.
     *
     * @param attributeName A name of the attribute.
     */ getAttributeProperties(attributeName) {
        return this._attributeProperties[attributeName] || {};
    }
    /**
     * Returns the lowest {@link module:engine/model/schema~Schema#isLimit limit element} containing the entire
     * selection/range/position or the root otherwise.
     *
     * @param selectionOrRangeOrPosition The selection/range/position to check.
     * @returns The lowest limit element containing the entire `selectionOrRangeOrPosition`.
     */ getLimitElement(selectionOrRangeOrPosition) {
        let element;
        if (selectionOrRangeOrPosition instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            element = selectionOrRangeOrPosition.parent;
        } else {
            const ranges = selectionOrRangeOrPosition instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] ? [
                selectionOrRangeOrPosition
            ] : Array.from(selectionOrRangeOrPosition.getRanges());
            // Find the common ancestor for all selection's ranges.
            element = ranges.reduce((element, range)=>{
                const rangeCommonAncestor = range.getCommonAncestor();
                if (!element) {
                    return rangeCommonAncestor;
                }
                return element.getCommonAncestor(rangeCommonAncestor, {
                    includeSelf: true
                });
            }, null);
        }
        while(!this.isLimit(element)){
            if (element.parent) {
                element = element.parent;
            } else {
                break;
            }
        }
        return element;
    }
    /**
     * Checks whether the attribute is allowed in selection:
     *
     * * if the selection is not collapsed, then checks if the attribute is allowed on any of nodes in that range,
     * * if the selection is collapsed, then checks if on the selection position there's a text with the
     * specified attribute allowed.
     *
     * @param selection Selection which will be checked.
     * @param attribute The name of the attribute to check.
     */ checkAttributeInSelection(selection, attribute) {
        if (selection.isCollapsed) {
            const firstPosition = selection.getFirstPosition();
            const context = [
                ...firstPosition.getAncestors(),
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]('', selection.getAttributes())
            ];
            // Check whether schema allows for a text with the attribute in the selection.
            return this.checkAttribute(context, attribute);
        } else {
            const ranges = selection.getRanges();
            // For all ranges, check nodes in them until you find a node that is allowed to have the attribute.
            for (const range of ranges){
                for (const value of range){
                    if (this.checkAttribute(value.item, attribute)) {
                        // If we found a node that is allowed to have the attribute, return true.
                        return true;
                    }
                }
            }
        }
        // If we haven't found such node, return false.
        return false;
    }
    /**
     * Transforms the given set of ranges into a set of ranges where the given attribute is allowed (and can be applied).
     *
     * @param ranges Ranges to be validated.
     * @param attribute The name of the attribute to check.
     * @returns Ranges in which the attribute is allowed.
     */ *getValidRanges(ranges, attribute) {
        ranges = convertToMinimalFlatRanges(ranges);
        for (const range of ranges){
            yield* this._getValidRangesForRange(range, attribute);
        }
    }
    /**
     * Basing on given `position`, finds and returns a {@link module:engine/model/range~Range range} which is
     * nearest to that `position` and is a correct range for selection.
     *
     * The correct selection range might be collapsed when it is located in a position where the text node can be placed.
     * Non-collapsed range is returned when selection can be placed around element marked as an "object" in
     * the {@link module:engine/model/schema~Schema schema}.
     *
     * Direction of searching for the nearest correct selection range can be specified as:
     *
     * * `both` - searching will be performed in both ways,
     * * `forward` - searching will be performed only forward,
     * * `backward` - searching will be performed only backward.
     *
     * When valid selection range cannot be found, `null` is returned.
     *
     * @param position Reference position where new selection range should be looked for.
     * @param direction Search direction.
     * @returns Nearest selection range or `null` if one cannot be found.
     */ getNearestSelectionRange(position, direction = 'both') {
        if (position.root.rootName == '$graveyard') {
            // No valid selection range in the graveyard.
            // This is important when getting the document selection default range.
            return null;
        }
        // Return collapsed range if provided position is valid.
        if (this.checkChild(position, '$text')) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position);
        }
        let backwardWalker, forwardWalker;
        // Never leave a limit element.
        const limitElement = position.getAncestors().reverse().find((item)=>this.isLimit(item)) || position.root;
        if (direction == 'both' || direction == 'backward') {
            backwardWalker = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
                boundaries: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(limitElement),
                startPosition: position,
                direction: 'backward'
            });
        }
        if (direction == 'both' || direction == 'forward') {
            forwardWalker = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
                boundaries: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(limitElement),
                startPosition: position
            });
        }
        for (const data of combineWalkers(backwardWalker, forwardWalker)){
            const type = data.walker == backwardWalker ? 'elementEnd' : 'elementStart';
            const value = data.value;
            if (value.type == type && this.isObject(value.item)) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(value.item);
            }
            if (this.checkChild(value.nextPosition, '$text')) {
                return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](value.nextPosition);
            }
        }
        return null;
    }
    /**
     * Tries to find position ancestors that allow to insert a given node.
     * It starts searching from the given position and goes node by node to the top of the model tree
     * as long as a {@link module:engine/model/schema~Schema#isLimit limit element}, an
     * {@link module:engine/model/schema~Schema#isObject object element} or a topmost ancestor is not reached.
     *
     * @param position The position that the search will start from.
     * @param node The node for which an allowed parent should be found or its name.
     * @returns Allowed parent or null if nothing was found.
     */ findAllowedParent(position, node) {
        let parent = position.parent;
        while(parent){
            if (this.checkChild(parent, node)) {
                return parent;
            }
            // Do not split limit elements.
            if (this.isLimit(parent)) {
                return null;
            }
            parent = parent.parent;
        }
        return null;
    }
    /**
     * Sets attributes allowed by the schema on a given node.
     *
     * @param node A node to set attributes on.
     * @param attributes Attributes keys and values.
     * @param writer An instance of the model writer.
     */ setAllowedAttributes(node, attributes, writer) {
        const model = writer.model;
        for (const [attributeName, attributeValue] of Object.entries(attributes)){
            if (model.schema.checkAttribute(node, attributeName)) {
                writer.setAttribute(attributeName, attributeValue, node);
            }
        }
    }
    /**
     * Removes attributes disallowed by the schema.
     *
     * @param nodes Nodes that will be filtered.
     */ removeDisallowedAttributes(nodes, writer) {
        for (const node of nodes){
            // When node is a `Text` it has no children, so just filter it out.
            if (node.is('$text')) {
                removeDisallowedAttributeFromNode(this, node, writer);
            } else {
                const rangeInNode = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(node);
                const positionsInRange = rangeInNode.getPositions();
                for (const position of positionsInRange){
                    const item = position.nodeBefore || position.parent;
                    removeDisallowedAttributeFromNode(this, item, writer);
                }
            }
        }
    }
    /**
     * Gets attributes of a node that have a given property.
     *
     * @param node Node to get attributes from.
     * @param propertyName Name of the property that attribute must have to return it.
     * @param propertyValue Desired value of the property that we want to check.
     * When `undefined` attributes will be returned if they have set a given property no matter what the value is. If specified it will
     * return attributes which given property's value is equal to this parameter.
     * @returns Object with attributes' names as key and attributes' values as value.
     */ getAttributesWithProperty(node, propertyName, propertyValue) {
        const attributes = {};
        for (const [attributeName, attributeValue] of node.getAttributes()){
            const attributeProperties = this.getAttributeProperties(attributeName);
            if (attributeProperties[propertyName] === undefined) {
                continue;
            }
            if (propertyValue === undefined || propertyValue === attributeProperties[propertyName]) {
                attributes[attributeName] = attributeValue;
            }
        }
        return attributes;
    }
    /**
     * Creates an instance of the schema context.
     */ createContext(context) {
        return new SchemaContext(context);
    }
    _clearCache() {
        this._compiledDefinitions = null;
    }
    _compile() {
        const compiledDefinitions = {};
        const sourceRules = this._sourceDefinitions;
        const itemNames = Object.keys(sourceRules);
        for (const itemName of itemNames){
            compiledDefinitions[itemName] = compileBaseItemRule(sourceRules[itemName], itemName);
        }
        for (const itemName of itemNames){
            compileAllowChildren(compiledDefinitions, itemName);
        }
        for (const itemName of itemNames){
            compileAllowContentOf(compiledDefinitions, itemName);
        }
        for (const itemName of itemNames){
            compileAllowWhere(compiledDefinitions, itemName);
        }
        for (const itemName of itemNames){
            compileAllowAttributesOf(compiledDefinitions, itemName);
            compileInheritPropertiesFrom(compiledDefinitions, itemName);
        }
        for (const itemName of itemNames){
            cleanUpAllowIn(compiledDefinitions, itemName);
            setupAllowChildren(compiledDefinitions, itemName);
            cleanUpAllowAttributes(compiledDefinitions, itemName);
        }
        this._compiledDefinitions = compiledDefinitions;
    }
    _checkContextMatch(def, context, contextItemIndex = context.length - 1) {
        const contextItem = context.getItem(contextItemIndex);
        if (def.allowIn.includes(contextItem.name)) {
            if (contextItemIndex == 0) {
                return true;
            } else {
                const parentRule = this.getDefinition(contextItem);
                return this._checkContextMatch(parentRule, context, contextItemIndex - 1);
            }
        } else {
            return false;
        }
    }
    /**
     * Takes a flat range and an attribute name. Traverses the range recursively and deeply to find and return all ranges
     * inside the given range on which the attribute can be applied.
     *
     * This is a helper function for {@link ~Schema#getValidRanges}.
     *
     * @param range The range to process.
     * @param attribute The name of the attribute to check.
     * @returns Ranges in which the attribute is allowed.
     */ *_getValidRangesForRange(range, attribute) {
        let start = range.start;
        let end = range.start;
        for (const item of range.getItems({
            shallow: true
        })){
            if (item.is('element')) {
                yield* this._getValidRangesForRange(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(item), attribute);
            }
            if (!this.checkAttribute(item, attribute)) {
                if (!start.isEqual(end)) {
                    yield new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end);
                }
                start = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(item);
            }
            end = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(item);
        }
        if (!start.isEqual(end)) {
            yield new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end);
        }
    }
    /**
     * Returns a model range which is optimal (in terms of UX) for inserting a widget block.
     *
     * For instance, if a selection is in the middle of a paragraph, the collapsed range before this paragraph
     * will be returned so that it is not split. If the selection is at the end of a paragraph,
     * the collapsed range after this paragraph will be returned.
     *
     * Note: If the selection is placed in an empty block, the range in that block will be returned. If that range
     * is then passed to {@link module:engine/model/model~Model#insertContent}, the block will be fully replaced
     * by the inserted widget block.
     *
     * @internal
     * @param selection The selection based on which the insertion position should be calculated.
     * @param place The place where to look for optimal insertion range.
     * The `auto` value will determine itself the best position for insertion.
     * The `before` value will try to find a position before selection.
     * The `after` value will try to find a position after selection.
     * @returns The optimal range.
     */ findOptimalInsertionRange(selection, place) {
        const selectedElement = selection.getSelectedElement();
        if (selectedElement && this.isObject(selectedElement) && !this.isInline(selectedElement)) {
            if (place == 'before' || place == 'after') {
                return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(selectedElement, place));
            }
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(selectedElement);
        }
        const firstBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$first$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__first$3e$__["first"])(selection.getSelectedBlocks());
        // There are no block elements within ancestors (in the current limit element).
        if (!firstBlock) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selection.focus);
        }
        // If inserting into an empty block – return position in that block. It will get
        // replaced with the image by insertContent(). #42.
        if (firstBlock.isEmpty) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(firstBlock, 0));
        }
        const positionAfter = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(firstBlock);
        // If selection is at the end of the block - return position after the block.
        if (selection.focus.isTouching(positionAfter)) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionAfter);
        }
        // Otherwise, return position before the block.
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(firstBlock));
    }
}
class SchemaContext {
    /**
     * Creates an instance of the context.
     */ constructor(context){
        if (context instanceof SchemaContext) {
            return context;
        }
        let items;
        if (typeof context == 'string') {
            items = [
                context
            ];
        } else if (!Array.isArray(context)) {
            // `context` is item or position.
            // Position#getAncestors() doesn't accept any parameters but it works just fine here.
            items = context.getAncestors({
                includeSelf: true
            });
        } else {
            items = context;
        }
        this._items = items.map(mapContextItem);
    }
    /**
     * The number of items.
     */ get length() {
        return this._items.length;
    }
    /**
     * The last item (the lowest node).
     */ get last() {
        return this._items[this._items.length - 1];
    }
    /**
     * Iterable interface.
     *
     * Iterates over all context items.
     */ [Symbol.iterator]() {
        return this._items[Symbol.iterator]();
    }
    /**
     * Returns a new schema context instance with an additional item.
     *
     * Item can be added as:
     *
     * ```ts
     * const context = new SchemaContext( [ '$root' ] );
     *
     * // An element.
     * const fooElement = writer.createElement( 'fooElement' );
     * const newContext = context.push( fooElement ); // [ '$root', 'fooElement' ]
     *
     * // A text node.
     * const text = writer.createText( 'foobar' );
     * const newContext = context.push( text ); // [ '$root', '$text' ]
     *
     * // A string (element name).
     * const newContext = context.push( 'barElement' ); // [ '$root', 'barElement' ]
     * ```
     *
     * **Note** {@link module:engine/model/node~Node} that is already in the model tree will be added as the only item
     * (without ancestors).
     *
     * @param item An item that will be added to the current context.
     * @returns A new schema context instance with an additional item.
     */ push(item) {
        const ctx = new SchemaContext([
            item
        ]);
        ctx._items = [
            ...this._items,
            ...ctx._items
        ];
        return ctx;
    }
    /**
     * Gets an item on the given index.
     */ getItem(index) {
        return this._items[index];
    }
    /**
     * Returns the names of items.
     */ *getNames() {
        yield* this._items.map((item)=>item.name);
    }
    /**
     * Checks whether the context ends with the given nodes.
     *
     * ```ts
     * const ctx = new SchemaContext( [ rootElement, paragraphElement, textNode ] );
     *
     * ctx.endsWith( '$text' ); // -> true
     * ctx.endsWith( 'paragraph $text' ); // -> true
     * ctx.endsWith( '$root' ); // -> false
     * ctx.endsWith( 'paragraph' ); // -> false
     * ```
     */ endsWith(query) {
        return Array.from(this.getNames()).join(' ').endsWith(query);
    }
    /**
     * Checks whether the context starts with the given nodes.
     *
     * ```ts
     * const ctx = new SchemaContext( [ rootElement, paragraphElement, textNode ] );
     *
     * ctx.endsWith( '$root' ); // -> true
     * ctx.endsWith( '$root paragraph' ); // -> true
     * ctx.endsWith( '$text' ); // -> false
     * ctx.endsWith( 'paragraph' ); // -> false
     * ```
     */ startsWith(query) {
        return Array.from(this.getNames()).join(' ').startsWith(query);
    }
}
function compileBaseItemRule(sourceItemRules, itemName) {
    const itemRule = {
        name: itemName,
        allowIn: [],
        allowContentOf: [],
        allowWhere: [],
        allowAttributes: [],
        allowAttributesOf: [],
        allowChildren: [],
        inheritTypesFrom: []
    };
    copyTypes(sourceItemRules, itemRule);
    copyProperty(sourceItemRules, itemRule, 'allowIn');
    copyProperty(sourceItemRules, itemRule, 'allowContentOf');
    copyProperty(sourceItemRules, itemRule, 'allowWhere');
    copyProperty(sourceItemRules, itemRule, 'allowAttributes');
    copyProperty(sourceItemRules, itemRule, 'allowAttributesOf');
    copyProperty(sourceItemRules, itemRule, 'allowChildren');
    copyProperty(sourceItemRules, itemRule, 'inheritTypesFrom');
    makeInheritAllWork(sourceItemRules, itemRule);
    return itemRule;
}
function compileAllowChildren(compiledDefinitions, itemName) {
    const item = compiledDefinitions[itemName];
    for (const allowChildrenItem of item.allowChildren){
        const allowedChildren = compiledDefinitions[allowChildrenItem];
        // The allowChildren property may point to an unregistered element.
        if (!allowedChildren) {
            continue;
        }
        allowedChildren.allowIn.push(itemName);
    }
    // The allowIn property already includes correct items, reset the allowChildren property
    // to avoid duplicates later when setting up compilation results.
    item.allowChildren.length = 0;
}
function compileAllowContentOf(compiledDefinitions, itemName) {
    for (const allowContentOfItemName of compiledDefinitions[itemName].allowContentOf){
        // The allowContentOf property may point to an unregistered element.
        if (compiledDefinitions[allowContentOfItemName]) {
            const allowedChildren = getAllowedChildren(compiledDefinitions, allowContentOfItemName);
            allowedChildren.forEach((allowedItem)=>{
                allowedItem.allowIn.push(itemName);
            });
        }
    }
    delete compiledDefinitions[itemName].allowContentOf;
}
function compileAllowWhere(compiledDefinitions, itemName) {
    for (const allowWhereItemName of compiledDefinitions[itemName].allowWhere){
        const inheritFrom = compiledDefinitions[allowWhereItemName];
        // The allowWhere property may point to an unregistered element.
        if (inheritFrom) {
            const allowedIn = inheritFrom.allowIn;
            compiledDefinitions[itemName].allowIn.push(...allowedIn);
        }
    }
    delete compiledDefinitions[itemName].allowWhere;
}
function compileAllowAttributesOf(compiledDefinitions, itemName) {
    for (const allowAttributeOfItem of compiledDefinitions[itemName].allowAttributesOf){
        const inheritFrom = compiledDefinitions[allowAttributeOfItem];
        if (inheritFrom) {
            const inheritAttributes = inheritFrom.allowAttributes;
            compiledDefinitions[itemName].allowAttributes.push(...inheritAttributes);
        }
    }
    delete compiledDefinitions[itemName].allowAttributesOf;
}
function compileInheritPropertiesFrom(compiledDefinitions, itemName) {
    const item = compiledDefinitions[itemName];
    for (const inheritPropertiesOfItem of item.inheritTypesFrom){
        const inheritFrom = compiledDefinitions[inheritPropertiesOfItem];
        if (inheritFrom) {
            const typeNames = Object.keys(inheritFrom).filter((name)=>name.startsWith('is'));
            for (const name of typeNames){
                if (!(name in item)) {
                    item[name] = inheritFrom[name];
                }
            }
        }
    }
    delete item.inheritTypesFrom;
}
// Remove items which weren't registered (because it may break some checks or we'd need to complicate them).
// Make sure allowIn doesn't contain repeated values.
function cleanUpAllowIn(compiledDefinitions, itemName) {
    const itemRule = compiledDefinitions[itemName];
    const existingItems = itemRule.allowIn.filter((itemToCheck)=>compiledDefinitions[itemToCheck]);
    itemRule.allowIn = Array.from(new Set(existingItems));
}
// Setup allowChildren items based on allowIn.
function setupAllowChildren(compiledDefinitions, itemName) {
    const itemRule = compiledDefinitions[itemName];
    for (const allowedParentItemName of itemRule.allowIn){
        const allowedParentItem = compiledDefinitions[allowedParentItemName];
        allowedParentItem.allowChildren.push(itemName);
    }
}
function cleanUpAllowAttributes(compiledDefinitions, itemName) {
    const itemRule = compiledDefinitions[itemName];
    itemRule.allowAttributes = Array.from(new Set(itemRule.allowAttributes));
}
function copyTypes(sourceItemRules, itemRule) {
    for (const sourceItemRule of sourceItemRules){
        const typeNames = Object.keys(sourceItemRule).filter((name)=>name.startsWith('is'));
        for (const name of typeNames){
            itemRule[name] = !!sourceItemRule[name];
        }
    }
}
function copyProperty(sourceItemRules, itemRule, propertyName) {
    for (const sourceItemRule of sourceItemRules){
        const value = sourceItemRule[propertyName];
        if (typeof value == 'string') {
            itemRule[propertyName].push(value);
        } else if (Array.isArray(value)) {
            itemRule[propertyName].push(...value);
        }
    }
}
function makeInheritAllWork(sourceItemRules, itemRule) {
    for (const sourceItemRule of sourceItemRules){
        const inheritFrom = sourceItemRule.inheritAllFrom;
        if (inheritFrom) {
            itemRule.allowContentOf.push(inheritFrom);
            itemRule.allowWhere.push(inheritFrom);
            itemRule.allowAttributesOf.push(inheritFrom);
            itemRule.inheritTypesFrom.push(inheritFrom);
        }
    }
}
function getAllowedChildren(compiledDefinitions, itemName) {
    const itemRule = compiledDefinitions[itemName];
    return getValues(compiledDefinitions).filter((def)=>def.allowIn.includes(itemRule.name));
}
function getValues(obj) {
    return Object.keys(obj).map((key)=>obj[key]);
}
function mapContextItem(ctxItem) {
    if (typeof ctxItem == 'string' || ctxItem.is('documentFragment')) {
        return {
            name: typeof ctxItem == 'string' ? ctxItem : '$documentFragment',
            *getAttributeKeys () {},
            getAttribute () {}
        };
    } else {
        return {
            // '$text' means text nodes and text proxies.
            name: ctxItem.is('element') ? ctxItem.name : '$text',
            *getAttributeKeys () {
                yield* ctxItem.getAttributeKeys();
            },
            getAttribute (key) {
                return ctxItem.getAttribute(key);
            }
        };
    }
}
/**
 * Generator function returning values from provided walkers, switching between them at each iteration. If only one walker
 * is provided it will return data only from that walker.
 *
 * @param backward Walker iterating in backward direction.
 * @param forward Walker iterating in forward direction.
 * @returns Object returned at each iteration contains `value` and `walker` (informing which walker returned
 * given value) fields.
 */ function* combineWalkers(backward, forward) {
    let done = false;
    while(!done){
        done = true;
        if (backward) {
            const step = backward.next();
            if (!step.done) {
                done = false;
                yield {
                    walker: backward,
                    value: step.value
                };
            }
        }
        if (forward) {
            const step = forward.next();
            if (!step.done) {
                done = false;
                yield {
                    walker: forward,
                    value: step.value
                };
            }
        }
    }
}
/**
 * Takes an array of non-intersecting ranges. For each of them gets minimal flat ranges covering that range and returns
 * all those minimal flat ranges.
 *
 * @param ranges Ranges to process.
 * @returns Minimal flat ranges of given `ranges`.
 */ function* convertToMinimalFlatRanges(ranges) {
    for (const range of ranges){
        yield* range.getMinimalFlatRanges();
    }
}
function removeDisallowedAttributeFromNode(schema, node, writer) {
    for (const attribute of node.getAttributeKeys()){
        if (!schema.checkAttribute(node, attribute)) {
            writer.removeAttribute(attribute, node);
        }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * Abstract base operation class.
 */ __turbopack_context__.s([
    "default",
    ()=>Operation
]);
class Operation {
    /**
     * Base operation constructor.
     *
     * @param baseVersion Document {@link module:engine/model/document~Document#version} on which operation
     * can be applied or `null` if the operation operates on detached (non-document) tree.
     */ constructor(baseVersion){
        this.baseVersion = baseVersion;
        this.isDocumentOperation = this.baseVersion !== null;
        this.batch = null;
    }
    /**
     * Checks whether the operation's parameters are correct and the operation can be correctly executed. Throws
     * an error if operation is not valid.
     *
     * @internal
     */ _validate() {}
    /**
     * Custom toJSON method to solve child-parent circular dependencies.
     *
     * @returns Clone of this object with the operation property replaced with string.
     */ toJSON() {
        // This method creates only a shallow copy, all nested objects should be defined separately.
        // See https://github.com/ckeditor/ckeditor5-engine/issues/1477.
        const json = Object.assign({}, this);
        json.__className = this.constructor.className;
        // Remove reference to the parent `Batch` to avoid circular dependencies.
        delete json.batch;
        // Only document operations are shared with other clients so it is not necessary to keep this information.
        delete json.isDocumentOperation;
        return json;
    }
    /**
     * Name of the operation class used for serialization.
     */ static get className() {
        return 'Operation';
    }
    /**
     * Creates `Operation` object from deserialized object, i.e. from parsed JSON string.
     *
     * @param json Deserialized JSON object.
     * @param doc Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        return new this(json.baseVersion);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/utils
 */ __turbopack_context__.s([
    "_insert",
    ()=>_insert,
    "_move",
    ()=>_move,
    "_normalizeNodes",
    ()=>_normalizeNodes,
    "_remove",
    ()=>_remove,
    "_setAttribute",
    ()=>_setAttribute
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/node.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/textproxy.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/isiterable.js [app-ssr] (ecmascript) <export default as isIterable>");
;
;
;
;
;
function _insert(position, nodes) {
    const normalizedNodes = _normalizeNodes(nodes);
    // We have to count offset before inserting nodes because they can get merged and we would get wrong offsets.
    const offset = normalizedNodes.reduce((sum, node)=>sum + node.offsetSize, 0);
    const parent = position.parent;
    // Insertion might be in a text node, we should split it if that's the case.
    _splitNodeAtPosition(position);
    const index = position.index;
    // Insert nodes at given index. After splitting we have a proper index and insertion is between nodes,
    // using basic `Element` API.
    parent._insertChild(index, normalizedNodes);
    // Merge text nodes, if possible. Merging is needed only at points where inserted nodes "touch" "old" nodes.
    _mergeNodesAtIndex(parent, index + normalizedNodes.length);
    _mergeNodesAtIndex(parent, index);
    return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position, position.getShiftedBy(offset));
}
function _remove(range) {
    if (!range.isFlat) {
        /**
         * Trying to remove a range which starts and ends in different element.
         *
         * @error operation-utils-remove-range-not-flat
         */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('operation-utils-remove-range-not-flat', this);
    }
    const parent = range.start.parent;
    // Range may be inside text nodes, we have to split them if that's the case.
    _splitNodeAtPosition(range.start);
    _splitNodeAtPosition(range.end);
    // Remove the text nodes using basic `Element` API.
    const removed = parent._removeChildren(range.start.index, range.end.index - range.start.index);
    // Merge text nodes, if possible. After some nodes were removed, node before and after removed range will be
    // touching at the position equal to the removed range beginning. We check merging possibility there.
    _mergeNodesAtIndex(parent, range.start.index);
    return removed;
}
function _move(sourceRange, targetPosition) {
    if (!sourceRange.isFlat) {
        /**
         * Trying to move a range which starts and ends in different element.
         *
         * @error operation-utils-move-range-not-flat
         */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('operation-utils-move-range-not-flat', this);
    }
    const nodes = _remove(sourceRange);
    // We have to fix `targetPosition` because model changed after nodes from `sourceRange` got removed and
    // that change might have an impact on `targetPosition`.
    targetPosition = targetPosition._getTransformedByDeletion(sourceRange.start, sourceRange.end.offset - sourceRange.start.offset);
    return _insert(targetPosition, nodes);
}
function _setAttribute(range, key, value) {
    // Range might start or end in text nodes, so we have to split them.
    _splitNodeAtPosition(range.start);
    _splitNodeAtPosition(range.end);
    // Iterate over all items in the range.
    for (const item of range.getItems({
        shallow: true
    })){
        // Iterator will return `TextProxy` instances but we know that those text proxies will
        // always represent full text nodes (this is guaranteed thanks to splitting we did before).
        // So, we can operate on those text proxies' text nodes.
        const node = item.is('$textProxy') ? item.textNode : item;
        if (value !== null) {
            node._setAttribute(key, value);
        } else {
            node._removeAttribute(key);
        }
        // After attributes changing it may happen that some text nodes can be merged. Try to merge with previous node.
        _mergeNodesAtIndex(node.parent, node.index);
    }
    // Try to merge last changed node with it's previous sibling (not covered by the loop above).
    _mergeNodesAtIndex(range.end.parent, range.end.index);
}
function _normalizeNodes(nodes) {
    const normalized = [];
    function convert(nodes) {
        if (typeof nodes == 'string') {
            normalized.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodes));
        } else if (nodes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            normalized.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodes.data, nodes.getAttributes()));
        } else if (nodes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            normalized.push(nodes);
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__["isIterable"])(nodes)) {
            for (const node of nodes){
                convert(node);
            }
        } else {
            // Skip unrecognized type.
            // eslint-disable-next-line @typescript-eslint/no-unused-vars
            const unreachable = nodes;
        }
    }
    convert(nodes);
    // Merge text nodes.
    for(let i = 1; i < normalized.length; i++){
        const node = normalized[i];
        const prev = normalized[i - 1];
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] && prev instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] && _haveSameAttributes(node, prev)) {
            // Doing this instead changing `prev.data` because `data` is readonly.
            normalized.splice(i - 1, 2, new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](prev.data + node.data, prev.getAttributes()));
            i--;
        }
    }
    return normalized;
}
/**
 * Checks if nodes before and after given index in given element are {@link module:engine/model/text~Text text nodes} and
 * merges them into one node if they have same attributes.
 *
 * Merging is done by removing two text nodes and inserting a new text node containing data from both merged text nodes.
 *
 * @param element Parent element of nodes to merge.
 * @param index Index between nodes to merge.
 */ function _mergeNodesAtIndex(element, index) {
    const nodeBefore = element.getChild(index - 1);
    const nodeAfter = element.getChild(index);
    // Check if both of those nodes are text objects with same attributes.
    if (nodeBefore && nodeAfter && nodeBefore.is('$text') && nodeAfter.is('$text') && _haveSameAttributes(nodeBefore, nodeAfter)) {
        // Append text of text node after index to the before one.
        const mergedNode = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodeBefore.data + nodeAfter.data, nodeBefore.getAttributes());
        // Remove separate text nodes.
        element._removeChildren(index - 1, 2);
        // Insert merged text node.
        element._insertChild(index - 1, mergedNode);
    }
}
/**
 * Checks if given position is in a text node, and if so, splits the text node in two text nodes, each of them
 * containing a part of original text node.
 *
 * @param position Position at which node should be split.
 */ function _splitNodeAtPosition(position) {
    const textNode = position.textNode;
    const element = position.parent;
    if (textNode) {
        const offsetDiff = position.offset - textNode.startOffset;
        const index = textNode.index;
        element._removeChildren(index, 1);
        const firstPart = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](textNode.data.substr(0, offsetDiff), textNode.getAttributes());
        const secondPart = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](textNode.data.substr(offsetDiff), textNode.getAttributes());
        element._insertChild(index, [
            firstPart,
            secondPart
        ]);
    }
}
/**
 * Checks whether two given nodes have same attributes.
 *
 * @param nodeA Node to check.
 * @param nodeB Node to check.
 * @returns `true` if nodes have same attributes, `false` otherwise.
 */ function _haveSameAttributes(nodeA, nodeB) {
    const iteratorA = nodeA.getAttributes();
    const iteratorB = nodeB.getAttributes();
    for (const attr of iteratorA){
        if (attr[1] !== nodeB.getAttribute(attr[0])) {
            return false;
        }
        iteratorB.next();
    }
    return iteratorB.next().done;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/moveoperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/moveoperation
 */ __turbopack_context__.s([
    "default",
    ()=>MoveOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/comparearrays.js [app-ssr] (ecmascript) <export default as compareArrays>");
;
;
;
;
;
class MoveOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a move operation.
     *
     * @param sourcePosition Position before the first {@link module:engine/model/item~Item model item} to move.
     * @param howMany Offset size of moved range. Moved range will start from `sourcePosition` and end at
     * `sourcePosition` with offset shifted by `howMany`.
     * @param targetPosition Position at which moved nodes will be inserted.
     * @param baseVersion Document {@link module:engine/model/document~Document#version} on which operation
     * can be applied or `null` if the operation operates on detached (non-document) tree.
     */ constructor(sourcePosition, howMany, targetPosition, baseVersion){
        super(baseVersion);
        this.sourcePosition = sourcePosition.clone();
        // `'toNext'` because `sourcePosition` is a bit like a start of the moved range.
        this.sourcePosition.stickiness = 'toNext';
        this.howMany = howMany;
        this.targetPosition = targetPosition.clone();
        this.targetPosition.stickiness = 'toNone';
    }
    /**
     * @inheritDoc
     */ get type() {
        if (this.targetPosition.root.rootName == '$graveyard') {
            return 'remove';
        } else if (this.sourcePosition.root.rootName == '$graveyard') {
            return 'reinsert';
        }
        return 'move';
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(this.sourcePosition, this.howMany),
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(this.targetPosition, 0)
        ];
    }
    /**
     * Creates and returns an operation that has the same parameters as this operation.
     */ clone() {
        return new MoveOperation(this.sourcePosition, this.howMany, this.targetPosition, this.baseVersion);
    }
    /**
     * Returns the start position of the moved range after it got moved. This may be different than
     * {@link module:engine/model/operation/moveoperation~MoveOperation#targetPosition} in some cases, i.e. when a range is moved
     * inside the same parent but {@link module:engine/model/operation/moveoperation~MoveOperation#targetPosition targetPosition}
     * is after {@link module:engine/model/operation/moveoperation~MoveOperation#sourcePosition sourcePosition}.
     *
     * ```
     *  vv              vv
     * abcdefg ===> adefbcg
     *      ^          ^
     *      targetPos  movedRangeStart
     *      offset 6   offset 4
     *```
     */ getMovedRangeStart() {
        return this.targetPosition._getTransformedByDeletion(this.sourcePosition, this.howMany);
    }
    /**
     * See {@link module:engine/model/operation/operation~Operation#getReversed `Operation#getReversed()`}.
     */ getReversed() {
        const newTargetPosition = this.sourcePosition._getTransformedByInsertion(this.targetPosition, this.howMany);
        return new MoveOperation(this.getMovedRangeStart(), this.howMany, newTargetPosition, this.baseVersion + 1);
    }
    /**
     * @inheritDoc
     * @internal
     */ _validate() {
        const sourceElement = this.sourcePosition.parent;
        const targetElement = this.targetPosition.parent;
        const sourceOffset = this.sourcePosition.offset;
        const targetOffset = this.targetPosition.offset;
        // Validate whether move operation has correct parameters.
        // Validation is pretty complex but move operation is one of the core ways to manipulate the document state.
        // We expect that many errors might be connected with one of scenarios described below.
        if (sourceOffset + this.howMany > sourceElement.maxOffset) {
            /**
             * The nodes which should be moved do not exist.
             *
             * @error move-operation-nodes-do-not-exist
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('move-operation-nodes-do-not-exist', this);
        } else if (sourceElement === targetElement && sourceOffset < targetOffset && targetOffset < sourceOffset + this.howMany) {
            /**
             * Trying to move a range of nodes into the middle of that range.
             *
             * @error move-operation-range-into-itself
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('move-operation-range-into-itself', this);
        } else if (this.sourcePosition.root == this.targetPosition.root) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(this.sourcePosition.getParentPath(), this.targetPosition.getParentPath()) == 'prefix') {
                const i = this.sourcePosition.path.length - 1;
                if (this.targetPosition.path[i] >= sourceOffset && this.targetPosition.path[i] < sourceOffset + this.howMany) {
                    /**
                     * Trying to move a range of nodes into one of nodes from that range.
                     *
                     * @error move-operation-node-into-itself
                     */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('move-operation-node-into-itself', this);
                }
            }
        }
    }
    /**
     * @inheritDoc
     * @internal
     */ _execute() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_move"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(this.sourcePosition, this.howMany), this.targetPosition);
    }
    /**
     * @inheritDoc
     */ toJSON() {
        const json = super.toJSON();
        json.sourcePosition = this.sourcePosition.toJSON();
        json.targetPosition = this.targetPosition.toJSON();
        return json;
    }
    /**
     * @inheritDoc
     */ static get className() {
        return 'MoveOperation';
    }
    /**
     * Creates `MoveOperation` object from deserialized object, i.e. from parsed JSON string.
     *
     * @param json Deserialized JSON object.
     * @param document Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        const sourcePosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.sourcePosition, document);
        const targetPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.targetPosition, document);
        return new this(sourcePosition, json.howMany, targetPosition, json.baseVersion);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/insertoperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/insertoperation
 */ __turbopack_context__.s([
    "default",
    ()=>InsertOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$nodelist$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/nodelist.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/moveoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
;
;
;
;
;
;
class InsertOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates an insert operation.
     *
     * @param position Position of insertion.
     * @param nodes The list of nodes to be inserted.
     * @param baseVersion Document {@link module:engine/model/document~Document#version} on which operation
     * can be applied or `null` if the operation operates on detached (non-document) tree.
     */ constructor(position, nodes, baseVersion){
        super(baseVersion);
        this.position = position.clone();
        this.position.stickiness = 'toNone';
        this.nodes = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$nodelist$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_normalizeNodes"])(nodes));
        this.shouldReceiveAttributes = false;
    }
    /**
     * @inheritDoc
     */ get type() {
        return 'insert';
    }
    /**
     * Total offset size of inserted nodes.
     */ get howMany() {
        return this.nodes.maxOffset;
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        return this.position.clone();
    }
    /**
     * Creates and returns an operation that has the same parameters as this operation.
     */ clone() {
        const nodes = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$nodelist$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]([
            ...this.nodes
        ].map((node)=>node._clone(true)));
        const insert = new InsertOperation(this.position, nodes, this.baseVersion);
        insert.shouldReceiveAttributes = this.shouldReceiveAttributes;
        return insert;
    }
    /**
     * See {@link module:engine/model/operation/operation~Operation#getReversed `Operation#getReversed()`}.
     */ getReversed() {
        const graveyard = this.position.root.document.graveyard;
        const gyPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](graveyard, [
            0
        ]);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.position, this.nodes.maxOffset, gyPosition, this.baseVersion + 1);
    }
    /**
     * @inheritDoc
     * @internal
     */ _validate() {
        const targetElement = this.position.parent;
        if (!targetElement || targetElement.maxOffset < this.position.offset) {
            /**
             * Insertion position is invalid.
             *
             * @error insert-operation-position-invalid
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('insert-operation-position-invalid', this);
        }
    }
    /**
     * @inheritDoc
     * @internal
     */ _execute() {
        // What happens here is that we want original nodes be passed to writer because we want original nodes
        // to be inserted to the model. But in InsertOperation, we want to keep those nodes as they were added
        // to the operation, not modified. For example, text nodes can get merged or cropped while Elements can
        // get children. It is important that InsertOperation has the copy of original nodes in intact state.
        const originalNodes = this.nodes;
        this.nodes = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$nodelist$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]([
            ...originalNodes
        ].map((node)=>node._clone(true)));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_insert"])(this.position, originalNodes);
    }
    /**
     * @inheritDoc
     */ toJSON() {
        const json = super.toJSON();
        json.position = this.position.toJSON();
        json.nodes = this.nodes.toJSON();
        return json;
    }
    /**
     * @inheritDoc
     */ static get className() {
        return 'InsertOperation';
    }
    /**
     * Creates `InsertOperation` object from deserialized object, i.e. from parsed JSON string.
     *
     * @param json Deserialized JSON object.
     * @param document Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        const children = [];
        for (const child of json.nodes){
            if (child.name) {
                // If child has name property, it is an Element.
                children.push(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(child));
            } else {
                // Otherwise, it is a Text node.
                children.push(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(child));
            }
        }
        const insert = new InsertOperation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.position, document), children, json.baseVersion);
        insert.shouldReceiveAttributes = json.shouldReceiveAttributes;
        return insert;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/splitoperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/splitoperation
 */ __turbopack_context__.s([
    "default",
    ()=>SplitOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/mergeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
;
;
;
;
class SplitOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a split operation.
     *
     * @param splitPosition Position at which an element should be split.
     * @param howMany Total offset size of elements that are in the split element after `position`.
     * @param insertionPosition Position at which the clone of split element (or element from graveyard) will be inserted.
     * @param graveyardPosition Position in the graveyard root before the element which
     * should be used as a parent of the nodes after `position`. If it is not set, a copy of the the `position` parent will be used.
     * @param baseVersion Document {@link module:engine/model/document~Document#version} on which operation
     * can be applied or `null` if the operation operates on detached (non-document) tree.
     */ constructor(splitPosition, howMany, insertionPosition, graveyardPosition, baseVersion){
        super(baseVersion);
        this.splitPosition = splitPosition.clone();
        // Keep position sticking to the next node. This way any new content added at the place where the element is split
        // will be left in the original element.
        this.splitPosition.stickiness = 'toNext';
        this.howMany = howMany;
        this.insertionPosition = insertionPosition;
        this.graveyardPosition = graveyardPosition ? graveyardPosition.clone() : null;
        if (this.graveyardPosition) {
            this.graveyardPosition.stickiness = 'toNext';
        }
    }
    /**
     * @inheritDoc
     */ get type() {
        return 'split';
    }
    /**
     * Position inside the new clone of a split element.
     *
     * This is a position where nodes that are after the split position will be moved to.
     */ get moveTargetPosition() {
        const path = this.insertionPosition.path.slice();
        path.push(0);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.insertionPosition.root, path);
    }
    /**
     * Artificial range that contains all the nodes from the split element that will be moved to the new element.
     * The range starts at {@link #splitPosition} and ends in the same parent, at `POSITIVE_INFINITY` offset.
     */ get movedRange() {
        const end = this.splitPosition.getShiftedBy(Number.POSITIVE_INFINITY);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.splitPosition, end);
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        // These could be positions but `Selectable` type only supports `Iterable<Range>`.
        const ranges = [
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(this.splitPosition, 0),
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(this.insertionPosition, 0)
        ];
        if (this.graveyardPosition) {
            ranges.push(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(this.graveyardPosition, 0));
        }
        return ranges;
    }
    /**
     * Creates and returns an operation that has the same parameters as this operation.
     *
     * @returns Clone of this operation.
     */ clone() {
        return new SplitOperation(this.splitPosition, this.howMany, this.insertionPosition, this.graveyardPosition, this.baseVersion);
    }
    /**
     * See {@link module:engine/model/operation/operation~Operation#getReversed `Operation#getReversed()`}.
     */ getReversed() {
        const graveyard = this.splitPosition.root.document.graveyard;
        const graveyardPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](graveyard, [
            0
        ]);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.moveTargetPosition, this.howMany, this.splitPosition, graveyardPosition, this.baseVersion + 1);
    }
    /**
     * @inheritDoc
     * @internal
     */ _validate() {
        const element = this.splitPosition.parent;
        const offset = this.splitPosition.offset;
        // Validate whether split operation has correct parameters.
        if (!element || element.maxOffset < offset) {
            /**
             * Split position is invalid.
             *
             * @error split-operation-position-invalid
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('split-operation-position-invalid', this);
        } else if (!element.parent) {
            /**
             * Cannot split root element.
             *
             * @error split-operation-split-in-root
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('split-operation-split-in-root', this);
        } else if (this.howMany != element.maxOffset - this.splitPosition.offset) {
            /**
             * Split operation specifies wrong number of nodes to move.
             *
             * @error split-operation-how-many-invalid
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('split-operation-how-many-invalid', this);
        } else if (this.graveyardPosition && !this.graveyardPosition.nodeAfter) {
            /**
             * Graveyard position invalid.
             *
             * @error split-operation-graveyard-position-invalid
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('split-operation-graveyard-position-invalid', this);
        }
    }
    /**
     * @inheritDoc
     * @internal
     */ _execute() {
        const splitElement = this.splitPosition.parent;
        if (this.graveyardPosition) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_move"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(this.graveyardPosition, 1), this.insertionPosition);
        } else {
            const newElement = splitElement._clone();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_insert"])(this.insertionPosition, newElement);
        }
        const sourceRange = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(splitElement, this.splitPosition.offset), __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(splitElement, splitElement.maxOffset));
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_move"])(sourceRange, this.moveTargetPosition);
    }
    /**
     * @inheritDoc
     */ toJSON() {
        const json = super.toJSON();
        json.splitPosition = this.splitPosition.toJSON();
        json.insertionPosition = this.insertionPosition.toJSON();
        if (this.graveyardPosition) {
            json.graveyardPosition = this.graveyardPosition.toJSON();
        }
        return json;
    }
    /**
     * @inheritDoc
     */ static get className() {
        return 'SplitOperation';
    }
    /**
     * Helper function that returns a default insertion position basing on given `splitPosition`. The default insertion
     * position is after the split element.
     */ static getInsertionPosition(splitPosition) {
        const path = splitPosition.path.slice(0, -1);
        path[path.length - 1]++;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](splitPosition.root, path, 'toPrevious');
    }
    /**
     * Creates `SplitOperation` object from deserialized object, i.e. from parsed JSON string.
     *
     * @param json Deserialized JSON object.
     * @param document Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        const splitPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.splitPosition, document);
        const insertionPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.insertionPosition, document);
        const graveyardPosition = json.graveyardPosition ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.graveyardPosition, document) : null;
        return new this(splitPosition, json.howMany, insertionPosition, graveyardPosition, json.baseVersion);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/mergeoperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/mergeoperation
 */ __turbopack_context__.s([
    "default",
    ()=>MergeOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/splitoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
;
;
;
;
class MergeOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a merge operation.
     *
     * @param sourcePosition Position inside the merged element. All nodes from that
     * element after that position will be moved to {@link #targetPosition}.
     * @param howMany Summary offset size of nodes which will be moved from the merged element to the new parent.
     * @param targetPosition Position which the nodes from the merged elements will be moved to.
     * @param graveyardPosition Position in graveyard to which the merged element will be moved.
     * @param baseVersion Document {@link module:engine/model/document~Document#version} on which operation
     * can be applied or `null` if the operation operates on detached (non-document) tree.
     */ constructor(sourcePosition, howMany, targetPosition, graveyardPosition, baseVersion){
        super(baseVersion);
        this.sourcePosition = sourcePosition.clone();
        // This is, and should always remain, the first position in its parent.
        this.sourcePosition.stickiness = 'toPrevious';
        this.howMany = howMany;
        this.targetPosition = targetPosition.clone();
        // Except of a rare scenario in `MergeOperation` x `MergeOperation` transformation,
        // this is, and should always remain, the last position in its parent.
        this.targetPosition.stickiness = 'toNext';
        this.graveyardPosition = graveyardPosition.clone();
    }
    /**
     * @inheritDoc
     */ get type() {
        return 'merge';
    }
    /**
     * Position before the merged element (which will be deleted).
     */ get deletionPosition() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.sourcePosition.root, this.sourcePosition.path.slice(0, -1));
    }
    /**
     * Artificial range that contains all the nodes from the merged element that will be moved to {@link ~MergeOperation#sourcePosition}.
     * The range starts at {@link ~MergeOperation#sourcePosition} and ends in the same parent, at `POSITIVE_INFINITY` offset.
     */ get movedRange() {
        const end = this.sourcePosition.getShiftedBy(Number.POSITIVE_INFINITY);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.sourcePosition, end);
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        const mergedElement = this.sourcePosition.parent;
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(mergedElement),
            // These could be positions but `Selectable` type only supports `Iterable<Range>`.
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(this.targetPosition, 0),
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(this.graveyardPosition, 0)
        ];
    }
    /**
     * Creates and returns an operation that has the same parameters as this operation.
     */ clone() {
        return new MergeOperation(this.sourcePosition, this.howMany, this.targetPosition, this.graveyardPosition, this.baseVersion);
    }
    /**
     * See {@link module:engine/model/operation/operation~Operation#getReversed `Operation#getReversed()`}.
     */ getReversed() {
        // Positions in this method are transformed by this merge operation because the split operation bases on
        // the context after this merge operation happened (because split operation reverses it).
        // So we need to acknowledge that the merge operation happened and those positions changed a little.
        const targetPosition = this.targetPosition._getTransformedByMergeOperation(this);
        const path = this.sourcePosition.path.slice(0, -1);
        const insertionPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.sourcePosition.root, path)._getTransformedByMergeOperation(this);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](targetPosition, this.howMany, insertionPosition, this.graveyardPosition, this.baseVersion + 1);
    }
    /**
     * @inheritDoc
     * @internal
     */ _validate() {
        const sourceElement = this.sourcePosition.parent;
        const targetElement = this.targetPosition.parent;
        // Validate whether merge operation has correct parameters.
        if (!sourceElement.parent) {
            /**
             * Merge source position is invalid. The element to be merged must have a parent node.
             *
             * @error merge-operation-source-position-invalid
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('merge-operation-source-position-invalid', this);
        } else if (!targetElement.parent) {
            /**
             * Merge target position is invalid. The element to be merged must have a parent node.
             *
             * @error merge-operation-target-position-invalid
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('merge-operation-target-position-invalid', this);
        } else if (this.howMany != sourceElement.maxOffset) {
            /**
             * Merge operation specifies wrong number of nodes to move.
             *
             * @error merge-operation-how-many-invalid
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('merge-operation-how-many-invalid', this);
        }
    }
    /**
     * @inheritDoc
     * @internal
     */ _execute() {
        const mergedElement = this.sourcePosition.parent;
        const sourceRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(mergedElement);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_move"])(sourceRange, this.targetPosition);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_move"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(mergedElement), this.graveyardPosition);
    }
    /**
     * @inheritDoc
     */ toJSON() {
        const json = super.toJSON();
        json.sourcePosition = json.sourcePosition.toJSON();
        json.targetPosition = json.targetPosition.toJSON();
        json.graveyardPosition = json.graveyardPosition.toJSON();
        return json;
    }
    /**
     * @inheritDoc
     */ static get className() {
        return 'MergeOperation';
    }
    /**
     * Creates `MergeOperation` object from deserialized object, i.e. from parsed JSON string.
     *
     * @param json Deserialized JSON object.
     * @param document Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        const sourcePosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.sourcePosition, document);
        const targetPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.targetPosition, document);
        const graveyardPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.graveyardPosition, document);
        return new this(sourcePosition, json.howMany, targetPosition, graveyardPosition, json.baseVersion);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/markeroperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/markeroperation
 */ __turbopack_context__.s([
    "default",
    ()=>MarkerOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
;
;
class MarkerOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * @param name Marker name.
     * @param oldRange Marker range before the change.
     * @param newRange Marker range after the change.
     * @param markers Marker collection on which change should be executed.
     * @param affectsData Specifies whether the marker operation affects the data produced by the data pipeline
     * (is persisted in the editor's data).
     * @param baseVersion Document {@link module:engine/model/document~Document#version} on which operation
     * can be applied or `null` if the operation operates on detached (non-document) tree.
     */ constructor(name, oldRange, newRange, markers, affectsData, baseVersion){
        super(baseVersion);
        this.name = name;
        this.oldRange = oldRange ? oldRange.clone() : null;
        this.newRange = newRange ? newRange.clone() : null;
        this.affectsData = affectsData;
        this._markers = markers;
    }
    /**
     * @inheritDoc
     */ get type() {
        return 'marker';
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        const ranges = [];
        if (this.oldRange) {
            ranges.push(this.oldRange.clone());
        }
        if (this.newRange) {
            if (this.oldRange) {
                ranges.push(...this.newRange.getDifference(this.oldRange));
            } else {
                ranges.push(this.newRange.clone());
            }
        }
        return ranges;
    }
    /**
     * Creates and returns an operation that has the same parameters as this operation.
     */ clone() {
        return new MarkerOperation(this.name, this.oldRange, this.newRange, this._markers, this.affectsData, this.baseVersion);
    }
    /**
     * See {@link module:engine/model/operation/operation~Operation#getReversed `Operation#getReversed()`}.
     */ getReversed() {
        return new MarkerOperation(this.name, this.newRange, this.oldRange, this._markers, this.affectsData, this.baseVersion + 1);
    }
    /**
     * @inheritDoc
     * @internal
     */ _execute() {
        if (this.newRange) {
            this._markers._set(this.name, this.newRange, true, this.affectsData);
        } else {
            this._markers._remove(this.name);
        }
    }
    /**
     * @inheritDoc
     * @internal
     */ toJSON() {
        const json = super.toJSON();
        if (this.oldRange) {
            json.oldRange = this.oldRange.toJSON();
        }
        if (this.newRange) {
            json.newRange = this.newRange.toJSON();
        }
        delete json._markers;
        return json;
    }
    /**
     * @inheritDoc
     */ static get className() {
        return 'MarkerOperation';
    }
    /**
     * Creates `MarkerOperation` object from deserialized object, i.e. from parsed JSON string.
     *
     * @param json Deserialized JSON object.
     * @param document Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        return new MarkerOperation(json.name, json.oldRange ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.oldRange, document) : null, json.newRange ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.newRange, document) : null, document.model.markers, json.affectsData, json.baseVersion);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/attributeoperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/attributeoperation
 */ __turbopack_context__.s([
    "default",
    ()=>AttributeOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isEqual$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/isEqual.js [app-ssr] (ecmascript) <export default as isEqual>");
;
;
;
;
;
class AttributeOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates an operation that changes, removes or adds attributes.
     *
     * If only `newValue` is set, attribute will be added on a node. Note that all nodes in operation's range must not
     * have an attribute with the same key as the added attribute.
     *
     * If only `oldValue` is set, then attribute with given key will be removed. Note that all nodes in operation's range
     * must have an attribute with that key added.
     *
     * If both `newValue` and `oldValue` are set, then the operation will change the attribute value. Note that all nodes in
     * operation's ranges must already have an attribute with given key and `oldValue` as value
     *
     * @param range Range on which the operation should be applied. Must be a flat range.
     * @param key Key of an attribute to change or remove.
     * @param oldValue Old value of the attribute with given key or `null`, if attribute was not set before.
     * @param newValue New value of the attribute with given key or `null`, if operation should remove attribute.
     * @param baseVersion Document {@link module:engine/model/document~Document#version} on which operation
     * can be applied or `null` if the operation operates on detached (non-document) tree.
     */ constructor(range, key, oldValue, newValue, baseVersion){
        super(baseVersion);
        this.range = range.clone();
        this.key = key;
        this.oldValue = oldValue === undefined ? null : oldValue;
        this.newValue = newValue === undefined ? null : newValue;
    }
    /**
     * @inheritDoc
     */ get type() {
        if (this.oldValue === null) {
            return 'addAttribute';
        } else if (this.newValue === null) {
            return 'removeAttribute';
        } else {
            return 'changeAttribute';
        }
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        return this.range.clone();
    }
    /**
     * Creates and returns an operation that has the same parameters as this operation.
     */ clone() {
        return new AttributeOperation(this.range, this.key, this.oldValue, this.newValue, this.baseVersion);
    }
    /**
     * See {@link module:engine/model/operation/operation~Operation#getReversed `Operation#getReversed()`}.
     */ getReversed() {
        return new AttributeOperation(this.range, this.key, this.newValue, this.oldValue, this.baseVersion + 1);
    }
    /**
     * @inheritDoc
     */ toJSON() {
        const json = super.toJSON();
        json.range = this.range.toJSON();
        return json;
    }
    /**
     * @inheritDoc
     * @internal
     */ _validate() {
        if (!this.range.isFlat) {
            /**
             * The range to change is not flat.
             *
             * @error attribute-operation-range-not-flat
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('attribute-operation-range-not-flat', this);
        }
        for (const item of this.range.getItems({
            shallow: true
        })){
            if (this.oldValue !== null && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isEqual$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__["isEqual"])(item.getAttribute(this.key), this.oldValue)) {
                /**
                 * Changed node has different attribute value than operation's old attribute value.
                 *
                 * @error attribute-operation-wrong-old-value
                 * @param item
                 * @param key
                 * @param value
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('attribute-operation-wrong-old-value', this, {
                    item,
                    key: this.key,
                    value: this.oldValue
                });
            }
            if (this.oldValue === null && this.newValue !== null && item.hasAttribute(this.key)) {
                /**
                 * The attribute with given key already exists for the given node.
                 *
                 * @error attribute-operation-attribute-exists
                 * @param node
                 * @param key
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('attribute-operation-attribute-exists', this, {
                    node: item,
                    key: this.key
                });
            }
        }
    }
    /**
     * @inheritDoc
     * @internal
     */ _execute() {
        // If value to set is same as old value, don't do anything.
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isEqual$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqual$3e$__["isEqual"])(this.oldValue, this.newValue)) {
            // Execution.
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_setAttribute"])(this.range, this.key, this.newValue);
        }
    }
    /**
     * @inheritDoc
     */ static get className() {
        return 'AttributeOperation';
    }
    /**
     * Creates `AttributeOperation` object from deserialized object, i.e. from parsed JSON string.
     *
     * @param json Deserialized JSON object.
     * @param document Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        return new AttributeOperation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.range, document), json.key, json.oldValue, json.newValue, json.baseVersion);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/nooperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/nooperation
 */ __turbopack_context__.s([
    "default",
    ()=>NoOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
;
class NoOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    get type() {
        return 'noop';
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        return null;
    }
    /**
     * Creates and returns an operation that has the same parameters as this operation.
     */ clone() {
        return new NoOperation(this.baseVersion);
    }
    /**
     * See {@link module:engine/model/operation/operation~Operation#getReversed `Operation#getReversed()`}.
     */ getReversed() {
        return new NoOperation(this.baseVersion + 1);
    }
    /** @internal */ _execute() {}
    /**
     * @inheritDoc
     */ static get className() {
        return 'NoOperation';
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/renameoperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/renameoperation
 */ __turbopack_context__.s([
    "default",
    ()=>RenameOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
;
;
class RenameOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates an operation that changes element's name.
     *
     * @param position Position before an element to change.
     * @param oldName Current name of the element.
     * @param newName New name for the element.
     * @param baseVersion Document {@link module:engine/model/document~Document#version} on which operation
     * can be applied or `null` if the operation operates on detached (non-document) tree.
     */ constructor(position, oldName, newName, baseVersion){
        super(baseVersion);
        this.position = position;
        // This position sticks to the next node because it is a position before the node that we want to change.
        this.position.stickiness = 'toNext';
        this.oldName = oldName;
        this.newName = newName;
    }
    /**
     * @inheritDoc
     */ get type() {
        return 'rename';
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        return this.position.nodeAfter;
    }
    /**
     * Creates and returns an operation that has the same parameters as this operation.
     *
     * @returns Clone of this operation.
     */ clone() {
        return new RenameOperation(this.position.clone(), this.oldName, this.newName, this.baseVersion);
    }
    /**
     * See {@link module:engine/model/operation/operation~Operation#getReversed `Operation#getReversed()`}.
     */ getReversed() {
        return new RenameOperation(this.position.clone(), this.newName, this.oldName, this.baseVersion + 1);
    }
    /**
     * @inheritDoc
     * @internal
     */ _validate() {
        const element = this.position.nodeAfter;
        if (!(element instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            /**
             * Given position is invalid or node after it is not instance of Element.
             *
             * @error rename-operation-wrong-position
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('rename-operation-wrong-position', this);
        } else if (element.name !== this.oldName) {
            /**
             * Element to change has different name than operation's old name.
             *
             * @error rename-operation-wrong-name
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('rename-operation-wrong-name', this);
        }
    }
    /**
     * @inheritDoc
     * @internal
     */ _execute() {
        const element = this.position.nodeAfter;
        element.name = this.newName;
    }
    /**
     * @inheritDoc
     */ toJSON() {
        const json = super.toJSON();
        json.position = this.position.toJSON();
        return json;
    }
    /**
     * @inheritDoc
     */ static get className() {
        return 'RenameOperation';
    }
    /**
     * Creates `RenameOperation` object from deserialized object, i.e. from parsed JSON string.
     *
     * @param json Deserialized JSON object.
     * @param document Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        return new RenameOperation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json.position, document), json.oldName, json.newName, json.baseVersion);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootattributeoperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/rootattributeoperation
 */ __turbopack_context__.s([
    "default",
    ()=>RootAttributeOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
class RootAttributeOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates an operation that changes, removes or adds attributes on root element.
     *
     * @see module:engine/model/operation/attributeoperation~AttributeOperation
     * @param root Root element to change.
     * @param key Key of an attribute to change or remove.
     * @param oldValue Old value of the attribute with given key or `null`, if attribute was not set before.
     * @param newValue New value of the attribute with given key or `null`, if operation should remove attribute.
     * @param baseVersion Document {@link module:engine/model/document~Document#version} on which operation
     * can be applied or `null` if the operation operates on detached (non-document) tree.
     */ constructor(root, key, oldValue, newValue, baseVersion){
        super(baseVersion);
        this.root = root;
        this.key = key;
        this.oldValue = oldValue === undefined ? null : oldValue;
        this.newValue = newValue === undefined ? null : newValue;
    }
    /**
     * @inheritDoc
     */ get type() {
        if (this.oldValue === null) {
            return 'addRootAttribute';
        } else if (this.newValue === null) {
            return 'removeRootAttribute';
        } else {
            return 'changeRootAttribute';
        }
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        return this.root;
    }
    /**
     * Creates and returns an operation that has the same parameters as this operation.
     *
     * @returns Clone of this operation.
     */ clone() {
        return new RootAttributeOperation(this.root, this.key, this.oldValue, this.newValue, this.baseVersion);
    }
    /**
     * See {@link module:engine/model/operation/operation~Operation#getReversed `Operation#getReversed()`}.
     */ getReversed() {
        return new RootAttributeOperation(this.root, this.key, this.newValue, this.oldValue, this.baseVersion + 1);
    }
    /**
     * @inheritDoc
     * @internal
     */ _validate() {
        if (this.root != this.root.root || this.root.is('documentFragment')) {
            /**
             * The element to change is not a root element.
             *
             * @error rootattribute-operation-not-a-root
             * @param root
             * @param key
             * @param value
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('rootattribute-operation-not-a-root', this, {
                root: this.root,
                key: this.key
            });
        }
        if (this.oldValue !== null && this.root.getAttribute(this.key) !== this.oldValue) {
            /**
             * The attribute which should be removed does not exist for the given node.
             *
             * @error rootattribute-operation-wrong-old-value
             * @param root
             * @param key
             * @param value
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('rootattribute-operation-wrong-old-value', this, {
                root: this.root,
                key: this.key
            });
        }
        if (this.oldValue === null && this.newValue !== null && this.root.hasAttribute(this.key)) {
            /**
             * The attribute with given key already exists for the given node.
             *
             * @error rootattribute-operation-attribute-exists
             * @param root
             * @param key
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('rootattribute-operation-attribute-exists', this, {
                root: this.root,
                key: this.key
            });
        }
    }
    /**
     * @inheritDoc
     * @internal
     */ _execute() {
        if (this.newValue !== null) {
            this.root._setAttribute(this.key, this.newValue);
        } else {
            this.root._removeAttribute(this.key);
        }
    }
    /**
     * @inheritDoc
     */ toJSON() {
        const json = super.toJSON();
        json.root = this.root.toJSON();
        return json;
    }
    /**
     * @inheritDoc
     */ static get className() {
        return 'RootAttributeOperation';
    }
    /**
     * Creates `RootAttributeOperation` object from deserialized object, i.e. from parsed JSON string.
     *
     * @param json Deserialized JSON object.
     * @param document Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        if (!document.getRoot(json.root)) {
            /**
             * Cannot create RootAttributeOperation for document. Root with specified name does not exist.
             *
             * @error rootattribute-operation-fromjson-no-root
             * @param rootName
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('rootattribute-operation-fromjson-no-root', this, {
                rootName: json.root
            });
        }
        return new RootAttributeOperation(document.getRoot(json.root), json.key, json.oldValue, json.newValue, json.baseVersion);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootoperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/rootoperation
 */ __turbopack_context__.s([
    "default",
    ()=>RootOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
;
class RootOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates an operation that creates or removes a root element.
     *
     * @param rootName Root name to create or detach.
     * @param elementName Root element name.
     * @param isAdd Specifies whether the operation adds (`true`) or detaches the root (`false`).
     * @param document Document which owns the root.
     * @param baseVersion Document {@link module:engine/model/document~Document#version} on which operation can be applied.
     */ constructor(rootName, elementName, isAdd, document, baseVersion){
        super(baseVersion);
        this.rootName = rootName;
        this.elementName = elementName;
        this.isAdd = isAdd;
        this._document = document;
        // Make sure that the root exists ASAP, this is important for RTC.
        // If the root was dynamically added, there will be more operations that operate on/in this root.
        // These operations will require root element instance (in operation property or in position instance).
        // If the root is not created ahead of time, instantiating such operations may fail.
        if (!this._document.getRoot(this.rootName)) {
            const root = this._document.createRoot(this.elementName, this.rootName);
            root._isAttached = false;
        }
    }
    /**
     * @inheritDoc
     */ get type() {
        return this.isAdd ? 'addRoot' : 'detachRoot';
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        return this._document.getRoot(this.rootName);
    }
    /**
     * @inheritDoc
     */ clone() {
        return new RootOperation(this.rootName, this.elementName, this.isAdd, this._document, this.baseVersion);
    }
    /**
     * @inheritDoc
     */ getReversed() {
        return new RootOperation(this.rootName, this.elementName, !this.isAdd, this._document, this.baseVersion + 1);
    }
    /**
     * @inheritDoc
     */ _execute() {
        this._document.getRoot(this.rootName)._isAttached = this.isAdd;
    }
    /**
     * @inheritDoc
     */ toJSON() {
        const json = super.toJSON();
        delete json._document;
        return json;
    }
    /**
     * @inheritDoc
     */ static get className() {
        return 'RootOperation';
    }
    /**
     * Creates `RootOperation` object from deserialized object, i.e. from parsed JSON string.
     *
     * @param json Deserialized JSON object.
     * @param document Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        return new RootOperation(json.rootName, json.elementName, json.isAdd, document, json.baseVersion);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operationfactory.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/operationfactory
 */ __turbopack_context__.s([
    "default",
    ()=>OperationFactory
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/attributeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/insertoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/markeroperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/moveoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/nooperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/renameoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootattributeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/splitoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/mergeoperation.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
const operations = {};
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
operations[__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].className] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"];
class OperationFactory {
    /**
     * Creates an operation instance from a JSON object (parsed JSON string).
     *
     * @param json Deserialized JSON object.
     * @param document Document on which this operation will be applied.
     */ static fromJSON(json, document) {
        return operations[json.__className].fromJSON(json, document);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/transform.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/transform
 */ __turbopack_context__.s([
    "transform",
    ()=>transform,
    "transformSets",
    ()=>transformSets
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/insertoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/attributeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/renameoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/markeroperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/moveoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootattributeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/mergeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/splitoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/nooperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/comparearrays.js [app-ssr] (ecmascript) <export default as compareArrays>");
;
;
;
;
;
;
;
;
;
;
;
;
;
const transformations = new Map();
/**
 * Sets a transformation function to be be used to transform instances of class `OperationA` by instances of class `OperationB`.
 *
 * The `transformationFunction` is passed three parameters:
 *
 * * `a` - operation to be transformed, an instance of `OperationA`,
 * * `b` - operation to be transformed by, an instance of `OperationB`,
 * * {@link module:engine/model/operation/transform~TransformationContext `context`} - object with additional information about
 * transformation context.
 *
 * The `transformationFunction` should return transformation result, which is an array with one or multiple
 * {@link module:engine/model/operation/operation~Operation operation} instances.
 *
 * @param transformationFunction Function to use for transforming.
 */ function setTransformation(OperationA, OperationB, transformationFunction) {
    let aGroup = transformations.get(OperationA);
    if (!aGroup) {
        aGroup = new Map();
        transformations.set(OperationA, aGroup);
    }
    aGroup.set(OperationB, transformationFunction);
}
/**
 * Returns a previously set transformation function for transforming an instance of `OperationA` by an instance of `OperationB`.
 *
 * If no transformation was set for given pair of operations, {@link module:engine/model/operation/transform~noUpdateTransformation}
 * is returned. This means that if no transformation was set, the `OperationA` instance will not change when transformed
 * by the `OperationB` instance.
 *
 * @returns Function set to transform an instance of `OperationA` by an instance of `OperationB`.
 */ function getTransformation(OperationA, OperationB) {
    const aGroup = transformations.get(OperationA);
    if (aGroup && aGroup.has(OperationB)) {
        return aGroup.get(OperationB);
    }
    return noUpdateTransformation;
}
/**
 * A transformation function that only clones operation to transform, without changing it.
 */ function noUpdateTransformation(a) {
    return [
        a
    ];
}
function transform(a, b, context = {}) {
    const transformationFunction = getTransformation(a.constructor, b.constructor);
    /* eslint-disable no-useless-catch */ try {
        a = a.clone();
        return transformationFunction(a, b, context);
    } catch (e) {
        // @if CK_DEBUG // console.warn( 'Error during operation transformation!', e.message );
        // @if CK_DEBUG // console.warn( 'Transformed operation', a );
        // @if CK_DEBUG // console.warn( 'Operation transformed by', b );
        // @if CK_DEBUG // console.warn( 'context.aIsStrong', context.aIsStrong );
        // @if CK_DEBUG // console.warn( 'context.aWasUndone', context.aWasUndone );
        // @if CK_DEBUG // console.warn( 'context.bWasUndone', context.bWasUndone );
        // @if CK_DEBUG // console.warn( 'context.abRelation', context.abRelation );
        // @if CK_DEBUG // console.warn( 'context.baRelation', context.baRelation );
        throw e;
    }
/* eslint-enable no-useless-catch */ }
function transformSets(operationsA, operationsB, options) {
    // Create new arrays so the originally passed arguments are not changed.
    // No need to clone operations, they are cloned as they are transformed.
    operationsA = operationsA.slice();
    operationsB = operationsB.slice();
    const contextFactory = new ContextFactory(options.document, options.useRelations, options.forceWeakRemove);
    contextFactory.setOriginalOperations(operationsA);
    contextFactory.setOriginalOperations(operationsB);
    const originalOperations = contextFactory.originalOperations;
    // If one of sets is empty there is simply nothing to transform, so return sets as they are.
    if (operationsA.length == 0 || operationsB.length == 0) {
        return {
            operationsA,
            operationsB,
            originalOperations
        };
    }
    //
    // Following is a description of transformation process:
    //
    // There are `operationsA` and `operationsB` to be transformed, both by both.
    //
    // So, suppose we have sets of two operations each: `operationsA` = `[ a1, a2 ]`, `operationsB` = `[ b1, b2 ]`.
    //
    // Remember, that we can only transform operations that base on the same context. We assert that `a1` and `b1` base on
    // the same context and we transform them. Then, we get `a1'` and `b1'`. `a2` bases on a context with `a1` -- `a2`
    // is an operation that followed `a1`. Similarly, `b2` bases on a context with `b1`.
    //
    // However, since `a1'` is a result of transformation by `b1`, `a1'` now also has a context with `b1`. This means that
    // we can safely transform `a1'` by `b2`. As we finish transforming `a1`, we also transformed all `operationsB`.
    // All `operationsB` also have context including `a1`. Now, we can properly transform `a2` by those operations.
    //
    // The transformation process can be visualized on a transformation diagram ("diamond diagram"):
    //
    //          [the initial state]
    //         [common for a1 and b1]
    //
    //                   *
    //                  / \
    //                 /   \
    //               b1     a1
    //               /       \
    //              /         \
    //             *           *
    //            / \         / \
    //           /   \       /   \
    //         b2    a1'   b1'    a2
    //         /       \   /       \
    //        /         \ /         \
    //       *           *           *
    //        \         / \         /
    //         \       /   \       /
    //        a1''   b2'   a2'   b1''
    //           \   /       \   /
    //            \ /         \ /
    //             *           *
    //              \         /
    //               \       /
    //              a2''   b2''
    //                 \   /
    //                  \ /
    //                   *
    //
    //           [the final state]
    //
    // The final state can be reached from the initial state by applying `a1`, `a2`, `b1''` and `b2''`, as well as by
    // applying `b1`, `b2`, `a1''`, `a2''`. Note how the operations get to a proper common state before each pair is
    // transformed.
    //
    // Another thing to consider is that an operation during transformation can be broken into multiple operations.
    // Suppose that `a1` * `b1` = `[ a11', a12' ]` (instead of `a1'` that we considered previously).
    //
    // In that case, we leave `a12'` for later and we continue transforming `a11'` until it is transformed by all `operationsB`
    // (in our case it is just `b2`). At this point, `b1` is transformed by "whole" `a1`, while `b2` is only transformed
    // by `a11'`. Similarly, `a12'` is only transformed by `b1`. This leads to a conclusion that we need to start transforming `a12'`
    // from the moment just after it was broken. So, `a12'` is transformed by `b2`. Now, "the whole" `a1` is transformed
    // by `operationsB`, while all `operationsB` are transformed by "the whole" `a1`. This means that we can continue with
    // following `operationsA` (in our case it is just `a2`).
    //
    // Of course, also `operationsB` can be broken. However, since we focus on transforming operation `a` to the end,
    // the only thing to do is to store both pieces of operation `b`, so that the next transformed operation `a` will
    // be transformed by both of them.
    //
    //                       *
    //                      / \
    //                     /   \
    //                    /     \
    //                  b1       a1
    //                  /         \
    //                 /           \
    //                /             \
    //               *               *
    //              / \             / \
    //             /  a11'         /   \
    //            /     \         /     \
    //          b2       *      b1'      a2
    //          /       / \     /         \
    //         /       /  a12' /           \
    //        /       /     \ /             \
    //       *       b2'     *               *
    //        \     /       / \             /
    //       a11'' /     b21'' \           /
    //          \ /       /     \         /
    //           *       *      a2'     b1''
    //            \     / \       \     /
    //          a12'' b22''\       \   /
    //              \ /     \       \ /
    //               *      a2''     *
    //                \       \     /
    //                 \       \  b21'''
    //                  \       \ /
    //                a2'''      *
    //                    \     /
    //                     \  b22'''
    //                      \ /
    //                       *
    //
    // Note, how `a1` is broken and transformed into `a11'` and `a12'`, while `b2'` got broken and transformed into `b21''` and `b22''`.
    //
    // Having all that on mind, here is an outline for the transformation process algorithm:
    //
    // 1. We have `operationsA` and `operationsB` array, which we dynamically update as the transformation process goes.
    //
    // 2. We take next (or first) operation from `operationsA` and check from which operation `b` we need to start transforming it.
    // All original `operationsA` are set to be transformed starting from the first operation `b`.
    //
    // 3. We take operations from `operationsB`, one by one, starting from the correct one, and transform operation `a`
    // by operation `b` (and vice versa). We update `operationsA` and `operationsB` by replacing the original operations
    // with the transformation results.
    //
    // 4. If operation is broken into multiple operations, we save all the new operations in the place of the
    // original operation.
    //
    // 5. Additionally, if operation `a` was broken, for the "new" operation, we remember from which operation `b` it should
    // be transformed by.
    //
    // 6. We continue transforming "current" operation `a` until it is transformed by all `operationsB`. Then, go to 2.
    // unless the last operation `a` was transformed.
    //
    // The actual implementation of the above algorithm is slightly different, as only one loop (while) is used.
    // The difference is that we have "current" `a` operation to transform and we store the index of the next `b` operation
    // to transform by. Each loop operates on two indexes then: index pointing to currently processed `a` operation and
    // index pointing to next `b` operation. Each loop is just one `a * b` + `b * a` transformation. After each loop
    // operation `b` index is updated. If all `b` operations were visited for the current `a` operation, we change
    // current `a` operation index to the next one.
    //
    // For each operation `a`, keeps information what is the index in `operationsB` from which the transformation should start.
    const nextTransformIndex = new WeakMap();
    // For all the original `operationsA`, set that they should be transformed starting from the first of `operationsB`.
    for (const op of operationsA){
        nextTransformIndex.set(op, 0);
    }
    // Additional data that is used for some postprocessing after the main transformation process is done.
    const data = {
        nextBaseVersionA: operationsA[operationsA.length - 1].baseVersion + 1,
        nextBaseVersionB: operationsB[operationsB.length - 1].baseVersion + 1,
        originalOperationsACount: operationsA.length,
        originalOperationsBCount: operationsB.length
    };
    // Index of currently transformed operation `a`.
    let i = 0;
    // While not all `operationsA` are transformed...
    while(i < operationsA.length){
        // Get "current" operation `a`.
        const opA = operationsA[i];
        // For the "current" operation `a`, get the index of the next operation `b` to transform by.
        const indexB = nextTransformIndex.get(opA);
        // If operation `a` was already transformed by every operation `b`, change "current" operation `a` to the next one.
        if (indexB == operationsB.length) {
            i++;
            continue;
        }
        const opB = operationsB[indexB];
        // Transform `a` by `b` and `b` by `a`.
        const newOpsA = transform(opA, opB, contextFactory.getContext(opA, opB, true));
        const newOpsB = transform(opB, opA, contextFactory.getContext(opB, opA, false));
        // As a result we get one or more `newOpsA` and one or more `newOpsB` operations.
        // Update contextual information about operations.
        contextFactory.updateRelation(opA, opB);
        contextFactory.setOriginalOperations(newOpsA, opA);
        contextFactory.setOriginalOperations(newOpsB, opB);
        // For new `a` operations, update their index of the next operation `b` to transform them by.
        //
        // This is needed even if there was only one result (`a` was not broken) because that information is used
        // at the beginning of this loop every time.
        for (const newOpA of newOpsA){
            // Acknowledge, that operation `b` also might be broken into multiple operations.
            //
            // This is why we raise `indexB` not just by 1. If `newOpsB` are multiple operations, they will be
            // spliced in the place of `opB`. So we need to change `transformBy` accordingly, so that an operation won't
            // be transformed by the same operation (part of it) again.
            nextTransformIndex.set(newOpA, indexB + newOpsB.length);
        }
        // Update `operationsA` and `operationsB` with the transformed versions.
        operationsA.splice(i, 1, ...newOpsA);
        operationsB.splice(indexB, 1, ...newOpsB);
    }
    if (options.padWithNoOps) {
        // If no-operations padding is enabled, count how many extra `a` and `b` operations were generated.
        const brokenOperationsACount = operationsA.length - data.originalOperationsACount;
        const brokenOperationsBCount = operationsB.length - data.originalOperationsBCount;
        // Then, if that number is not the same, pad `operationsA` or `operationsB` with correct number of no-ops so
        // that the base versions are equalled.
        //
        // Note that only one array will be updated, as only one of those subtractions can be greater than zero.
        padWithNoOps(operationsA, brokenOperationsBCount - brokenOperationsACount);
        padWithNoOps(operationsB, brokenOperationsACount - brokenOperationsBCount);
    }
    // Finally, update base versions of transformed operations.
    updateBaseVersions(operationsA, data.nextBaseVersionB);
    updateBaseVersions(operationsB, data.nextBaseVersionA);
    return {
        operationsA,
        operationsB,
        originalOperations
    };
}
/**
 * Gathers additional data about operations processed during transformation. Can be used to obtain contextual information
 * about two operations that are about to be transformed. This contextual information can be used for better conflict resolution.
 */ class ContextFactory {
    /**
     * Creates `ContextFactory` instance.
     *
     * @param document Document which the operations change.
     * @param useRelations Whether during transformation relations should be used (used during undo for
     * better conflict resolution).
     * @param forceWeakRemove If set to `false`, remove operation will be always stronger than move operation,
     * so the removed nodes won't end up back in the document root. When set to `true`, context data will be used.
     */ constructor(document, useRelations, forceWeakRemove = false){
        // For each operation that is created during transformation process, we keep a reference to the original operation
        // which it comes from. The original operation works as a kind of "identifier". Every contextual information
        // gathered during transformation that we want to save for given operation, is actually saved for the original operation.
        // This way no matter if operation `a` is cloned, then transformed, even breaks, we still have access to the previously
        // gathered data through original operation reference.
        this.originalOperations = new Map();
        // `model.History` instance which information about undone operations will be taken from.
        this._history = document.history;
        // Whether additional context should be used.
        this._useRelations = useRelations;
        this._forceWeakRemove = !!forceWeakRemove;
        // Relations is a double-map structure (maps in map) where for two operations we store how those operations were related
        // to each other. Those relations are evaluated during transformation process. For every transformated pair of operations
        // we keep relations between them.
        this._relations = new Map();
    }
    /**
     * Sets "original operation" for given operations.
     *
     * During transformation process, operations are cloned, then changed, then processed again, sometimes broken into two
     * or multiple operations. When gathering additional data it is important that all operations can be somehow linked
     * so a cloned and transformed "version" still kept track of the data assigned earlier to it.
     *
     * The original operation object will be used as such an universal linking id. Throughout the transformation process
     * all cloned operations will refer to "the original operation" when storing and reading additional data.
     *
     * If `takeFrom` is not set, each operation from `operations` array will be assigned itself as "the original operation".
     * This should be used as an initialization step.
     *
     * If `takeFrom` is set, each operation from `operations` will be assigned the same original operation as assigned
     * for `takeFrom` operation. This should be used to update original operations. It should be used in a way that
     * `operations` are the result of `takeFrom` transformation to ensure proper "original operation propagation".
     */ setOriginalOperations(operations, takeFrom = null) {
        const originalOperation = takeFrom ? this.originalOperations.get(takeFrom) : null;
        for (const operation of operations){
            this.originalOperations.set(operation, originalOperation || operation);
        }
    }
    /**
     * Saves a relation between operations `opA` and `opB`.
     *
     * Relations are then later used to help solve conflicts when operations are transformed.
     */ updateRelation(opA, opB) {
        // The use of relations is described in a bigger detail in transformation functions.
        //
        // In brief, this function, for specified pairs of operation types, checks how positions defined in those operations relate.
        // Then those relations are saved. For example, for two move operations, it is saved if one of those operations target
        // position is before the other operation source position. This kind of information gives contextual information when
        // transformation is used during undo. Similar checks are done for other pairs of operations.
        //
        if (opA instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            if (opB instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                if (opA.targetPosition.isEqual(opB.sourcePosition) || opB.movedRange.containsPosition(opA.targetPosition)) {
                    this._setRelation(opA, opB, 'insertAtSource');
                } else if (opA.targetPosition.isEqual(opB.deletionPosition)) {
                    this._setRelation(opA, opB, 'insertBetween');
                } else if (opA.targetPosition.isAfter(opB.sourcePosition)) {
                    this._setRelation(opA, opB, 'moveTargetAfter');
                }
            } else if (opB instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                if (opA.targetPosition.isEqual(opB.sourcePosition) || opA.targetPosition.isBefore(opB.sourcePosition)) {
                    this._setRelation(opA, opB, 'insertBefore');
                } else {
                    this._setRelation(opA, opB, 'insertAfter');
                }
            }
        } else if (opA instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            if (opB instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                if (opA.splitPosition.isBefore(opB.sourcePosition)) {
                    this._setRelation(opA, opB, 'splitBefore');
                }
            } else if (opB instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                if (opA.splitPosition.isEqual(opB.sourcePosition) || opA.splitPosition.isBefore(opB.sourcePosition)) {
                    this._setRelation(opA, opB, 'splitBefore');
                } else {
                    const range = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(opB.sourcePosition, opB.howMany);
                    if (opA.splitPosition.hasSameParentAs(opB.sourcePosition) && range.containsPosition(opA.splitPosition)) {
                        const howMany = range.end.offset - opA.splitPosition.offset;
                        const offset = opA.splitPosition.offset - range.start.offset;
                        this._setRelation(opA, opB, {
                            howMany,
                            offset
                        });
                    }
                }
            }
        } else if (opA instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            if (opB instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                if (!opA.targetPosition.isEqual(opB.sourcePosition)) {
                    this._setRelation(opA, opB, 'mergeTargetNotMoved');
                }
                if (opA.sourcePosition.isEqual(opB.targetPosition)) {
                    this._setRelation(opA, opB, 'mergeSourceNotMoved');
                }
                if (opA.sourcePosition.isEqual(opB.sourcePosition)) {
                    this._setRelation(opA, opB, 'mergeSameElement');
                }
            } else if (opB instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                if (opA.sourcePosition.isEqual(opB.splitPosition)) {
                    this._setRelation(opA, opB, 'splitAtSource');
                }
            } else if (opB instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] && opB.howMany > 0) {
                if (opA.sourcePosition.isEqual(opB.sourcePosition.getShiftedBy(opB.howMany))) {
                    this._setRelation(opA, opB, 'mergeSourceAffected');
                }
                if (opA.targetPosition.isEqual(opB.sourcePosition)) {
                    this._setRelation(opA, opB, 'mergeTargetWasBefore');
                }
            }
        } else if (opA instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            const markerRange = opA.newRange;
            if (!markerRange) {
                return;
            }
            if (opB instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                const movedRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(opB.sourcePosition, opB.howMany);
                const affectedLeft = movedRange.containsPosition(markerRange.start) || movedRange.start.isEqual(markerRange.start);
                const affectedRight = movedRange.containsPosition(markerRange.end) || movedRange.end.isEqual(markerRange.end);
                if ((affectedLeft || affectedRight) && !movedRange.containsRange(markerRange)) {
                    this._setRelation(opA, opB, {
                        side: affectedLeft ? 'left' : 'right',
                        path: affectedLeft ? markerRange.start.path.slice() : markerRange.end.path.slice()
                    });
                }
            } else if (opB instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                const wasInLeftElement = markerRange.start.isEqual(opB.targetPosition);
                const wasStartBeforeMergedElement = markerRange.start.isEqual(opB.deletionPosition);
                const wasEndBeforeMergedElement = markerRange.end.isEqual(opB.deletionPosition);
                const wasInRightElement = markerRange.end.isEqual(opB.sourcePosition);
                if (wasInLeftElement || wasStartBeforeMergedElement || wasEndBeforeMergedElement || wasInRightElement) {
                    this._setRelation(opA, opB, {
                        wasInLeftElement,
                        wasStartBeforeMergedElement,
                        wasEndBeforeMergedElement,
                        wasInRightElement
                    });
                }
            }
        }
    }
    /**
     * Evaluates and returns contextual information about two given operations `opA` and `opB` which are about to be transformed.
     */ getContext(opA, opB, aIsStrong) {
        return {
            aIsStrong,
            aWasUndone: this._wasUndone(opA),
            bWasUndone: this._wasUndone(opB),
            abRelation: this._useRelations ? this._getRelation(opA, opB) : null,
            baRelation: this._useRelations ? this._getRelation(opB, opA) : null,
            forceWeakRemove: this._forceWeakRemove
        };
    }
    /**
     * Returns whether given operation `op` has already been undone.
     *
     * Information whether an operation was undone gives more context when making a decision when two operations are in conflict.
     */ _wasUndone(op) {
        // For `op`, get its original operation. After all, if `op` is a clone (or even transformed clone) of another
        // operation, literally `op` couldn't be undone. It was just generated. If anything, it was the operation it origins
        // from which was undone. So get that original operation.
        const originalOp = this.originalOperations.get(op);
        // And check with the document if the original operation was undone.
        return originalOp.wasUndone || this._history.isUndoneOperation(originalOp);
    }
    /**
     * Returns a relation between `opA` and an operation which is undone by `opB`. This can be `String` value if a relation
     * was set earlier or `null` if there was no relation between those operations.
     *
     * This is a little tricky to understand, so let's compare it to `ContextFactory#_wasUndone`.
     *
     * When `wasUndone( opB )` is used, we check if the `opB` has already been undone. It is obvious, that the
     * undoing operation must happen after the undone operation. So, essentially, we have `opB`, we take document history,
     * we look forward in the future and ask if in that future `opB` was undone.
     *
     * Relations is a backward process to `wasUndone()`.
     *
     * Long story short - using relations is asking what happened in the past. Looking back. This time we have an undoing
     * operation `opB` which has undone some other operation. When there is a transformation `opA` x `opB` and there is
     * a conflict to solve and `opB` is an undoing operation, we can look back in the history and see what was a relation
     * between `opA` and the operation which `opB` undone. Basing on that relation from the past, we can now make
     * a better decision when resolving a conflict between two operations, because we know more about the context of
     * those two operations.
     *
     * This is why this function does not return a relation directly between `opA` and `opB` because we need to look
     * back to search for a meaningful contextual information.
     */ _getRelation(opA, opB) {
        // Get the original operation. Similarly as in `wasUndone()` it is used as an universal identifier for stored data.
        const origB = this.originalOperations.get(opB);
        const undoneB = this._history.getUndoneOperation(origB);
        // If `opB` is not undoing any operation, there is no relation.
        if (!undoneB) {
            return null;
        }
        const origA = this.originalOperations.get(opA);
        const relationsA = this._relations.get(origA);
        // Get all relations for `opA`, and check if there is a relation with `opB`-undone-counterpart. If so, return it.
        if (relationsA) {
            return relationsA.get(undoneB) || null;
        }
        return null;
    }
    /**
     * Helper function for `ContextFactory#updateRelations`.
     */ _setRelation(opA, opB, relation) {
        // As always, setting is for original operations, not the clones/transformed operations.
        const origA = this.originalOperations.get(opA);
        const origB = this.originalOperations.get(opB);
        let relationsA = this._relations.get(origA);
        if (!relationsA) {
            relationsA = new Map();
            this._relations.set(origA, relationsA);
        }
        relationsA.set(origB, relation);
    }
}
/**
 * An utility function that updates {@link module:engine/model/operation/operation~Operation#baseVersion base versions}
 * of passed operations.
 *
 * The function simply sets `baseVersion` as a base version of the first passed operation and then increments it for
 * each following operation in `operations`.
 *
 * @param operations Operations to update.
 * @param baseVersion Base version to set for the first operation in `operations`.
 */ function updateBaseVersions(operations, baseVersion) {
    for (const operation of operations){
        operation.baseVersion = baseVersion++;
    }
}
/**
 * Adds `howMany` instances of {@link module:engine/model/operation/nooperation~NoOperation} to `operations` set.
 */ function padWithNoOps(operations, howMany) {
    for(let i = 0; i < howMany; i++){
        operations.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0));
    }
}
// -----------------------
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    // If operations in conflict, check if their ranges intersect and manage them properly.
    //
    // Operations can be in conflict only if:
    //
    // * their key is the same (they change the same attribute), and
    // * they are in the same parent (operations for ranges [ 1 ] - [ 3 ] and [ 2, 0 ] - [ 2, 5 ] change different
    // elements and can't be in conflict).
    if (a.key === b.key && a.range.start.hasSameParentAs(b.range.start)) {
        // First, we want to apply change to the part of a range that has not been changed by the other operation.
        const operations = a.range.getDifference(b.range).map((range)=>{
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range, a.key, a.oldValue, a.newValue, 0);
        });
        // Then we take care of the common part of ranges.
        const common = a.range.getIntersection(b.range);
        if (common) {
            // If this operation is more important, we also want to apply change to the part of the
            // original range that has already been changed by the other operation. Since that range
            // got changed we also have to update `oldValue`.
            if (context.aIsStrong) {
                operations.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](common, b.key, b.newValue, a.newValue, 0));
            }
        }
        if (operations.length == 0) {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
            ];
        }
        return operations;
    } else {
        // If operations don't conflict, simply return an array containing just a clone of this operation.
        return [
            a
        ];
    }
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    // Case 1:
    //
    // The attribute operation range includes the position where nodes were inserted.
    // There are two possible scenarios: the inserted nodes were text and they should receive attributes or
    // the inserted nodes were elements and they should not receive attributes.
    //
    if (a.range.start.hasSameParentAs(b.position) && a.range.containsPosition(b.position)) {
        // If new nodes should not receive attributes, two separated ranges will be returned.
        // Otherwise, one expanded range will be returned.
        const range = a.range._getTransformedByInsertion(b.position, b.howMany, !b.shouldReceiveAttributes);
        const result = range.map((r)=>{
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](r, a.key, a.oldValue, a.newValue, a.baseVersion);
        });
        if (b.shouldReceiveAttributes) {
            // `AttributeOperation#range` includes some newly inserted text.
            // The operation should also change the attribute of that text. An example:
            //
            // Bold should be applied on the following range:
            // <p>Fo[zb]ar</p>
            //
            // In meantime, new text is typed:
            // <p>Fozxxbar</p>
            //
            // Bold should be applied also on the new text:
            // <p>Fo[zxxb]ar</p>
            // <p>Fo<$text bold="true">zxxb</$text>ar</p>
            //
            // There is a special case to consider here to consider.
            //
            // Consider setting an attribute with multiple possible values, for example `highlight`. The inserted text might
            // have already an attribute value applied and the `oldValue` property of the attribute operation might be wrong:
            //
            // Attribute `highlight="yellow"` should be applied on the following range:
            // <p>Fo[zb]ar<p>
            //
            // In meantime, character `x` with `highlight="red"` is typed:
            // <p>Fo[z<$text highlight="red">x</$text>b]ar</p>
            //
            // In this case we cannot simply apply operation changing the attribute value from `null` to `"yellow"` for the whole range
            // because that would lead to an exception (`oldValue` is incorrect for `x`).
            //
            // We also cannot break the original range as this would mess up a scenario when there are multiple following
            // insert operations, because then only the first inserted character is included in those ranges:
            // <p>Fo[z][x][b]ar</p>   -->   <p>Fo[z][x]x[b]ar</p>   -->   <p>Fo[z][x]xx[b]ar</p>
            //
            // So, the attribute range needs be expanded, no matter what attributes are set on the inserted nodes:
            //
            // <p>Fo[z<$text highlight="red">x</$text>b]ar</p>      <--- Change from `null` to `yellow`, throwing an exception.
            //
            // But before that operation would be applied, we will add an additional attribute operation that will change
            // attributes on the inserted nodes in a way which would make the original operation correct:
            //
            // <p>Fo[z{<$text highlight="red">}x</$text>b]ar</p>    <--- Change range `{}` from `red` to `null`.
            // <p>Fo[zxb]ar</p>                                     <--- Now change from `null` to `yellow` is completely fine.
            //
            // Generate complementary attribute operation. Be sure to add it before the original operation.
            const op = _getComplementaryAttributeOperations(b, a.key, a.oldValue);
            if (op) {
                result.unshift(op);
            }
        }
        // If nodes should not receive new attribute, we are done here.
        return result;
    }
    // If insert operation is not expanding the attribute operation range, simply transform the range.
    a.range = a.range._getTransformedByInsertion(b.position, b.howMany, false)[0];
    return [
        a
    ];
});
/**
 * Helper function for `AttributeOperation` x `InsertOperation` (and reverse) transformation.
 *
 * For given `insertOperation` it checks the inserted node if it has an attribute `key` set to a value different
 * than `newValue`. If so, it generates an `AttributeOperation` which changes the value of `key` attribute to `newValue`.
 */ function _getComplementaryAttributeOperations(insertOperation, key, newValue) {
    const nodes = insertOperation.nodes;
    // At the beginning we store the attribute value from the first node.
    const insertValue = nodes.getNode(0).getAttribute(key);
    if (insertValue == newValue) {
        return null;
    }
    const range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](insertOperation.position, insertOperation.position.getShiftedBy(insertOperation.howMany));
    return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range, key, insertValue, newValue, 0);
}
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    const ranges = [];
    // Case 1:
    //
    // Attribute change on the merged element. In this case, the merged element was moved to the graveyard.
    // An additional attribute operation that will change the (re)moved element needs to be generated.
    //
    if (a.range.start.hasSameParentAs(b.deletionPosition)) {
        if (a.range.containsPosition(b.deletionPosition) || a.range.start.isEqual(b.deletionPosition)) {
            ranges.push(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(b.graveyardPosition, 1));
        }
    }
    const range = a.range._getTransformedByMergeOperation(b);
    // Do not add empty (collapsed) ranges to the result. `range` may be collapsed if it contained only the merged element.
    if (!range.isCollapsed) {
        ranges.push(range);
    }
    // Create `AttributeOperation`s out of the ranges.
    return ranges.map((range)=>{
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range, a.key, a.oldValue, a.newValue, a.baseVersion);
    });
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    const ranges = _breakRangeByMoveOperation(a.range, b);
    // Create `AttributeOperation`s out of the ranges.
    return ranges.map((range)=>new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range, a.key, a.oldValue, a.newValue, a.baseVersion));
});
/**
 * Helper function for `AttributeOperation` x `MoveOperation` transformation.
 *
 * Takes the passed `range` and transforms it by move operation `moveOp` in a specific way. Only top-level nodes of `range`
 * are considered to be in the range. If move operation moves nodes deep from inside of the range, those nodes won't
 * be included in the result. In other words, top-level nodes of the ranges from the result are exactly the same as
 * top-level nodes of the original `range`.
 *
 * This is important for `AttributeOperation` because, for its range, it changes only the top-level nodes. So we need to
 * track only how those nodes have been affected by `MoveOperation`.
 */ function _breakRangeByMoveOperation(range, moveOp) {
    const moveRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(moveOp.sourcePosition, moveOp.howMany);
    // We are transforming `range` (original range) by `moveRange` (range moved by move operation). As usual when it comes to
    // transforming a ranges, we may have a common part of the ranges and we may have a difference part (zero to two ranges).
    let common = null;
    let difference = [];
    // Let's compare the ranges.
    if (moveRange.containsRange(range, true)) {
        // If the whole original range is moved, treat it whole as a common part. There's also no difference part.
        common = range;
    } else if (range.start.hasSameParentAs(moveRange.start)) {
        // If the ranges are "on the same level" (in the same parent) then move operation may move exactly those nodes
        // that are changed by the attribute operation. In this case we get common part and difference part in the usual way.
        difference = range.getDifference(moveRange);
        common = range.getIntersection(moveRange);
    } else {
        // In any other situation we assume that original range is different than move range, that is that move operation
        // moves other nodes that attribute operation change. Even if the moved range is deep inside in the original range.
        //
        // Note that this is different than in `.getIntersection` (we would get a common part in that case) and different
        // than `.getDifference` (we would get two ranges).
        difference = [
            range
        ];
    }
    const result = [];
    // The default behaviour of `_getTransformedByMove` might get wrong results for difference part, though, so
    // we do it by hand.
    for (let diff of difference){
        // First, transform the range by removing moved nodes. Since this is a difference, this is safe, `null` won't be returned
        // as the range is different than the moved range.
        diff = diff._getTransformedByDeletion(moveOp.sourcePosition, moveOp.howMany);
        // Transform also `targetPosition`.
        const targetPosition = moveOp.getMovedRangeStart();
        // Spread the range only if moved nodes are inserted only between the top-level nodes of the `diff` range.
        const spread = diff.start.hasSameParentAs(targetPosition);
        // Transform by insertion of moved nodes.
        const diffs = diff._getTransformedByInsertion(targetPosition, moveOp.howMany, spread);
        result.push(...diffs);
    }
    // Common part can be simply transformed by the move operation. This is because move operation will not target to
    // that common part (the operation would have to target inside its own moved range).
    if (common) {
        result.push(common._getTransformedByMove(moveOp.sourcePosition, moveOp.targetPosition, moveOp.howMany, false)[0]);
    }
    return result;
}
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    // Case 1:
    //
    // Split node is the last node in `AttributeOperation#range`.
    // `AttributeOperation#range` needs to be expanded to include the new (split) node.
    //
    // Attribute `type` to be changed to `numbered` but the `listItem` is split.
    // <listItem type="bulleted">foobar</listItem>
    //
    // After split:
    // <listItem type="bulleted">foo</listItem><listItem type="bulleted">bar</listItem>
    //
    // After attribute change:
    // <listItem type="numbered">foo</listItem><listItem type="numbered">foo</listItem>
    //
    if (a.range.end.isEqual(b.insertionPosition)) {
        if (!b.graveyardPosition) {
            a.range.end.offset++;
        }
        return [
            a
        ];
    }
    // Case 2:
    //
    // Split position is inside `AttributeOperation#range`, at the same level, so the nodes to change are
    // not going to make a flat range.
    //
    // Content with range-to-change and split position:
    // <p>Fo[zb^a]r</p>
    //
    // After split:
    // <p>Fozb</p><p>ar</p>
    //
    // Make two separate ranges containing all nodes to change:
    // <p>Fo[zb]</p><p>[a]r</p>
    //
    if (a.range.start.hasSameParentAs(b.splitPosition) && a.range.containsPosition(b.splitPosition)) {
        const secondPart = a.clone();
        secondPart.range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](b.moveTargetPosition.clone(), a.range.end._getCombined(b.splitPosition, b.moveTargetPosition));
        a.range.end = b.splitPosition.clone();
        a.range.end.stickiness = 'toPrevious';
        return [
            a,
            secondPart
        ];
    }
    // The default case.
    //
    a.range = a.range._getTransformedBySplitOperation(b);
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    const result = [
        a
    ];
    // Case 1:
    //
    // The attribute operation range includes the position where nodes were inserted.
    // There are two possible scenarios: the inserted nodes were text and they should receive attributes or
    // the inserted nodes were elements and they should not receive attributes.
    //
    // This is a mirror scenario to the one described in `AttributeOperation` x `InsertOperation` transformation,
    // although this case is a little less complicated. In this case we simply need to change attributes of the
    // inserted nodes and that's it.
    //
    if (a.shouldReceiveAttributes && a.position.hasSameParentAs(b.range.start) && b.range.containsPosition(a.position)) {
        const op = _getComplementaryAttributeOperations(a, b.key, b.newValue);
        if (op) {
            result.push(op);
        }
    }
    // The default case is: do nothing.
    // `AttributeOperation` does not change the model tree structure so `InsertOperation` does not need to be changed.
    //
    return result;
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    // Case 1:
    //
    // Two insert operations insert nodes at the same position. Since they are the same, it needs to be decided
    // what will be the order of inserted nodes. However, there is no additional information to help in that
    // decision. Also, when `b` will be transformed by `a`, the same order must be maintained.
    //
    // To achieve that, we will check if the operation is strong.
    // If it is, it won't get transformed. If it is not, it will be moved.
    //
    if (a.position.isEqual(b.position) && context.aIsStrong) {
        return [
            a
        ];
    }
    // The default case.
    //
    a.position = a.position._getTransformedByInsertOperation(b);
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    // The default case.
    //
    a.position = a.position._getTransformedByMoveOperation(b);
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    // The default case.
    //
    a.position = a.position._getTransformedBySplitOperation(b);
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    a.position = a.position._getTransformedByMergeOperation(b);
    return [
        a
    ];
});
// -----------------------
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    if (a.oldRange) {
        a.oldRange = a.oldRange._getTransformedByInsertOperation(b)[0];
    }
    if (a.newRange) {
        a.newRange = a.newRange._getTransformedByInsertOperation(b)[0];
    }
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    if (a.name == b.name) {
        if (context.aIsStrong) {
            a.oldRange = b.newRange ? b.newRange.clone() : null;
        } else {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
            ];
        }
    }
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    if (a.oldRange) {
        a.oldRange = a.oldRange._getTransformedByMergeOperation(b);
    }
    if (a.newRange) {
        a.newRange = a.newRange._getTransformedByMergeOperation(b);
    }
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    if (a.oldRange) {
        a.oldRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromRanges(a.oldRange._getTransformedByMoveOperation(b));
    }
    if (a.newRange) {
        if (context.abRelation) {
            const aNewRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromRanges(a.newRange._getTransformedByMoveOperation(b));
            if (context.abRelation.side == 'left' && b.targetPosition.isEqual(a.newRange.start)) {
                a.newRange.end = aNewRange.end;
                a.newRange.start.path = context.abRelation.path;
                return [
                    a
                ];
            } else if (context.abRelation.side == 'right' && b.targetPosition.isEqual(a.newRange.end)) {
                a.newRange.start = aNewRange.start;
                a.newRange.end.path = context.abRelation.path;
                return [
                    a
                ];
            }
        }
        a.newRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromRanges(a.newRange._getTransformedByMoveOperation(b));
    }
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    if (a.oldRange) {
        a.oldRange = a.oldRange._getTransformedBySplitOperation(b);
    }
    if (a.newRange) {
        if (context.abRelation) {
            const aNewRange = a.newRange._getTransformedBySplitOperation(b);
            if (a.newRange.start.isEqual(b.splitPosition) && context.abRelation.wasStartBeforeMergedElement) {
                a.newRange.start = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(b.insertionPosition);
            } else if (a.newRange.start.isEqual(b.splitPosition) && !context.abRelation.wasInLeftElement) {
                a.newRange.start = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(b.moveTargetPosition);
            }
            if (a.newRange.end.isEqual(b.splitPosition) && context.abRelation.wasInRightElement) {
                a.newRange.end = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(b.moveTargetPosition);
            } else if (a.newRange.end.isEqual(b.splitPosition) && context.abRelation.wasEndBeforeMergedElement) {
                a.newRange.end = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(b.insertionPosition);
            } else {
                a.newRange.end = aNewRange.end;
            }
            return [
                a
            ];
        }
        a.newRange = a.newRange._getTransformedBySplitOperation(b);
    }
    return [
        a
    ];
});
// -----------------------
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    if (a.sourcePosition.hasSameParentAs(b.position)) {
        a.howMany += b.howMany;
    }
    a.sourcePosition = a.sourcePosition._getTransformedByInsertOperation(b);
    a.targetPosition = a.targetPosition._getTransformedByInsertOperation(b);
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    // Case 1:
    //
    // Same merge operations.
    //
    // Both operations have same source and target positions. So the element already got merged and there is
    // theoretically nothing to do.
    //
    if (a.sourcePosition.isEqual(b.sourcePosition) && a.targetPosition.isEqual(b.targetPosition)) {
        // There are two ways that we can provide a do-nothing operation.
        //
        // First is simply a NoOperation instance. We will use it if `b` operation was not undone.
        //
        // Second is a merge operation that has the source operation in the merged element - in the graveyard -
        // same target position and `howMany` equal to `0`. So it is basically merging an empty element from graveyard
        // which is almost the same as NoOperation.
        //
        // This way the merge operation can be later transformed by split operation
        // to provide correct undo. This will be used if `b` operation was undone (only then it is correct).
        //
        if (!context.bWasUndone) {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
            ];
        } else {
            const path = b.graveyardPosition.path.slice();
            path.push(0);
            a.sourcePosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](b.graveyardPosition.root, path);
            a.howMany = 0;
            return [
                a
            ];
        }
    }
    // Case 2:
    //
    // Same merge source position but different target position.
    //
    // This can happen during collaboration. For example, if one client merged a paragraph to the previous paragraph
    // and the other person removed that paragraph and merged the same paragraph to something before:
    //
    // Client A:
    // <p>Foo</p><p>Bar</p><p>[]Xyz</p>
    // <p>Foo</p><p>BarXyz</p>
    //
    // Client B:
    // <p>Foo</p>[<p>Bar</p>]<p>Xyz</p>
    // <p>Foo</p><p>[]Xyz</p>
    // <p>FooXyz</p>
    //
    // In this case we need to decide where finally "Xyz" will land:
    //
    // <p>FooXyz</p>               graveyard: <p>Bar</p>
    // <p>Foo</p>                  graveyard: <p>BarXyz</p>
    //
    // Let's move it in a way so that a merge operation that does not target to graveyard is more important so that
    // nodes does not end up in the graveyard. It makes sense. Both for Client A and for Client B "Xyz" finally did not
    // end up in the graveyard (see above).
    //
    // If neither or both operations point to graveyard, then let `aIsStrong` decide.
    //
    if (a.sourcePosition.isEqual(b.sourcePosition) && !a.targetPosition.isEqual(b.targetPosition) && !context.bWasUndone && context.abRelation != 'splitAtSource') {
        const aToGraveyard = a.targetPosition.root.rootName == '$graveyard';
        const bToGraveyard = b.targetPosition.root.rootName == '$graveyard';
        // If `aIsWeak` it means that `a` points to graveyard while `b` doesn't. Don't move nodes then.
        const aIsWeak = aToGraveyard && !bToGraveyard;
        // If `bIsWeak` it means that `b` points to graveyard while `a` doesn't. Force moving nodes then.
        const bIsWeak = bToGraveyard && !aToGraveyard;
        // Force move if `b` is weak or neither operation is weak but `a` is stronger through `context.aIsStrong`.
        const forceMove = bIsWeak || !aIsWeak && context.aIsStrong;
        if (forceMove) {
            const sourcePosition = b.targetPosition._getTransformedByMergeOperation(b);
            const targetPosition = a.targetPosition._getTransformedByMergeOperation(b);
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](sourcePosition, a.howMany, targetPosition, 0)
            ];
        } else {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
            ];
        }
    }
    // The default case.
    //
    if (a.sourcePosition.hasSameParentAs(b.targetPosition)) {
        a.howMany += b.howMany;
    }
    a.sourcePosition = a.sourcePosition._getTransformedByMergeOperation(b);
    a.targetPosition = a.targetPosition._getTransformedByMergeOperation(b);
    // Handle positions in graveyard.
    // If graveyard positions are same and `a` operation is strong - do not transform.
    if (!a.graveyardPosition.isEqual(b.graveyardPosition) || !context.aIsStrong) {
        a.graveyardPosition = a.graveyardPosition._getTransformedByMergeOperation(b);
    }
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    // Case 1:
    //
    // The element to merge got removed.
    //
    // Merge operation does support merging elements which are not siblings. So it would not be a problem
    // from technical point of view. However, if the element was removed, the intention of the user deleting it
    // was to have it all deleted, together with its children. From user experience point of view, moving back the
    // removed nodes might be unexpected. This means that in this scenario we will block the merging.
    //
    // The exception of this rule would be if the remove operation was later undone.
    //
    const removedRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(b.sourcePosition, b.howMany);
    if (b.type == 'remove' && !context.bWasUndone && !context.forceWeakRemove) {
        if (a.deletionPosition.hasSameParentAs(b.sourcePosition) && removedRange.containsPosition(a.sourcePosition)) {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
            ];
        }
    }
    // In most cases we want `sourcePosition` to stick to previous and `targetPosition` to stick to next.
    // Usually, `sourcePosition` is at the beginning of the merged element and `targetPosition` is at the end of the merge-target element.
    //
    // However, `sourcePosition` and `targetPosition` may end up in the middle of an element due to some OT magic that happens during undo.
    // It is expected and used in `MergeOperation` x `SplitOperation` transformation.
    //
    // But when these positions are in the middle, it messes up the regular `MergeOperation` x `MoveOperation` transformation because
    // these positions may "follow" some moved elements. And we want them stick in the original elements.
    //
    // This is why we add two extra cases: (1) and (2).
    //
    // But after this `MergeOperation` is transformed by "this" move (which is undone), we also need to define extra cases for
    // the operation undoing previous move. These are (3) and (4).
    //
    // (1). Note that this case is also added to `updateRelations()` and sets `mergeSourceAffected` relation.
    //
    // [] is move operation, } is merge source position (sticks to previous by default):
    // <p>A[b]}c</p>  ->  <p>A}c</p>
    //
    if (b.sourcePosition.getShiftedBy(b.howMany).isEqual(a.sourcePosition)) {
        a.sourcePosition.stickiness = 'toNone';
    } else if (b.targetPosition.isEqual(a.sourcePosition) && context.abRelation == 'mergeSourceAffected') {
        a.sourcePosition.stickiness = 'toNext';
    } else if (b.sourcePosition.isEqual(a.targetPosition)) {
        a.targetPosition.stickiness = 'toNone';
        a.howMany -= b.howMany;
    } else if (b.targetPosition.isEqual(a.targetPosition) && context.abRelation == 'mergeTargetWasBefore') {
        a.targetPosition.stickiness = 'toPrevious';
        a.howMany += b.howMany;
    } else {
        if (a.sourcePosition.hasSameParentAs(b.targetPosition)) {
            a.howMany += b.howMany;
        }
        if (a.sourcePosition.hasSameParentAs(b.sourcePosition)) {
            a.howMany -= b.howMany;
        }
    }
    a.sourcePosition = a.sourcePosition._getTransformedByMoveOperation(b);
    a.targetPosition = a.targetPosition._getTransformedByMoveOperation(b);
    // After transformations are done, make sure to revert stickiness in case if (1) - (4) scenario happened.
    a.sourcePosition.stickiness = 'toPrevious';
    a.targetPosition.stickiness = 'toNext';
    // `MergeOperation` graveyard position is like `MoveOperation` target position. It is a position where element(s) will
    // be moved. Like in other similar cases, we need to consider the scenario when those positions are same.
    // Here, we will treat `MergeOperation` like it is always strong (see `InsertOperation` x `InsertOperation` for comparison).
    // This means that we won't transform graveyard position if it is equal to move operation target position.
    if (!a.graveyardPosition.isEqual(b.targetPosition)) {
        a.graveyardPosition = a.graveyardPosition._getTransformedByMoveOperation(b);
    }
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    if (b.graveyardPosition) {
        // If `b` operation defines graveyard position, a node from graveyard will be moved. This means that we need to
        // transform `a.graveyardPosition` accordingly.
        a.graveyardPosition = a.graveyardPosition._getTransformedByDeletion(b.graveyardPosition, 1);
        // This is a scenario foreseen in `MergeOperation` x `MergeOperation`, with two identical merge operations.
        //
        // So, there was `MergeOperation` x `MergeOperation` transformation earlier. Now, `a` is a merge operation which
        // source position is in graveyard. Interestingly, split operation wants to use the node to be merged by `a`. This
        // means that `b` is undoing that merge operation from earlier, which caused `a` to be in graveyard.
        //
        // If that's the case, at this point, we will only "fix" `a.howMany`. It was earlier set to `0` in
        // `MergeOperation` x `MergeOperation` transformation. Later transformations in this function will change other
        // properties.
        //
        if (a.deletionPosition.isEqual(b.graveyardPosition)) {
            a.howMany = b.howMany;
        }
    }
    // Case 1:
    //
    // Merge operation moves nodes to the place where split happens.
    // This is a classic situation when there are two paragraphs, and there is a split (enter) after the first
    // paragraph and there is a merge (delete) at the beginning of the second paragraph:
    //
    // <p>Foo{}</p><p>[]Bar</p>.
    //
    // Split is after `Foo`, while merge is from `Bar` to the end of `Foo`.
    //
    // State after split:
    // <p>Foo</p><p></p><p>Bar</p>
    //
    // Now, `Bar` should be merged to the new paragraph:
    // <p>Foo</p><p>Bar</p>
    //
    // Instead of merging it to the original paragraph:
    // <p>FooBar</p><p></p>
    //
    // This means that `targetPosition` needs to be transformed. This is the default case though.
    // For example, if the split would be after `F`, `targetPosition` should also be transformed.
    //
    // There are three exceptions, though, when we want to keep `targetPosition` as it was.
    //
    // First exception is when the merge target position is inside an element (not at the end, as usual). This
    // happens when the merge operation earlier was transformed by "the same" merge operation. If merge operation
    // targets inside the element we want to keep the original target position (and not transform it) because
    // we have additional context telling us that we want to merge to the original element. We can check if the
    // merge operation points inside element by checking what is `SplitOperation#howMany`. Since merge target position
    // is same as split position, if `howMany` is non-zero, it means that the merge target position is inside an element.
    //
    // Second exception is when the element to merge is in the graveyard and split operation uses it. In that case
    // if target position would be transformed, the merge operation would target at the source position:
    //
    // root: <p>Foo</p>				graveyard: <p></p>
    //
    // SplitOperation: root [ 0, 3 ] using graveyard [ 0 ] (howMany = 0)
    // MergeOperation: graveyard [ 0, 0 ] -> root [ 0, 3 ] (howMany = 0)
    //
    // Since split operation moves the graveyard node back to the root, the merge operation source position changes.
    // We would like to merge from the empty <p> to the "Foo" <p>:
    //
    // root: <p>Foo</p><p></p>			graveyard:
    //
    // MergeOperation#sourcePosition = root [ 1, 0 ]
    //
    // If `targetPosition` is transformed, it would become root [ 1, 0 ] as well. It has to be kept as it was.
    //
    // Third exception is connected with relations. If this happens during undo and we have explicit information
    // that target position has not been affected by the operation which is undone by this split then this split should
    // not move the target position either.
    //
    if (a.targetPosition.isEqual(b.splitPosition)) {
        const mergeInside = b.howMany != 0;
        const mergeSplittingElement = b.graveyardPosition && a.deletionPosition.isEqual(b.graveyardPosition);
        if (mergeInside || mergeSplittingElement || context.abRelation == 'mergeTargetNotMoved') {
            a.sourcePosition = a.sourcePosition._getTransformedBySplitOperation(b);
            return [
                a
            ];
        }
    }
    // Case 2:
    //
    // Merge source is at the same position as split position. This sometimes happen, mostly during undo.
    // The decision here is mostly to choose whether merge source position should stay where it is (so it will be at the end of the
    // split element) or should be move to the beginning of the new element.
    //
    if (a.sourcePosition.isEqual(b.splitPosition)) {
        // Use context to check if `SplitOperation` is not undoing a merge operation, that didn't change the `a` operation.
        // This scenario happens the undone merge operation moved nodes at the source position of `a` operation.
        // In that case `a` operation source position should stay where it is.
        if (context.abRelation == 'mergeSourceNotMoved') {
            a.howMany = 0;
            a.targetPosition = a.targetPosition._getTransformedBySplitOperation(b);
            return [
                a
            ];
        }
        // This merge operation might have been earlier transformed by a merge operation which both merged the same element.
        // See that case in `MergeOperation` x `MergeOperation` transformation. In that scenario, if the merge operation has been undone,
        // the special case is not applied.
        //
        // Now, the merge operation is transformed by the split which has undone that previous merge operation.
        // So now we are fixing situation which was skipped in `MergeOperation` x `MergeOperation` case.
        //
        if (context.abRelation == 'mergeSameElement' || a.sourcePosition.offset > 0) {
            a.sourcePosition = b.moveTargetPosition.clone();
            a.targetPosition = a.targetPosition._getTransformedBySplitOperation(b);
            return [
                a
            ];
        }
    }
    // The default case.
    //
    if (a.sourcePosition.hasSameParentAs(b.splitPosition)) {
        a.howMany = b.splitPosition.offset;
    }
    a.sourcePosition = a.sourcePosition._getTransformedBySplitOperation(b);
    a.targetPosition = a.targetPosition._getTransformedBySplitOperation(b);
    return [
        a
    ];
});
// -----------------------
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    const moveRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(a.sourcePosition, a.howMany);
    const transformed = moveRange._getTransformedByInsertOperation(b, false)[0];
    a.sourcePosition = transformed.start;
    a.howMany = transformed.end.offset - transformed.start.offset;
    // See `InsertOperation` x `MoveOperation` transformation for details on this case.
    //
    // In summary, both operations point to the same place, so the order of nodes needs to be decided.
    // `MoveOperation` is considered weaker, so it is always transformed, unless there was a certain relation
    // between operations.
    //
    if (!a.targetPosition.isEqual(b.position)) {
        a.targetPosition = a.targetPosition._getTransformedByInsertOperation(b);
    }
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    //
    // Setting and evaluating some variables that will be used in special cases and default algorithm.
    //
    // Create ranges from `MoveOperations` properties.
    const rangeA = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(a.sourcePosition, a.howMany);
    const rangeB = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(b.sourcePosition, b.howMany);
    // Assign `context.aIsStrong` to a different variable, because the value may change during execution of
    // this algorithm and we do not want to override original `context.aIsStrong` that will be used in later transformations.
    let aIsStrong = context.aIsStrong;
    // This will be used to decide the order of nodes if both operations target at the same position.
    // By default, use strong/weak operation mechanism.
    let insertBefore = !context.aIsStrong;
    // If the relation is set, then use it to decide nodes order.
    if (context.abRelation == 'insertBefore' || context.baRelation == 'insertAfter') {
        insertBefore = true;
    } else if (context.abRelation == 'insertAfter' || context.baRelation == 'insertBefore') {
        insertBefore = false;
    }
    // `a.targetPosition` could be affected by the `b` operation. We will transform it.
    let newTargetPosition;
    if (a.targetPosition.isEqual(b.targetPosition) && insertBefore) {
        newTargetPosition = a.targetPosition._getTransformedByDeletion(b.sourcePosition, b.howMany);
    } else {
        newTargetPosition = a.targetPosition._getTransformedByMove(b.sourcePosition, b.targetPosition, b.howMany);
    }
    //
    // Special case #1 + mirror.
    //
    // Special case when both move operations' target positions are inside nodes that are
    // being moved by the other move operation. So in other words, we move ranges into inside of each other.
    // This case can't be solved reasonably (on the other hand, it should not happen often).
    if (_moveTargetIntoMovedRange(a, b) && _moveTargetIntoMovedRange(b, a)) {
        // Instead of transforming operation, we return a reverse of the operation that we transform by.
        // So when the results of this "transformation" will be applied, `b` MoveOperation will get reversed.
        return [
            b.getReversed()
        ];
    }
    //
    // End of special case #1.
    //
    //
    // Special case #2.
    //
    // Check if `b` operation targets inside `rangeA`.
    const bTargetsToA = rangeA.containsPosition(b.targetPosition);
    // If `b` targets to `rangeA` and `rangeA` contains `rangeB`, `b` operation has no influence on `a` operation.
    // You might say that operation `b` is captured inside operation `a`.
    if (bTargetsToA && rangeA.containsRange(rangeB, true)) {
        // There is a mini-special case here, where `rangeB` is on other level than `rangeA`. That's why
        // we need to transform `a` operation anyway.
        rangeA.start = rangeA.start._getTransformedByMove(b.sourcePosition, b.targetPosition, b.howMany);
        rangeA.end = rangeA.end._getTransformedByMove(b.sourcePosition, b.targetPosition, b.howMany);
        return _makeMoveOperationsFromRanges([
            rangeA
        ], newTargetPosition);
    }
    //
    // Special case #2 mirror.
    //
    const aTargetsToB = rangeB.containsPosition(a.targetPosition);
    if (aTargetsToB && rangeB.containsRange(rangeA, true)) {
        // `a` operation is "moved together" with `b` operation.
        // Here, just move `rangeA` "inside" `rangeB`.
        rangeA.start = rangeA.start._getCombined(b.sourcePosition, b.getMovedRangeStart());
        rangeA.end = rangeA.end._getCombined(b.sourcePosition, b.getMovedRangeStart());
        return _makeMoveOperationsFromRanges([
            rangeA
        ], newTargetPosition);
    }
    //
    // End of special case #2.
    //
    //
    // Special case #3 + mirror.
    //
    // `rangeA` has a node which is an ancestor of `rangeB`. In other words, `rangeB` is inside `rangeA`
    // but not on the same tree level. In such case ranges have common part but we have to treat it
    // differently, because in such case those ranges are not really conflicting and should be treated like
    // two separate ranges. Also we have to discard two difference parts.
    const aCompB = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(a.sourcePosition.getParentPath(), b.sourcePosition.getParentPath());
    if (aCompB == 'prefix' || aCompB == 'extension') {
        // Transform `rangeA` by `b` operation and make operation out of it, and that's all.
        // Note that this is a simplified version of default case, but here we treat the common part (whole `rangeA`)
        // like a one difference part.
        rangeA.start = rangeA.start._getTransformedByMove(b.sourcePosition, b.targetPosition, b.howMany);
        rangeA.end = rangeA.end._getTransformedByMove(b.sourcePosition, b.targetPosition, b.howMany);
        return _makeMoveOperationsFromRanges([
            rangeA
        ], newTargetPosition);
    }
    //
    // End of special case #3.
    //
    //
    // Default case - ranges are on the same level or are not connected with each other.
    //
    // Modifier for default case.
    // Modifies `aIsStrong` flag in certain conditions.
    //
    // If only one of operations is a remove operation, we force remove operation to be the "stronger" one
    // to provide more expected results.
    if (a.type == 'remove' && b.type != 'remove' && !context.aWasUndone && !context.forceWeakRemove) {
        aIsStrong = true;
    } else if (a.type != 'remove' && b.type == 'remove' && !context.bWasUndone && !context.forceWeakRemove) {
        aIsStrong = false;
    }
    // Handle operation's source ranges - check how `rangeA` is affected by `b` operation.
    // This will aggregate transformed ranges.
    const ranges = [];
    // Get the "difference part" of `a` operation source range.
    // This is an array with one or two ranges. Two ranges if `rangeB` is inside `rangeA`.
    const difference = rangeA.getDifference(rangeB);
    for (const range of difference){
        // Transform those ranges by `b` operation. For example if `b` moved range from before those ranges, fix those ranges.
        range.start = range.start._getTransformedByDeletion(b.sourcePosition, b.howMany);
        range.end = range.end._getTransformedByDeletion(b.sourcePosition, b.howMany);
        // If `b` operation targets into `rangeA` on the same level, spread `rangeA` into two ranges.
        const shouldSpread = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(range.start.getParentPath(), b.getMovedRangeStart().getParentPath()) == 'same';
        const newRanges = range._getTransformedByInsertion(b.getMovedRangeStart(), b.howMany, shouldSpread);
        ranges.push(...newRanges);
    }
    // Then, we have to manage the "common part" of both move ranges.
    const common = rangeA.getIntersection(rangeB);
    if (common !== null && aIsStrong) {
        // Calculate the new position of that part of original range.
        common.start = common.start._getCombined(b.sourcePosition, b.getMovedRangeStart());
        common.end = common.end._getCombined(b.sourcePosition, b.getMovedRangeStart());
        // Take care of proper range order.
        //
        // Put `common` at appropriate place. Keep in mind that we are interested in original order.
        // Basically there are only three cases: there is zero, one or two difference ranges.
        //
        // If there is zero difference ranges, just push `common` in the array.
        if (ranges.length === 0) {
            ranges.push(common);
        } else if (ranges.length == 1) {
            if (rangeB.start.isBefore(rangeA.start) || rangeB.start.isEqual(rangeA.start)) {
                ranges.unshift(common);
            } else {
                ranges.push(common);
            }
        } else {
            ranges.splice(1, 0, common);
        }
    }
    if (ranges.length === 0) {
        // If there are no "source ranges", nothing should be changed.
        // Note that this can happen only if `aIsStrong == false` and `rangeA.isEqual( rangeB )`.
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](a.baseVersion)
        ];
    }
    return _makeMoveOperationsFromRanges(ranges, newTargetPosition);
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    let newTargetPosition = a.targetPosition.clone();
    // Do not transform if target position is same as split insertion position and this split comes from undo.
    // This should be done on relations but it is too much work for now as it would require relations working in collaboration.
    // We need to make a decision how we will resolve such conflict and this is less harmful way.
    if (!a.targetPosition.isEqual(b.insertionPosition) || !b.graveyardPosition || context.abRelation == 'moveTargetAfter') {
        newTargetPosition = a.targetPosition._getTransformedBySplitOperation(b);
    }
    // Case 1:
    //
    // Last element in the moved range got split.
    //
    // In this case the default range transformation will not work correctly as the element created by
    // split operation would be outside the range. The range to move needs to be fixed manually.
    //
    const moveRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(a.sourcePosition, a.howMany);
    if (moveRange.end.isEqual(b.insertionPosition)) {
        // Do it only if this is a "natural" split, not a one that comes from undo.
        // If this is undo split, only `targetPosition` needs to be changed (if the move is a remove).
        if (!b.graveyardPosition) {
            a.howMany++;
        }
        a.targetPosition = newTargetPosition;
        return [
            a
        ];
    }
    // Case 2:
    //
    // Split happened between the moved nodes. In this case two ranges to move need to be generated.
    //
    // Characters `ozba` are moved to the end of paragraph `Xyz` but split happened.
    // <p>F[oz|ba]r</p><p>Xyz</p>
    //
    // After split:
    // <p>F[oz</p><p>ba]r</p><p>Xyz</p>
    //
    // Correct ranges:
    // <p>F[oz]</p><p>[ba]r</p><p>Xyz</p>
    //
    // After move:
    // <p>F</p><p>r</p><p>Xyzozba</p>
    //
    if (moveRange.start.hasSameParentAs(b.splitPosition) && moveRange.containsPosition(b.splitPosition)) {
        let rightRange = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](b.splitPosition, moveRange.end);
        rightRange = rightRange._getTransformedBySplitOperation(b);
        const ranges = [
            new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](moveRange.start, b.splitPosition),
            rightRange
        ];
        return _makeMoveOperationsFromRanges(ranges, newTargetPosition);
    }
    // Case 3:
    //
    // Move operation targets at the split position. We need to decide if the nodes should be inserted
    // at the end of the split element or at the beginning of the new element.
    //
    if (a.targetPosition.isEqual(b.splitPosition) && context.abRelation == 'insertAtSource') {
        newTargetPosition = b.moveTargetPosition;
    }
    // Case 4:
    //
    // Move operation targets just after the split element. We need to decide if the nodes should be inserted
    // between two parts of split element, or after the new element.
    //
    // Split at `|`, while move operation moves `<p>Xyz</p>` and targets at `^`:
    // <p>Foo|bar</p>^<p>baz</p>
    // <p>Foo</p>^<p>bar</p><p>baz</p> or <p>Foo</p><p>bar</p>^<p>baz</p>?
    //
    // If there is no contextual information between operations (for example, they come from collaborative
    // editing), we don't want to put some unrelated content (move) between parts of related content (split parts).
    // However, if the split is from undo, in the past, the moved content might be targeting between the
    // split parts, meaning that was exactly user's intention:
    //
    // <p>Foo</p>^<p>bar</p>		<--- original situation, in "past".
    // <p>Foobar</p>^				<--- after merge target position is transformed.
    // <p>Foo|bar</p>^				<--- then the merge is undone, and split happens, which leads us to current situation.
    //
    // In this case it is pretty clear that the intention was to put new paragraph between those nodes,
    // so we need to transform accordingly. We can detect this scenario thanks to relations.
    //
    if (a.targetPosition.isEqual(b.insertionPosition) && context.abRelation == 'insertBetween') {
        newTargetPosition = a.targetPosition;
    }
    // The default case.
    //
    const transformed = moveRange._getTransformedBySplitOperation(b);
    const ranges = [
        transformed
    ];
    // Case 5:
    //
    // Moved range contains graveyard element used by split operation. Add extra move operation to the result.
    //
    if (b.graveyardPosition) {
        const movesGraveyardElement = moveRange.start.isEqual(b.graveyardPosition) || moveRange.containsPosition(b.graveyardPosition);
        if (a.howMany > 1 && movesGraveyardElement && !context.aWasUndone) {
            ranges.push(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(b.insertionPosition, 1));
        }
    }
    return _makeMoveOperationsFromRanges(ranges, newTargetPosition);
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    const movedRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(a.sourcePosition, a.howMany);
    if (b.deletionPosition.hasSameParentAs(a.sourcePosition) && movedRange.containsPosition(b.sourcePosition)) {
        if (a.type == 'remove' && !context.forceWeakRemove) {
            // Case 1:
            //
            // The element to remove got merged.
            //
            // Merge operation does support merging elements which are not siblings. So it would not be a problem
            // from technical point of view. However, if the element was removed, the intention of the user
            // deleting it was to have it all deleted. From user experience point of view, moving back the
            // removed nodes might be unexpected. This means that in this scenario we will reverse merging and remove the element.
            //
            if (!context.aWasUndone) {
                const results = [];
                let gyMoveSource = b.graveyardPosition.clone();
                let splitNodesMoveSource = b.targetPosition._getTransformedByMergeOperation(b);
                if (a.howMany > 1) {
                    results.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](a.sourcePosition, a.howMany - 1, a.targetPosition, 0));
                    gyMoveSource = gyMoveSource._getTransformedByMove(a.sourcePosition, a.targetPosition, a.howMany - 1);
                    splitNodesMoveSource = splitNodesMoveSource._getTransformedByMove(a.sourcePosition, a.targetPosition, a.howMany - 1);
                }
                const gyMoveTarget = b.deletionPosition._getCombined(a.sourcePosition, a.targetPosition);
                const gyMove = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](gyMoveSource, 1, gyMoveTarget, 0);
                const splitNodesMoveTargetPath = gyMove.getMovedRangeStart().path.slice();
                splitNodesMoveTargetPath.push(0);
                const splitNodesMoveTarget = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](gyMove.targetPosition.root, splitNodesMoveTargetPath);
                splitNodesMoveSource = splitNodesMoveSource._getTransformedByMove(gyMoveSource, gyMoveTarget, 1);
                const splitNodesMove = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](splitNodesMoveSource, b.howMany, splitNodesMoveTarget, 0);
                results.push(gyMove);
                results.push(splitNodesMove);
                return results;
            }
        } else {
            // Case 2:
            //
            // The element to move got merged and it was the only element to move.
            // In this case just don't do anything, leave the node in the graveyard. Without special case
            // it would be a move operation that moves 0 nodes, so maybe it is better just to return no-op.
            //
            if (a.howMany == 1) {
                if (!context.bWasUndone) {
                    return [
                        new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
                    ];
                } else {
                    a.sourcePosition = b.graveyardPosition.clone();
                    a.targetPosition = a.targetPosition._getTransformedByMergeOperation(b);
                    return [
                        a
                    ];
                }
            }
        }
    }
    // The default case.
    //
    const moveRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(a.sourcePosition, a.howMany);
    const transformed = moveRange._getTransformedByMergeOperation(b);
    a.sourcePosition = transformed.start;
    a.howMany = transformed.end.offset - transformed.start.offset;
    a.targetPosition = a.targetPosition._getTransformedByMergeOperation(b);
    return [
        a
    ];
});
// -----------------------
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    a.position = a.position._getTransformedByInsertOperation(b);
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    // Case 1:
    //
    // Element to rename got merged, so it was moved to `b.graveyardPosition`.
    //
    if (a.position.isEqual(b.deletionPosition)) {
        a.position = b.graveyardPosition.clone();
        a.position.stickiness = 'toNext';
        return [
            a
        ];
    }
    a.position = a.position._getTransformedByMergeOperation(b);
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    a.position = a.position._getTransformedByMoveOperation(b);
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    if (a.position.isEqual(b.position)) {
        if (context.aIsStrong) {
            a.oldName = b.newName;
        } else {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
            ];
        }
    }
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    // Case 1:
    //
    // The element to rename has been split. In this case, the new element should be also renamed.
    //
    // User decides to change the paragraph to a list item:
    // <paragraph>Foobar</paragraph>
    //
    // However, in meantime, split happens:
    // <paragraph>Foo</paragraph><paragraph>bar</paragraph>
    //
    // As a result, rename both elements:
    // <listItem>Foo</listItem><listItem>bar</listItem>
    //
    const renamePath = a.position.path;
    const splitPath = b.splitPosition.getParentPath();
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(renamePath, splitPath) == 'same' && !b.graveyardPosition) {
        const extraRename = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](a.position.getShiftedBy(1), a.oldName, a.newName, 0);
        return [
            a,
            extraRename
        ];
    }
    // The default case.
    //
    a.position = a.position._getTransformedBySplitOperation(b);
    return [
        a
    ];
});
// -----------------------
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    if (a.root === b.root && a.key === b.key) {
        if (!context.aIsStrong || a.newValue === b.newValue) {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
            ];
        } else {
            a.oldValue = b.newValue;
        }
    }
    return [
        a
    ];
});
// -----------------------
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    if (a.rootName === b.rootName && a.isAdd === b.isAdd) {
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
        ];
    }
    return [
        a
    ];
});
// -----------------------
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b)=>{
    // The default case.
    //
    if (a.splitPosition.hasSameParentAs(b.position) && a.splitPosition.offset < b.position.offset) {
        a.howMany += b.howMany;
    }
    a.splitPosition = a.splitPosition._getTransformedByInsertOperation(b);
    a.insertionPosition = a.insertionPosition._getTransformedByInsertOperation(b);
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    // Case 1:
    //
    // Split element got merged. If two different elements were merged, clients will have different content.
    //
    // Example. Merge at `{}`, split at `[]`:
    // <heading>Foo</heading>{}<paragraph>B[]ar</paragraph>
    //
    // On merge side it will look like this:
    // <heading>FooB[]ar</heading>
    // <heading>FooB</heading><heading>ar</heading>
    //
    // On split side it will look like this:
    // <heading>Foo</heading>{}<paragraph>B</paragraph><paragraph>ar</paragraph>
    // <heading>FooB</heading><paragraph>ar</paragraph>
    //
    // Clearly, the second element is different for both clients.
    //
    // We could use the removed merge element from graveyard as a split element but then clients would have a different
    // model state (in graveyard), because the split side client would still have an element in graveyard (removed by merge).
    //
    // To overcome this, in `SplitOperation` x `MergeOperation` transformation we will add additional `SplitOperation`
    // in the graveyard, which will actually clone the merged-and-deleted element. Then, that cloned element will be
    // used for splitting. Example below.
    //
    // Original state:
    // <heading>Foo</heading>{}<paragraph>B[]ar</paragraph>
    //
    // Merge side client:
    //
    // After merge:
    // <heading>FooB[]ar</heading>                                 graveyard: <paragraph></paragraph>
    //
    // Extra split:
    // <heading>FooB[]ar</heading>                                 graveyard: <paragraph></paragraph><paragraph></paragraph>
    //
    // Use the "cloned" element from graveyard:
    // <heading>FooB</heading><paragraph>ar</paragraph>            graveyard: <paragraph></paragraph>
    //
    // Split side client:
    //
    // After split:
    // <heading>Foo</heading>{}<paragraph>B</paragraph><paragraph>ar</paragraph>
    //
    // After merge:
    // <heading>FooB</heading><paragraph>ar</paragraph>            graveyard: <paragraph></paragraph>
    //
    // This special case scenario only applies if the original split operation clones the split element.
    // If the original split operation has `graveyardPosition` set, it all doesn't have sense because split operation
    // knows exactly which element it should use. So there would be no original problem with different contents.
    //
    // Additionally, the special case applies only if the merge wasn't already undone.
    //
    if (!a.graveyardPosition && !context.bWasUndone && a.splitPosition.hasSameParentAs(b.sourcePosition)) {
        const splitPath = b.graveyardPosition.path.slice();
        splitPath.push(0);
        const splitPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](b.graveyardPosition.root, splitPath);
        const insertionPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getInsertionPosition(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](b.graveyardPosition.root, splitPath));
        const additionalSplit = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](splitPosition, 0, insertionPosition, null, 0);
        a.splitPosition = a.splitPosition._getTransformedByMergeOperation(b);
        a.insertionPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getInsertionPosition(a.splitPosition);
        a.graveyardPosition = additionalSplit.insertionPosition.clone();
        a.graveyardPosition.stickiness = 'toNext';
        return [
            additionalSplit,
            a
        ];
    }
    // The default case.
    //
    if (a.splitPosition.hasSameParentAs(b.deletionPosition) && !a.splitPosition.isAfter(b.deletionPosition)) {
        a.howMany--;
    }
    if (a.splitPosition.hasSameParentAs(b.targetPosition)) {
        a.howMany += b.howMany;
    }
    a.splitPosition = a.splitPosition._getTransformedByMergeOperation(b);
    a.insertionPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getInsertionPosition(a.splitPosition);
    if (a.graveyardPosition) {
        a.graveyardPosition = a.graveyardPosition._getTransformedByMergeOperation(b);
    }
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    const rangeToMove = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(b.sourcePosition, b.howMany);
    if (a.graveyardPosition) {
        // Case 1:
        //
        // Split operation graveyard node was moved. In this case move operation is stronger. Since graveyard element
        // is already moved to the correct position, we need to only move the nodes after the split position.
        // This will be done by `MoveOperation` instead of `SplitOperation`.
        //
        const gyElementMoved = rangeToMove.start.isEqual(a.graveyardPosition) || rangeToMove.containsPosition(a.graveyardPosition);
        if (!context.bWasUndone && gyElementMoved) {
            const sourcePosition = a.splitPosition._getTransformedByMoveOperation(b);
            const newParentPosition = a.graveyardPosition._getTransformedByMoveOperation(b);
            const newTargetPath = newParentPosition.path.slice();
            newTargetPath.push(0);
            const newTargetPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](newParentPosition.root, newTargetPath);
            const moveOp = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](sourcePosition, a.howMany, newTargetPosition, 0);
            return [
                moveOp
            ];
        }
        a.graveyardPosition = a.graveyardPosition._getTransformedByMoveOperation(b);
    }
    // Case 2:
    //
    // Split is at a position where nodes were moved.
    //
    // This is a scenario described in `MoveOperation` x `SplitOperation` transformation but from the
    // "split operation point of view".
    //
    const splitAtTarget = a.splitPosition.isEqual(b.targetPosition);
    if (splitAtTarget && (context.baRelation == 'insertAtSource' || context.abRelation == 'splitBefore')) {
        a.howMany += b.howMany;
        a.splitPosition = a.splitPosition._getTransformedByDeletion(b.sourcePosition, b.howMany);
        a.insertionPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getInsertionPosition(a.splitPosition);
        return [
            a
        ];
    }
    if (splitAtTarget && context.abRelation && context.abRelation.howMany) {
        const { howMany, offset } = context.abRelation;
        a.howMany += howMany;
        a.splitPosition = a.splitPosition.getShiftedBy(offset);
        return [
            a
        ];
    }
    // Case 3:
    //
    // If the split position is inside the moved range, we need to shift the split position to a proper place.
    // The position cannot be moved together with moved range because that would result in splitting of an incorrect element.
    //
    // Characters `bc` should be moved to the second paragraph while split position is between them:
    // <paragraph>A[b|c]d</paragraph><paragraph>Xyz</paragraph>
    //
    // After move, new split position is incorrect:
    // <paragraph>Ad</paragraph><paragraph>Xb|cyz</paragraph>
    //
    // Correct split position:
    // <paragraph>A|d</paragraph><paragraph>Xbcyz</paragraph>
    //
    // After split:
    // <paragraph>A</paragraph><paragraph>d</paragraph><paragraph>Xbcyz</paragraph>
    //
    if (a.splitPosition.hasSameParentAs(b.sourcePosition) && rangeToMove.containsPosition(a.splitPosition)) {
        const howManyRemoved = b.howMany - (a.splitPosition.offset - b.sourcePosition.offset);
        a.howMany -= howManyRemoved;
        if (a.splitPosition.hasSameParentAs(b.targetPosition) && a.splitPosition.offset < b.targetPosition.offset) {
            a.howMany += b.howMany;
        }
        a.splitPosition = b.sourcePosition.clone();
        a.insertionPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getInsertionPosition(a.splitPosition);
        return [
            a
        ];
    }
    // The default case.
    // Don't change `howMany` if move operation does not really move anything.
    //
    if (!b.sourcePosition.isEqual(b.targetPosition)) {
        if (a.splitPosition.hasSameParentAs(b.sourcePosition) && a.splitPosition.offset <= b.sourcePosition.offset) {
            a.howMany -= b.howMany;
        }
        if (a.splitPosition.hasSameParentAs(b.targetPosition) && a.splitPosition.offset < b.targetPosition.offset) {
            a.howMany += b.howMany;
        }
    }
    // Change position stickiness to force a correct transformation.
    a.splitPosition.stickiness = 'toNone';
    a.splitPosition = a.splitPosition._getTransformedByMoveOperation(b);
    a.splitPosition.stickiness = 'toNext';
    if (a.graveyardPosition) {
        a.insertionPosition = a.insertionPosition._getTransformedByMoveOperation(b);
    } else {
        a.insertionPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getInsertionPosition(a.splitPosition);
    }
    return [
        a
    ];
});
setTransformation(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], (a, b, context)=>{
    // Case 1:
    //
    // Split at the same position.
    //
    // If there already was a split at the same position as in `a` operation, it means that the intention
    // conveyed by `a` operation has already been fulfilled and `a` should not do anything (to avoid double split).
    //
    // However, there is a difference if these are new splits or splits created by undo. These have different
    // intentions. Also splits moving back different elements from graveyard have different intentions. They
    // are just different operations.
    //
    // So we cancel split operation only if it was really identical.
    //
    // Also, there is additional case, where split operations aren't identical and should not be cancelled, however the
    // default transformation is incorrect too.
    //
    if (a.splitPosition.isEqual(b.splitPosition)) {
        if (!a.graveyardPosition && !b.graveyardPosition) {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
            ];
        }
        if (a.graveyardPosition && b.graveyardPosition && a.graveyardPosition.isEqual(b.graveyardPosition)) {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
            ];
        }
        // Use context to know that the `a.splitPosition` should stay where it is.
        // This happens during undo when first a merge operation moved nodes to `a.splitPosition` and now `b` operation undoes that merge.
        if (context.abRelation == 'splitBefore') {
            // Since split is at the same position, there are no nodes left to split.
            a.howMany = 0;
            // Note: there was `if ( a.graveyardPosition )` here but it was uncovered in tests and I couldn't find any scenarios for now.
            // That would have to be a `SplitOperation` that didn't come from undo but is transformed by operations that were undone.
            // It could happen if `context` is enabled in collaboration.
            a.graveyardPosition = a.graveyardPosition._getTransformedBySplitOperation(b);
            return [
                a
            ];
        }
    }
    // Case 2:
    //
    // Same node is using to split different elements. This happens in undo when previously same element was merged to
    // two different elements. This is described in `MergeOperation` x `MergeOperation` transformation.
    //
    // In this case we will follow the same logic. We will assume that `insertionPosition` is same for both
    // split operations. This might not always be true but in the real cases that were experienced it was. After all,
    // if these splits are reverses of merge operations that were merging the same element, then the `insertionPosition`
    // should be same for both of those splits.
    //
    // Again, we will decide which operation is stronger by checking if split happens in graveyard or in non-graveyard root.
    //
    if (a.graveyardPosition && b.graveyardPosition && a.graveyardPosition.isEqual(b.graveyardPosition)) {
        const aInGraveyard = a.splitPosition.root.rootName == '$graveyard';
        const bInGraveyard = b.splitPosition.root.rootName == '$graveyard';
        // If `aIsWeak` it means that `a` points to graveyard while `b` doesn't. Don't move nodes then.
        const aIsWeak = aInGraveyard && !bInGraveyard;
        // If `bIsWeak` it means that `b` points to graveyard while `a` doesn't. Force moving nodes then.
        const bIsWeak = bInGraveyard && !aInGraveyard;
        // Force move if `b` is weak or neither operation is weak but `a` is stronger through `context.aIsStrong`.
        const forceMove = bIsWeak || !aIsWeak && context.aIsStrong;
        if (forceMove) {
            const result = [];
            // First we need to move any nodes split by `b` back to where they were.
            // Do it only if `b` actually moved something.
            if (b.howMany) {
                result.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](b.moveTargetPosition, b.howMany, b.splitPosition, 0));
            }
            // Then we need to move nodes from `a` split position to their new element.
            // Do it only if `a` actually should move something.
            if (a.howMany) {
                result.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](a.splitPosition, a.howMany, a.moveTargetPosition, 0));
            }
            return result;
        } else {
            return [
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](0)
            ];
        }
    }
    if (a.graveyardPosition) {
        a.graveyardPosition = a.graveyardPosition._getTransformedBySplitOperation(b);
    }
    // Case 3:
    //
    // Position where operation `b` inserted a new node after split is the same as the operation `a` split position.
    // As in similar cases, there is ambiguity if the split should be before the new node (created by `b`) or after.
    //
    if (a.splitPosition.isEqual(b.insertionPosition) && context.abRelation == 'splitBefore') {
        a.howMany++;
        return [
            a
        ];
    }
    // Case 4:
    //
    // This is a mirror to the case 2. above.
    //
    if (b.splitPosition.isEqual(a.insertionPosition) && context.baRelation == 'splitBefore') {
        const newPositionPath = b.insertionPosition.path.slice();
        newPositionPath.push(0);
        const newPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](b.insertionPosition.root, newPositionPath);
        const moveOp = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](a.insertionPosition, 1, newPosition, 0);
        return [
            a,
            moveOp
        ];
    }
    // The default case.
    //
    if (a.splitPosition.hasSameParentAs(b.splitPosition) && a.splitPosition.offset < b.splitPosition.offset) {
        a.howMany -= b.howMany;
    }
    a.splitPosition = a.splitPosition._getTransformedBySplitOperation(b);
    a.insertionPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getInsertionPosition(a.splitPosition);
    return [
        a
    ];
});
/**
 * Checks whether `MoveOperation` `targetPosition` is inside a node from the moved range of the other `MoveOperation`.
 */ function _moveTargetIntoMovedRange(a, b) {
    return a.targetPosition._getTransformedByDeletion(b.sourcePosition, b.howMany) === null;
}
/**
 * Helper function for `MoveOperation` x `MoveOperation` transformation. Converts given ranges and target position to
 * move operations and returns them.
 *
 * Ranges and target position will be transformed on-the-fly when generating operations.
 *
 * Given `ranges` should be in the order of how they were in the original transformed operation.
 *
 * Given `targetPosition` is the target position of the first range from `ranges`.
 */ function _makeMoveOperationsFromRanges(ranges, targetPosition) {
    // At this moment we have some ranges and a target position, to which those ranges should be moved.
    // Order in `ranges` array is the go-to order of after transformation.
    //
    // We are almost done. We have `ranges` and `targetPosition` to make operations from.
    // Unfortunately, those operations may affect each other. Precisely, first operation after move
    // may affect source range and target position of second and third operation. Same with second
    // operation affecting third.
    //
    // We need to fix those source ranges and target positions once again, before converting `ranges` to operations.
    const operations = [];
    // Keep in mind that nothing will be transformed if there is just one range in `ranges`.
    for(let i = 0; i < ranges.length; i++){
        // Create new operation out of a range and target position.
        const range = ranges[i];
        const op = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range.start, range.end.offset - range.start.offset, targetPosition, 0);
        operations.push(op);
        // Transform other ranges by the generated operation.
        for(let j = i + 1; j < ranges.length; j++){
            // All ranges in `ranges` array should be:
            //
            // * non-intersecting (these are part of original operation source range), and
            // * `targetPosition` does not target into them (opposite would mean that transformed operation targets "inside itself").
            //
            // This means that the transformation will be "clean" and always return one result.
            ranges[j] = ranges[j]._getTransformedByMove(op.sourcePosition, op.targetPosition, op.howMany)[0];
        }
        targetPosition = targetPosition._getTransformedByMove(op.sourcePosition, op.targetPosition, op.howMany);
    }
    return operations;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liveposition.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/liveposition
 */ __turbopack_context__.s([
    "default",
    ()=>LivePosition
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
;
;
class LivePosition extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
    /**
     * Creates a live position.
     *
     * @see module:engine/model/position~Position
     */ constructor(root, path, stickiness = 'toNone'){
        super(root, path, stickiness);
        if (!this.root.is('rootElement')) {
            /**
             * LivePosition's root has to be an instance of RootElement.
             *
             * @error model-liveposition-root-not-rootelement
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-liveposition-root-not-rootelement', root);
        }
        bindWithDocument.call(this);
    }
    /**
     * Unbinds all events previously bound by `LivePosition`. Use it whenever you don't need `LivePosition` instance
     * anymore (i.e. when leaving scope in which it was declared or before re-assigning variable that was
     * referring to it).
     */ detach() {
        this.stopListening();
    }
    /**
     * Creates a {@link module:engine/model/position~Position position instance}, which is equal to this live position.
     */ toPosition() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.root, this.path.slice(), this.stickiness);
    }
    /**
     * Creates a `LivePosition` instance that is equal to position.
     */ static fromPosition(position, stickiness) {
        return new this(position.root, position.path.slice(), stickiness ? stickiness : position.stickiness);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
LivePosition.prototype.is = function(type) {
    return type === 'livePosition' || type === 'model:livePosition' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
    type == 'position' || type === 'model:position';
};
/**
 * Binds this `LivePosition` to the {@link module:engine/model/document~Document document} that owns
 * this position's {@link module:engine/model/position~Position#root root}.
 */ function bindWithDocument() {
    this.listenTo(this.root.document.model, 'applyOperation', (event, args)=>{
        const operation = args[0];
        if (!operation.isDocumentOperation) {
            return;
        }
        transform.call(this, operation);
    }, {
        priority: 'low'
    });
}
/**
 * Updates this position accordingly to the updates applied to the model. Bases on change events.
 */ function transform(operation) {
    const result = this.getTransformedByOperation(operation);
    if (!this.isEqual(result)) {
        const oldPosition = this.toPosition();
        this.path = result.path;
        this.root = result.root;
        this.fire('change', oldPosition);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/batch.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/batch
 */ __turbopack_context__.s([
    "default",
    ()=>Batch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript)");
;
class Batch {
    /**
     * Creates a batch instance.
     *
     * @see module:engine/model/model~Model#enqueueChange
     * @see module:engine/model/model~Model#change
     * @param type A set of flags that specify the type of the batch. Batch type can alter how some of the features work
     * when encountering a given `Batch` instance (for example, when a feature listens to applied operations).
     */ constructor(type = {}){
        if (typeof type === 'string') {
            type = type === 'transparent' ? {
                isUndoable: false
            } : {};
            /**
             * The string value for a `type` property of the `Batch` constructor has been deprecated and will be removed in the near future.
             * Please refer to the {@link module:engine/model/batch~Batch#constructor `Batch` constructor API documentation} for more
             * information.
             *
             * @error batch-constructor-deprecated-string-type
             */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('batch-constructor-deprecated-string-type');
        }
        const { isUndoable = true, isLocal = true, isUndo = false, isTyping = false } = type;
        this.operations = [];
        this.isUndoable = isUndoable;
        this.isLocal = isLocal;
        this.isUndo = isUndo;
        this.isTyping = isTyping;
    }
    /**
     * The type of the batch.
     *
     * **This property has been deprecated and is always set to the `'default'` value.**
     *
     * It can be one of the following values:
     * * `'default'` &ndash; All "normal" batches. This is the most commonly used type.
     * * `'transparent'` &ndash; A batch that should be ignored by other features, i.e. an initial batch or collaborative editing
     * changes.
     *
     * @deprecated
     */ get type() {
        /**
         * The {@link module:engine/model/batch~Batch#type `Batch#type` } property has been deprecated and will be removed in the near
         * future. Use `Batch#isLocal`, `Batch#isUndoable`, `Batch#isUndo` and `Batch#isTyping` instead.
         *
         * @error batch-type-deprecated
         */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('batch-type-deprecated');
        return 'default';
    }
    /**
     * Returns the base version of this batch, which is equal to the base version of the first operation in the batch.
     * If there are no operations in the batch or neither operation has the base version set, it returns `null`.
     */ get baseVersion() {
        for (const op of this.operations){
            if (op.baseVersion !== null) {
                return op.baseVersion;
            }
        }
        return null;
    }
    /**
     * Adds an operation to the batch instance.
     *
     * @param operation An operation to add.
     * @returns The added operation.
     */ addOperation(operation) {
        operation.batch = this;
        this.operations.push(operation);
        return operation;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/differ.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/differ
 */ __turbopack_context__.s([
    "default",
    ()=>Differ
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
;
;
class Differ {
    /**
     * Creates a `Differ` instance.
     *
     * @param markerCollection Model's marker collection.
     */ constructor(markerCollection){
        /**
         * A map that stores changes that happened in a given element.
         *
         * The keys of the map are references to the model elements.
         * The values of the map are arrays with changes that were done on this element.
         */ this._changesInElement = new Map();
        /**
         * A map that stores "element's children snapshots". A snapshot is representing children of a given element before
         * the first change was applied on that element. Snapshot items are objects with two properties: `name`,
         * containing the element name (or `'$text'` for a text node) and `attributes` which is a map of the node's attributes.
         */ this._elementSnapshots = new Map();
        /**
         * A map that stores all changed markers.
         *
         * The keys of the map are marker names.
         * The values of the map are objects with the following properties:
         * - `oldMarkerData`,
         * - `newMarkerData`.
         */ this._changedMarkers = new Map();
        /**
         * A map that stores all roots that have been changed.
         *
         * The keys are the names of the roots while value represents the changes.
         */ this._changedRoots = new Map();
        /**
         * Stores the number of changes that were processed. Used to order the changes chronologically. It is important
         * when changes are sorted.
         */ this._changeCount = 0;
        /**
         * For efficiency purposes, `Differ` stores the change set returned by the differ after {@link #getChanges} call.
         * Cache is reset each time a new operation is buffered. If the cache has not been reset, {@link #getChanges} will
         * return the cached value instead of calculating it again.
         *
         * This property stores those changes that did not take place in graveyard root.
         */ this._cachedChanges = null;
        /**
         * For efficiency purposes, `Differ` stores the change set returned by the differ after the {@link #getChanges} call.
         * The cache is reset each time a new operation is buffered. If the cache has not been reset, {@link #getChanges} will
         * return the cached value instead of calculating it again.
         *
         * This property stores all changes evaluated by `Differ`, including those that took place in the graveyard.
         */ this._cachedChangesWithGraveyard = null;
        /**
         * Set of model items that were marked to get refreshed in {@link #_refreshItem}.
         */ this._refreshedItems = new Set();
        this._markerCollection = markerCollection;
    }
    /**
     * Informs whether there are any changes buffered in `Differ`.
     */ get isEmpty() {
        return this._changesInElement.size == 0 && this._changedMarkers.size == 0 && this._changedRoots.size == 0;
    }
    /**
     * Buffers the given operation. An operation has to be buffered before it is executed.
     *
     * @param operationToBuffer An operation to buffer.
     */ bufferOperation(operationToBuffer) {
        // Below we take an operation, check its type, then use its parameters in marking (private) methods.
        // The general rule is to not mark elements inside inserted element. All inserted elements are re-rendered.
        // Marking changes in them would cause a "double" changing then.
        //
        const operation = operationToBuffer;
        // Note: an operation that happens inside a non-loaded root will be ignored. If the operation happens partially inside
        // a non-loaded root, that part will be ignored (this may happen for move or marker operations).
        //
        switch(operation.type){
            case 'insert':
                {
                    if (this._isInInsertedElement(operation.position.parent)) {
                        return;
                    }
                    this._markInsert(operation.position.parent, operation.position.offset, operation.nodes.maxOffset);
                    break;
                }
            case 'addAttribute':
            case 'removeAttribute':
            case 'changeAttribute':
                {
                    for (const item of operation.range.getItems({
                        shallow: true
                    })){
                        if (this._isInInsertedElement(item.parent)) {
                            continue;
                        }
                        this._markAttribute(item);
                    }
                    break;
                }
            case 'remove':
            case 'move':
            case 'reinsert':
                {
                    // When range is moved to the same position then not mark it as a change.
                    // See: https://github.com/ckeditor/ckeditor5-engine/issues/1664.
                    if (operation.sourcePosition.isEqual(operation.targetPosition) || operation.sourcePosition.getShiftedBy(operation.howMany).isEqual(operation.targetPosition)) {
                        return;
                    }
                    const sourceParentInserted = this._isInInsertedElement(operation.sourcePosition.parent);
                    const targetParentInserted = this._isInInsertedElement(operation.targetPosition.parent);
                    if (!sourceParentInserted) {
                        this._markRemove(operation.sourcePosition.parent, operation.sourcePosition.offset, operation.howMany);
                    }
                    if (!targetParentInserted) {
                        this._markInsert(operation.targetPosition.parent, operation.getMovedRangeStart().offset, operation.howMany);
                    }
                    break;
                }
            case 'rename':
                {
                    if (this._isInInsertedElement(operation.position.parent)) {
                        return;
                    }
                    this._markRemove(operation.position.parent, operation.position.offset, 1);
                    this._markInsert(operation.position.parent, operation.position.offset, 1);
                    const range = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(operation.position, 1);
                    for (const marker of this._markerCollection.getMarkersIntersectingRange(range)){
                        const markerData = marker.getData();
                        this.bufferMarkerChange(marker.name, markerData, markerData);
                    }
                    break;
                }
            case 'split':
                {
                    const splitElement = operation.splitPosition.parent;
                    // Mark that children of the split element were removed.
                    if (!this._isInInsertedElement(splitElement)) {
                        this._markRemove(splitElement, operation.splitPosition.offset, operation.howMany);
                    }
                    // Mark that the new element (split copy) was inserted.
                    if (!this._isInInsertedElement(operation.insertionPosition.parent)) {
                        this._markInsert(operation.insertionPosition.parent, operation.insertionPosition.offset, 1);
                    }
                    // If the split took the element from the graveyard, mark that the element from the graveyard was removed.
                    if (operation.graveyardPosition) {
                        this._markRemove(operation.graveyardPosition.parent, operation.graveyardPosition.offset, 1);
                    }
                    break;
                }
            case 'merge':
                {
                    // Mark that the merged element was removed.
                    const mergedElement = operation.sourcePosition.parent;
                    if (!this._isInInsertedElement(mergedElement.parent)) {
                        this._markRemove(mergedElement.parent, mergedElement.startOffset, 1);
                    }
                    // Mark that the merged element was inserted into graveyard.
                    const graveyardParent = operation.graveyardPosition.parent;
                    this._markInsert(graveyardParent, operation.graveyardPosition.offset, 1);
                    // Mark that children of merged element were inserted at new parent.
                    const mergedIntoElement = operation.targetPosition.parent;
                    if (!this._isInInsertedElement(mergedIntoElement)) {
                        this._markInsert(mergedIntoElement, operation.targetPosition.offset, mergedElement.maxOffset);
                    }
                    break;
                }
            case 'detachRoot':
            case 'addRoot':
                {
                    const root = operation.affectedSelectable;
                    if (!root._isLoaded) {
                        return;
                    }
                    // Don't buffer if the root state does not change.
                    if (root.isAttached() == operation.isAdd) {
                        return;
                    }
                    this._bufferRootStateChange(operation.rootName, operation.isAdd);
                    break;
                }
            case 'addRootAttribute':
            case 'removeRootAttribute':
            case 'changeRootAttribute':
                {
                    if (!operation.root._isLoaded) {
                        return;
                    }
                    const rootName = operation.root.rootName;
                    this._bufferRootAttributeChange(rootName, operation.key, operation.oldValue, operation.newValue);
                    break;
                }
        }
        // Clear cache after each buffered operation as it is no longer valid.
        this._cachedChanges = null;
    }
    /**
     * Buffers a marker change.
     *
     * @param markerName The name of the marker that changed.
     * @param oldMarkerData Marker data before the change.
     * @param newMarkerData Marker data after the change.
     */ bufferMarkerChange(markerName, oldMarkerData, newMarkerData) {
        if (oldMarkerData.range && oldMarkerData.range.root.is('rootElement') && !oldMarkerData.range.root._isLoaded) {
            oldMarkerData.range = null;
        }
        if (newMarkerData.range && newMarkerData.range.root.is('rootElement') && !newMarkerData.range.root._isLoaded) {
            newMarkerData.range = null;
        }
        let buffered = this._changedMarkers.get(markerName);
        if (!buffered) {
            buffered = {
                newMarkerData,
                oldMarkerData
            };
            this._changedMarkers.set(markerName, buffered);
        } else {
            buffered.newMarkerData = newMarkerData;
        }
        if (buffered.oldMarkerData.range == null && newMarkerData.range == null) {
            // The marker is going to be removed (`newMarkerData.range == null`) but it did not exist before the first buffered change
            // (`buffered.oldMarkerData.range == null`). In this case, do not keep the marker in buffer at all.
            this._changedMarkers.delete(markerName);
        }
    }
    /**
     * Returns all markers that should be removed as a result of buffered changes.
     *
     * @returns Markers to remove. Each array item is an object containing the `name` and `range` properties.
     */ getMarkersToRemove() {
        const result = [];
        for (const [name, change] of this._changedMarkers){
            if (change.oldMarkerData.range != null) {
                result.push({
                    name,
                    range: change.oldMarkerData.range
                });
            }
        }
        return result;
    }
    /**
     * Returns all markers which should be added as a result of buffered changes.
     *
     * @returns Markers to add. Each array item is an object containing the `name` and `range` properties.
     */ getMarkersToAdd() {
        const result = [];
        for (const [name, change] of this._changedMarkers){
            if (change.newMarkerData.range != null) {
                result.push({
                    name,
                    range: change.newMarkerData.range
                });
            }
        }
        return result;
    }
    /**
     * Returns all markers which changed.
     */ getChangedMarkers() {
        return Array.from(this._changedMarkers).map(([name, change])=>({
                name,
                data: {
                    oldRange: change.oldMarkerData.range,
                    newRange: change.newMarkerData.range
                }
            }));
    }
    /**
     * Checks whether some of the buffered changes affect the editor data.
     *
     * Types of changes which affect the editor data:
     *
     * * model structure changes,
     * * attribute changes,
     * * a root is added or detached,
     * * changes of markers which were defined as `affectsData`,
     * * changes of markers' `affectsData` property.
     */ hasDataChanges() {
        if (this.getChanges().length) {
            return true;
        }
        if (this._changedRoots.size > 0) {
            return true;
        }
        for (const { newMarkerData, oldMarkerData } of this._changedMarkers.values()){
            if (newMarkerData.affectsData !== oldMarkerData.affectsData) {
                return true;
            }
            if (newMarkerData.affectsData) {
                const markerAdded = newMarkerData.range && !oldMarkerData.range;
                const markerRemoved = !newMarkerData.range && oldMarkerData.range;
                const markerChanged = newMarkerData.range && oldMarkerData.range && !newMarkerData.range.isEqual(oldMarkerData.range);
                if (markerAdded || markerRemoved || markerChanged) {
                    return true;
                }
            }
        }
        return false;
    }
    /**
     * Calculates the diff between the old model tree state (the state before the first buffered operations since the last {@link #reset}
     * call) and the new model tree state (actual one). It should be called after all buffered operations are executed.
     *
     * The diff set is returned as an array of {@link module:engine/model/differ~DiffItem diff items}, each describing a change done
     * on the model. The items are sorted by the position on which the change happened. If a position
     * {@link module:engine/model/position~Position#isBefore is before} another one, it will be on an earlier index in the diff set.
     *
     * **Note**: Elements inside inserted element will not have a separate diff item, only the top most element change will be reported.
     *
     * Because calculating the diff is a costly operation, the result is cached. If no new operation was buffered since the
     * previous {@link #getChanges} call, the next call will return the cached value.
     *
     * @param options Additional options.
     * @param options.includeChangesInGraveyard If set to `true`, also changes that happened
     * in the graveyard root will be returned. By default, changes in the graveyard root are not returned.
     * @returns Diff between the old and the new model tree state.
     */ getChanges(options = {}) {
        // If there are cached changes, just return them instead of calculating changes again.
        if (this._cachedChanges) {
            if (options.includeChangesInGraveyard) {
                return this._cachedChangesWithGraveyard.slice();
            } else {
                return this._cachedChanges.slice();
            }
        }
        // Will contain returned results.
        let diffSet = [];
        // Check all changed elements.
        for (const element of this._changesInElement.keys()){
            // Get changes for this element and sort them.
            const changes = this._changesInElement.get(element).sort((a, b)=>{
                if (a.offset === b.offset) {
                    if (a.type != b.type) {
                        // If there are multiple changes at the same position, "remove" change should be first.
                        // If the order is different, for example, we would first add some nodes and then removed them
                        // (instead of the nodes that we should remove).
                        return a.type == 'remove' ? -1 : 1;
                    }
                    return 0;
                }
                return a.offset < b.offset ? -1 : 1;
            });
            // Get children of this element before any change was applied on it.
            const snapshotChildren = this._elementSnapshots.get(element);
            // Get snapshot of current element's children.
            const elementChildren = _getChildrenSnapshot(element.getChildren());
            // Generate actions basing on changes done on element.
            const actions = _generateActionsFromChanges(snapshotChildren.length, changes);
            let i = 0; // Iterator in `elementChildren` array -- iterates through current children of element.
            let j = 0; // Iterator in `snapshotChildren` array -- iterates through old children of element.
            // Process every action.
            for (const action of actions){
                if (action === 'i') {
                    // Generate diff item for this element and insert it into the diff set.
                    diffSet.push(this._getInsertDiff(element, i, elementChildren[i]));
                    i++;
                } else if (action === 'r') {
                    // Generate diff item for this element and insert it into the diff set.
                    diffSet.push(this._getRemoveDiff(element, i, snapshotChildren[j]));
                    j++;
                } else if (action === 'a') {
                    // Take attributes from saved and current children.
                    const elementAttributes = elementChildren[i].attributes;
                    const snapshotAttributes = snapshotChildren[j].attributes;
                    let range;
                    if (elementChildren[i].name == '$text') {
                        range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(element, i), __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(element, i + 1));
                    } else {
                        const index = element.offsetToIndex(i);
                        range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(element, i), __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(element.getChild(index), 0));
                    }
                    // Generate diff items for this change (there might be multiple attributes changed and
                    // there is a single diff for each of them) and insert them into the diff set.
                    diffSet.push(...this._getAttributesDiff(range, snapshotAttributes, elementAttributes));
                    i++;
                    j++;
                } else {
                    // `action` is 'equal'. Child not changed.
                    i++;
                    j++;
                }
            }
        }
        // Then, sort the changes by the position (change at position before other changes is first).
        diffSet.sort((a, b)=>{
            // If the change is in different root, we don't care much, but we'd like to have all changes in given
            // root "together" in the array. So let's just sort them by the root name. It does not matter which root
            // will be processed first.
            if (a.position.root != b.position.root) {
                return a.position.root.rootName < b.position.root.rootName ? -1 : 1;
            }
            // If change happens at the same position...
            if (a.position.isEqual(b.position)) {
                // Keep chronological order of operations.
                return a.changeCount - b.changeCount;
            }
            // If positions differ, position "on the left" should be earlier in the result.
            return a.position.isBefore(b.position) ? -1 : 1;
        });
        // Glue together multiple changes (mostly on text nodes).
        for(let i = 1, prevIndex = 0; i < diffSet.length; i++){
            const prevDiff = diffSet[prevIndex];
            const thisDiff = diffSet[i];
            // Glue remove changes if they happen on text on same position.
            const isConsecutiveTextRemove = prevDiff.type == 'remove' && thisDiff.type == 'remove' && prevDiff.name == '$text' && thisDiff.name == '$text' && prevDiff.position.isEqual(thisDiff.position);
            // Glue insert changes if they happen on text on consecutive fragments.
            const isConsecutiveTextAdd = prevDiff.type == 'insert' && thisDiff.type == 'insert' && prevDiff.name == '$text' && thisDiff.name == '$text' && prevDiff.position.parent == thisDiff.position.parent && prevDiff.position.offset + prevDiff.length == thisDiff.position.offset;
            // Glue attribute changes if they happen on consecutive fragments and have same key, old value and new value.
            const isConsecutiveAttributeChange = prevDiff.type == 'attribute' && thisDiff.type == 'attribute' && prevDiff.position.parent == thisDiff.position.parent && prevDiff.range.isFlat && thisDiff.range.isFlat && prevDiff.position.offset + prevDiff.length == thisDiff.position.offset && prevDiff.attributeKey == thisDiff.attributeKey && prevDiff.attributeOldValue == thisDiff.attributeOldValue && prevDiff.attributeNewValue == thisDiff.attributeNewValue;
            if (isConsecutiveTextRemove || isConsecutiveTextAdd || isConsecutiveAttributeChange) {
                prevDiff.length++;
                if (isConsecutiveAttributeChange) {
                    prevDiff.range.end = prevDiff.range.end.getShiftedBy(1);
                }
                diffSet[i] = null;
            } else {
                prevIndex = i;
            }
        }
        diffSet = diffSet.filter((v)=>v);
        // Remove `changeCount` property from diff items. It is used only for sorting and is internal thing.
        for (const item of diffSet){
            delete item.changeCount;
            if (item.type == 'attribute') {
                delete item.position;
                delete item.length;
            }
        }
        this._changeCount = 0;
        // Cache changes.
        this._cachedChangesWithGraveyard = diffSet;
        this._cachedChanges = diffSet.filter(_changesInGraveyardFilter);
        if (options.includeChangesInGraveyard) {
            return this._cachedChangesWithGraveyard.slice();
        } else {
            return this._cachedChanges.slice();
        }
    }
    /**
     * Returns all roots that have changed (either were attached, or detached, or their attributes changed).
     *
     * @returns Diff between the old and the new roots state.
     */ getChangedRoots() {
        return Array.from(this._changedRoots.values()).map((diffItem)=>{
            const entry = {
                ...diffItem
            };
            if (entry.state !== undefined) {
                // The root was attached or detached -- do not return its attributes changes.
                // If the root was attached, it should be handled as a whole, together with its attributes, the same way as model nodes.
                // If the root was detached, its attributes should be discarded anyway.
                //
                // Keep in mind that filtering must happen on this stage (when retrieving changes). If filtering happens on-the-fly as
                // the attributes change, it may lead to incorrect situation, e.g.: detach root, change attribute, re-attach root.
                // In this case, attribute change cannot be filtered. After the root is re-attached, the attribute change must be kept.
                delete entry.attributes;
            }
            return entry;
        });
    }
    /**
     * Returns a set of model items that were marked to get refreshed.
     */ getRefreshedItems() {
        return new Set(this._refreshedItems);
    }
    /**
     * Resets `Differ`. Removes all buffered changes.
     */ reset() {
        this._changesInElement.clear();
        this._elementSnapshots.clear();
        this._changedMarkers.clear();
        this._changedRoots.clear();
        this._refreshedItems = new Set();
        this._cachedChanges = null;
    }
    /**
     * Buffers the root state change after the root was attached or detached
     */ _bufferRootStateChange(rootName, isAttached) {
        if (!this._changedRoots.has(rootName)) {
            this._changedRoots.set(rootName, {
                name: rootName,
                state: isAttached ? 'attached' : 'detached'
            });
            return;
        }
        const diffItem = this._changedRoots.get(rootName);
        if (diffItem.state !== undefined) {
            // Root `state` can only toggle between one of the values and no value. It cannot be any other way,
            // because if the root was originally attached it can only become detached. Then, if it is re-attached in the same batch of
            // changes, it gets back to "no change" (which means no value). Same if the root was originally detached.
            delete diffItem.state;
            if (diffItem.attributes === undefined) {
                // If there is no `state` change and no `attributes` change, remove the entry.
                this._changedRoots.delete(rootName);
            }
        } else {
            diffItem.state = isAttached ? 'attached' : 'detached';
        }
    }
    /**
     * Buffers a root attribute change.
     */ _bufferRootAttributeChange(rootName, key, oldValue, newValue) {
        const diffItem = this._changedRoots.get(rootName) || {
            name: rootName
        };
        const attrs = diffItem.attributes || {};
        if (attrs[key]) {
            // If this attribute or metadata was already changed earlier and is changed again, check to what value it is changed.
            const attrEntry = attrs[key];
            if (newValue === attrEntry.oldValue) {
                // If it was changed back to the old value, remove the entry.
                delete attrs[key];
            } else {
                // If it was changed to a different value, update the entry.
                attrEntry.newValue = newValue;
            }
        } else {
            // If this attribute or metadata was not set earlier, add an entry.
            attrs[key] = {
                oldValue,
                newValue
            };
        }
        if (Object.entries(attrs).length === 0) {
            // If attributes or metadata changes set became empty, remove it from the diff item.
            delete diffItem.attributes;
            if (diffItem.state === undefined) {
                // If there is no `state` change and no `attributes` change, remove the entry.
                this._changedRoots.delete(rootName);
            }
        } else {
            // Make sure that, if a new object in the structure was created, it gets set.
            diffItem.attributes = attrs;
            this._changedRoots.set(rootName, diffItem);
        }
    }
    /**
     * Marks the given `item` in differ to be "refreshed". It means that the item will be marked as removed and inserted
     * in the differ changes set, so it will be effectively re-converted when the differ changes are handled by a dispatcher.
     *
     * @internal
     * @param item Item to refresh.
     */ _refreshItem(item) {
        if (this._isInInsertedElement(item.parent)) {
            return;
        }
        this._markRemove(item.parent, item.startOffset, item.offsetSize);
        this._markInsert(item.parent, item.startOffset, item.offsetSize);
        this._refreshedItems.add(item);
        const range = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(item);
        for (const marker of this._markerCollection.getMarkersIntersectingRange(range)){
            const markerData = marker.getData();
            this.bufferMarkerChange(marker.name, markerData, markerData);
        }
        // Clear cache after each buffered operation as it is no longer valid.
        this._cachedChanges = null;
    }
    /**
     * Buffers all the data related to given root like it was all just added to the editor.
     *
     * Following changes are buffered:
     *
     * * root is attached,
     * * all root content is inserted,
     * * all root attributes are added,
     * * all markers inside the root are added.
     *
     * @internal
     */ _bufferRootLoad(root) {
        if (!root.isAttached()) {
            return;
        }
        this._bufferRootStateChange(root.rootName, true);
        this._markInsert(root, 0, root.maxOffset);
        // Buffering root attribute changes makes sense and is actually needed, even though we buffer root state change above.
        // Because the root state change is buffered, the root attributes changes are not returned by the differ.
        // But, if the root attribute is removed in the same change block, or the root is detached, then the differ results would be wrong.
        //
        for (const key of root.getAttributeKeys()){
            this._bufferRootAttributeChange(root.rootName, key, null, root.getAttribute(key));
        }
        for (const marker of this._markerCollection){
            if (marker.getRange().root == root) {
                const markerData = marker.getData();
                this.bufferMarkerChange(marker.name, {
                    ...markerData,
                    range: null
                }, markerData);
            }
        }
    }
    /**
     * Saves and handles an insert change.
     */ _markInsert(parent, offset, howMany) {
        if (parent.root.is('rootElement') && !parent.root._isLoaded) {
            return;
        }
        const changeItem = {
            type: 'insert',
            offset,
            howMany,
            count: this._changeCount++
        };
        this._markChange(parent, changeItem);
    }
    /**
     * Saves and handles a remove change.
     */ _markRemove(parent, offset, howMany) {
        if (parent.root.is('rootElement') && !parent.root._isLoaded) {
            return;
        }
        const changeItem = {
            type: 'remove',
            offset,
            howMany,
            count: this._changeCount++
        };
        this._markChange(parent, changeItem);
        this._removeAllNestedChanges(parent, offset, howMany);
    }
    /**
     * Saves and handles an attribute change.
     */ _markAttribute(item) {
        if (item.root.is('rootElement') && !item.root._isLoaded) {
            return;
        }
        const changeItem = {
            type: 'attribute',
            offset: item.startOffset,
            howMany: item.offsetSize,
            count: this._changeCount++
        };
        this._markChange(item.parent, changeItem);
    }
    /**
     * Saves and handles a model change.
     */ _markChange(parent, changeItem) {
        // First, make a snapshot of this parent's children (it will be made only if it was not made before).
        this._makeSnapshot(parent);
        // Then, get all changes that already were done on the element (empty array if this is the first change).
        const changes = this._getChangesForElement(parent);
        // Then, look through all the changes, and transform them or the new change.
        this._handleChange(changeItem, changes);
        // Add the new change.
        changes.push(changeItem);
        // Remove incorrect changes. During transformation some change might be, for example, included in another.
        // In that case, the change will have `howMany` property set to `0` or less. We need to remove those changes.
        for(let i = 0; i < changes.length; i++){
            if (changes[i].howMany < 1) {
                changes.splice(i, 1);
                i--;
            }
        }
    }
    /**
     * Gets an array of changes that have already been saved for a given element.
     */ _getChangesForElement(element) {
        let changes;
        if (this._changesInElement.has(element)) {
            changes = this._changesInElement.get(element);
        } else {
            changes = [];
            this._changesInElement.set(element, changes);
        }
        return changes;
    }
    /**
     * Saves a children snapshot for a given element.
     */ _makeSnapshot(element) {
        if (!this._elementSnapshots.has(element)) {
            this._elementSnapshots.set(element, _getChildrenSnapshot(element.getChildren()));
        }
    }
    /**
     * For a given newly saved change, compares it with a change already done on the element and modifies the incoming
     * change and/or the old change.
     *
     * @param inc Incoming (new) change.
     * @param changes An array containing all the changes done on that element.
     */ _handleChange(inc, changes) {
        // We need a helper variable that will store how many nodes are to be still handled for this change item.
        // `nodesToHandle` (how many nodes still need to be handled) and `howMany` (how many nodes were affected)
        // needs to be differentiated.
        //
        // This comes up when there are multiple changes that are affected by `inc` change item.
        //
        // For example: assume two insert changes: `{ offset: 2, howMany: 1 }` and `{ offset: 5, howMany: 1 }`.
        // Assume that `inc` change is remove `{ offset: 2, howMany: 2, nodesToHandle: 2 }`.
        //
        // Then, we:
        // - "forget" about first insert change (it is "eaten" by remove),
        // - because of that, at the end we will want to remove only one node (`nodesToHandle = 1`),
        // - but still we have to change offset of the second insert change from `5` to `3`!
        //
        // So, `howMany` does not change throughout items transformation and keeps information about how many nodes were affected,
        // while `nodesToHandle` means how many nodes need to be handled after the change item is transformed by other changes.
        inc.nodesToHandle = inc.howMany;
        for (const old of changes){
            const incEnd = inc.offset + inc.howMany;
            const oldEnd = old.offset + old.howMany;
            if (inc.type == 'insert') {
                if (old.type == 'insert') {
                    if (inc.offset <= old.offset) {
                        old.offset += inc.howMany;
                    } else if (inc.offset < oldEnd) {
                        old.howMany += inc.nodesToHandle;
                        inc.nodesToHandle = 0;
                    }
                }
                if (old.type == 'remove') {
                    if (inc.offset < old.offset) {
                        old.offset += inc.howMany;
                    }
                }
                if (old.type == 'attribute') {
                    if (inc.offset <= old.offset) {
                        old.offset += inc.howMany;
                    } else if (inc.offset < oldEnd) {
                        // This case is more complicated, because attribute change has to be split into two.
                        // Example (assume that uppercase and lowercase letters mean different attributes):
                        //
                        // initial state:		abcxyz
                        // attribute change:	aBCXYz
                        // incoming insert:		aBCfooXYz
                        //
                        // Change ranges cannot intersect because each item has to be described exactly (it was either
                        // not changed, inserted, removed, or its attribute was changed). That's why old attribute
                        // change has to be split and both parts has to be handled separately from now on.
                        const howMany = old.howMany;
                        old.howMany = inc.offset - old.offset;
                        // Add the second part of attribute change to the beginning of processed array so it won't
                        // be processed again in this loop.
                        changes.unshift({
                            type: 'attribute',
                            offset: incEnd,
                            howMany: howMany - old.howMany,
                            count: this._changeCount++
                        });
                    }
                }
            }
            if (inc.type == 'remove') {
                if (old.type == 'insert') {
                    if (incEnd <= old.offset) {
                        old.offset -= inc.howMany;
                    } else if (incEnd <= oldEnd) {
                        if (inc.offset < old.offset) {
                            const intersectionLength = incEnd - old.offset;
                            old.offset = inc.offset;
                            old.howMany -= intersectionLength;
                            inc.nodesToHandle -= intersectionLength;
                        } else {
                            old.howMany -= inc.nodesToHandle;
                            inc.nodesToHandle = 0;
                        }
                    } else {
                        if (inc.offset <= old.offset) {
                            inc.nodesToHandle -= old.howMany;
                            old.howMany = 0;
                        } else if (inc.offset < oldEnd) {
                            const intersectionLength = oldEnd - inc.offset;
                            old.howMany -= intersectionLength;
                            inc.nodesToHandle -= intersectionLength;
                        }
                    }
                }
                if (old.type == 'remove') {
                    if (incEnd <= old.offset) {
                        old.offset -= inc.howMany;
                    } else if (inc.offset < old.offset) {
                        inc.nodesToHandle += old.howMany;
                        old.howMany = 0;
                    }
                }
                if (old.type == 'attribute') {
                    if (incEnd <= old.offset) {
                        old.offset -= inc.howMany;
                    } else if (inc.offset < old.offset) {
                        const intersectionLength = incEnd - old.offset;
                        old.offset = inc.offset;
                        old.howMany -= intersectionLength;
                    } else if (inc.offset < oldEnd) {
                        if (incEnd <= oldEnd) {
                            // On first sight in this case we don't need to split attribute operation into two.
                            // However the changes set is later converted to actions (see `_generateActionsFromChanges`).
                            // For that reason, no two changes may intersect.
                            // So we cannot have an attribute change that "contains" remove change.
                            // Attribute change needs to be split.
                            const howMany = old.howMany;
                            old.howMany = inc.offset - old.offset;
                            const howManyAfter = howMany - old.howMany - inc.nodesToHandle;
                            // Add the second part of attribute change to the beginning of processed array so it won't
                            // be processed again in this loop.
                            changes.unshift({
                                type: 'attribute',
                                offset: inc.offset,
                                howMany: howManyAfter,
                                count: this._changeCount++
                            });
                        } else {
                            old.howMany -= oldEnd - inc.offset;
                        }
                    }
                }
            }
            if (inc.type == 'attribute') {
                // In case of attribute change, `howMany` should be kept same as `nodesToHandle`. It's not an error.
                if (old.type == 'insert') {
                    if (inc.offset < old.offset && incEnd > old.offset) {
                        if (incEnd > oldEnd) {
                            // This case is similar to a case described when incoming change was insert and old change was attribute.
                            // See comment above.
                            //
                            // This time incoming change is attribute. We need to split incoming change in this case too.
                            // However this time, the second part of the attribute change needs to be processed further
                            // because there might be other changes that it collides with.
                            const attributePart = {
                                type: 'attribute',
                                offset: oldEnd,
                                howMany: incEnd - oldEnd,
                                count: this._changeCount++
                            };
                            this._handleChange(attributePart, changes);
                            changes.push(attributePart);
                        }
                        inc.nodesToHandle = old.offset - inc.offset;
                        inc.howMany = inc.nodesToHandle;
                    } else if (inc.offset >= old.offset && inc.offset < oldEnd) {
                        if (incEnd > oldEnd) {
                            inc.nodesToHandle = incEnd - oldEnd;
                            inc.offset = oldEnd;
                        } else {
                            inc.nodesToHandle = 0;
                        }
                    }
                }
                if (old.type == 'remove') {
                    // This is a case when attribute change "contains" remove change.
                    // The attribute change needs to be split into two because changes cannot intersect.
                    if (inc.offset < old.offset && incEnd > old.offset) {
                        const attributePart = {
                            type: 'attribute',
                            offset: old.offset,
                            howMany: incEnd - old.offset,
                            count: this._changeCount++
                        };
                        this._handleChange(attributePart, changes);
                        changes.push(attributePart);
                        inc.nodesToHandle = old.offset - inc.offset;
                        inc.howMany = inc.nodesToHandle;
                    }
                }
                if (old.type == 'attribute') {
                    // There are only two conflicting scenarios possible here:
                    if (inc.offset >= old.offset && incEnd <= oldEnd) {
                        // `old` change includes `inc` change, or they are the same.
                        inc.nodesToHandle = 0;
                        inc.howMany = 0;
                        inc.offset = 0;
                    } else if (inc.offset <= old.offset && incEnd >= oldEnd) {
                        // `inc` change includes `old` change.
                        old.howMany = 0;
                    }
                }
            }
        }
        inc.howMany = inc.nodesToHandle;
        delete inc.nodesToHandle;
    }
    /**
     * Returns an object with a single insert change description.
     *
     * @param parent The element in which the change happened.
     * @param offset The offset at which change happened.
     * @param elementSnapshot The snapshot of the removed element a character.
     * @returns The diff item.
     */ _getInsertDiff(parent, offset, elementSnapshot) {
        return {
            type: 'insert',
            position: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(parent, offset),
            name: elementSnapshot.name,
            attributes: new Map(elementSnapshot.attributes),
            length: 1,
            changeCount: this._changeCount++,
            _element: elementSnapshot.element
        };
    }
    /**
     * Returns an object with a single remove change description.
     *
     * @param parent The element in which change happened.
     * @param offset The offset at which change happened.
     * @param elementSnapshot The snapshot of the removed element a character.
     * @returns The diff item.
     */ _getRemoveDiff(parent, offset, elementSnapshot) {
        return {
            type: 'remove',
            position: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(parent, offset),
            name: elementSnapshot.name,
            attributes: new Map(elementSnapshot.attributes),
            length: 1,
            changeCount: this._changeCount++,
            _element: elementSnapshot.element
        };
    }
    /**
     * Returns an array of objects where each one is a single attribute change description.
     *
     * @param range The range where the change happened.
     * @param oldAttributes A map, map iterator or compatible object that contains attributes before the change.
     * @param newAttributes A map, map iterator or compatible object that contains attributes after the change.
     * @returns An array containing one or more diff items.
     */ _getAttributesDiff(range, oldAttributes, newAttributes) {
        // Results holder.
        const diffs = [];
        // Clone new attributes as we will be performing changes on this object.
        newAttributes = new Map(newAttributes);
        // Look through old attributes.
        for (const [key, oldValue] of oldAttributes){
            // Check what is the new value of the attribute (or if it was removed).
            const newValue = newAttributes.has(key) ? newAttributes.get(key) : null;
            // If values are different (or attribute was removed)...
            if (newValue !== oldValue) {
                // Add diff item.
                diffs.push({
                    type: 'attribute',
                    position: range.start,
                    range: range.clone(),
                    length: 1,
                    attributeKey: key,
                    attributeOldValue: oldValue,
                    attributeNewValue: newValue,
                    changeCount: this._changeCount++
                });
            }
            // Prevent returning two diff items for the same change.
            newAttributes.delete(key);
        }
        // Look through new attributes that weren't handled above.
        for (const [key, newValue] of newAttributes){
            // Each of them is a new attribute. Add diff item.
            diffs.push({
                type: 'attribute',
                position: range.start,
                range: range.clone(),
                length: 1,
                attributeKey: key,
                attributeOldValue: null,
                attributeNewValue: newValue,
                changeCount: this._changeCount++
            });
        }
        return diffs;
    }
    /**
     * Checks whether given element or any of its parents is an element that is buffered as an inserted element.
     */ _isInInsertedElement(element) {
        const parent = element.parent;
        if (!parent) {
            return false;
        }
        const changes = this._changesInElement.get(parent);
        const offset = element.startOffset;
        if (changes) {
            for (const change of changes){
                if (change.type == 'insert' && offset >= change.offset && offset < change.offset + change.howMany) {
                    return true;
                }
            }
        }
        return this._isInInsertedElement(parent);
    }
    /**
     * Removes deeply all buffered changes that are registered in elements from range specified by `parent`, `offset`
     * and `howMany`.
     */ _removeAllNestedChanges(parent, offset, howMany) {
        const range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(parent, offset), __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(parent, offset + howMany));
        for (const item of range.getItems({
            shallow: true
        })){
            if (item.is('element')) {
                this._elementSnapshots.delete(item);
                this._changesInElement.delete(item);
                this._removeAllNestedChanges(item, 0, item.maxOffset);
            }
        }
    }
}
/**
 * Returns an array that is a copy of passed child list with the exception that text nodes are split to one or more
 * objects, each representing one character and attributes set on that character.
 */ function _getChildrenSnapshot(children) {
    const snapshot = [];
    for (const child of children){
        if (child.is('$text')) {
            for(let i = 0; i < child.data.length; i++){
                snapshot.push({
                    name: '$text',
                    attributes: new Map(child.getAttributes())
                });
            }
        } else {
            snapshot.push({
                name: child.name,
                attributes: new Map(child.getAttributes()),
                element: child
            });
        }
    }
    return snapshot;
}
/**
 * Generates array of actions for given changes set.
 * It simulates what `diff` function does.
 * Generated actions are:
 * - 'e' for 'equal' - when item at that position did not change,
 * - 'i' for 'insert' - when item at that position was inserted,
 * - 'r' for 'remove' - when item at that position was removed,
 * - 'a' for 'attribute' - when item at that position has it attributes changed.
 *
 * Example (assume that uppercase letters have bold attribute, compare with function code):
 *
 * children before:	fooBAR
 * children after:	foxybAR
 *
 * changes: type: remove, offset: 1, howMany: 1
 *			type: insert, offset: 2, howMany: 2
 *			type: attribute, offset: 4, howMany: 1
 *
 * expected actions: equal (f), remove (o), equal (o), insert (x), insert (y), attribute (b), equal (A), equal (R)
 *
 * steps taken by th script:
 *
 * 1. change = "type: remove, offset: 1, howMany: 1"; offset = 0; oldChildrenHandled = 0
 *    1.1 between this change and the beginning is one not-changed node, fill with one equal action, one old child has been handled
 *    1.2 this change removes one node, add one remove action
 *    1.3 change last visited `offset` to 1
 *    1.4 since an old child has been removed, one more old child has been handled
 *    1.5 actions at this point are: equal, remove
 *
 * 2. change = "type: insert, offset: 2, howMany: 2"; offset = 1; oldChildrenHandled = 2
 *    2.1 between this change and previous change is one not-changed node, add equal action, another one old children has been handled
 *    2.2 this change inserts two nodes, add two insert actions
 *    2.3 change last visited offset to the end of the inserted range, that is 4
 *    2.4 actions at this point are: equal, remove, equal, insert, insert
 *
 * 3. change = "type: attribute, offset: 4, howMany: 1"; offset = 4, oldChildrenHandled = 3
 *    3.1 between this change and previous change are no not-changed nodes
 *    3.2 this change changes one node, add one attribute action
 *    3.3 change last visited `offset` to the end of change range, that is 5
 *    3.4 since an old child has been changed, one more old child has been handled
 *    3.5 actions at this point are: equal, remove, equal, insert, insert, attribute
 *
 * 4. after loop oldChildrenHandled = 4, oldChildrenLength = 6 (fooBAR is 6 characters)
 *    4.1 fill up with two equal actions
 *
 * The result actions are: equal, remove, equal, insert, insert, attribute, equal, equal.
 */ function _generateActionsFromChanges(oldChildrenLength, changes) {
    const actions = [];
    let offset = 0;
    let oldChildrenHandled = 0;
    // Go through all buffered changes.
    for (const change of changes){
        // First, fill "holes" between changes with "equal" actions.
        if (change.offset > offset) {
            for(let i = 0; i < change.offset - offset; i++){
                actions.push('e');
            }
            oldChildrenHandled += change.offset - offset;
        }
        // Then, fill up actions accordingly to change type.
        if (change.type == 'insert') {
            for(let i = 0; i < change.howMany; i++){
                actions.push('i');
            }
            // The last handled offset is after inserted range.
            offset = change.offset + change.howMany;
        } else if (change.type == 'remove') {
            for(let i = 0; i < change.howMany; i++){
                actions.push('r');
            }
            // The last handled offset is at the position where the nodes were removed.
            offset = change.offset;
            // We removed `howMany` old nodes, update `oldChildrenHandled`.
            oldChildrenHandled += change.howMany;
        } else {
            actions.push(...'a'.repeat(change.howMany).split(''));
            // The last handled offset is at the position after the changed range.
            offset = change.offset + change.howMany;
            // We changed `howMany` old nodes, update `oldChildrenHandled`.
            oldChildrenHandled += change.howMany;
        }
    }
    // Fill "equal" actions at the end of actions set. Use `oldChildrenHandled` to see how many children
    // has not been changed / removed at the end of their parent.
    if (oldChildrenHandled < oldChildrenLength) {
        for(let i = 0; i < oldChildrenLength - oldChildrenHandled - offset; i++){
            actions.push('e');
        }
    }
    return actions;
}
/**
 * Filter callback for Array.filter that filters out change entries that are in graveyard.
 */ function _changesInGraveyardFilter(entry) {
    const posInGy = 'position' in entry && entry.position.root.rootName == '$graveyard';
    const rangeInGy = 'range' in entry && entry.range.root.rootName == '$graveyard';
    return !posInGy && !rangeInGy;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/history.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "default",
    ()=>History
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
class History {
    constructor(){
        /**
         * Operations added to the history.
         */ this._operations = [];
        /**
         * Holds an information which {@link module:engine/model/operation/operation~Operation operation} undoes which
         * {@link module:engine/model/operation/operation~Operation operation}.
         *
         * Keys of the map are "undoing operations", that is operations that undone some other operations. For each key, the
         * value is an operation that has been undone by the "undoing operation".
         */ this._undoPairs = new Map();
        /**
         * Holds all undone operations.
         */ this._undoneOperations = new Set();
        /**
         * A map that allows retrieving the operations fast based on the given base version.
         */ this._baseVersionToOperationIndex = new Map();
        /**
         * The history version.
         */ this._version = 0;
        /**
         * The gap pairs kept in the <from,to> format.
         *
         * Anytime the `history.version` is set to a version larger than `history.version + 1`,
         * a new <lastHistoryVersion, newHistoryVersion> entry is added to the map.
         */ this._gaps = new Map();
    }
    /**
     * The version of the last operation in the history.
     *
     * The history version is incremented automatically when a new operation is added to the history.
     * Setting the version manually should be done only in rare circumstances when a gap is planned
     * between history versions. When doing so, a gap will be created and the history will accept adding
     * an operation with base version equal to the new history version.
     */ get version() {
        return this._version;
    }
    set version(version) {
        // Store a gap if there are some operations already in the history and the
        // new version does not increment the latest one.
        if (this._operations.length && version > this._version + 1) {
            this._gaps.set(this._version, version);
        }
        this._version = version;
    }
    /**
     * The last history operation.
     */ get lastOperation() {
        return this._operations[this._operations.length - 1];
    }
    /**
     * Adds an operation to the history and increments the history version.
     *
     * The operation's base version should be equal to the history version. Otherwise an error is thrown.
     */ addOperation(operation) {
        if (operation.baseVersion !== this.version) {
            /**
             * Only operations with matching versions can be added to the history.
             *
             * @error model-document-history-addoperation-incorrect-version
             * @param errorData The operation and the current document history version.
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-document-history-addoperation-incorrect-version', this, {
                operation,
                historyVersion: this.version
            });
        }
        this._operations.push(operation);
        this._version++;
        this._baseVersionToOperationIndex.set(operation.baseVersion, this._operations.length - 1);
    }
    /**
     * Returns operations from the given range of operation base versions that were added to the history.
     *
     * Note that there may be gaps in operations base versions.
     *
     * @param fromBaseVersion Base version from which operations should be returned (inclusive).
     * @param toBaseVersion Base version up to which operations should be returned (exclusive).
     * @returns History operations for the given range, in chronological order.
     */ getOperations(fromBaseVersion, toBaseVersion = this.version) {
        // When there is no operation in the history, return an empty array.
        // After that we can be sure that `firstOperation`, `lastOperation` are not nullish.
        if (!this._operations.length) {
            return [];
        }
        const firstOperation = this._operations[0];
        if (fromBaseVersion === undefined) {
            fromBaseVersion = firstOperation.baseVersion;
        }
        // Change exclusive `toBaseVersion` to inclusive, so it will refer to the actual index.
        // Thanks to that mapping from base versions to operation indexes are possible.
        let inclusiveTo = toBaseVersion - 1;
        // Check if "from" or "to" point to a gap between versions.
        // If yes, then change the incorrect position to the proper side of the gap.
        // Thanks to it, it will be possible to get index of the operation.
        for (const [gapFrom, gapTo] of this._gaps){
            if (fromBaseVersion > gapFrom && fromBaseVersion < gapTo) {
                fromBaseVersion = gapTo;
            }
            if (inclusiveTo > gapFrom && inclusiveTo < gapTo) {
                inclusiveTo = gapFrom - 1;
            }
        }
        // If the whole range is outside of the operation versions, then return an empty array.
        if (inclusiveTo < firstOperation.baseVersion || fromBaseVersion > this.lastOperation.baseVersion) {
            return [];
        }
        let fromIndex = this._baseVersionToOperationIndex.get(fromBaseVersion);
        // If the range starts before the first operation, then use the first operation as the range's start.
        if (fromIndex === undefined) {
            fromIndex = 0;
        }
        let toIndex = this._baseVersionToOperationIndex.get(inclusiveTo);
        // If the range ends after the last operation, then use the last operation as the range's end.
        if (toIndex === undefined) {
            toIndex = this._operations.length - 1;
        }
        // Return the part of the history operations based on the calculated start index and end index.
        return this._operations.slice(fromIndex, // The `toIndex` should be included in the returned operations, so add `1`.
        toIndex + 1);
    }
    /**
     * Returns operation from the history that bases on given `baseVersion`.
     *
     * @param baseVersion Base version of the operation to get.
     * @returns Operation with given base version or `undefined` if there is no such operation in history.
     */ getOperation(baseVersion) {
        const operationIndex = this._baseVersionToOperationIndex.get(baseVersion);
        if (operationIndex === undefined) {
            return;
        }
        return this._operations[operationIndex];
    }
    /**
     * Marks in history that one operation is an operation that is undoing the other operation. By marking operation this way,
     * history is keeping more context information about operations, which helps in operational transformation.
     *
     * @param undoneOperation Operation which is undone by `undoingOperation`.
     * @param undoingOperation Operation which undoes `undoneOperation`.
     */ setOperationAsUndone(undoneOperation, undoingOperation) {
        this._undoPairs.set(undoingOperation, undoneOperation);
        this._undoneOperations.add(undoneOperation);
    }
    /**
     * Checks whether given `operation` is undoing any other operation.
     *
     * @param operation Operation to check.
     * @returns `true` if given `operation` is undoing any other operation, `false` otherwise.
     */ isUndoingOperation(operation) {
        return this._undoPairs.has(operation);
    }
    /**
     * Checks whether given `operation` has been undone by any other operation.
     *
     * @param operation Operation to check.
     * @returns `true` if given `operation` has been undone any other operation, `false` otherwise.
     */ isUndoneOperation(operation) {
        return this._undoneOperations.has(operation);
    }
    /**
     * For given `undoingOperation`, returns the operation which has been undone by it.
     *
     * @returns Operation that has been undone by given `undoingOperation` or `undefined`
     * if given `undoingOperation` is not undoing any other operation.
     */ getUndoneOperation(undoingOperation) {
        return this._undoPairs.get(undoingOperation);
    }
    /**
     * Resets the history of operations.
     */ reset() {
        this._version = 0;
        this._undoPairs = new Map();
        this._operations = [];
        this._undoneOperations = new Set();
        this._gaps = new Map();
        this._baseVersionToOperationIndex = new Map();
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/rootelement.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/rootelement
 */ __turbopack_context__.s([
    "default",
    ()=>RootElement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
;
class RootElement extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates root element.
     *
     * @param document Document that is an owner of this root.
     * @param name Node name.
     * @param rootName Unique root name used to identify this root element by {@link module:engine/model/document~Document}.
     */ constructor(document, name, rootName = 'main'){
        super(name);
        /**
         * @internal
         */ this._isAttached = true;
        /**
         * Informs if the root element is loaded (default).
         *
         * @internal
         */ this._isLoaded = true;
        this._document = document;
        this.rootName = rootName;
    }
    /**
     * {@link module:engine/model/document~Document Document} that owns this root element.
     */ get document() {
        return this._document;
    }
    /**
     * Informs if the root element is currently attached to the document, or not.
     *
     * A detached root is equivalent to being removed and cannot contain any children or markers.
     *
     * By default, a newly added root is attached. It can be detached using
     * {@link module:engine/model/writer~Writer#detachRoot `Writer#detachRoot`}. A detached root can be re-attached again using
     * {@link module:engine/model/writer~Writer#addRoot `Writer#addRoot`}.
     */ isAttached() {
        return this._isAttached;
    }
    /**
     * Converts `RootElement` instance to `string` containing its name.
     *
     * @returns `RootElement` instance converted to `string`.
     */ toJSON() {
        return this.rootName;
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
RootElement.prototype.is = function(type, name) {
    if (!name) {
        return type === 'rootElement' || type === 'model:rootElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'element' || type === 'model:element' || type === 'node' || type === 'model:node';
    }
    return name === this.name && (type === 'rootElement' || type === 'model:rootElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
    type === 'element' || type === 'model:element');
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/document.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/document
 */ __turbopack_context__.s([
    "default",
    ()=>Document
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$differ$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/differ.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$history$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/history.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$rootelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/rootelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$collection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Collection$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/collection.js [app-ssr] (ecmascript) <export default as Collection>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$unicode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/unicode.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$clone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__clone$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/clone.js [app-ssr] (ecmascript) <export default as clone>");
;
;
;
;
;
;
// @if CK_DEBUG_ENGINE // const { logDocument } = require( '../dev-utils/utils' );
const graveyardName = '$graveyard';
class Document extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])() {
    /**
     * Creates an empty document instance with no {@link #roots} (other than
     * the {@link #graveyard graveyard root}).
     */ constructor(model){
        super();
        this.model = model;
        this.history = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$history$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        this.selection = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this);
        this.roots = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$collection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Collection$3e$__["Collection"]({
            idProperty: 'rootName'
        });
        this.differ = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$differ$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](model.markers);
        this.isReadOnly = false;
        this._postFixers = new Set();
        this._hasSelectionChangedFromTheLastChangeBlock = false;
        // Graveyard tree root. Document always have a graveyard root, which stores removed nodes.
        this.createRoot('$root', graveyardName);
        // Then, still before an operation is applied on model, buffer the change in differ.
        this.listenTo(model, 'applyOperation', (evt, args)=>{
            const operation = args[0];
            if (operation.isDocumentOperation) {
                this.differ.bufferOperation(operation);
            }
        }, {
            priority: 'high'
        });
        // After the operation is applied, bump document's version and add the operation to the history.
        this.listenTo(model, 'applyOperation', (evt, args)=>{
            const operation = args[0];
            if (operation.isDocumentOperation) {
                this.history.addOperation(operation);
            }
        }, {
            priority: 'low'
        });
        // Listen to selection changes. If selection changed, mark it.
        this.listenTo(this.selection, 'change', ()=>{
            this._hasSelectionChangedFromTheLastChangeBlock = true;
        });
        // Buffer marker changes.
        // This is not covered in buffering operations because markers may change outside of them (when they
        // are modified using `model.markers` collection, not through `MarkerOperation`).
        this.listenTo(model.markers, 'update', (evt, marker, oldRange, newRange, oldMarkerData)=>{
            // Copy the `newRange` to the new marker data as during the marker removal the range is not updated.
            const newMarkerData = {
                ...marker.getData(),
                range: newRange
            };
            // Whenever marker is updated, buffer that change.
            this.differ.bufferMarkerChange(marker.name, oldMarkerData, newMarkerData);
            if (oldRange === null) {
                // If this is a new marker, add a listener that will buffer change whenever marker changes.
                marker.on('change', (evt, oldRange)=>{
                    const markerData = marker.getData();
                    this.differ.bufferMarkerChange(marker.name, {
                        ...markerData,
                        range: oldRange
                    }, markerData);
                });
            }
        });
        // This is a solution for a problem that may occur during real-time editing. If one client detached a root and another added
        // something there at the same moment, the OT does not solve this problem currently. In such situation, the added elements would
        // stay in the detached root.
        //
        // This is incorrect, a detached root should be empty and all elements from it should be removed. To solve this, the post-fixer will
        // remove any element that is left in a detached root.
        //
        // Similarly, markers that are created at the beginning or at the end of the detached root will not be removed as well.
        //
        // The drawback of this solution over the OT solution is that the elements removed by the post-fixer will never be brought back.
        // If the root detachment gets undone (and the root is brought back), the removed elements will not be there.
        this.registerPostFixer((writer)=>{
            let result = false;
            for (const root of this.roots){
                if (!root.isAttached() && !root.isEmpty) {
                    writer.remove(writer.createRangeIn(root));
                    result = true;
                }
            }
            for (const marker of this.model.markers){
                if (!marker.getRange().root.isAttached()) {
                    writer.removeMarker(marker);
                    result = true;
                }
            }
            return result;
        });
    }
    /**
     * The document version. Every applied operation increases the version number. It is used to
     * ensure that operations are applied on a proper document version.
     *
     * This property is equal to {@link module:engine/model/history~History#version `model.Document#history#version`}.
     *
     * If the {@link module:engine/model/operation/operation~Operation#baseVersion base version} does not match the document version,
     * a {@link module:utils/ckeditorerror~CKEditorError model-document-applyoperation-wrong-version} error is thrown.
     */ get version() {
        return this.history.version;
    }
    set version(version) {
        this.history.version = version;
    }
    /**
     * The graveyard tree root. A document always has a graveyard root that stores removed nodes.
     */ get graveyard() {
        return this.getRoot(graveyardName);
    }
    /**
     * Creates a new root.
     *
     * **Note:** do not use this method after the editor has been initialized! If you want to dynamically add a root, use
     * {@link module:engine/model/writer~Writer#addRoot `model.Writer#addRoot`} instead.
     *
     * @param elementName The element name. Defaults to `'$root'` which also has some basic schema defined
     * (e.g. `$block` elements are allowed inside the `$root`). Make sure to define a proper schema if you use a different name.
     * @param rootName A unique root name.
     * @returns The created root.
     */ createRoot(elementName = '$root', rootName = 'main') {
        if (this.roots.get(rootName)) {
            /**
             * A root with the specified name already exists.
             *
             * @error model-document-createroot-name-exists
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-document-createroot-name-exists', this, {
                name: rootName
            });
        }
        const root = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$rootelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this, elementName, rootName);
        this.roots.add(root);
        return root;
    }
    /**
     * Removes all event listeners set by the document instance.
     */ destroy() {
        this.selection.destroy();
        this.stopListening();
    }
    /**
     * Returns a root by its name.
     *
     * Detached roots are returned by this method. This is to be able to operate on the detached root (for example, to be able to create
     * a position inside such a root for undo feature purposes).
     *
     * @param name The root name of the root to return.
     * @returns The root registered under a given name or `null` when there is no root with the given name.
     */ getRoot(name = 'main') {
        return this.roots.get(name);
    }
    /**
     * Returns an array with names of all roots added to the document (except the {@link #graveyard graveyard root}).
     *
     * Detached roots **are not** returned by this method by default. This is to make sure that all features or algorithms that operate
     * on the document data know which roots are still a part of the document and should be processed.
     *
     * @param includeDetached Specified whether detached roots should be returned as well.
     */ getRootNames(includeDetached = false) {
        return this.getRoots(includeDetached).map((root)=>root.rootName);
    }
    /**
     * Returns an array with all roots added to the document (except the {@link #graveyard graveyard root}).
     *
     * Detached roots **are not** returned by this method by default. This is to make sure that all features or algorithms that operate
     * on the document data know which roots are still a part of the document and should be processed.
     *
     * @param includeDetached Specified whether detached roots should be returned as well.
     */ getRoots(includeDetached = false) {
        return this.roots.filter((root)=>root != this.graveyard && (includeDetached || root.isAttached()) && root._isLoaded);
    }
    /**
     * Used to register a post-fixer callback. A post-fixer mechanism guarantees that the features
     * will operate on a correct model state.
     *
     * An execution of a feature may lead to an incorrect document tree state. The callbacks are used to fix the document tree after
     * it has changed. Post-fixers are fired just after all changes from the outermost change block were applied but
     * before the {@link module:engine/model/document~Document#event:change change event} is fired. If a post-fixer callback made
     * a change, it should return `true`. When this happens, all post-fixers are fired again to check if something else should
     * not be fixed in the new document tree state.
     *
     * As a parameter, a post-fixer callback receives a {@link module:engine/model/writer~Writer writer} instance connected with the
     * executed changes block. Thanks to that, all changes done by the callback will be added to the same
     * {@link module:engine/model/batch~Batch batch} (and undo step) as the original changes. This makes post-fixer changes transparent
     * for the user.
     *
     * An example of a post-fixer is a callback that checks if all the data were removed from the editor. If so, the
     * callback should add an empty paragraph so that the editor is never empty:
     *
     * ```ts
     * document.registerPostFixer( writer => {
     * 	const changes = document.differ.getChanges();
     *
     * 	// Check if the changes lead to an empty root in the editor.
     * 	for ( const entry of changes ) {
     * 		if ( entry.type == 'remove' && entry.position.root.isEmpty ) {
     * 			writer.insertElement( 'paragraph', entry.position.root, 0 );
     *
     * 			// It is fine to return early, even if multiple roots would need to be fixed.
     * 			// All post-fixers will be fired again, so if there are more empty roots, those will be fixed, too.
     * 			return true;
     * 		}
     * 	}
     *
     * 	return false;
     * } );
     * ```
     */ registerPostFixer(postFixer) {
        this._postFixers.add(postFixer);
    }
    /**
     * A custom `toJSON()` method to solve child-parent circular dependencies.
     *
     * @returns A clone of this object with the document property changed to a string.
     */ toJSON() {
        const json = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$clone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__clone$3e$__["clone"])(this);
        // Due to circular references we need to remove parent reference.
        json.selection = '[engine.model.DocumentSelection]';
        json.model = '[engine.model.Model]';
        return json;
    }
    /**
     * Check if there were any changes done on document, and if so, call post-fixers,
     * fire `change` event for features and conversion and then reset the differ.
     * Fire `change:data` event when at least one operation or buffered marker changes the data.
     *
     * @internal
     * @fires change
     * @fires change:data
     * @param writer The writer on which post-fixers will be called.
     */ _handleChangeBlock(writer) {
        if (this._hasDocumentChangedFromTheLastChangeBlock()) {
            this._callPostFixers(writer);
            // Refresh selection attributes according to the final position in the model after the change.
            this.selection.refresh();
            if (this.differ.hasDataChanges()) {
                this.fire('change:data', writer.batch);
            } else {
                this.fire('change', writer.batch);
            }
            // Theoretically, it is not necessary to refresh selection after change event because
            // post-fixers are the last who should change the model, but just in case...
            this.selection.refresh();
            this.differ.reset();
        }
        this._hasSelectionChangedFromTheLastChangeBlock = false;
    }
    /**
     * Returns whether there is a buffered change or if the selection has changed from the last
     * {@link module:engine/model/model~Model#enqueueChange `enqueueChange()` block}
     * or {@link module:engine/model/model~Model#change `change()` block}.
     *
     * @returns Returns `true` if document has changed from the last `change()` or `enqueueChange()` block.
     */ _hasDocumentChangedFromTheLastChangeBlock() {
        return !this.differ.isEmpty || this._hasSelectionChangedFromTheLastChangeBlock;
    }
    /**
     * Returns the default root for this document which is either the first root that was added to the document using
     * {@link #createRoot} or the {@link #graveyard graveyard root} if no other roots were created.
     *
     * @returns The default root for this document.
     */ _getDefaultRoot() {
        const roots = this.getRoots();
        return roots.length ? roots[0] : this.graveyard;
    }
    /**
     * Returns the default range for this selection. The default range is a collapsed range that starts and ends
     * at the beginning of this selection's document {@link #_getDefaultRoot default root}.
     *
     * @internal
     */ _getDefaultRange() {
        const defaultRoot = this._getDefaultRoot();
        const model = this.model;
        const schema = model.schema;
        // Find the first position where the selection can be put.
        const position = model.createPositionFromPath(defaultRoot, [
            0
        ]);
        const nearestRange = schema.getNearestSelectionRange(position);
        // If valid selection range is not found - return range collapsed at the beginning of the root.
        return nearestRange || model.createRange(position);
    }
    /**
     * Checks whether a given {@link module:engine/model/range~Range range} is a valid range for
     * the {@link #selection document's selection}.
     *
     * @internal
     * @param range A range to check.
     * @returns `true` if `range` is valid, `false` otherwise.
     */ _validateSelectionRange(range) {
        return validateTextNodePosition(range.start) && validateTextNodePosition(range.end);
    }
    /**
     * Performs post-fixer loops. Executes post-fixer callbacks as long as none of them has done any changes to the model.
     *
     * @param writer The writer on which post-fixer callbacks will be called.
     */ _callPostFixers(writer) {
        let wasFixed = false;
        do {
            for (const callback of this._postFixers){
                // Ensure selection attributes are up to date before each post-fixer.
                // https://github.com/ckeditor/ckeditor5-engine/issues/1673.
                //
                // It might be good to refresh the selection after each operation but at the moment it leads
                // to losing attributes for composition or and spell checking
                // https://github.com/ckeditor/ckeditor5-typing/issues/188
                this.selection.refresh();
                wasFixed = callback(writer);
                if (wasFixed) {
                    break;
                }
            }
        }while (wasFixed)
    }
}
/**
 * Checks whether given range boundary position is valid for document selection, meaning that is not between
 * unicode surrogate pairs or base character and combining marks.
 */ function validateTextNodePosition(rangeBoundary) {
    const textNode = rangeBoundary.textNode;
    if (textNode) {
        const data = textNode.data;
        const offset = rangeBoundary.offset - textNode.startOffset;
        return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$unicode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInsideSurrogatePair"])(data, offset) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$unicode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInsideCombinedSymbol"])(data, offset);
    }
    return true;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/markercollection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/markercollection
 */ __turbopack_context__.s([
    "default",
    ()=>MarkerCollection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liverange.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
;
;
;
class MarkerCollection extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])() {
    constructor(){
        super(...arguments);
        /**
         * Stores {@link ~Marker markers} added to the collection.
         */ this._markers = new Map();
    }
    /**
     * Iterable interface.
     *
     * Iterates over all {@link ~Marker markers} added to the collection.
     */ [Symbol.iterator]() {
        return this._markers.values();
    }
    /**
     * Checks if given {@link ~Marker marker} or marker name is in the collection.
     *
     * @param markerOrName Name of marker or marker instance to check.
     * @returns `true` if marker is in the collection, `false` otherwise.
     */ has(markerOrName) {
        const markerName = markerOrName instanceof Marker ? markerOrName.name : markerOrName;
        return this._markers.has(markerName);
    }
    /**
     * Returns {@link ~Marker marker} with given `markerName`.
     *
     * @param markerName Name of marker to get.
     * @returns Marker with given name or `null` if such marker was
     * not added to the collection.
     */ get(markerName) {
        return this._markers.get(markerName) || null;
    }
    /**
     * Creates and adds a {@link ~Marker marker} to the `MarkerCollection` with given name on given
     * {@link module:engine/model/range~Range range}.
     *
     * If `MarkerCollection` already had a marker with given name (or {@link ~Marker marker} was passed), the marker in
     * collection is updated and {@link module:engine/model/markercollection~MarkerCollection#event:update} event is fired
     * but only if there was a change (marker range or {@link module:engine/model/markercollection~Marker#managedUsingOperations}
     * flag has changed.
     *
     * @internal
     * @fires update
     * @param markerOrName Name of marker to set or marker instance to update.
     * @param range Marker range.
     * @param managedUsingOperations Specifies whether the marker is managed using operations.
     * @param affectsData Specifies whether the marker affects the data produced by the data pipeline
     * (is persisted in the editor's data).
     * @returns `Marker` instance which was added or updated.
     */ _set(markerOrName, range, managedUsingOperations = false, affectsData = false) {
        const markerName = markerOrName instanceof Marker ? markerOrName.name : markerOrName;
        if (markerName.includes(',')) {
            /**
             * Marker name cannot contain the "," character.
             *
             * @error markercollection-incorrect-marker-name
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('markercollection-incorrect-marker-name', this);
        }
        const oldMarker = this._markers.get(markerName);
        if (oldMarker) {
            const oldMarkerData = oldMarker.getData();
            const oldRange = oldMarker.getRange();
            let hasChanged = false;
            if (!oldRange.isEqual(range)) {
                oldMarker._attachLiveRange(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromRange(range));
                hasChanged = true;
            }
            if (managedUsingOperations != oldMarker.managedUsingOperations) {
                oldMarker._managedUsingOperations = managedUsingOperations;
                hasChanged = true;
            }
            if (typeof affectsData === 'boolean' && affectsData != oldMarker.affectsData) {
                oldMarker._affectsData = affectsData;
                hasChanged = true;
            }
            if (hasChanged) {
                this.fire(`update:${markerName}`, oldMarker, oldRange, range, oldMarkerData);
            }
            return oldMarker;
        }
        const liveRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromRange(range);
        const marker = new Marker(markerName, liveRange, managedUsingOperations, affectsData);
        this._markers.set(markerName, marker);
        this.fire(`update:${markerName}`, marker, null, range, {
            ...marker.getData(),
            range: null
        });
        return marker;
    }
    /**
     * Removes given {@link ~Marker marker} or a marker with given name from the `MarkerCollection`.
     *
     * @internal
     * @fires update
     * @param markerOrName Marker or name of a marker to remove.
     * @returns `true` if marker was found and removed, `false` otherwise.
     */ _remove(markerOrName) {
        const markerName = markerOrName instanceof Marker ? markerOrName.name : markerOrName;
        const oldMarker = this._markers.get(markerName);
        if (oldMarker) {
            this._markers.delete(markerName);
            this.fire(`update:${markerName}`, oldMarker, oldMarker.getRange(), null, oldMarker.getData());
            this._destroyMarker(oldMarker);
            return true;
        }
        return false;
    }
    /**
     * Fires an {@link module:engine/model/markercollection~MarkerCollection#event:update} event for the given {@link ~Marker marker}
     * but does not change the marker. Useful to force {@link module:engine/conversion/downcastdispatcher~DowncastDispatcher downcast
     * conversion} for the marker.
     *
     * @internal
     * @fires update
     * @param markerOrName Marker or name of a marker to refresh.
     */ _refresh(markerOrName) {
        const markerName = markerOrName instanceof Marker ? markerOrName.name : markerOrName;
        const marker = this._markers.get(markerName);
        if (!marker) {
            /**
             * Marker with provided name does not exists.
             *
             * @error markercollection-refresh-marker-not-exists
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('markercollection-refresh-marker-not-exists', this);
        }
        const range = marker.getRange();
        this.fire(`update:${markerName}`, marker, range, range, marker.getData());
    }
    /**
     * Returns iterator that iterates over all markers, which ranges contain given {@link module:engine/model/position~Position position}.
     */ *getMarkersAtPosition(position) {
        for (const marker of this){
            if (marker.getRange().containsPosition(position)) {
                yield marker;
            }
        }
    }
    /**
     * Returns iterator that iterates over all markers, which intersects with given {@link module:engine/model/range~Range range}.
     */ *getMarkersIntersectingRange(range) {
        for (const marker of this){
            if (marker.getRange().getIntersection(range) !== null) {
                yield marker;
            }
        }
    }
    /**
     * Destroys marker collection and all markers inside it.
     */ destroy() {
        for (const marker of this._markers.values()){
            this._destroyMarker(marker);
        }
        this._markers = null;
        this.stopListening();
    }
    /**
     * Iterates over all markers that starts with given `prefix`.
     *
     * ```ts
     * const markerFooA = markersCollection._set( 'foo:a', rangeFooA );
     * const markerFooB = markersCollection._set( 'foo:b', rangeFooB );
     * const markerBarA = markersCollection._set( 'bar:a', rangeBarA );
     * const markerFooBarA = markersCollection._set( 'foobar:a', rangeFooBarA );
     * Array.from( markersCollection.getMarkersGroup( 'foo' ) ); // [ markerFooA, markerFooB ]
     * Array.from( markersCollection.getMarkersGroup( 'a' ) ); // []
     * ```
     */ *getMarkersGroup(prefix) {
        for (const marker of this._markers.values()){
            if (marker.name.startsWith(prefix + ':')) {
                yield marker;
            }
        }
    }
    /**
     * Destroys the marker.
     */ _destroyMarker(marker) {
        marker.stopListening();
        marker._detachLiveRange();
    }
}
/**
 * `Marker` is a continuous part of the model (like a range), is named and represents some kind of information about the
 * marked part of the model document. In contrary to {@link module:engine/model/node~Node nodes}, which are building blocks of
 * the model document tree, markers are not stored directly in the document tree but in the
 * {@link module:engine/model/model~Model#markers model markers' collection}. Still, they are document data, by giving
 * additional meaning to the part of a model document between marker start and marker end.
 *
 * In this sense, markers are similar to adding and converting attributes on nodes. The difference is that attribute is
 * connected with a given node (e.g. a character is bold no matter if it gets moved or content around it changes).
 * Markers on the other hand are continuous ranges and are characterized by their start and end position. This means that
 * any character in the marker is marked by the marker. For example, if a character is moved outside of marker it stops being
 * "special" and the marker is shrunk. Similarly, when a character is moved into the marker from other place in document
 * model, it starts being "special" and the marker is enlarged.
 *
 * Another upside of markers is that finding marked part of document is fast and easy. Using attributes to mark some nodes
 * and then trying to find that part of document would require traversing whole document tree. Marker gives instant access
 * to the range which it is marking at the moment.
 *
 * Markers are built from a name and a range.
 *
 * Range of the marker is updated automatically when document changes, using
 * {@link module:engine/model/liverange~LiveRange live range} mechanism.
 *
 * Name is used to group and identify markers. Names have to be unique, but markers can be grouped by
 * using common prefixes, separated with `:`, for example: `user:john` or `search:3`. That's useful in term of creating
 * namespaces for custom elements (e.g. comments, highlights). You can use this prefixes in
 * {@link module:engine/model/markercollection~MarkerCollection#event:update} listeners to listen on changes in a group of markers.
 * For instance: `model.markers.on( 'update:user', callback );` will be called whenever any `user:*` markers changes.
 *
 * There are two types of markers.
 *
 * 1. Markers managed directly, without using operations. They are added directly by {@link module:engine/model/writer~Writer}
 * to the {@link module:engine/model/markercollection~MarkerCollection} without any additional mechanism. They can be used
 * as bookmarks or visual markers. They are great for showing results of the find, or select link when the focus is in the input.
 *
 * 1. Markers managed using operations. These markers are also stored in {@link module:engine/model/markercollection~MarkerCollection}
 * but changes in these markers is managed the same way all other changes in the model structure - using operations.
 * Therefore, they are handled in the undo stack and synchronized between clients if the collaboration plugin is enabled.
 * This type of markers is useful for solutions like spell checking or comments.
 *
 * Both type of them should be added / updated by {@link module:engine/model/writer~Writer#addMarker}
 * and removed by {@link module:engine/model/writer~Writer#removeMarker} methods.
 *
 * ```ts
 * model.change( ( writer ) => {
 * 	const marker = writer.addMarker( name, { range, usingOperation: true } );
 *
 * 	// ...
 *
 * 	writer.removeMarker( marker );
 * } );
 * ```
 *
 * See {@link module:engine/model/writer~Writer} to find more examples.
 *
 * Since markers need to track change in the document, for efficiency reasons, it is best to create and keep as little
 * markers as possible and remove them as soon as they are not needed anymore.
 *
 * Markers can be downcasted and upcasted.
 *
 * Markers downcast happens on {@link module:engine/conversion/downcastdispatcher~DowncastDispatcher#event:addMarker} and
 * {@link module:engine/conversion/downcastdispatcher~DowncastDispatcher#event:removeMarker} events.
 * Use {@link module:engine/conversion/downcasthelpers downcast converters} or attach a custom converter to mentioned events.
 * For {@link module:engine/controller/datacontroller~DataController data pipeline}, marker should be downcasted to an element.
 * Then, it can be upcasted back to a marker. Again, use {@link module:engine/conversion/upcasthelpers upcast converters} or
 * attach a custom converter to {@link module:engine/conversion/upcastdispatcher~UpcastDispatcher#event:element}.
 *
 * `Marker` instances are created and destroyed only by {@link ~MarkerCollection MarkerCollection}.
 */ class Marker extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
    /**
     * Creates a marker instance.
     *
     * @param name Marker name.
     * @param liveRange Range marked by the marker.
     * @param managedUsingOperations Specifies whether the marker is managed using operations.
     * @param affectsData Specifies whether the marker affects the data produced by the data pipeline (is persisted in the editor's data).
     */ constructor(name, liveRange, managedUsingOperations, affectsData){
        super();
        this.name = name;
        this._liveRange = this._attachLiveRange(liveRange);
        this._managedUsingOperations = managedUsingOperations;
        this._affectsData = affectsData;
    }
    /**
     * A value indicating if the marker is managed using operations.
     * See {@link ~Marker marker class description} to learn more about marker types.
     * See {@link module:engine/model/writer~Writer#addMarker}.
     */ get managedUsingOperations() {
        if (!this._liveRange) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('marker-destroyed', this);
        }
        return this._managedUsingOperations;
    }
    /**
     * A value indicating if the marker changes the data.
     */ get affectsData() {
        if (!this._liveRange) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('marker-destroyed', this);
        }
        return this._affectsData;
    }
    /**
     * Returns the marker data (properties defining the marker).
     */ getData() {
        return {
            range: this.getRange(),
            affectsData: this.affectsData,
            managedUsingOperations: this.managedUsingOperations
        };
    }
    /**
     * Returns current marker start position.
     */ getStart() {
        if (!this._liveRange) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('marker-destroyed', this);
        }
        return this._liveRange.start.clone();
    }
    /**
     * Returns current marker end position.
     */ getEnd() {
        if (!this._liveRange) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('marker-destroyed', this);
        }
        return this._liveRange.end.clone();
    }
    /**
     * Returns a range that represents the current state of the marker.
     *
     * Keep in mind that returned value is a {@link module:engine/model/range~Range Range}, not a
     * {@link module:engine/model/liverange~LiveRange LiveRange}. This means that it is up-to-date and relevant only
     * until next model document change. Do not store values returned by this method. Instead, store {@link ~Marker#name}
     * and get `Marker` instance from {@link module:engine/model/markercollection~MarkerCollection MarkerCollection} every
     * time there is a need to read marker properties. This will guarantee that the marker has not been removed and
     * that it's data is up-to-date.
     */ getRange() {
        if (!this._liveRange) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('marker-destroyed', this);
        }
        return this._liveRange.toRange();
    }
    /**
     * Binds new live range to the marker and detach the old one if is attached.
     *
     * @internal
     * @param liveRange Live range to attach
     * @returns Attached live range.
     */ _attachLiveRange(liveRange) {
        if (this._liveRange) {
            this._detachLiveRange();
        }
        // Delegating does not work with namespaces. Alternatively, we could delegate all events (using `*`).
        liveRange.delegate('change:range').to(this);
        liveRange.delegate('change:content').to(this);
        this._liveRange = liveRange;
        return liveRange;
    }
    /**
     * Unbinds and destroys currently attached live range.
     *
     * @internal
     */ _detachLiveRange() {
        this._liveRange.stopDelegating('change:range', this);
        this._liveRange.stopDelegating('change:content', this);
        this._liveRange.detach();
        this._liveRange = null;
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Marker.prototype.is = function(type) {
    return type === 'marker' || type === 'model:marker';
}; /**
 * Cannot use a {@link module:engine/model/markercollection~MarkerCollection#destroy destroyed marker} instance.
 *
 * @error marker-destroyed
 */ 
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/detachoperation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/operation/detachoperation
 */ __turbopack_context__.s([
    "default",
    ()=>DetachOperation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/utils.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
;
;
class DetachOperation extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates an insert operation.
     *
     * @param sourcePosition Position before the first {@link module:engine/model/item~Item model item} to move.
     * @param howMany Offset size of moved range. Moved range will start from `sourcePosition` and end at
     * `sourcePosition` with offset shifted by `howMany`.
     */ constructor(sourcePosition, howMany){
        super(null);
        this.sourcePosition = sourcePosition.clone();
        this.howMany = howMany;
    }
    /**
     * @inheritDoc
     */ get type() {
        return 'detach';
    }
    /**
     * @inheritDoc
     */ get affectedSelectable() {
        return null;
    }
    /**
     * @inheritDoc
     */ toJSON() {
        const json = super.toJSON();
        json.sourcePosition = this.sourcePosition.toJSON();
        return json;
    }
    /**
     * @inheritDoc
     * @internal
     */ _validate() {
        if (this.sourcePosition.root.document) {
            /**
             * Cannot detach document node.
             *
             * @error detach-operation-on-document-node
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('detach-operation-on-document-node', this);
        }
    }
    /**
     * @inheritDoc
     * @internal
     */ _execute() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_remove"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(this.sourcePosition, this.howMany));
    }
    /**
     * @inheritDoc
     */ static get className() {
        return 'DetachOperation';
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentfragment.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/documentfragment
 */ __turbopack_context__.s([
    "default",
    ()=>DocumentFragment
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$nodelist$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/nodelist.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/textproxy.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/isiterable.js [app-ssr] (ecmascript) <export default as isIterable>");
;
;
;
;
;
;
class DocumentFragment extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates an empty `DocumentFragment`.
     *
     * **Note:** Constructor of this class shouldn't be used directly in the code.
     * Use the {@link module:engine/model/writer~Writer#createDocumentFragment} method instead.
     *
     * @internal
     * @param children Nodes to be contained inside the `DocumentFragment`.
     */ constructor(children){
        super();
        /**
         * DocumentFragment static markers map. This is a list of names and {@link module:engine/model/range~Range ranges}
         * which will be set as Markers to {@link module:engine/model/model~Model#markers model markers collection}
         * when DocumentFragment will be inserted to the document.
         */ this.markers = new Map();
        /**
         * List of nodes contained inside the document fragment.
         */ this._children = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$nodelist$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        if (children) {
            this._insertChild(0, children);
        }
    }
    /**
     * Returns an iterator that iterates over all nodes contained inside this document fragment.
     */ [Symbol.iterator]() {
        return this.getChildren();
    }
    /**
     * Number of this document fragment's children.
     */ get childCount() {
        return this._children.length;
    }
    /**
     * Sum of {@link module:engine/model/node~Node#offsetSize offset sizes} of all of this document fragment's children.
     */ get maxOffset() {
        return this._children.maxOffset;
    }
    /**
     * Is `true` if there are no nodes inside this document fragment, `false` otherwise.
     */ get isEmpty() {
        return this.childCount === 0;
    }
    /**
     * Artificial next sibling. Returns `null`. Added for compatibility reasons.
     */ get nextSibling() {
        return null;
    }
    /**
     * Artificial previous sibling. Returns `null`. Added for compatibility reasons.
     */ get previousSibling() {
        return null;
    }
    /**
     * Artificial root of `DocumentFragment`. Returns itself. Added for compatibility reasons.
     */ get root() {
        return this;
    }
    /**
     * Artificial parent of `DocumentFragment`. Returns `null`. Added for compatibility reasons.
     */ get parent() {
        return null;
    }
    /**
     * Artificial owner of `DocumentFragment`. Returns `null`. Added for compatibility reasons.
     */ get document() {
        return null;
    }
    /**
     * Returns `false` as `DocumentFragment` by definition is not attached to a document. Added for compatibility reasons.
     */ isAttached() {
        return false;
    }
    /**
     * Returns empty array. Added for compatibility reasons.
     */ getAncestors() {
        return [];
    }
    /**
     * Gets the child at the given index. Returns `null` if incorrect index was passed.
     *
     * @param index Index of child.
     * @returns Child node.
     */ getChild(index) {
        return this._children.getNode(index);
    }
    /**
     * Returns an iterator that iterates over all of this document fragment's children.
     */ getChildren() {
        return this._children[Symbol.iterator]();
    }
    /**
     * Returns an index of the given child node. Returns `null` if given node is not a child of this document fragment.
     *
     * @param node Child node to look for.
     * @returns Child node's index.
     */ getChildIndex(node) {
        return this._children.getNodeIndex(node);
    }
    /**
     * Returns the starting offset of given child. Starting offset is equal to the sum of
     * {@link module:engine/model/node~Node#offsetSize offset sizes} of all node's siblings that are before it. Returns `null` if
     * given node is not a child of this document fragment.
     *
     * @param node Child node to look for.
     * @returns Child node's starting offset.
     */ getChildStartOffset(node) {
        return this._children.getNodeStartOffset(node);
    }
    /**
     * Returns path to a `DocumentFragment`, which is an empty array. Added for compatibility reasons.
     */ getPath() {
        return [];
    }
    /**
     * Returns a descendant node by its path relative to this element.
     *
     * ```ts
     * // <this>a<b>c</b></this>
     * this.getNodeByPath( [ 0 ] );     // -> "a"
     * this.getNodeByPath( [ 1 ] );     // -> <b>
     * this.getNodeByPath( [ 1, 0 ] );  // -> "c"
     * ```
     *
     * @param relativePath Path of the node to find, relative to this element.
     */ getNodeByPath(relativePath) {
        // eslint-disable-next-line @typescript-eslint/no-this-alias, consistent-this
        let node = this;
        for (const index of relativePath){
            node = node.getChild(node.offsetToIndex(index));
        }
        return node;
    }
    /**
     * Converts offset "position" to index "position".
     *
     * Returns index of a node that occupies given offset. If given offset is too low, returns `0`. If given offset is
     * too high, returns index after last child.
     *
     * ```ts
     * const textNode = new Text( 'foo' );
     * const pElement = new Element( 'p' );
     * const docFrag = new DocumentFragment( [ textNode, pElement ] );
     * docFrag.offsetToIndex( -1 ); // Returns 0, because offset is too low.
     * docFrag.offsetToIndex( 0 ); // Returns 0, because offset 0 is taken by `textNode` which is at index 0.
     * docFrag.offsetToIndex( 1 ); // Returns 0, because `textNode` has `offsetSize` equal to 3, so it occupies offset 1 too.
     * docFrag.offsetToIndex( 2 ); // Returns 0.
     * docFrag.offsetToIndex( 3 ); // Returns 1.
     * docFrag.offsetToIndex( 4 ); // Returns 2. There are no nodes at offset 4, so last available index is returned.
     * ```
     *
     * @param offset Offset to look for.
     * @returns Index of a node that occupies given offset.
     */ offsetToIndex(offset) {
        return this._children.offsetToIndex(offset);
    }
    /**
     * Converts `DocumentFragment` instance to plain object and returns it.
     * Takes care of converting all of this document fragment's children.
     *
     * @returns `DocumentFragment` instance converted to plain object.
     */ toJSON() {
        const json = [];
        for (const node of this._children){
            json.push(node.toJSON());
        }
        return json;
    }
    /**
     * Creates a `DocumentFragment` instance from given plain object (i.e. parsed JSON string).
     * Converts `DocumentFragment` children to proper nodes.
     *
     * @param json Plain object to be converted to `DocumentFragment`.
     * @returns `DocumentFragment` instance created using given plain object.
     */ static fromJSON(json) {
        const children = [];
        for (const child of json){
            if (child.name) {
                // If child has name property, it is an Element.
                children.push(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(child));
            } else {
                // Otherwise, it is a Text node.
                children.push(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(child));
            }
        }
        return new DocumentFragment(children);
    }
    /**
     * {@link #_insertChild Inserts} one or more nodes at the end of this document fragment.
     *
     * @internal
     * @param items Items to be inserted.
     */ _appendChild(items) {
        this._insertChild(this.childCount, items);
    }
    /**
     * Inserts one or more nodes at the given index and sets {@link module:engine/model/node~Node#parent parent} of these nodes
     * to this document fragment.
     *
     * @internal
     * @param index Index at which nodes should be inserted.
     * @param items Items to be inserted.
     */ _insertChild(index, items) {
        const nodes = normalize(items);
        for (const node of nodes){
            // If node that is being added to this element is already inside another element, first remove it from the old parent.
            if (node.parent !== null) {
                node._remove();
            }
            node.parent = this;
        }
        this._children._insertNodes(index, nodes);
    }
    /**
     * Removes one or more nodes starting at the given index
     * and sets {@link module:engine/model/node~Node#parent parent} of these nodes to `null`.
     *
     * @internal
     * @param index Index of the first node to remove.
     * @param howMany Number of nodes to remove.
     * @returns Array containing removed nodes.
     */ _removeChildren(index, howMany = 1) {
        const nodes = this._children._removeNodes(index, howMany);
        for (const node of nodes){
            node.parent = null;
        }
        return nodes;
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
DocumentFragment.prototype.is = function(type) {
    return type === 'documentFragment' || type === 'model:documentFragment';
};
/**
 * Converts strings to Text and non-iterables to arrays.
 */ function normalize(nodes) {
    // Separate condition because string is iterable.
    if (typeof nodes == 'string') {
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodes)
        ];
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__["isIterable"])(nodes)) {
        nodes = [
            nodes
        ];
    }
    // Array.from to enable .map() on non-arrays.
    return Array.from(nodes).map((node)=>{
        if (typeof node == 'string') {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node);
        }
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node.data, node.getAttributes());
        }
        return node;
    });
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/writer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/writer
 */ __turbopack_context__.s([
    "default",
    ()=>Writer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/attributeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$detachoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/detachoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/insertoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/markeroperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/mergeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/moveoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/renameoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootattributeoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/rootoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/splitoperation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$rootelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/rootelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/tomap.js [app-ssr] (ecmascript) <export default as toMap>");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
class Writer {
    /**
     * Creates a writer instance.
     *
     * **Note:** It is not recommended to use it directly. Use {@link module:engine/model/model~Model#change `Model#change()`} or
     * {@link module:engine/model/model~Model#enqueueChange `Model#enqueueChange()`} instead.
     *
     * @internal
     */ constructor(model, batch){
        this.model = model;
        this.batch = batch;
    }
    /**
     * Creates a new {@link module:engine/model/text~Text text node}.
     *
     * ```ts
     * writer.createText( 'foo' );
     * writer.createText( 'foo', { bold: true } );
     * ```
     *
     * @param data Text data.
     * @param attributes Text attributes.
     * @returns {module:engine/model/text~Text} Created text node.
     */ createText(data, attributes) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](data, attributes);
    }
    /**
     * Creates a new {@link module:engine/model/element~Element element}.
     *
     * ```ts
     * writer.createElement( 'paragraph' );
     * writer.createElement( 'paragraph', { alignment: 'center' } );
     * ```
     *
     * @param name Name of the element.
     * @param attributes Elements attributes.
     * @returns Created element.
     */ createElement(name, attributes) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](name, attributes);
    }
    /**
     * Creates a new {@link module:engine/model/documentfragment~DocumentFragment document fragment}.
     *
     * @returns Created document fragment.
     */ createDocumentFragment() {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
    }
    /**
     * Creates a copy of the element and returns it. Created element has the same name and attributes as the original element.
     * If clone is deep, the original element's children are also cloned. If not, then empty element is returned.
     *
     * @param element The element to clone.
     * @param deep If set to `true` clones element and all its children recursively. When set to `false`,
     * element will be cloned without any child.
     */ cloneElement(element, deep = true) {
        return element._clone(deep);
    }
    /**
     * Inserts item on given position.
     *
     * ```ts
     * const paragraph = writer.createElement( 'paragraph' );
     * writer.insert( paragraph, position );
     * ```
     *
     * Instead of using position you can use parent and offset:
     *
     * ```ts
     * const text = writer.createText( 'foo' );
     * writer.insert( text, paragraph, 5 );
     * ```
     *
     * You can also use `end` instead of the offset to insert at the end:
     *
     * ```ts
     * const text = writer.createText( 'foo' );
     * writer.insert( text, paragraph, 'end' );
     * ```
     *
     * Or insert before or after another element:
     *
     * ```ts
     * const paragraph = writer.createElement( 'paragraph' );
     * writer.insert( paragraph, anotherParagraph, 'after' );
     * ```
     *
     * These parameters works the same way as {@link #createPositionAt `writer.createPositionAt()`}.
     *
     * Note that if the item already has parent it will be removed from the previous parent.
     *
     * Note that you cannot re-insert a node from a document to a different document or a document fragment. In this case,
     * `model-writer-insert-forbidden-move` is thrown.
     *
     * If you want to move {@link module:engine/model/range~Range range} instead of an
     * {@link module:engine/model/item~Item item} use {@link module:engine/model/writer~Writer#move `Writer#move()`}.
     *
     * **Note:** For a paste-like content insertion mechanism see
     * {@link module:engine/model/model~Model#insertContent `model.insertContent()`}.
     *
     * @param item Item or document fragment to insert.
     * @param offset Offset or one of the flags. Used only when second parameter is a {@link module:engine/model/item~Item model item}.
     */ insert(item, itemOrPosition, offset = 0) {
        this._assertWriterUsedCorrectly();
        if (item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] && item.data == '') {
            return;
        }
        const position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(itemOrPosition, offset);
        // If item has a parent already.
        if (item.parent) {
            // We need to check if item is going to be inserted within the same document.
            if (isSameTree(item.root, position.root)) {
                // If it's we just need to move it.
                this.move(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(item), position);
                return;
            } else {
                if (item.root.document) {
                    /**
                     * Cannot move a node from a document to a different tree.
                     * It is forbidden to move a node that was already in a document outside of it.
                     *
                     * @error model-writer-insert-forbidden-move
                     */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('model-writer-insert-forbidden-move', this);
                } else {
                    // Move between two different document fragments or from document fragment to a document is possible.
                    // In that case, remove the item from it's original parent.
                    this.remove(item);
                }
            }
        }
        const version = position.root.document ? position.root.document.version : null;
        const insert = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$insertoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position, item, version);
        if (item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            insert.shouldReceiveAttributes = true;
        }
        this.batch.addOperation(insert);
        this.model.applyOperation(insert);
        // When element is a DocumentFragment we need to move its markers to Document#markers.
        if (item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            for (const [markerName, markerRange] of item.markers){
                // We need to migrate marker range from DocumentFragment to Document.
                const rangeRootPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(markerRange.root, 0);
                const range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](markerRange.start._getCombined(rangeRootPosition, position), markerRange.end._getCombined(rangeRootPosition, position));
                const options = {
                    range,
                    usingOperation: true,
                    affectsData: true
                };
                if (this.model.markers.has(markerName)) {
                    this.updateMarker(markerName, options);
                } else {
                    this.addMarker(markerName, options);
                }
            }
        }
    }
    insertText(text, attributes, itemOrPosition, offset // Too complicated when not using `any`.
    ) {
        if (attributes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || attributes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || attributes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            this.insert(this.createText(text), attributes, itemOrPosition);
        } else {
            this.insert(this.createText(text, attributes), itemOrPosition, offset);
        }
    }
    insertElement(name, attributes, itemOrPositionOrOffset, offset // Too complicated when not using `any`.
    ) {
        if (attributes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || attributes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || attributes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            this.insert(this.createElement(name), attributes, itemOrPositionOrOffset);
        } else {
            this.insert(this.createElement(name, attributes), itemOrPositionOrOffset, offset);
        }
    }
    /**
     * Inserts item at the end of the given parent.
     *
     * ```ts
     * const paragraph = writer.createElement( 'paragraph' );
     * writer.append( paragraph, root );
     * ```
     *
     * Note that if the item already has parent it will be removed from the previous parent.
     *
     * If you want to move {@link module:engine/model/range~Range range} instead of an
     * {@link module:engine/model/item~Item item} use {@link module:engine/model/writer~Writer#move `Writer#move()`}.
     *
     * @param item Item or document fragment to insert.
     */ append(item, parent) {
        this.insert(item, parent, 'end');
    }
    appendText(text, attributes, parent) {
        if (attributes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || attributes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            this.insert(this.createText(text), attributes, 'end');
        } else {
            this.insert(this.createText(text, attributes), parent, 'end');
        }
    }
    appendElement(name, attributes, parent) {
        if (attributes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || attributes instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            this.insert(this.createElement(name), attributes, 'end');
        } else {
            this.insert(this.createElement(name, attributes), parent, 'end');
        }
    }
    /**
     * Sets value of the attribute with given key on a {@link module:engine/model/item~Item model item}
     * or on a {@link module:engine/model/range~Range range}.
     *
     * @param key Attribute key.
     * @param value Attribute new value.
     * @param itemOrRange Model item or range on which the attribute will be set.
     */ setAttribute(key, value, itemOrRange) {
        this._assertWriterUsedCorrectly();
        if (itemOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            const ranges = itemOrRange.getMinimalFlatRanges();
            for (const range of ranges){
                setAttributeOnRange(this, key, value, range);
            }
        } else {
            setAttributeOnItem(this, key, value, itemOrRange);
        }
    }
    /**
     * Sets values of attributes on a {@link module:engine/model/item~Item model item}
     * or on a {@link module:engine/model/range~Range range}.
     *
     * ```ts
     * writer.setAttributes( {
     * 	bold: true,
     * 	italic: true
     * }, range );
     * ```
     *
     * @param attributes Attributes keys and values.
     * @param itemOrRange Model item or range on which the attributes will be set.
     */ setAttributes(attributes, itemOrRange) {
        for (const [key, val] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__["toMap"])(attributes)){
            this.setAttribute(key, val, itemOrRange);
        }
    }
    /**
     * Removes an attribute with given key from a {@link module:engine/model/item~Item model item}
     * or from a {@link module:engine/model/range~Range range}.
     *
     * @param key Attribute key.
     * @param itemOrRange Model item or range from which the attribute will be removed.
     */ removeAttribute(key, itemOrRange) {
        this._assertWriterUsedCorrectly();
        if (itemOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            const ranges = itemOrRange.getMinimalFlatRanges();
            for (const range of ranges){
                setAttributeOnRange(this, key, null, range);
            }
        } else {
            setAttributeOnItem(this, key, null, itemOrRange);
        }
    }
    /**
     * Removes all attributes from all elements in the range or from the given item.
     *
     * @param itemOrRange Model item or range from which all attributes will be removed.
     */ clearAttributes(itemOrRange) {
        this._assertWriterUsedCorrectly();
        const removeAttributesFromItem = (item)=>{
            for (const attribute of item.getAttributeKeys()){
                this.removeAttribute(attribute, item);
            }
        };
        if (!(itemOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            removeAttributesFromItem(itemOrRange);
        } else {
            for (const item of itemOrRange.getItems()){
                removeAttributesFromItem(item);
            }
        }
    }
    /**
     * Moves all items in the source range to the target position.
     *
     * ```ts
     * writer.move( sourceRange, targetPosition );
     * ```
     *
     * Instead of the target position you can use parent and offset or define that range should be moved to the end
     * or before or after chosen item:
     *
     * ```ts
     * // Moves all items in the range to the paragraph at offset 5:
     * writer.move( sourceRange, paragraph, 5 );
     * // Moves all items in the range to the end of a blockquote:
     * writer.move( sourceRange, blockquote, 'end' );
     * // Moves all items in the range to a position after an image:
     * writer.move( sourceRange, image, 'after' );
     * ```
     *
     * These parameters work the same way as {@link #createPositionAt `writer.createPositionAt()`}.
     *
     * Note that items can be moved only within the same tree. It means that you can move items within the same root
     * (element or document fragment) or between {@link module:engine/model/document~Document#roots documents roots},
     * but you can not move items from document fragment to the document or from one detached element to another. Use
     * {@link module:engine/model/writer~Writer#insert} in such cases.
     *
     * @param range Source range.
     * @param offset Offset or one of the flags. Used only when second parameter is a {@link module:engine/model/item~Item model item}.
     */ move(range, itemOrPosition, offset) {
        this._assertWriterUsedCorrectly();
        if (!(range instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            /**
             * Invalid range to move.
             *
             * @error writer-move-invalid-range
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-move-invalid-range', this);
        }
        if (!range.isFlat) {
            /**
             * Range to move is not flat.
             *
             * @error writer-move-range-not-flat
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-move-range-not-flat', this);
        }
        const position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(itemOrPosition, offset);
        // Do not move anything if the move target is same as moved range start.
        if (position.isEqual(range.start)) {
            return;
        }
        // If part of the marker is removed, create additional marker operation for undo purposes.
        this._addOperationForAffectedMarkers('move', range);
        if (!isSameTree(range.root, position.root)) {
            /**
             * Range is going to be moved within not the same document. Please use
             * {@link module:engine/model/writer~Writer#insert insert} instead.
             *
             * @error writer-move-different-document
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-move-different-document', this);
        }
        const version = range.root.document ? range.root.document.version : null;
        const operation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range.start, range.end.offset - range.start.offset, position, version);
        this.batch.addOperation(operation);
        this.model.applyOperation(operation);
    }
    /**
     * Removes given model {@link module:engine/model/item~Item item} or {@link module:engine/model/range~Range range}.
     *
     * @param itemOrRange Model item or range to remove.
     */ remove(itemOrRange) {
        this._assertWriterUsedCorrectly();
        const rangeToRemove = itemOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] ? itemOrRange : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(itemOrRange);
        const ranges = rangeToRemove.getMinimalFlatRanges().reverse();
        for (const flat of ranges){
            // If part of the marker is removed, create additional marker operation for undo purposes.
            this._addOperationForAffectedMarkers('move', flat);
            applyRemoveOperation(flat.start, flat.end.offset - flat.start.offset, this.batch, this.model);
        }
    }
    /**
     * Merges two siblings at the given position.
     *
     * Node before and after the position have to be an element. Otherwise `writer-merge-no-element-before` or
     * `writer-merge-no-element-after` error will be thrown.
     *
     * @param position Position between merged elements.
     */ merge(position) {
        this._assertWriterUsedCorrectly();
        const nodeBefore = position.nodeBefore;
        const nodeAfter = position.nodeAfter;
        // If part of the marker is removed, create additional marker operation for undo purposes.
        this._addOperationForAffectedMarkers('merge', position);
        if (!(nodeBefore instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            /**
             * Node before merge position must be an element.
             *
             * @error writer-merge-no-element-before
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-merge-no-element-before', this);
        }
        if (!(nodeAfter instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            /**
             * Node after merge position must be an element.
             *
             * @error writer-merge-no-element-after
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-merge-no-element-after', this);
        }
        if (!position.root.document) {
            this._mergeDetached(position);
        } else {
            this._merge(position);
        }
    }
    /**
     * Shortcut for {@link module:engine/model/model~Model#createPositionFromPath `Model#createPositionFromPath()`}.
     *
     * @param root Root of the position.
     * @param path Position path. See {@link module:engine/model/position~Position#path}.
     * @param stickiness Position stickiness. See {@link module:engine/model/position~PositionStickiness}.
     */ createPositionFromPath(root, path, stickiness) {
        return this.model.createPositionFromPath(root, path, stickiness);
    }
    /**
     * Shortcut for {@link module:engine/model/model~Model#createPositionAt `Model#createPositionAt()`}.
     *
     * @param offset Offset or one of the flags. Used only when first parameter is a {@link module:engine/model/item~Item model item}.
     */ createPositionAt(itemOrPosition, offset) {
        return this.model.createPositionAt(itemOrPosition, offset);
    }
    /**
     * Shortcut for {@link module:engine/model/model~Model#createPositionAfter `Model#createPositionAfter()`}.
     *
     * @param item Item after which the position should be placed.
     */ createPositionAfter(item) {
        return this.model.createPositionAfter(item);
    }
    /**
     * Shortcut for {@link module:engine/model/model~Model#createPositionBefore `Model#createPositionBefore()`}.
     *
     * @param item Item after which the position should be placed.
     */ createPositionBefore(item) {
        return this.model.createPositionBefore(item);
    }
    /**
     * Shortcut for {@link module:engine/model/model~Model#createRange `Model#createRange()`}.
     *
     * @param start Start position.
     * @param end End position. If not set, range will be collapsed at `start` position.
     */ createRange(start, end) {
        return this.model.createRange(start, end);
    }
    /**
     * Shortcut for {@link module:engine/model/model~Model#createRangeIn `Model#createRangeIn()`}.
     *
     * @param element Element which is a parent for the range.
     */ createRangeIn(element) {
        return this.model.createRangeIn(element);
    }
    /**
     * Shortcut for {@link module:engine/model/model~Model#createRangeOn `Model#createRangeOn()`}.
     *
     * @param element Element which is a parent for the range.
     */ createRangeOn(element) {
        return this.model.createRangeOn(element);
    }
    createSelection(...args) {
        return this.model.createSelection(...args);
    }
    /**
     * Performs merge action in a detached tree.
     *
     * @param position Position between merged elements.
     */ _mergeDetached(position) {
        const nodeBefore = position.nodeBefore;
        const nodeAfter = position.nodeAfter;
        this.move(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(nodeAfter), __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(nodeBefore, 'end'));
        this.remove(nodeAfter);
    }
    /**
     * Performs merge action in a non-detached tree.
     *
     * @param position Position between merged elements.
     */ _merge(position) {
        const targetPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(position.nodeBefore, 'end');
        const sourcePosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(position.nodeAfter, 0);
        const graveyard = position.root.document.graveyard;
        const graveyardPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](graveyard, [
            0
        ]);
        const version = position.root.document.version;
        const merge = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$mergeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](sourcePosition, position.nodeAfter.maxOffset, targetPosition, graveyardPosition, version);
        this.batch.addOperation(merge);
        this.model.applyOperation(merge);
    }
    /**
     * Renames the given element.
     *
     * @param element The element to rename.
     * @param newName New element name.
     */ rename(element, newName) {
        this._assertWriterUsedCorrectly();
        if (!(element instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            /**
             * Trying to rename an object which is not an instance of Element.
             *
             * @error writer-rename-not-element-instance
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-rename-not-element-instance', this);
        }
        const version = element.root.document ? element.root.document.version : null;
        const renameOperation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$renameoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(element), element.name, newName, version);
        this.batch.addOperation(renameOperation);
        this.model.applyOperation(renameOperation);
    }
    /**
     * Splits elements starting from the given position and going to the top of the model tree as long as given
     * `limitElement` is reached. When `limitElement` is not defined then only the parent of the given position will be split.
     *
     * The element needs to have a parent. It cannot be a root element nor a document fragment.
     * The `writer-split-element-no-parent` error will be thrown if you try to split an element with no parent.
     *
     * @param position Position of split.
     * @param limitElement Stop splitting when this element will be reached.
     * @returns Split result with properties:
     * * `position` - Position between split elements.
     * * `range` - Range that stars from the end of the first split element and ends at the beginning of the first copy element.
     */ split(position, limitElement) {
        this._assertWriterUsedCorrectly();
        let splitElement = position.parent;
        if (!splitElement.parent) {
            /**
             * Element with no parent can not be split.
             *
             * @error writer-split-element-no-parent
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-split-element-no-parent', this);
        }
        // When limit element is not defined lets set splitElement parent as limit.
        if (!limitElement) {
            limitElement = splitElement.parent;
        }
        if (!position.parent.getAncestors({
            includeSelf: true
        }).includes(limitElement)) {
            /**
             * Limit element is not a position ancestor.
             *
             * @error writer-split-invalid-limit-element
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-split-invalid-limit-element', this);
        }
        // We need to cache elements that will be created as a result of the first split because
        // we need to create a range from the end of the first split element to the beginning of the
        // first copy element. This should be handled by LiveRange but it doesn't work on detached nodes.
        let firstSplitElement;
        let firstCopyElement;
        do {
            const version = splitElement.root.document ? splitElement.root.document.version : null;
            const howMany = splitElement.maxOffset - position.offset;
            const insertionPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].getInsertionPosition(position);
            const split = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$splitoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position, howMany, insertionPosition, null, version);
            this.batch.addOperation(split);
            this.model.applyOperation(split);
            // Cache result of the first split.
            if (!firstSplitElement && !firstCopyElement) {
                firstSplitElement = splitElement;
                firstCopyElement = position.parent.nextSibling;
            }
            position = this.createPositionAfter(position.parent);
            splitElement = position.parent;
        }while (splitElement !== limitElement)
        return {
            position,
            range: new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(firstSplitElement, 'end'), __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(firstCopyElement, 0))
        };
    }
    /**
     * Wraps the given range with the given element or with a new element (if a string was passed).
     *
     * **Note:** range to wrap should be a "flat range" (see {@link module:engine/model/range~Range#isFlat `Range#isFlat`}).
     * If not, an error will be thrown.
     *
     * @param range Range to wrap.
     * @param elementOrString Element or name of element to wrap the range with.
     */ wrap(range, elementOrString) {
        this._assertWriterUsedCorrectly();
        if (!range.isFlat) {
            /**
             * Range to wrap is not flat.
             *
             * @error writer-wrap-range-not-flat
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-wrap-range-not-flat', this);
        }
        const element = elementOrString instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] ? elementOrString : new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](elementOrString);
        if (element.childCount > 0) {
            /**
             * Element to wrap with is not empty.
             *
             * @error writer-wrap-element-not-empty
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-wrap-element-not-empty', this);
        }
        if (element.parent !== null) {
            /**
             * Element to wrap with is already attached to a tree model.
             *
             * @error writer-wrap-element-attached
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-wrap-element-attached', this);
        }
        this.insert(element, range.start);
        // Shift the range-to-wrap because we just inserted an element before that range.
        const shiftedRange = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range.start.getShiftedBy(1), range.end.getShiftedBy(1));
        this.move(shiftedRange, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(element, 0));
    }
    /**
     * Unwraps children of the given element – all its children are moved before it and then the element is removed.
     * Throws error if you try to unwrap an element which does not have a parent.
     *
     * @param element Element to unwrap.
     */ unwrap(element) {
        this._assertWriterUsedCorrectly();
        if (element.parent === null) {
            /**
             * Trying to unwrap an element which has no parent.
             *
             * @error writer-unwrap-element-no-parent
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-unwrap-element-no-parent', this);
        }
        this.move(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(element), this.createPositionAfter(element));
        this.remove(element);
    }
    /**
     * Adds a {@link module:engine/model/markercollection~Marker marker}. Marker is a named range, which tracks
     * changes in the document and updates its range automatically, when model tree changes.
     *
     * As the first parameter you can set marker name.
     *
     * The required `options.usingOperation` parameter lets you decide if the marker should be managed by operations or not. See
     * {@link module:engine/model/markercollection~Marker marker class description} to learn about the difference between
     * markers managed by operations and not-managed by operations.
     *
     * The `options.affectsData` parameter, which defaults to `false`, allows you to define if a marker affects the data. It should be
     * `true` when the marker change changes the data returned by the
     * {@link module:core/editor/editor~Editor#getData `editor.getData()`} method.
     * When set to `true` it fires the {@link module:engine/model/document~Document#event:change:data `change:data`} event.
     * When set to `false` it fires the {@link module:engine/model/document~Document#event:change `change`} event.
     *
     * Create marker directly base on marker's name:
     *
     * ```ts
     * addMarker( markerName, { range, usingOperation: false } );
     * ```
     *
     * Create marker using operation:
     *
     * ```ts
     * addMarker( markerName, { range, usingOperation: true } );
     * ```
     *
     * Create marker that affects the editor data:
     *
     * ```ts
     * addMarker( markerName, { range, usingOperation: false, affectsData: true } );
     * ```
     *
     * Note: For efficiency reasons, it's best to create and keep as little markers as possible.
     *
     * @see module:engine/model/markercollection~Marker
     * @param name Name of a marker to create - must be unique.
     * @param options.usingOperation Flag indicating that the marker should be added by MarkerOperation.
     * See {@link module:engine/model/markercollection~Marker#managedUsingOperations}.
     * @param options.range Marker range.
     * @param options.affectsData Flag indicating that the marker changes the editor data.
     * @returns Marker that was set.
     */ addMarker(name, options) {
        this._assertWriterUsedCorrectly();
        if (!options || typeof options.usingOperation != 'boolean') {
            /**
             * The `options.usingOperation` parameter is required when adding a new marker.
             *
             * @error writer-addmarker-no-usingoperation
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-addmarker-no-usingoperation', this);
        }
        const usingOperation = options.usingOperation;
        const range = options.range;
        const affectsData = options.affectsData === undefined ? false : options.affectsData;
        if (this.model.markers.has(name)) {
            /**
             * Marker with provided name already exists.
             *
             * @error writer-addmarker-marker-exists
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-addmarker-marker-exists', this);
        }
        if (!range) {
            /**
             * Range parameter is required when adding a new marker.
             *
             * @error writer-addmarker-no-range
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-addmarker-no-range', this);
        }
        if (!usingOperation) {
            return this.model.markers._set(name, range, usingOperation, affectsData);
        }
        applyMarkerOperation(this, name, null, range, affectsData);
        return this.model.markers.get(name);
    }
    /**
     * Adds, updates or refreshes a {@link module:engine/model/markercollection~Marker marker}. Marker is a named range, which tracks
     * changes in the document and updates its range automatically, when model tree changes. Still, it is possible to change the
     * marker's range directly using this method.
     *
     * As the first parameter you can set marker name or instance. If none of them is provided, new marker, with a unique
     * name is created and returned.
     *
     * **Note**: If you want to change the {@link module:engine/view/element~Element view element} of the marker while its data in the model
     * remains the same, use the dedicated {@link module:engine/controller/editingcontroller~EditingController#reconvertMarker} method.
     *
     * The `options.usingOperation` parameter lets you change if the marker should be managed by operations or not. See
     * {@link module:engine/model/markercollection~Marker marker class description} to learn about the difference between
     * markers managed by operations and not-managed by operations. It is possible to change this option for an existing marker.
     *
     * The `options.affectsData` parameter, which defaults to `false`, allows you to define if a marker affects the data. It should be
     * `true` when the marker change changes the data returned by
     * the {@link module:core/editor/editor~Editor#getData `editor.getData()`} method.
     * When set to `true` it fires the {@link module:engine/model/document~Document#event:change:data `change:data`} event.
     * When set to `false` it fires the {@link module:engine/model/document~Document#event:change `change`} event.
     *
     * Update marker directly base on marker's name:
     *
     * ```ts
     * updateMarker( markerName, { range } );
     * ```
     *
     * Update marker using operation:
     *
     * ```ts
     * updateMarker( marker, { range, usingOperation: true } );
     * updateMarker( markerName, { range, usingOperation: true } );
     * ```
     *
     * Change marker's option (start using operations to manage it):
     *
     * ```ts
     * updateMarker( marker, { usingOperation: true } );
     * ```
     *
     * Change marker's option (inform the engine, that the marker does not affect the data anymore):
     *
     * ```ts
     * updateMarker( markerName, { affectsData: false } );
     * ```
     *
     * @see module:engine/model/markercollection~Marker
     * @param markerOrName Name of a marker to update, or a marker instance.
     * @param options If options object is not defined then marker will be refreshed by triggering
     * downcast conversion for this marker with the same data.
     * @param options.range Marker range to update.
     * @param options.usingOperation Flag indicated whether the marker should be added by MarkerOperation.
     * See {@link module:engine/model/markercollection~Marker#managedUsingOperations}.
     * @param options.affectsData Flag indicating that the marker changes the editor data.
     */ updateMarker(markerOrName, options) {
        this._assertWriterUsedCorrectly();
        const markerName = typeof markerOrName == 'string' ? markerOrName : markerOrName.name;
        const currentMarker = this.model.markers.get(markerName);
        if (!currentMarker) {
            /**
             * Marker with provided name does not exist and will not be updated.
             *
             * @error writer-updatemarker-marker-not-exists
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-updatemarker-marker-not-exists', this);
        }
        if (!options) {
            /**
             * The usage of `writer.updateMarker()` only to reconvert (refresh) a
             * {@link module:engine/model/markercollection~Marker model marker} was deprecated and may not work in the future.
             * Please update your code to use
             * {@link module:engine/controller/editingcontroller~EditingController#reconvertMarker `editor.editing.reconvertMarker()`}
             * instead.
             *
             * @error writer-updatemarker-reconvert-using-editingcontroller
             * @param markerName The name of the updated marker.
             */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('writer-updatemarker-reconvert-using-editingcontroller', {
                markerName
            });
            this.model.markers._refresh(currentMarker);
            return;
        }
        const hasUsingOperationDefined = typeof options.usingOperation == 'boolean';
        const affectsDataDefined = typeof options.affectsData == 'boolean';
        // Use previously defined marker's affectsData if the property is not provided.
        const affectsData = affectsDataDefined ? options.affectsData : currentMarker.affectsData;
        if (!hasUsingOperationDefined && !options.range && !affectsDataDefined) {
            /**
             * One of the options is required - provide range, usingOperations or affectsData.
             *
             * @error writer-updatemarker-wrong-options
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-updatemarker-wrong-options', this);
        }
        const currentRange = currentMarker.getRange();
        const updatedRange = options.range ? options.range : currentRange;
        if (hasUsingOperationDefined && options.usingOperation !== currentMarker.managedUsingOperations) {
            // The marker type is changed so it's necessary to create proper operations.
            if (options.usingOperation) {
                // If marker changes to a managed one treat this as synchronizing existing marker.
                // Create `MarkerOperation` with `oldRange` set to `null`, so reverse operation will remove the marker.
                applyMarkerOperation(this, markerName, null, updatedRange, affectsData);
            } else {
                // If marker changes to a marker that do not use operations then we need to create additional operation
                // that removes that marker first.
                applyMarkerOperation(this, markerName, currentRange, null, affectsData);
                // Although not managed the marker itself should stay in model and its range should be preserver or changed to passed range.
                this.model.markers._set(markerName, updatedRange, undefined, affectsData);
            }
            return;
        }
        // Marker's type doesn't change so update it accordingly.
        if (currentMarker.managedUsingOperations) {
            applyMarkerOperation(this, markerName, currentRange, updatedRange, affectsData);
        } else {
            this.model.markers._set(markerName, updatedRange, undefined, affectsData);
        }
    }
    /**
     * Removes given {@link module:engine/model/markercollection~Marker marker} or marker with given name.
     * The marker is removed accordingly to how it has been created, so if the marker was created using operation,
     * it will be destroyed using operation.
     *
     * @param markerOrName Marker or marker name to remove.
     */ removeMarker(markerOrName) {
        this._assertWriterUsedCorrectly();
        const name = typeof markerOrName == 'string' ? markerOrName : markerOrName.name;
        if (!this.model.markers.has(name)) {
            /**
             * Trying to remove marker which does not exist.
             *
             * @error writer-removemarker-no-marker
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-removemarker-no-marker', this);
        }
        const marker = this.model.markers.get(name);
        if (!marker.managedUsingOperations) {
            this.model.markers._remove(name);
            return;
        }
        const oldRange = marker.getRange();
        applyMarkerOperation(this, name, oldRange, null, marker.affectsData);
    }
    /**
     * Adds a new root to the document (or re-attaches a {@link #detachRoot detached root}).
     *
     * Throws an error, if trying to add a root that is already added and attached.
     *
     * @param rootName Name of the added root.
     * @param elementName The element name. Defaults to `'$root'` which also has some basic schema defined
     * (e.g. `$block` elements are allowed inside the `$root`). Make sure to define a proper schema if you use a different name.
     * @returns The added root element.
     */ addRoot(rootName, elementName = '$root') {
        this._assertWriterUsedCorrectly();
        const root = this.model.document.getRoot(rootName);
        if (root && root.isAttached()) {
            /**
             * Root with provided name already exists and is attached.
             *
             * @error writer-addroot-root-exists
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-addroot-root-exists', this);
        }
        const document = this.model.document;
        const operation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](rootName, elementName, true, document, document.version);
        this.batch.addOperation(operation);
        this.model.applyOperation(operation);
        return this.model.document.getRoot(rootName);
    }
    /**
     * Detaches the root from the document.
     *
     * All content and markers are removed from the root upon detaching. New content and new markers cannot be added to the root, as long
     * as it is detached.
     *
     * A root cannot be fully removed from the document, it can be only detached. A root is permanently removed only after you
     * re-initialize the editor and do not specify the root in the initial data.
     *
     * A detached root can be re-attached using {@link #addRoot}.
     *
     * Throws an error if the root does not exist or the root is already detached.
     *
     * @param rootOrName Name of the detached root.
     */ detachRoot(rootOrName) {
        this._assertWriterUsedCorrectly();
        const root = typeof rootOrName == 'string' ? this.model.document.getRoot(rootOrName) : rootOrName;
        if (!root || !root.isAttached()) {
            /**
             * Root with provided name does not exist or is already detached.
             *
             * @error writer-detachroot-no-root
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-detachroot-no-root', this);
        }
        // First, remove all markers from the root. It is better to do it before removing stuff for undo purposes.
        // However, looking through all the markers may not be the best performance wise. But there's no better solution for now.
        for (const marker of this.model.markers){
            if (marker.getRange().root === root) {
                this.removeMarker(marker);
            }
        }
        // Remove all attributes from the root.
        for (const key of root.getAttributeKeys()){
            this.removeAttribute(key, root);
        }
        // Remove all contents of the root.
        this.remove(this.createRangeIn(root));
        // Finally, detach the root.
        const document = this.model.document;
        const operation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](root.rootName, root.name, false, document, document.version);
        this.batch.addOperation(operation);
        this.model.applyOperation(operation);
    }
    setSelection(...args) {
        this._assertWriterUsedCorrectly();
        this.model.document.selection._setTo(...args);
    }
    /**
     * Moves {@link module:engine/model/documentselection~DocumentSelection#focus} to the specified location.
     *
     * The location can be specified in the same form as
     * {@link #createPositionAt `writer.createPositionAt()`} parameters.
     *
     * @param itemOrPosition
     * @param offset Offset or one of the flags. Used only when first parameter is a {@link module:engine/model/item~Item model item}.
     */ setSelectionFocus(itemOrPosition, offset) {
        this._assertWriterUsedCorrectly();
        this.model.document.selection._setFocus(itemOrPosition, offset);
    }
    setSelectionAttribute(keyOrObjectOrIterable, value) {
        this._assertWriterUsedCorrectly();
        if (typeof keyOrObjectOrIterable === 'string') {
            this._setSelectionAttribute(keyOrObjectOrIterable, value);
        } else {
            for (const [key, value] of (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__["toMap"])(keyOrObjectOrIterable)){
                this._setSelectionAttribute(key, value);
            }
        }
    }
    /**
     * Removes attribute(s) with given key(s) from the selection.
     *
     * Remove one attribute:
     *
     * ```ts
     * writer.removeSelectionAttribute( 'italic' );
     * ```
     *
     * Remove multiple attributes:
     *
     * ```ts
     * writer.removeSelectionAttribute( [ 'italic', 'bold' ] );
     * ```
     *
     * @param keyOrIterableOfKeys Key of the attribute to remove or an iterable of attribute keys to remove.
     */ removeSelectionAttribute(keyOrIterableOfKeys) {
        this._assertWriterUsedCorrectly();
        if (typeof keyOrIterableOfKeys === 'string') {
            this._removeSelectionAttribute(keyOrIterableOfKeys);
        } else {
            for (const key of keyOrIterableOfKeys){
                this._removeSelectionAttribute(key);
            }
        }
    }
    /**
     * Temporarily changes the {@link module:engine/model/documentselection~DocumentSelection#isGravityOverridden gravity}
     * of the selection from left to right.
     *
     * The gravity defines from which direction the selection inherits its attributes. If it's the default left gravity,
     * then the selection (after being moved by the user) inherits attributes from its left-hand side.
     * This method allows to temporarily override this behavior by forcing the gravity to the right.
     *
     * For the following model fragment:
     *
     * ```xml
     * <$text bold="true" linkHref="url">bar[]</$text><$text bold="true">biz</$text>
     * ```
     *
     * * Default gravity: selection will have the `bold` and `linkHref` attributes.
     * * Overridden gravity: selection will have `bold` attribute.
     *
     * **Note**: It returns an unique identifier which is required to restore the gravity. It guarantees the symmetry
     * of the process.
     *
     * @returns The unique id which allows restoring the gravity.
     */ overrideSelectionGravity() {
        return this.model.document.selection._overrideGravity();
    }
    /**
     * Restores {@link ~Writer#overrideSelectionGravity} gravity to default.
     *
     * Restoring the gravity is only possible using the unique identifier returned by
     * {@link ~Writer#overrideSelectionGravity}. Note that the gravity remains overridden as long as won't be restored
     * the same number of times it was overridden.
     *
     * @param uid The unique id returned by {@link ~Writer#overrideSelectionGravity}.
     */ restoreSelectionGravity(uid) {
        this.model.document.selection._restoreGravity(uid);
    }
    /**
     * @param key Key of the attribute to remove.
     * @param value Attribute value.
     */ _setSelectionAttribute(key, value) {
        const selection = this.model.document.selection;
        // Store attribute in parent element if the selection is collapsed in an empty node.
        if (selection.isCollapsed && selection.anchor.parent.isEmpty) {
            const storeKey = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._getStoreAttributeKey(key);
            this.setAttribute(storeKey, value, selection.anchor.parent);
        }
        selection._setAttribute(key, value);
    }
    /**
     * @param key Key of the attribute to remove.
     */ _removeSelectionAttribute(key) {
        const selection = this.model.document.selection;
        // Remove stored attribute from parent element if the selection is collapsed in an empty node.
        if (selection.isCollapsed && selection.anchor.parent.isEmpty) {
            const storeKey = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._getStoreAttributeKey(key);
            this.removeAttribute(storeKey, selection.anchor.parent);
        }
        selection._removeAttribute(key);
    }
    /**
     * Throws `writer-detached-writer-tries-to-modify-model` error when the writer is used outside of the `change()` block.
     */ _assertWriterUsedCorrectly() {
        /**
         * Trying to use a writer outside a {@link module:engine/model/model~Model#change `change()`} or
         * {@link module:engine/model/model~Model#enqueueChange `enqueueChange()`} blocks.
         *
         * The writer can only be used inside these blocks which ensures that the model
         * can only be changed during such "sessions".
         *
         * @error writer-incorrect-use
         */ if (this.model._currentWriter !== this) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('writer-incorrect-use', this);
        }
    }
    /**
     * For given action `type` and `positionOrRange` where the action happens, this function finds all affected markers
     * and applies a marker operation with the new marker range equal to the current range. Thanks to this, the marker range
     * can be later correctly processed during undo.
     *
     * @param type Writer action type.
     * @param positionOrRange Position or range where the writer action happens.
     */ _addOperationForAffectedMarkers(type, positionOrRange) {
        for (const marker of this.model.markers){
            if (!marker.managedUsingOperations) {
                continue;
            }
            const markerRange = marker.getRange();
            let isAffected = false;
            if (type === 'move') {
                const range = positionOrRange;
                isAffected = range.containsPosition(markerRange.start) || range.start.isEqual(markerRange.start) || range.containsPosition(markerRange.end) || range.end.isEqual(markerRange.end);
            } else {
                // if type === 'merge'.
                const position = positionOrRange;
                const elementBefore = position.nodeBefore;
                const elementAfter = position.nodeAfter;
                //               Start:  <p>Foo[</p><p>Bar]</p>
                //         After merge:  <p>Foo[Bar]</p>
                // After undoing split:  <p>Foo</p><p>[Bar]</p>     <-- incorrect, needs remembering for undo.
                //
                const affectedInLeftElement = markerRange.start.parent == elementBefore && markerRange.start.isAtEnd;
                //               Start:  <p>[Foo</p><p>]Bar</p>
                //         After merge:  <p>[Foo]Bar</p>
                // After undoing split:  <p>[Foo]</p><p>Bar</p>     <-- incorrect, needs remembering for undo.
                //
                const affectedInRightElement = markerRange.end.parent == elementAfter && markerRange.end.offset == 0;
                //               Start:  <p>[Foo</p>]<p>Bar</p>
                //         After merge:  <p>[Foo]Bar</p>
                // After undoing split:  <p>[Foo]</p><p>Bar</p>     <-- incorrect, needs remembering for undo.
                //
                const affectedAfterLeftElement = markerRange.end.nodeAfter == elementAfter;
                //               Start:  <p>Foo</p>[<p>Bar]</p>
                //         After merge:  <p>Foo[Bar]</p>
                // After undoing split:  <p>Foo</p><p>[Bar]</p>     <-- incorrect, needs remembering for undo.
                //
                const affectedBeforeRightElement = markerRange.start.nodeAfter == elementAfter;
                isAffected = affectedInLeftElement || affectedInRightElement || affectedAfterLeftElement || affectedBeforeRightElement;
            }
            if (isAffected) {
                this.updateMarker(marker.name, {
                    range: markerRange
                });
            }
        }
    }
}
/**
 * Sets given attribute to each node in given range. When attribute value is null then attribute will be removed.
 *
 * Because attribute operation needs to have the same attribute value on the whole range, this function splits
 * the range into smaller parts.
 *
 * Given `range` must be flat.
 */ function setAttributeOnRange(writer, key, value, range) {
    const model = writer.model;
    const doc = model.document;
    // Position of the last split, the beginning of the new range.
    let lastSplitPosition = range.start;
    // Currently position in the scanning range. Because we need value after the position, it is not a current
    // position of the iterator but the previous one (we need to iterate one more time to get the value after).
    let position;
    // Value before the currently position.
    let valueBefore;
    // Value after the currently position.
    let valueAfter;
    for (const val of range.getWalker({
        shallow: true
    })){
        valueAfter = val.item.getAttribute(key);
        // At the first run of the iterator the position in undefined. We also do not have a valueBefore, but
        // because valueAfter may be null, valueBefore may be equal valueAfter ( undefined == null ).
        if (position && valueBefore != valueAfter) {
            // if valueBefore == value there is nothing to change, so we add operation only if these values are different.
            if (valueBefore != value) {
                addOperation();
            }
            lastSplitPosition = position;
        }
        position = val.nextPosition;
        valueBefore = valueAfter;
    }
    // Because position in the loop is not the iterator position (see let position comment), the last position in
    // the while loop will be last but one position in the range. We need to check the last position manually.
    if (position instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] && position != lastSplitPosition && valueBefore != value) {
        addOperation();
    }
    function addOperation() {
        const range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](lastSplitPosition, position);
        const version = range.root.document ? doc.version : null;
        const operation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range, key, valueBefore, value, version);
        writer.batch.addOperation(operation);
        model.applyOperation(operation);
    }
}
/**
 * Sets given attribute to the given node. When attribute value is null then attribute will be removed.
 */ function setAttributeOnItem(writer, key, value, item) {
    const model = writer.model;
    const doc = model.document;
    const previousValue = item.getAttribute(key);
    let range, operation;
    if (previousValue != value) {
        const isRootChanged = item.root === item;
        if (isRootChanged) {
            // If we change attributes of root element, we have to use `RootAttributeOperation`.
            const version = item.document ? doc.version : null;
            operation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$rootattributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](item, key, previousValue, value, version);
        } else {
            range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item), writer.createPositionAfter(item));
            const version = range.root.document ? doc.version : null;
            operation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$attributeoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range, key, previousValue, value, version);
        }
        writer.batch.addOperation(operation);
        model.applyOperation(operation);
    }
}
/**
 * Creates and applies marker operation to {@link module:engine/model/operation/operation~Operation operation}.
 */ function applyMarkerOperation(writer, name, oldRange, newRange, affectsData) {
    const model = writer.model;
    const doc = model.document;
    const operation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$markeroperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](name, oldRange, newRange, model.markers, !!affectsData, doc.version);
    writer.batch.addOperation(operation);
    model.applyOperation(operation);
}
/**
 * Creates `MoveOperation` or `DetachOperation` that removes `howMany` nodes starting from `position`.
 * The operation will be applied on given model instance and added to given operation instance.
 *
 * @param position Position from which nodes are removed.
 * @param howMany Number of nodes to remove.
 * @param batch Batch to which the operation will be added.
 * @param model Model instance on which operation will be applied.
 */ function applyRemoveOperation(position, howMany, batch, model) {
    let operation;
    if (position.root.document) {
        const doc = model.document;
        const graveyardPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](doc.graveyard, [
            0
        ]);
        operation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$moveoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position, howMany, graveyardPosition, doc.version);
    } else {
        operation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$detachoperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position, howMany);
    }
    batch.addOperation(operation);
    model.applyOperation(operation);
}
/**
 * Returns `true` if both root elements are the same element or both are documents root elements.
 *
 * Elements in the same tree can be moved (for instance you can move element form one documents root to another, or
 * within the same document fragment), but when element supposed to be moved from document fragment to the document, or
 * to another document it should be removed and inserted to avoid problems with OT. This is because features like undo or
 * collaboration may track changes on the document but ignore changes on detached fragments and should not get
 * unexpected `move` operation.
 */ function isSameTree(rootA, rootB) {
    // If it is the same root this is the same tree.
    if (rootA === rootB) {
        return true;
    }
    // If both roots are documents root it is operation within the document what we still treat as the same tree.
    if (rootA instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$rootelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] && rootB instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$rootelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        return true;
    }
    return false;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/deletecontent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/utils/deletecontent
 */ __turbopack_context__.s([
    "default",
    ()=>deleteContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liveposition.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
;
;
;
function deleteContent(model, selection, options = {}) {
    if (selection.isCollapsed) {
        return;
    }
    const selRange = selection.getFirstRange();
    // If the selection is already removed, don't do anything.
    if (selRange.root.rootName == '$graveyard') {
        return;
    }
    const schema = model.schema;
    model.change((writer)=>{
        // 1. Replace the entire content with paragraph.
        // See: https://github.com/ckeditor/ckeditor5-engine/issues/1012#issuecomment-315017594.
        if (!options.doNotResetEntireContent && shouldEntireContentBeReplacedWithParagraph(schema, selection)) {
            replaceEntireContentWithParagraph(writer, selection);
            return;
        }
        // Collect attributes to copy in case of autoparagraphing.
        const attributesForAutoparagraph = {};
        if (!options.doNotAutoparagraph) {
            const selectedElement = selection.getSelectedElement();
            if (selectedElement) {
                Object.assign(attributesForAutoparagraph, schema.getAttributesWithProperty(selectedElement, 'copyOnReplace', true));
            }
        }
        // Get the live positions for the range adjusted to span only blocks selected from the user perspective.
        const [startPosition, endPosition] = getLivePositionsForSelectedBlocks(selRange);
        // 2. Remove the content if there is any.
        if (!startPosition.isTouching(endPosition)) {
            writer.remove(writer.createRange(startPosition, endPosition));
        }
        // 3. Merge elements in the right branch to the elements in the left branch.
        // The only reasonable (in terms of data and selection correctness) case in which we need to do that is:
        //
        // <heading type=1>Fo[</heading><paragraph>]ar</paragraph> => <heading type=1>Fo^ar</heading>
        //
        // However, the algorithm supports also merging deeper structures (up to the depth of the shallower branch),
        // as it's hard to imagine what should actually be the default behavior. Usually, specific features will
        // want to override that behavior anyway.
        if (!options.leaveUnmerged) {
            mergeBranches(writer, startPosition, endPosition);
            // TMP this will be replaced with a postfixer.
            // We need to check and strip disallowed attributes in all nested nodes because after merge
            // some attributes could end up in a path where are disallowed.
            //
            // e.g. bold is disallowed for <H1>
            // <h1>Fo{o</h1><p>b}a<b>r</b><p> -> <h1>Fo{}a<b>r</b><h1> -> <h1>Fo{}ar<h1>.
            schema.removeDisallowedAttributes(startPosition.parent.getChildren(), writer);
        }
        collapseSelectionAt(writer, selection, startPosition);
        // 4. Add a paragraph to set selection in it.
        // Check if a text is allowed in the new container. If not, try to create a new paragraph (if it's allowed here).
        // If autoparagraphing is off, we assume that you know what you do so we leave the selection wherever it was.
        if (!options.doNotAutoparagraph && shouldAutoparagraph(schema, startPosition)) {
            insertParagraph(writer, startPosition, selection, attributesForAutoparagraph);
        }
        startPosition.detach();
        endPosition.detach();
    });
}
/**
 * Returns the live positions for the range adjusted to span only blocks selected from the user perspective. Example:
 *
 * ```
 * <heading1>[foo</heading1>
 * <paragraph>bar</paragraph>
 * <heading1>]abc</heading1>  <-- this block is not considered as selected
 * ```
 *
 * This is the same behavior as in Selection#getSelectedBlocks() "special case".
 */ function getLivePositionsForSelectedBlocks(range) {
    const model = range.root.document.model;
    const startPosition = range.start;
    let endPosition = range.end;
    // If the end of selection is at the start position of last block in the selection, then
    // shrink it to not include that trailing block. Note that this should happen only for not empty selection.
    if (model.hasContent(range, {
        ignoreMarkers: true
    })) {
        const endBlock = getParentBlock(endPosition);
        if (endBlock && endPosition.isTouching(model.createPositionAt(endBlock, 0))) {
            // Create forward selection as a probe to find a valid position after excluding last block from the range.
            const selection = model.createSelection(range);
            // Modify the forward selection in backward direction to shrink it and remove first position of following block from it.
            // This is how modifySelection works and here we are making use of it.
            model.modifySelection(selection, {
                direction: 'backward'
            });
            const newEndPosition = selection.getLastPosition();
            // For such a model and selection:
            //     <paragraph>A[</paragraph><imageBlock></imageBlock><paragraph>]B</paragraph>
            //
            // After modifySelection(), we would end up with this:
            //     <paragraph>A[</paragraph>]<imageBlock></imageBlock><paragraph>B</paragraph>
            //
            // So we need to check if there is no content in the skipped range (because we want to include the <imageBlock>).
            const skippedRange = model.createRange(newEndPosition, endPosition);
            if (!model.hasContent(skippedRange, {
                ignoreMarkers: true
            })) {
                endPosition = newEndPosition;
            }
        }
    }
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromPosition(startPosition, 'toPrevious'),
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromPosition(endPosition, 'toNext')
    ];
}
/**
 * Finds the lowest element in position's ancestors which is a block.
 * Returns null if a limit element is encountered before reaching a block element.
 */ function getParentBlock(position) {
    const element = position.parent;
    const schema = element.root.document.model.schema;
    const ancestors = element.getAncestors({
        parentFirst: true,
        includeSelf: true
    });
    for (const element of ancestors){
        if (schema.isLimit(element)) {
            return null;
        }
        if (schema.isBlock(element)) {
            return element;
        }
    }
}
/**
 * This function is a result of reaching the Ballmer's peak for just the right amount of time.
 * Even I had troubles documenting it after a while and after reading it again I couldn't believe that it really works.
 */ function mergeBranches(writer, startPosition, endPosition) {
    const model = writer.model;
    // Verify if there is a need and possibility to merge.
    if (!checkShouldMerge(writer.model.schema, startPosition, endPosition)) {
        return;
    }
    // If the start element on the common ancestor level is empty, and the end element on the same level is not empty
    // then merge those to the right element so that it's properties are preserved (name, attributes).
    // Because of OT merging is used instead of removing elements.
    //
    // Merge left:
    //     <heading1>foo[</heading1>    ->  <heading1>foo[]bar</heading1>
    //     <paragraph>]bar</paragraph>  ->               --^
    //
    // Merge right:
    //     <heading1>[</heading1>       ->
    //     <paragraph>]bar</paragraph>  ->  <paragraph>[]bar</paragraph>
    //
    // Merge left:
    //     <blockQuote>                     ->  <blockQuote>
    //         <heading1>foo[</heading1>    ->      <heading1>foo[]bar</heading1>
    //         <paragraph>]bar</paragraph>  ->                   --^
    //     </blockQuote>                    ->  </blockQuote>
    //
    // Merge right:
    //     <blockQuote>                     ->  <blockQuote>
    //         <heading1>[</heading1>       ->
    //         <paragraph>]bar</paragraph>  ->      <paragraph>[]bar</paragraph>
    //     </blockQuote>                    ->  </blockQuote>
    // Merging should not go deeper than common ancestor.
    const [startAncestor, endAncestor] = getAncestorsJustBelowCommonAncestor(startPosition, endPosition);
    // Branches can't be merged if one of the positions is directly inside a common ancestor.
    //
    // Example:
    //     <blockQuote>
    //         <paragraph>[foo</paragraph>]
    //         <table> ... </table>
    //     <blockQuote>
    //
    if (!startAncestor || !endAncestor) {
        return;
    }
    if (!model.hasContent(startAncestor, {
        ignoreMarkers: true
    }) && model.hasContent(endAncestor, {
        ignoreMarkers: true
    })) {
        mergeBranchesRight(writer, startPosition, endPosition, startAncestor.parent);
    } else {
        mergeBranchesLeft(writer, startPosition, endPosition, startAncestor.parent);
    }
}
/**
 * Merging blocks to the left (properties of the left block are preserved).
 * Simple example:
 *
 * ```
 * <heading1>foo[</heading1>    ->  <heading1>foo[bar</heading1>]
 * <paragraph>]bar</paragraph>  ->              --^
 * ```
 *
 * Nested example:
 *
 * ```
 * <blockQuote>                     ->  <blockQuote>
 *     <heading1>foo[</heading1>    ->      <heading1>foo[bar</heading1>
 * </blockQuote>                    ->  </blockQuote>]    ^
 * <blockBlock>                     ->                    |
 *     <paragraph>]bar</paragraph>  ->                 ---
 * </blockBlock>                    ->
 * ```
 */ function mergeBranchesLeft(writer, startPosition, endPosition, commonAncestor) {
    const startElement = startPosition.parent;
    const endElement = endPosition.parent;
    // Merging reached the common ancestor element, stop here.
    if (startElement == commonAncestor || endElement == commonAncestor) {
        return;
    }
    // Remember next positions to merge in next recursive step (also used as modification points pointers).
    startPosition = writer.createPositionAfter(startElement);
    endPosition = writer.createPositionBefore(endElement);
    // Move endElement just after startElement if they aren't siblings.
    if (!endPosition.isEqual(startPosition)) {
        //
        //     <blockQuote>                     ->  <blockQuote>
        //         <heading1>foo[</heading1>    ->      <heading1>foo</heading1>[<paragraph>bar</paragraph>
        //     </blockQuote>                    ->  </blockQuote>                ^
        //     <blockBlock>                     ->  <blockBlock>                 |
        //         <paragraph>]bar</paragraph>  ->      ]                     ---
        //     </blockBlock>                    ->  </blockBlock>
        //
        writer.insert(endElement, startPosition);
    }
    // Merge two siblings (nodes on sides of startPosition):
    //
    //     <blockQuote>                                             ->  <blockQuote>
    //         <heading1>foo</heading1>[<paragraph>bar</paragraph>  ->      <heading1>foo[bar</heading1>
    //     </blockQuote>                                            ->  </blockQuote>
    //     <blockBlock>                                             ->  <blockBlock>
    //         ]                                                    ->      ]
    //     </blockBlock>                                            ->  </blockBlock>
    //
    // Or in simple case (without moving elements in above if):
    //     <heading1>foo</heading1>[<paragraph>bar</paragraph>]  ->  <heading1>foo[bar</heading1>]
    //
    writer.merge(startPosition);
    // Remove empty end ancestors:
    //
    //     <blockQuote>                      ->  <blockQuote>
    //         <heading1>foo[bar</heading1>  ->      <heading1>foo[bar</heading1>
    //     </blockQuote>                     ->  </blockQuote>
    //     <blockBlock>                      ->
    //         ]                             ->  ]
    //     </blockBlock>                     ->
    //
    while(endPosition.parent.isEmpty){
        const parentToRemove = endPosition.parent;
        endPosition = writer.createPositionBefore(parentToRemove);
        writer.remove(parentToRemove);
    }
    // Verify if there is a need and possibility to merge next level.
    if (!checkShouldMerge(writer.model.schema, startPosition, endPosition)) {
        return;
    }
    // Continue merging next level (blockQuote with blockBlock in the examples above if it would not be empty and got removed).
    mergeBranchesLeft(writer, startPosition, endPosition, commonAncestor);
}
/**
 * Merging blocks to the right (properties of the right block are preserved).
 * Simple example:
 *
 * ```
 * <heading1>foo[</heading1>    ->            --v
 * <paragraph>]bar</paragraph>  ->  [<paragraph>foo]bar</paragraph>
 * ```
 *
 * Nested example:
 *
 * ```
 * <blockQuote>                     ->
 *     <heading1>foo[</heading1>    ->              ---
 * </blockQuote>                    ->                 |
 * <blockBlock>                     ->  [<blockBlock>  v
 *     <paragraph>]bar</paragraph>  ->      <paragraph>foo]bar</paragraph>
 * </blockBlock>                    ->  </blockBlock>
 * ```
 */ function mergeBranchesRight(writer, startPosition, endPosition, commonAncestor) {
    const startElement = startPosition.parent;
    const endElement = endPosition.parent;
    // Merging reached the common ancestor element, stop here.
    if (startElement == commonAncestor || endElement == commonAncestor) {
        return;
    }
    // Remember next positions to merge in next recursive step (also used as modification points pointers).
    startPosition = writer.createPositionAfter(startElement);
    endPosition = writer.createPositionBefore(endElement);
    // Move startElement just before endElement if they aren't siblings.
    if (!endPosition.isEqual(startPosition)) {
        //
        //     <blockQuote>                     ->  <blockQuote>
        //         <heading1>foo[</heading1>    ->      [                   ---
        //     </blockQuote>                    ->  </blockQuote>              |
        //     <blockBlock>                     ->  <blockBlock>               v
        //         <paragraph>]bar</paragraph>  ->      <heading1>foo</heading1>]<paragraph>bar</paragraph>
        //     </blockBlock>                    ->  </blockBlock>
        //
        writer.insert(startElement, endPosition);
    }
    // Remove empty end ancestors:
    //
    //     <blockQuote>                                             ->
    //         [                                                    ->  [
    //     </blockQuote>                                            ->
    //     <blockBlock>                                             ->  <blockBlock>
    //         <heading1>foo</heading1>]<paragraph>bar</paragraph>  ->      <heading1>foo</heading1>]<paragraph>bar</paragraph>
    //     </blockBlock>                                            ->  </blockBlock>
    //
    while(startPosition.parent.isEmpty){
        const parentToRemove = startPosition.parent;
        startPosition = writer.createPositionBefore(parentToRemove);
        writer.remove(parentToRemove);
    }
    // Update endPosition after inserting and removing elements.
    endPosition = writer.createPositionBefore(endElement);
    // Merge right two siblings (nodes on sides of endPosition):
    //                                                              ->
    //     [                                                        ->  [
    //                                                              ->
    //     <blockBlock>                                             ->  <blockBlock>
    //         <heading1>foo</heading1>]<paragraph>bar</paragraph>  ->      <paragraph>foo]bar</paragraph>
    //     </blockBlock>                                            ->  </blockBlock>
    //
    // Or in simple case (without moving elements in above if):
    //     [<heading1>foo</heading1>]<paragraph>bar</paragraph>  ->  [<heading1>foo]bar</heading1>
    //
    mergeRight(writer, endPosition);
    // Verify if there is a need and possibility to merge next level.
    if (!checkShouldMerge(writer.model.schema, startPosition, endPosition)) {
        return;
    }
    // Continue merging next level (blockQuote with blockBlock in the examples above if it would not be empty and got removed).
    mergeBranchesRight(writer, startPosition, endPosition, commonAncestor);
}
/**
 * There is no right merge operation so we need to simulate it.
 */ function mergeRight(writer, position) {
    const startElement = position.nodeBefore;
    const endElement = position.nodeAfter;
    if (startElement.name != endElement.name) {
        writer.rename(startElement, endElement.name);
    }
    writer.clearAttributes(startElement);
    writer.setAttributes(Object.fromEntries(endElement.getAttributes()), startElement);
    writer.merge(position);
}
/**
 * Verifies if merging is needed and possible. It's not needed if both positions are in the same element
 * and it's not possible if some element is a limit or the range crosses a limit element.
 */ function checkShouldMerge(schema, startPosition, endPosition) {
    const startElement = startPosition.parent;
    const endElement = endPosition.parent;
    // If both positions ended up in the same parent, then there's nothing more to merge:
    // <$root><p>x[</p><p>]y</p></$root> => <$root><p>xy</p>[]</$root>
    if (startElement == endElement) {
        return false;
    }
    // If one of the positions is a limit element, then there's nothing to merge because we don't want to cross the limit boundaries.
    if (schema.isLimit(startElement) || schema.isLimit(endElement)) {
        return false;
    }
    // Check if operations we'll need to do won't need to cross object or limit boundaries.
    // E.g., we can't merge endElement into startElement in this case:
    // <limit><startElement>x[</startElement></limit><endElement>]</endElement>
    return isCrossingLimitElement(startPosition, endPosition, schema);
}
/**
 * Returns the elements that are the ancestors of the provided positions that are direct children of the common ancestor.
 */ function getAncestorsJustBelowCommonAncestor(positionA, positionB) {
    const ancestorsA = positionA.getAncestors();
    const ancestorsB = positionB.getAncestors();
    let i = 0;
    while(ancestorsA[i] && ancestorsA[i] == ancestorsB[i]){
        i++;
    }
    return [
        ancestorsA[i],
        ancestorsB[i]
    ];
}
function shouldAutoparagraph(schema, position) {
    const isTextAllowed = schema.checkChild(position, '$text');
    const isParagraphAllowed = schema.checkChild(position, 'paragraph');
    return !isTextAllowed && isParagraphAllowed;
}
/**
 * Check if parents of two positions can be merged by checking if there are no limit/object
 * boundaries between those two positions.
 *
 * E.g. in <bQ><p>x[]</p></bQ><widget><caption>{}</caption></widget>
 * we'll check <p>, <bQ>, <widget> and <caption>.
 * Usually, widget and caption are marked as objects/limits in the schema, so in this case merging will be blocked.
 */ function isCrossingLimitElement(leftPos, rightPos, schema) {
    const rangeToCheck = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](leftPos, rightPos);
    for (const value of rangeToCheck.getWalker()){
        if (schema.isLimit(value.item)) {
            return false;
        }
    }
    return true;
}
function insertParagraph(writer, position, selection, attributes = {}) {
    const paragraph = writer.createElement('paragraph');
    writer.model.schema.setAllowedAttributes(paragraph, attributes, writer);
    writer.insert(paragraph, position);
    collapseSelectionAt(writer, selection, writer.createPositionAt(paragraph, 0));
}
function replaceEntireContentWithParagraph(writer, selection) {
    const limitElement = writer.model.schema.getLimitElement(selection);
    writer.remove(writer.createRangeIn(limitElement));
    insertParagraph(writer, writer.createPositionAt(limitElement, 0), selection);
}
/**
 * We want to replace the entire content with a paragraph when:
 * * the entire content is selected,
 * * selection contains at least two elements,
 * * whether the paragraph is allowed in schema in the common ancestor.
 */ function shouldEntireContentBeReplacedWithParagraph(schema, selection) {
    const limitElement = schema.getLimitElement(selection);
    if (!selection.containsEntireContent(limitElement)) {
        return false;
    }
    const range = selection.getFirstRange();
    if (range.start.parent == range.end.parent) {
        return false;
    }
    return schema.checkChild(limitElement, 'paragraph');
}
/**
 * Helper function that sets the selection. Depending whether given `selection` is a document selection or not,
 * uses a different method to set it.
 */ function collapseSelectionAt(writer, selection, positionOrRange) {
    if (selection instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        writer.setSelection(positionOrRange);
    } else {
        selection.setTo(positionOrRange);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/getselectedcontent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/utils/getselectedcontent
 */ /**
 * Gets a clone of the selected content.
 *
 * For example, for the following selection:
 *
 * ```html
 * <p>x</p><quote><p>y</p><h>fir[st</h></quote><p>se]cond</p><p>z</p>
 * ```
 *
 * It will return a document fragment with such a content:
 *
 * ```html
 * <quote><h>st</h></quote><p>se</p>
 * ```
 *
 * @param model The model in context of which the selection modification should be performed.
 * @param selection The selection of which content will be returned.
 */ __turbopack_context__.s([
    "default",
    ()=>getSelectedContent
]);
function getSelectedContent(model, selection) {
    return model.change((writer)=>{
        const frag = writer.createDocumentFragment();
        const range = selection.getFirstRange();
        if (!range || range.isCollapsed) {
            return frag;
        }
        const root = range.start.root;
        const commonPath = range.start.getCommonPath(range.end);
        const commonParent = root.getNodeByPath(commonPath);
        // ## 1st step
        //
        // First, we'll clone a fragment represented by a minimal flat range
        // containing the original range to be cloned.
        // E.g. let's consider such a range:
        //
        // <p>x</p><quote><p>y</p><h>fir[st</h></quote><p>se]cond</p><p>z</p>
        //
        // A minimal flat range containing this one is:
        //
        // <p>x</p>[<quote><p>y</p><h>first</h></quote><p>second</p>]<p>z</p>
        //
        // We can easily clone this structure, preserving e.g. the <quote> element.
        let flatSubtreeRange;
        if (range.start.parent == range.end.parent) {
            // The original range is flat, so take it.
            flatSubtreeRange = range;
        } else {
            flatSubtreeRange = writer.createRange(writer.createPositionAt(commonParent, range.start.path[commonPath.length]), writer.createPositionAt(commonParent, range.end.path[commonPath.length] + 1));
        }
        const howMany = flatSubtreeRange.end.offset - flatSubtreeRange.start.offset;
        // Clone the whole contents.
        for (const item of flatSubtreeRange.getItems({
            shallow: true
        })){
            if (item.is('$textProxy')) {
                writer.appendText(item.data, item.getAttributes(), frag);
            } else {
                writer.append(writer.cloneElement(item, true), frag);
            }
        }
        // ## 2nd step
        //
        // If the original range wasn't flat, then we need to remove the excess nodes from the both ends of the cloned fragment.
        //
        // For example, for the range shown in the 1st step comment, we need to remove these pieces:
        //
        // <quote>[<p>y</p>]<h>[fir]st</h></quote><p>se[cond]</p>
        //
        // So this will be the final copied content:
        //
        // <quote><h>st</h></quote><p>se</p>
        //
        // In order to do that, we remove content from these two ranges:
        //
        // [<quote><p>y</p><h>fir]st</h></quote><p>se[cond</p>]
        if (flatSubtreeRange != range) {
            // Find the position of the original range in the cloned fragment.
            const newRange = range._getTransformedByMove(flatSubtreeRange.start, writer.createPositionAt(frag, 0), howMany)[0];
            const leftExcessRange = writer.createRange(writer.createPositionAt(frag, 0), newRange.start);
            const rightExcessRange = writer.createRange(newRange.end, writer.createPositionAt(frag, 'end'));
            removeRangeContent(rightExcessRange, writer);
            removeRangeContent(leftExcessRange, writer);
        }
        return frag;
    });
}
// After https://github.com/ckeditor/ckeditor5-engine/issues/690 is fixed,
// this function will, most likely, be able to rewritten using getMinimalFlatRanges().
function removeRangeContent(range, writer) {
    const parentsToCheck = [];
    Array.from(range.getItems({
        direction: 'backward'
    }))// We should better store ranges because text proxies will lose integrity
    // with the text nodes when we'll start removing content.
    .map((item)=>writer.createRangeOn(item))// Filter only these items which are fully contained in the passed range.
    //
    // E.g. for the following range: [<quote><p>y</p><h>fir]st</h>
    // the walker will return the entire <h> element, when only the "fir" item inside it is fully contained.
    .filter((itemRange)=>{
        // We should be able to use Range.containsRange, but https://github.com/ckeditor/ckeditor5-engine/issues/691.
        const contained = (itemRange.start.isAfter(range.start) || itemRange.start.isEqual(range.start)) && (itemRange.end.isBefore(range.end) || itemRange.end.isEqual(range.end));
        return contained;
    }).forEach((itemRange)=>{
        parentsToCheck.push(itemRange.start.parent);
        writer.remove(itemRange);
    });
    // Remove ancestors of the removed items if they turned to be empty now
    // (their whole content was contained in the range).
    parentsToCheck.forEach((parentToCheck)=>{
        let parent = parentToCheck;
        while(parent.parent && parent.isEmpty){
            const removeRange = writer.createRangeOn(parent);
            parent = parent.parent;
            writer.remove(removeRange);
        }
    });
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/insertcontent.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/utils/insertcontent
 */ __turbopack_context__.s([
    "default",
    ()=>insertContent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liveposition.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liverange.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
;
;
;
;
;
function insertContent(model, content, selectable) {
    return model.change((writer)=>{
        const selection = selectable ? selectable : model.document.selection;
        if (!selection.isCollapsed) {
            model.deleteContent(selection, {
                doNotAutoparagraph: true
            });
        }
        const insertion = new Insertion(model, writer, selection.anchor);
        const fakeMarkerElements = [];
        let nodesToInsert;
        if (content.is('documentFragment')) {
            // If document fragment has any markers, these markers should be inserted into the model as well.
            if (content.markers.size) {
                const markersPosition = [];
                for (const [name, range] of content.markers){
                    const { start, end } = range;
                    const isCollapsed = start.isEqual(end);
                    markersPosition.push({
                        position: start,
                        name,
                        isCollapsed
                    }, {
                        position: end,
                        name,
                        isCollapsed
                    });
                }
                // Markers position is sorted backwards to ensure that the insertion of fake markers will not change
                // the position of the next markers.
                markersPosition.sort(({ position: posA }, { position: posB })=>posA.isBefore(posB) ? 1 : -1);
                for (const { position, name, isCollapsed } of markersPosition){
                    let fakeElement = null;
                    let collapsed = null;
                    const isAtBeginning = position.parent === content && position.isAtStart;
                    const isAtEnd = position.parent === content && position.isAtEnd;
                    // We have two ways of handling markers. In general, we want to add temporary <$marker> model elements to
                    // represent marker boundaries. These elements will be inserted into content together with the rest
                    // of the document fragment. After insertion is done, positions for these elements will be read
                    // and proper, actual markers will be created in the model and fake elements will be removed.
                    //
                    // However, if the <$marker> element is at the beginning or at the end of the document fragment,
                    // it may affect how the inserted content is merged with current model, impacting the insertion
                    // result. To avoid that, we don't add <$marker> elements at these positions. Instead, we will use
                    // `Insertion#getAffectedRange()` to figure out new positions for these marker boundaries.
                    if (!isAtBeginning && !isAtEnd) {
                        fakeElement = writer.createElement('$marker');
                        writer.insert(fakeElement, position);
                    } else if (isCollapsed) {
                        // Save whether the collapsed marker was at the beginning or at the end of document fragment
                        // to know where to create it after the insertion is done.
                        collapsed = isAtBeginning ? 'start' : 'end';
                    }
                    fakeMarkerElements.push({
                        name,
                        element: fakeElement,
                        collapsed
                    });
                }
            }
            nodesToInsert = content.getChildren();
        } else {
            nodesToInsert = [
                content
            ];
        }
        insertion.handleNodes(nodesToInsert);
        let newRange = insertion.getSelectionRange();
        if (content.is('documentFragment') && fakeMarkerElements.length) {
            // After insertion was done, the selection was set but the model contains fake <$marker> elements.
            // These <$marker> elements will be now removed. Because of that, we will need to fix the selection.
            // We will create a live range that will automatically be update as <$marker> elements are removed.
            const selectionLiveRange = newRange ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromRange(newRange) : null;
            // Marker name -> [ start position, end position ].
            const markersData = {};
            // Note: `fakeMarkerElements` are sorted backwards. However, now, we want to handle the markers
            // from the beginning, so that existing <$marker> elements do not affect markers positions.
            // This is why we iterate from the end to the start.
            for(let i = fakeMarkerElements.length - 1; i >= 0; i--){
                const { name, element, collapsed } = fakeMarkerElements[i];
                const isStartBoundary = !markersData[name];
                if (isStartBoundary) {
                    markersData[name] = [];
                }
                if (element) {
                    // Read fake marker element position to learn where the marker should be created.
                    const elementPosition = writer.createPositionAt(element, 'before');
                    markersData[name].push(elementPosition);
                    writer.remove(element);
                } else {
                    // If the fake marker element does not exist, it means that the marker boundary was at the beginning or at the end.
                    const rangeOnInsertion = insertion.getAffectedRange();
                    if (!rangeOnInsertion) {
                        // If affected range is `null` it means that nothing was in the document fragment or all content was filtered out.
                        // Some markers that were in the filtered content may be removed (partially or totally).
                        // Let's handle only those markers that were at the beginning or at the end of the document fragment.
                        if (collapsed) {
                            markersData[name].push(insertion.position);
                        }
                        continue;
                    }
                    if (collapsed) {
                        // If the marker was collapsed at the beginning or at the end of the document fragment,
                        // put both boundaries at the beginning or at the end of inserted range (to keep the marker collapsed).
                        markersData[name].push(rangeOnInsertion[collapsed]);
                    } else {
                        markersData[name].push(isStartBoundary ? rangeOnInsertion.start : rangeOnInsertion.end);
                    }
                }
            }
            for (const [name, [start, end]] of Object.entries(markersData)){
                // For now, we ignore markers if they are included in the filtered-out content.
                // In the future implementation we will improve that case to create markers that are not filtered out completely.
                if (start && end && start.root === end.root && start.root.document && !writer.model.markers.has(name)) {
                    writer.addMarker(name, {
                        usingOperation: true,
                        affectsData: true,
                        range: new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end)
                    });
                }
            }
            if (selectionLiveRange) {
                newRange = selectionLiveRange.toRange();
                selectionLiveRange.detach();
            }
        }
        /* istanbul ignore else -- @preserve */ if (newRange) {
            if (selection instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                writer.setSelection(newRange);
            } else {
                selection.setTo(newRange);
            }
        } else {
        // We are not testing else because it's a safe check for unpredictable edge cases:
        // an insertion without proper range to select.
        //
        // @if CK_DEBUG // console.warn( 'Cannot determine a proper selection range after insertion.' );
        }
        const affectedRange = insertion.getAffectedRange() || model.createRange(selection.anchor);
        insertion.destroy();
        return affectedRange;
    });
}
/**
 * Utility class for performing content insertion.
 */ class Insertion {
    constructor(model, writer, position){
        /**
         * The reference to the first inserted node.
         */ this._firstNode = null;
        /**
         * The reference to the last inserted node.
         */ this._lastNode = null;
        /**
         * The reference to the last auto paragraph node.
         */ this._lastAutoParagraph = null;
        /**
         * The array of nodes that should be cleaned of not allowed attributes.
         */ this._filterAttributesOf = [];
        /**
         * Beginning of the affected range. See {@link module:engine/model/utils/insertcontent~Insertion#getAffectedRange}.
         */ this._affectedStart = null;
        /**
         * End of the affected range. See {@link module:engine/model/utils/insertcontent~Insertion#getAffectedRange}.
         */ this._affectedEnd = null;
        this._nodeToSelect = null;
        this.model = model;
        this.writer = writer;
        this.position = position;
        this.canMergeWith = new Set([
            this.position.parent
        ]);
        this.schema = model.schema;
        this._documentFragment = writer.createDocumentFragment();
        this._documentFragmentPosition = writer.createPositionAt(this._documentFragment, 0);
    }
    /**
     * Handles insertion of a set of nodes.
     *
     * @param nodes Nodes to insert.
     */ handleNodes(nodes) {
        for (const node of Array.from(nodes)){
            this._handleNode(node);
        }
        // Insert nodes collected in temporary DocumentFragment.
        this._insertPartialFragment();
        // If there was an auto paragraph then we might need to adjust the end of insertion.
        if (this._lastAutoParagraph) {
            this._updateLastNodeFromAutoParagraph(this._lastAutoParagraph);
        }
        // After the content was inserted we may try to merge it with its next sibling if the selection was in it initially.
        // Merging with the previous sibling was performed just after inserting the first node to the document.
        this._mergeOnRight();
        // TMP this will become a post-fixer.
        this.schema.removeDisallowedAttributes(this._filterAttributesOf, this.writer);
        this._filterAttributesOf = [];
    }
    /**
     * Updates the last node after the auto paragraphing.
     *
     * @param node The last auto paragraphing node.
     */ _updateLastNodeFromAutoParagraph(node) {
        const positionAfterLastNode = this.writer.createPositionAfter(this._lastNode);
        const positionAfterNode = this.writer.createPositionAfter(node);
        // If the real end was after the last auto paragraph then update relevant properties.
        if (positionAfterNode.isAfter(positionAfterLastNode)) {
            this._lastNode = node;
            /* istanbul ignore if -- @preserve */ if (this.position.parent != node || !this.position.isAtEnd) {
                // Algorithm's correctness check. We should never end up here but it's good to know that we did.
                // At this point the insertion position should be at the end of the last auto paragraph.
                // Note: This error is documented in other place in this file.
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('insertcontent-invalid-insertion-position', this);
            }
            this.position = positionAfterNode;
            this._setAffectedBoundaries(this.position);
        }
    }
    /**
     * Returns range to be selected after insertion.
     * Returns `null` if there is no valid range to select after insertion.
     */ getSelectionRange() {
        if (this._nodeToSelect) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(this._nodeToSelect);
        }
        return this.model.schema.getNearestSelectionRange(this.position);
    }
    /**
     * Returns a range which contains all the performed changes. This is a range that, if removed, would return the model to the state
     * before the insertion. Returns `null` if no changes were done.
     */ getAffectedRange() {
        if (!this._affectedStart) {
            return null;
        }
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this._affectedStart, this._affectedEnd);
    }
    /**
     * Destroys `Insertion` instance.
     */ destroy() {
        if (this._affectedStart) {
            this._affectedStart.detach();
        }
        if (this._affectedEnd) {
            this._affectedEnd.detach();
        }
    }
    /**
     * Handles insertion of a single node.
     */ _handleNode(node) {
        // Let's handle object in a special way.
        // * They should never be merged with other elements.
        // * If they are not allowed in any of the selection ancestors, they could be either autoparagraphed or totally removed.
        if (this.schema.isObject(node)) {
            this._handleObject(node);
            return;
        }
        // Try to find a place for the given node.
        // Check if a node can be inserted in the given position or it would be accepted if a paragraph would be inserted.
        // Inserts the auto paragraph if it would allow for insertion.
        let isAllowed = this._checkAndAutoParagraphToAllowedPosition(node);
        if (!isAllowed) {
            // Split the position.parent's branch up to a point where the node can be inserted.
            // If it isn't allowed in the whole branch, then of course don't split anything.
            isAllowed = this._checkAndSplitToAllowedPosition(node);
            if (!isAllowed) {
                this._handleDisallowedNode(node);
                return;
            }
        }
        // Add node to the current temporary DocumentFragment.
        this._appendToFragment(node);
        // Store the first and last nodes for easy access for merging with sibling nodes.
        if (!this._firstNode) {
            this._firstNode = node;
        }
        this._lastNode = node;
    }
    /**
     * Inserts the temporary DocumentFragment into the model.
     */ _insertPartialFragment() {
        if (this._documentFragment.isEmpty) {
            return;
        }
        const livePosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromPosition(this.position, 'toNext');
        this._setAffectedBoundaries(this.position);
        // If the very first node of the whole insertion process is inserted, insert it separately for OT reasons (undo).
        // Note: there can be multiple calls to `_insertPartialFragment()` during one insertion process.
        // Note: only the very first node can be merged so we have to do separate operation only for it.
        if (this._documentFragment.getChild(0) == this._firstNode) {
            this.writer.insert(this._firstNode, this.position);
            // We must merge the first node just after inserting it to avoid problems with OT.
            // (See: https://github.com/ckeditor/ckeditor5/pull/8773#issuecomment-760945652).
            this._mergeOnLeft();
            this.position = livePosition.toPosition();
        }
        // Insert the remaining nodes from document fragment.
        if (!this._documentFragment.isEmpty) {
            this.writer.insert(this._documentFragment, this.position);
        }
        this._documentFragmentPosition = this.writer.createPositionAt(this._documentFragment, 0);
        this.position = livePosition.toPosition();
        livePosition.detach();
    }
    /**
     * @param node The object element.
     */ _handleObject(node) {
        // Try finding it a place in the tree.
        if (this._checkAndSplitToAllowedPosition(node)) {
            this._appendToFragment(node);
        } else {
            this._tryAutoparagraphing(node);
        }
    }
    /**
     * @param node The disallowed node which needs to be handled.
     */ _handleDisallowedNode(node) {
        // If the node is an element, try inserting its children (strip the parent).
        if (node.is('element')) {
            this.handleNodes(node.getChildren());
        } else {
            this._tryAutoparagraphing(node);
        }
    }
    /**
     * Append a node to the temporary DocumentFragment.
     *
     * @param node The node to insert.
     */ _appendToFragment(node) {
        /* istanbul ignore if -- @preserve */ if (!this.schema.checkChild(this.position, node)) {
            // Algorithm's correctness check. We should never end up here but it's good to know that we did.
            // Note that it would often be a silent issue if we insert node in a place where it's not allowed.
            /**
             * Given node cannot be inserted on the given position.
             *
             * @error insertcontent-wrong-position
             * @param node Node to insert.
             * @param position Position to insert the node at.
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('insertcontent-wrong-position', this, {
                node,
                position: this.position
            });
        }
        this.writer.insert(node, this._documentFragmentPosition);
        this._documentFragmentPosition = this._documentFragmentPosition.getShiftedBy(node.offsetSize);
        // The last inserted object should be selected because we can't put a collapsed selection after it.
        if (this.schema.isObject(node) && !this.schema.checkChild(this.position, '$text')) {
            this._nodeToSelect = node;
        } else {
            this._nodeToSelect = null;
        }
        this._filterAttributesOf.push(node);
    }
    /**
     * Sets `_affectedStart` and `_affectedEnd` to the given `position`. Should be used before a change is done during insertion process to
     * mark the affected range.
     *
     * This method is used before inserting a node or splitting a parent node. `_affectedStart` and `_affectedEnd` are also changed
     * during merging, but the logic there is more complicated so it is left out of this function.
     */ _setAffectedBoundaries(position) {
        // Set affected boundaries stickiness so that those position will "expand" when something is inserted in between them:
        // <paragraph>Foo][bar</paragraph> -> <paragraph>Foo]xx[bar</paragraph>
        // This is why it cannot be a range but two separate positions.
        if (!this._affectedStart) {
            this._affectedStart = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromPosition(position, 'toPrevious');
        }
        // If `_affectedEnd` is before the new boundary position, expand `_affectedEnd`. This can happen if first inserted node was
        // inserted into the parent but the next node is moved-out of that parent:
        // (1) <paragraph>Foo][</paragraph> -> <paragraph>Foo]xx[</paragraph>
        // (2) <paragraph>Foo]xx[</paragraph> -> <paragraph>Foo]xx</paragraph><widget></widget>[
        if (!this._affectedEnd || this._affectedEnd.isBefore(position)) {
            if (this._affectedEnd) {
                this._affectedEnd.detach();
            }
            this._affectedEnd = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromPosition(position, 'toNext');
        }
    }
    /**
     * Merges the previous sibling of the first node if it should be merged.
     *
     * After the content was inserted we may try to merge it with its siblings.
     * This should happen only if the selection was in those elements initially.
     */ _mergeOnLeft() {
        const node = this._firstNode;
        if (!(node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            return;
        }
        if (!this._canMergeLeft(node)) {
            return;
        }
        const mergePosLeft = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(node);
        mergePosLeft.stickiness = 'toNext';
        const livePosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromPosition(this.position, 'toNext');
        // If `_affectedStart` is sames as merge position, it means that the element "marked" by `_affectedStart` is going to be
        // removed and its contents will be moved. This won't transform `LivePosition` so `_affectedStart` needs to be moved
        // by hand to properly reflect affected range. (Due to `_affectedStart` and `_affectedEnd` stickiness, the "range" is
        // shown as `][`).
        //
        // Example - insert `<paragraph>Abc</paragraph><paragraph>Xyz</paragraph>` at the end of `<paragraph>Foo^</paragraph>`:
        //
        // <paragraph>Foo</paragraph><paragraph>Bar</paragraph>   -->
        // <paragraph>Foo</paragraph>]<paragraph>Abc</paragraph><paragraph>Xyz</paragraph>[<paragraph>Bar</paragraph>   -->
        // <paragraph>Foo]Abc</paragraph><paragraph>Xyz</paragraph>[<paragraph>Bar</paragraph>
        //
        // Note, that if we are here then something must have been inserted, so `_affectedStart` and `_affectedEnd` have to be set.
        if (this._affectedStart.isEqual(mergePosLeft)) {
            this._affectedStart.detach();
            this._affectedStart = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(mergePosLeft.nodeBefore, 'end', 'toPrevious');
        }
        // We need to update the references to the first and last nodes if they will be merged into the previous sibling node
        // because the reference would point to the removed node.
        //
        // <p>A^A</p> + <p>X</p>
        //
        // <p>A</p>^<p>A</p>
        // <p>A</p><p>X</p><p>A</p>
        // <p>AX</p><p>A</p>
        // <p>AXA</p>
        if (this._firstNode === this._lastNode) {
            this._firstNode = mergePosLeft.nodeBefore;
            this._lastNode = mergePosLeft.nodeBefore;
        }
        this.writer.merge(mergePosLeft);
        // If only one element (the merged one) is in the "affected range", also move the affected range end appropriately.
        //
        // Example - insert `<paragraph>Abc</paragraph>` at the of `<paragraph>Foo^</paragraph>`:
        //
        // <paragraph>Foo</paragraph><paragraph>Bar</paragraph>   -->
        // <paragraph>Foo</paragraph>]<paragraph>Abc</paragraph>[<paragraph>Bar</paragraph>   -->
        // <paragraph>Foo]Abc</paragraph>[<paragraph>Bar</paragraph>   -->
        // <paragraph>Foo]Abc[</paragraph><paragraph>Bar</paragraph>
        if (mergePosLeft.isEqual(this._affectedEnd) && this._firstNode === this._lastNode) {
            this._affectedEnd.detach();
            this._affectedEnd = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(mergePosLeft.nodeBefore, 'end', 'toNext');
        }
        this.position = livePosition.toPosition();
        livePosition.detach();
        // After merge elements that were marked by _insert() to be filtered might be gone so
        // we need to mark the new container.
        this._filterAttributesOf.push(this.position.parent);
        mergePosLeft.detach();
    }
    /**
     * Merges the next sibling of the last node if it should be merged.
     *
     * After the content was inserted we may try to merge it with its siblings.
     * This should happen only if the selection was in those elements initially.
     */ _mergeOnRight() {
        const node = this._lastNode;
        if (!(node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            return;
        }
        if (!this._canMergeRight(node)) {
            return;
        }
        const mergePosRight = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(node);
        mergePosRight.stickiness = 'toNext';
        /* istanbul ignore if -- @preserve */ if (!this.position.isEqual(mergePosRight)) {
            // Algorithm's correctness check. We should never end up here but it's good to know that we did.
            // At this point the insertion position should be after the node we'll merge. If it isn't,
            // it should need to be secured as in the left merge case.
            /**
             * An internal error occurred when merging inserted content with its siblings.
             * The insertion position should equal the merge position.
             *
             * If you encountered this error, report it back to the CKEditor 5 team
             * with as many details as possible regarding the content being inserted and the insertion position.
             *
             * @error insertcontent-invalid-insertion-position
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('insertcontent-invalid-insertion-position', this);
        }
        // Move the position to the previous node, so it isn't moved to the graveyard on merge.
        // <p>x</p>[]<p>y</p> => <p>x[]</p><p>y</p>
        this.position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(mergePosRight.nodeBefore, 'end');
        // Explanation of setting position stickiness to `'toPrevious'`:
        // OK:  <p>xx[]</p> + <p>yy</p> => <p>xx[]yy</p> (when sticks to previous)
        // NOK: <p>xx[]</p> + <p>yy</p> => <p>xxyy[]</p> (when sticks to next)
        const livePosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromPosition(this.position, 'toPrevious');
        // See comment in `_mergeOnLeft()` on moving `_affectedStart`.
        if (this._affectedEnd.isEqual(mergePosRight)) {
            this._affectedEnd.detach();
            this._affectedEnd = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(mergePosRight.nodeBefore, 'end', 'toNext');
        }
        // We need to update the references to the first and last nodes if they will be merged into the previous sibling node
        // because the reference would point to the removed node.
        //
        // <p>A^A</p> + <p>X</p>
        //
        // <p>A</p>^<p>A</p>
        // <p>A</p><p>X</p><p>A</p>
        // <p>AX</p><p>A</p>
        // <p>AXA</p>
        if (this._firstNode === this._lastNode) {
            this._firstNode = mergePosRight.nodeBefore;
            this._lastNode = mergePosRight.nodeBefore;
        }
        this.writer.merge(mergePosRight);
        // See comment in `_mergeOnLeft()` on moving `_affectedStart`.
        if (mergePosRight.getShiftedBy(-1).isEqual(this._affectedStart) && this._firstNode === this._lastNode) {
            this._affectedStart.detach();
            this._affectedStart = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liveposition$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(mergePosRight.nodeBefore, 0, 'toPrevious');
        }
        this.position = livePosition.toPosition();
        livePosition.detach();
        // After merge elements that were marked by _insert() to be filtered might be gone so
        // we need to mark the new container.
        this._filterAttributesOf.push(this.position.parent);
        mergePosRight.detach();
    }
    /**
     * Checks whether specified node can be merged with previous sibling element.
     *
     * @param node The node which could potentially be merged.
     */ _canMergeLeft(node) {
        const previousSibling = node.previousSibling;
        return previousSibling instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] && this.canMergeWith.has(previousSibling) && this.model.schema.checkMerge(previousSibling, node);
    }
    /**
     * Checks whether specified node can be merged with next sibling element.
     *
     * @param node The node which could potentially be merged.
     */ _canMergeRight(node) {
        const nextSibling = node.nextSibling;
        return nextSibling instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] && this.canMergeWith.has(nextSibling) && this.model.schema.checkMerge(node, nextSibling);
    }
    /**
     * Tries wrapping the node in a new paragraph and inserting it this way.
     *
     * @param node The node which needs to be autoparagraphed.
     */ _tryAutoparagraphing(node) {
        const paragraph = this.writer.createElement('paragraph');
        // Do not autoparagraph if the paragraph won't be allowed there,
        // cause that would lead to an infinite loop. The paragraph would be rejected in
        // the next _handleNode() call and we'd be here again.
        if (this._getAllowedIn(this.position.parent, paragraph) && this.schema.checkChild(paragraph, node)) {
            paragraph._appendChild(node);
            this._handleNode(paragraph);
        }
    }
    /**
     * Checks if a node can be inserted in the given position or it would be accepted if a paragraph would be inserted.
     * It also handles inserting the paragraph.
     *
     * @returns Whether an allowed position was found.
     * `false` is returned if the node isn't allowed at the current position or in auto paragraph, `true` if was.
     */ _checkAndAutoParagraphToAllowedPosition(node) {
        if (this.schema.checkChild(this.position.parent, node)) {
            return true;
        }
        // Do not auto paragraph if the paragraph won't be allowed there,
        // cause that would lead to an infinite loop. The paragraph would be rejected in
        // the next _handleNode() call and we'd be here again.
        if (!this.schema.checkChild(this.position.parent, 'paragraph') || !this.schema.checkChild('paragraph', node)) {
            return false;
        }
        // Insert nodes collected in temporary DocumentFragment if the position parent needs change to process further nodes.
        this._insertPartialFragment();
        // Insert a paragraph and move insertion position to it.
        const paragraph = this.writer.createElement('paragraph');
        this.writer.insert(paragraph, this.position);
        this._setAffectedBoundaries(this.position);
        this._lastAutoParagraph = paragraph;
        this.position = this.writer.createPositionAt(paragraph, 0);
        return true;
    }
    /**
     * @returns Whether an allowed position was found.
     * `false` is returned if the node isn't allowed at any position up in the tree, `true` if was.
     */ _checkAndSplitToAllowedPosition(node) {
        const allowedIn = this._getAllowedIn(this.position.parent, node);
        if (!allowedIn) {
            return false;
        }
        // Insert nodes collected in temporary DocumentFragment if the position parent needs change to process further nodes.
        if (allowedIn != this.position.parent) {
            this._insertPartialFragment();
        }
        while(allowedIn != this.position.parent){
            if (this.position.isAtStart) {
                // If insertion position is at the beginning of the parent, move it out instead of splitting.
                // <p>^Foo</p> -> ^<p>Foo</p>
                const parent = this.position.parent;
                this.position = this.writer.createPositionBefore(parent);
                // Special case – parent is empty (<p>^</p>).
                //
                // 1. parent.isEmpty
                // We can remove the element after moving insertion position out of it.
                //
                // 2. parent.parent === allowedIn
                // However parent should remain in place when allowed element is above limit element in document tree.
                // For example there shouldn't be allowed to remove empty paragraph from tableCell, when is pasted
                // content allowed in $root.
                if (parent.isEmpty && parent.parent === allowedIn) {
                    this.writer.remove(parent);
                }
            } else if (this.position.isAtEnd) {
                // If insertion position is at the end of the parent, move it out instead of splitting.
                // <p>Foo^</p> -> <p>Foo</p>^
                this.position = this.writer.createPositionAfter(this.position.parent);
            } else {
                const tempPos = this.writer.createPositionAfter(this.position.parent);
                this._setAffectedBoundaries(this.position);
                this.writer.split(this.position);
                this.position = tempPos;
                this.canMergeWith.add(this.position.nodeAfter);
            }
        }
        return true;
    }
    /**
     * Gets the element in which the given node is allowed. It checks the passed element and all its ancestors.
     *
     * @param contextElement The element in which context the node should be checked.
     * @param childNode The node to check.
     */ _getAllowedIn(contextElement, childNode) {
        if (this.schema.checkChild(contextElement, childNode)) {
            return contextElement;
        }
        // If the child wasn't allowed in the context element and the element is a limit there's no point in
        // checking any further towards the root. This is it: the limit is unsplittable and there's nothing
        // we can do about it. Without this check, the algorithm will analyze parent of the limit and may create
        // an illusion of the child being allowed. There's no way to insert it down there, though. It results in
        // infinite loops.
        if (this.schema.isLimit(contextElement)) {
            return null;
        }
        return this._getAllowedIn(contextElement.parent, childNode);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/insertobject.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "default",
    ()=>insertObject
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$first$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__first$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/first.js [app-ssr] (ecmascript) <export default as first>");
;
function insertObject(model, object, selectable, options = {}) {
    if (!model.schema.isObject(object)) {
        /**
         * Tried to insert an element with {@link module:engine/model/utils/insertobject insertObject()} function
         * that is not defined as an object in schema.
         * See {@link module:engine/model/schema~SchemaItemDefinition#isObject `SchemaItemDefinition`}.
         * If you want to insert content that is not an object you might want to use
         * {@link module:engine/model/utils/insertcontent insertContent()} function.
         * @error insertobject-element-not-an-object
         */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('insertobject-element-not-an-object', model, {
            object
        });
    }
    // Normalize selectable to a selection instance.
    const originalSelection = selectable ? selectable : model.document.selection;
    // Adjust the insertion selection.
    let insertionSelection = originalSelection;
    if (options.findOptimalPosition && model.schema.isBlock(object)) {
        insertionSelection = model.createSelection(model.schema.findOptimalInsertionRange(originalSelection, options.findOptimalPosition));
    }
    // Collect attributes to be copied on the inserted object.
    const firstSelectedBlock = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$first$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__first$3e$__["first"])(originalSelection.getSelectedBlocks());
    const attributesToCopy = {};
    if (firstSelectedBlock) {
        Object.assign(attributesToCopy, model.schema.getAttributesWithProperty(firstSelectedBlock, 'copyOnReplace', true));
    }
    return model.change((writer)=>{
        // Remove the selected content to find out what the parent of the inserted object would be.
        // It would be removed inside model.insertContent() anyway.
        if (!insertionSelection.isCollapsed) {
            model.deleteContent(insertionSelection, {
                doNotAutoparagraph: true
            });
        }
        let elementToInsert = object;
        const insertionPositionParent = insertionSelection.anchor.parent;
        // Autoparagraphing of an inline objects.
        if (!model.schema.checkChild(insertionPositionParent, object) && model.schema.checkChild(insertionPositionParent, 'paragraph') && model.schema.checkChild('paragraph', object)) {
            elementToInsert = writer.createElement('paragraph');
            writer.insert(object, elementToInsert);
        }
        // Apply attributes that are allowed on the inserted object (or paragraph if autoparagraphed).
        model.schema.setAllowedAttributes(elementToInsert, attributesToCopy, writer);
        // Insert the prepared content at the optionally adjusted selection.
        const affectedRange = model.insertContent(elementToInsert, insertionSelection);
        // Nothing got inserted.
        if (affectedRange.isCollapsed) {
            return affectedRange;
        }
        if (options.setSelection) {
            updateSelection(writer, object, options.setSelection, attributesToCopy);
        }
        return affectedRange;
    });
}
/**
 * Updates document selection based on given `place` parameter in relation to `contextElement` element.
 *
 * @param writer An instance of the model writer.
 * @param contextElement An element to set the attributes on.
 * @param place The place where selection should be set in relation to the `contextElement` element.
 * Value `on` will set selection on the passed `contextElement`. Value `after` will set selection after `contextElement`.
 * @param attributes Attributes keys and values to set on a paragraph that this function can create when
 * `place` parameter is equal to `after` but there is no element with `$text` node to set selection in.
 */ function updateSelection(writer, contextElement, place, paragraphAttributes) {
    const model = writer.model;
    if (place == 'on') {
        writer.setSelection(contextElement, 'on');
        return;
    }
    if (place != 'after') {
        /**
         * The unsupported `options.setSelection` parameter was passed
         * to the {@link module:engine/model/utils/insertobject insertObject()} function.
         * Check the {@link module:engine/model/utils/insertobject insertObject()} API documentation for allowed
         * `options.setSelection` parameter values.
         *
         * @error insertobject-invalid-place-parameter-value
         */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('insertobject-invalid-place-parameter-value', model);
    }
    let nextElement = contextElement.nextSibling;
    if (model.schema.isInline(contextElement)) {
        writer.setSelection(contextElement, 'after');
        return;
    }
    // Check whether an element next to the inserted element is defined and can contain a text.
    const canSetSelection = nextElement && model.schema.checkChild(nextElement, '$text');
    // If the element is missing, but a paragraph could be inserted next to the element, let's add it.
    if (!canSetSelection && model.schema.checkChild(contextElement.parent, 'paragraph')) {
        nextElement = writer.createElement('paragraph');
        model.schema.setAllowedAttributes(nextElement, paragraphAttributes, writer);
        model.insertContent(nextElement, writer.createPositionAfter(contextElement));
    }
    // Put the selection inside the element, at the beginning.
    if (nextElement) {
        writer.setSelection(nextElement, 0);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/modifyselection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/utils/modifyselection
 */ __turbopack_context__.s([
    "default",
    ()=>modifySelection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/treewalker.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$unicode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/unicode.js [app-ssr] (ecmascript)");
;
;
;
;
;
const wordBoundaryCharacters = ' ,.?!:;"-()';
function modifySelection(model, selection, options = {}) {
    const schema = model.schema;
    const isForward = options.direction != 'backward';
    const unit = options.unit ? options.unit : 'character';
    const treatEmojiAsSingleUnit = !!options.treatEmojiAsSingleUnit;
    const focus = selection.focus;
    const walker = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
        boundaries: getSearchRange(focus, isForward),
        singleCharacters: true,
        direction: isForward ? 'forward' : 'backward'
    });
    const data = {
        walker,
        schema,
        isForward,
        unit,
        treatEmojiAsSingleUnit
    };
    let next;
    while(next = walker.next()){
        if (next.done) {
            return;
        }
        const position = tryExtendingTo(data, next.value);
        if (position) {
            if (selection instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                model.change((writer)=>{
                    writer.setSelectionFocus(position);
                });
            } else {
                selection.setFocus(position);
            }
            return;
        }
    }
}
/**
 * Checks whether the selection can be extended to the the walker's next value (next position).
 */ function tryExtendingTo(data, value) {
    const { isForward, walker, unit, schema, treatEmojiAsSingleUnit } = data;
    const { type, item, nextPosition } = value;
    // If found text, we can certainly put the focus in it. Let's just find a correct position
    // based on the unit.
    if (type == 'text') {
        if (data.unit === 'word') {
            return getCorrectWordBreakPosition(walker, isForward);
        }
        return getCorrectPosition(walker, unit, treatEmojiAsSingleUnit);
    }
    // Entering an element.
    if (type == (isForward ? 'elementStart' : 'elementEnd')) {
        // If it's a selectable, we can select it now.
        if (schema.isSelectable(item)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(item, isForward ? 'after' : 'before');
        }
        // If text allowed on this position, extend to this place.
        if (schema.checkChild(nextPosition, '$text')) {
            return nextPosition;
        }
    } else {
        // If leaving a limit element, stop.
        if (schema.isLimit(item)) {
            // NOTE: Fast-forward the walker until the end.
            walker.skip(()=>true);
            return;
        }
        // If text allowed on this position, extend to this place.
        if (schema.checkChild(nextPosition, '$text')) {
            return nextPosition;
        }
    }
}
/**
 * Finds a correct position by walking in a text node and checking whether selection can be extended to given position
 * or should be extended further.
 */ function getCorrectPosition(walker, unit, treatEmojiAsSingleUnit) {
    const textNode = walker.position.textNode;
    if (textNode) {
        const data = textNode.data;
        let offset = walker.position.offset - textNode.startOffset;
        while((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$unicode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInsideSurrogatePair"])(data, offset) || unit == 'character' && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$unicode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInsideCombinedSymbol"])(data, offset) || treatEmojiAsSingleUnit && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$unicode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInsideEmojiSequence"])(data, offset)){
            walker.next();
            offset = walker.position.offset - textNode.startOffset;
        }
    }
    return walker.position;
}
/**
 * Finds a correct position of a word break by walking in a text node and checking whether selection can be extended to given position
 * or should be extended further.
 */ function getCorrectWordBreakPosition(walker, isForward) {
    let textNode = walker.position.textNode;
    if (!textNode) {
        textNode = isForward ? walker.position.nodeAfter : walker.position.nodeBefore;
    }
    while(textNode && textNode.is('$text')){
        const offset = walker.position.offset - textNode.startOffset;
        // Check of adjacent text nodes with different attributes (like BOLD).
        // Example          : 'foofoo []bar<$text bold="true">bar</$text> bazbaz'
        // should expand to : 'foofoo [bar<$text bold="true">bar</$text>] bazbaz'.
        if (isAtNodeBoundary(textNode, offset, isForward)) {
            textNode = isForward ? walker.position.nodeAfter : walker.position.nodeBefore;
        } else if (isAtWordBoundary(textNode.data, offset, isForward)) {
            break;
        } else {
            walker.next();
        }
    }
    return walker.position;
}
function getSearchRange(start, isForward) {
    const root = start.root;
    const searchEnd = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(root, isForward ? 'end' : 0);
    if (isForward) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, searchEnd);
    } else {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](searchEnd, start);
    }
}
/**
 * Checks if selection is on word boundary.
 */ function isAtWordBoundary(data, offset, isForward) {
    // The offset to check depends on direction.
    const offsetToCheck = offset + (isForward ? 0 : -1);
    return wordBoundaryCharacters.includes(data.charAt(offsetToCheck));
}
/**
 * Checks if selection is on node boundary.
 */ function isAtNodeBoundary(textNode, offset, isForward) {
    return offset === (isForward ? textNode.offsetSize : 0);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/model.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/model/model
 */ __turbopack_context__.s([
    "default",
    ()=>Model
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$batch$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/batch.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/document.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$markercollection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/markercollection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/selection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operationfactory$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/operationfactory.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$schema$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/schema.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$writer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/writer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/node.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$autoparagraphing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/autoparagraphing.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$selection$2d$post$2d$fixer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/selection-post-fixer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$deletecontent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/deletecontent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$getselectedcontent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/getselectedcontent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$insertcontent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/insertcontent.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$insertobject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/insertobject.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$modifyselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/modifyselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/observablemixin.js [app-ssr] (ecmascript) <export default as ObservableMixin>");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
class Model extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])() {
    // @if CK_DEBUG_ENGINE // private _operationLogs: Array<string>;
    // @if CK_DEBUG_ENGINE // private _appliedOperations: Array<Operation>;
    constructor(){
        super();
        this.markers = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$markercollection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        this.document = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this);
        this.schema = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$schema$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        this._pendingChanges = [];
        this._currentWriter = null;
        [
            'deleteContent',
            'modifySelection',
            'getSelectedContent',
            'applyOperation'
        ].forEach((methodName)=>this.decorate(methodName));
        // Adding operation validation with `highest` priority, so it is called before any other feature would like
        // to do anything with the operation. If the operation has incorrect parameters it should throw on the earliest occasion.
        this.on('applyOperation', (evt, args)=>{
            const operation = args[0];
            operation._validate();
        }, {
            priority: 'highest'
        });
        // Register some default abstract entities.
        this.schema.register('$root', {
            isLimit: true
        });
        this.schema.register('$container', {
            allowIn: [
                '$root',
                '$container'
            ]
        });
        this.schema.register('$block', {
            allowIn: [
                '$root',
                '$container'
            ],
            isBlock: true
        });
        this.schema.register('$blockObject', {
            allowWhere: '$block',
            isBlock: true,
            isObject: true
        });
        this.schema.register('$inlineObject', {
            allowWhere: '$text',
            allowAttributesOf: '$text',
            isInline: true,
            isObject: true
        });
        this.schema.register('$text', {
            allowIn: '$block',
            isInline: true,
            isContent: true
        });
        this.schema.register('$clipboardHolder', {
            allowContentOf: '$root',
            allowChildren: '$text',
            isLimit: true
        });
        this.schema.register('$documentFragment', {
            allowContentOf: '$root',
            allowChildren: '$text',
            isLimit: true
        });
        // An element needed by the `upcastElementToMarker` converter.
        // This element temporarily represents a marker boundary during the conversion process and is removed
        // at the end of the conversion. `UpcastDispatcher` or at least `Conversion` class looks like a
        // better place for this registration but both know nothing about `Schema`.
        this.schema.register('$marker');
        this.schema.addChildCheck((context, childDefinition)=>{
            if (childDefinition.name === '$marker') {
                return true;
            }
        });
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$selection$2d$post$2d$fixer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["injectSelectionPostFixer"])(this);
        // Post-fixer which takes care of adding empty paragraph elements to the empty roots.
        this.document.registerPostFixer(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$autoparagraphing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["autoParagraphEmptyRoots"]);
        // The base implementation for "decorated" method with remapped arguments.
        this.on('insertContent', (evt, [content, selectable])=>{
            evt.return = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$insertcontent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, content, selectable);
        });
        // The base implementation for "decorated" method with remapped arguments.
        this.on('insertObject', (evt, [element, selection, options])=>{
            evt.return = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$insertobject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, element, selection, options);
        });
        // The base implementation for "decorated" method with remapped arguments.
        this.on('canEditAt', (evt)=>{
            const canEditAt = !this.document.isReadOnly;
            evt.return = canEditAt;
            if (!canEditAt) {
                // Prevent further processing if the selection is at non-editable place.
                evt.stop();
            }
        });
    // @if CK_DEBUG_ENGINE // initDocumentDumping( this.document );
    // @if CK_DEBUG_ENGINE // this.on( 'applyOperation', () => {
    // @if CK_DEBUG_ENGINE // 	dumpTrees( this.document, this.document.version );
    // @if CK_DEBUG_ENGINE // }, { priority: 'lowest' } );
    // @if CK_DEBUG_ENGINE // this._operationLogs = [];
    // @if CK_DEBUG_ENGINE // this._appliedOperations = [];
    }
    /**
     * The `change()` method is the primary way of changing the model. You should use it to modify all document nodes
     * (including detached nodes – i.e. nodes not added to the {@link module:engine/model/model~Model#document model document}),
     * the {@link module:engine/model/document~Document#selection document's selection}, and
     * {@link module:engine/model/model~Model#markers model markers}.
     *
     * ```ts
     * model.change( writer => {
     * 	writer.insertText( 'foo', paragraph, 'end' );
     * } );
     * ```
     *
     * All changes inside the change block use the same {@link module:engine/model/batch~Batch} so they are combined
     * into a single undo step.
     *
     * ```ts
     * model.change( writer => {
     * 	writer.insertText( 'foo', paragraph, 'end' ); // foo.
     *
     * 	model.change( writer => {
     * 		writer.insertText( 'bar', paragraph, 'end' ); // foobar.
     * 	} );
     *
     * 	writer.insertText( 'bom', paragraph, 'end' ); // foobarbom.
     * } );
     * ```
     *
     * The callback of the `change()` block is executed synchronously.
     *
     * You can also return a value from the change block.
     *
     * ```ts
     * const img = model.change( writer => {
     * 	return writer.createElement( 'img' );
     * } );
     * ```
     *
     * @see #enqueueChange
     * @typeParam TReturn The return type of the provided callback.
     * @param callback Callback function which may modify the model.
     */ change(callback) {
        try {
            if (this._pendingChanges.length === 0) {
                // If this is the outermost block, create a new batch and start `_runPendingChanges` execution flow.
                this._pendingChanges.push({
                    batch: new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$batch$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](),
                    callback
                });
                return this._runPendingChanges()[0];
            } else {
                // If this is not the outermost block, just execute the callback.
                return callback(this._currentWriter);
            }
        } catch (err) {
            // @if CK_DEBUG // throw err;
            /* istanbul ignore next -- @preserve */ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"].rethrowUnexpectedError(err, this);
        }
    }
    enqueueChange(batchOrType, callback) {
        try {
            if (!batchOrType) {
                batchOrType = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$batch$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
            } else if (typeof batchOrType === 'function') {
                callback = batchOrType;
                batchOrType = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$batch$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
            } else if (!(batchOrType instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$batch$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
                batchOrType = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$batch$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](batchOrType);
            }
            this._pendingChanges.push({
                batch: batchOrType,
                callback
            });
            if (this._pendingChanges.length == 1) {
                this._runPendingChanges();
            }
        } catch (err) {
            // @if CK_DEBUG // throw err;
            /* istanbul ignore next -- @preserve */ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"].rethrowUnexpectedError(err, this);
        }
    }
    /**
     * {@link module:utils/observablemixin~Observable#decorate Decorated} function for applying
     * {@link module:engine/model/operation/operation~Operation operations} to the model.
     *
     * This is a low-level way of changing the model. It is exposed for very specific use cases (like the undo feature).
     * Normally, to modify the model, you will want to use {@link module:engine/model/writer~Writer `Writer`}.
     * See also {@glink framework/architecture/editing-engine#changing-the-model Changing the model} section
     * of the {@glink framework/architecture/editing-engine Editing architecture} guide.
     *
     * @param operation The operation to apply.
     */ applyOperation(operation) {
        // @if CK_DEBUG_ENGINE // console.log( 'Applying ' + operation );
        // @if CK_DEBUG_ENGINE // this._operationLogs.push( JSON.stringify( operation ) );
        // @if CK_DEBUG_ENGINE // this._appliedOperations.push( operation );
        operation._execute();
    }
    // @if CK_DEBUG_ENGINE // public getAppliedOperation(): string {
    // @if CK_DEBUG_ENGINE // 	if ( !this._appliedOperations ) {
    // @if CK_DEBUG_ENGINE // 		return '';
    // @if CK_DEBUG_ENGINE // 	}
    // @if CK_DEBUG_ENGINE // 	return this._appliedOperations.map( operation => JSON.stringify( operation ) ).join( '-------' );
    // @if CK_DEBUG_ENGINE // }
    // @if CK_DEBUG_ENGINE // public createReplayer( stringifiedOperations: string ): typeof OperationReplayer {
    // @if CK_DEBUG_ENGINE // 	return new OperationReplayer( this, '-------', stringifiedOperations );
    // @if CK_DEBUG_ENGINE // }
    /**
     * Inserts content at the position in the editor specified by the selection, as one would expect the paste
     * functionality to work.
     *
     * **Note**: If you want to insert an {@glink framework/deep-dive/schema#object-elements object element}
     * (e.g. a {@link module:widget/utils~toWidget widget}), see {@link #insertObject} instead.
     *
     * This is a high-level method. It takes the {@link #schema schema} into consideration when inserting
     * the content, clears the given selection's content before inserting nodes and moves the selection
     * to its target position at the end of the process.
     * It can split elements, merge them, wrap bare text nodes with paragraphs, etc. &ndash; just like the
     * pasting feature should do.
     *
     * For lower-level methods see {@link module:engine/model/writer~Writer `Writer`}.
     *
     * This method, unlike {@link module:engine/model/writer~Writer `Writer`}'s methods, does not have to be used
     * inside a {@link #change `change()` block}.
     *
     * # Conversion and schema
     *
     * Inserting elements and text nodes into the model is not enough to make CKEditor 5 render that content
     * to the user. CKEditor 5 implements a model-view-controller architecture and what `model.insertContent()` does
     * is only adding nodes to the model. Additionally, you need to define
     * {@glink framework/architecture/editing-engine#conversion converters} between the model and view
     * and define those nodes in the {@glink framework/architecture/editing-engine#schema schema}.
     *
     * So, while this method may seem similar to CKEditor 4 `editor.insertHtml()` (in fact, both methods
     * are used for paste-like content insertion), the CKEditor 5 method cannot be use to insert arbitrary HTML
     * unless converters are defined for all elements and attributes in that HTML.
     *
     * # Examples
     *
     * Using `insertContent()` with a manually created model structure:
     *
     * ```ts
     * // Let's create a document fragment containing such content as:
     * //
     * // <paragraph>foo</paragraph>
     * // <blockQuote>
     * //    <paragraph>bar</paragraph>
     * // </blockQuote>
     * const docFrag = editor.model.change( writer => {
     * 	const p1 = writer.createElement( 'paragraph' );
     * 	const p2 = writer.createElement( 'paragraph' );
     * 	const blockQuote = writer.createElement( 'blockQuote' );
     * 	const docFrag = writer.createDocumentFragment();
     *
     * 	writer.append( p1, docFrag );
     * 	writer.append( blockQuote, docFrag );
     * 	writer.append( p2, blockQuote );
     * 	writer.insertText( 'foo', p1 );
     * 	writer.insertText( 'bar', p2 );
     *
     * 	return docFrag;
     * } );
     *
     * // insertContent() does not have to be used in a change() block. It can, though,
     * // so this code could be moved to the callback defined above.
     * editor.model.insertContent( docFrag );
     * ```
     *
     * Using `insertContent()` with an HTML string converted to a model document fragment (similar to the pasting mechanism):
     *
     * ```ts
     * // You can create your own HtmlDataProcessor instance or use editor.data.processor
     * // if you have not overridden the default one (which is the HtmlDataProcessor instance).
     * const htmlDP = new HtmlDataProcessor( viewDocument );
     *
     * // Convert an HTML string to a view document fragment:
     * const viewFragment = htmlDP.toView( htmlString );
     *
     * // Convert the view document fragment to a model document fragment
     * // in the context of $root. This conversion takes the schema into
     * // account so if, for example, the view document fragment contained a bare text node,
     * // this text node cannot be a child of $root, so it will be automatically
     * // wrapped with a <paragraph>. You can define the context yourself (in the second parameter),
     * // and e.g. convert the content like it would happen in a <paragraph>.
     * // Note: The clipboard feature uses a custom context called $clipboardHolder
     * // which has a loosened schema.
     * const modelFragment = editor.data.toModel( viewFragment );
     *
     * editor.model.insertContent( modelFragment );
     * ```
     *
     * By default this method will use the document selection but it can also be used with a position, range or selection instance.
     *
     * ```ts
     * // Insert text at the current document selection position.
     * editor.model.change( writer => {
     * 	editor.model.insertContent( writer.createText( 'x' ) );
     * } );
     *
     * // Insert text at a given position - the document selection will not be modified.
     * editor.model.change( writer => {
     * 	editor.model.insertContent( writer.createText( 'x' ), doc.getRoot(), 2 );
     *
     * 	// Which is a shorthand for:
     * 	editor.model.insertContent( writer.createText( 'x' ), writer.createPositionAt( doc.getRoot(), 2 ) );
     * } );
     * ```
     *
     * If you want the document selection to be moved to the inserted content, use the
     * {@link module:engine/model/writer~Writer#setSelection `setSelection()`} method of the writer after inserting
     * the content:
     *
     * ```ts
     * editor.model.change( writer => {
     * 	const paragraph = writer.createElement( 'paragraph' );
     *
     * 	// Insert an empty paragraph at the beginning of the root.
     * 	editor.model.insertContent( paragraph, writer.createPositionAt( editor.model.document.getRoot(), 0 ) );
     *
     * 	// Move the document selection to the inserted paragraph.
     * 	writer.setSelection( paragraph, 'in' );
     * } );
     * ```
     *
     * If an instance of the {@link module:engine/model/selection~Selection model selection} is passed as `selectable`,
     * the new content will be inserted at the passed selection (instead of document selection):
     *
     * ```ts
     * editor.model.change( writer => {
     * 	// Create a selection in a paragraph that will be used as a place of insertion.
     * 	const selection = writer.createSelection( paragraph, 'in' );
     *
     * 	// Insert the new text at the created selection.
     * 	editor.model.insertContent( writer.createText( 'x' ), selection );
     *
     * 	// insertContent() modifies the passed selection instance so it can be used to set the document selection.
     * 	// Note: This is not necessary when you passed the document selection to insertContent().
     * 	writer.setSelection( selection );
     * } );
     * ```
     *
     * @fires insertContent
     * @param content The content to insert.
     * @param selectable The selection into which the content should be inserted.
     * If not provided the current model document selection will be used.
     * @param placeOrOffset To be used when a model item was passed as `selectable`.
     * This param defines a position in relation to that item.
     * at the insertion position.
     */ insertContent(content, selectable, placeOrOffset, ...rest) {
        const selection = normalizeSelectable(selectable, placeOrOffset);
        // Passing all call arguments so it acts like decorated method.
        return this.fire('insertContent', [
            content,
            selection,
            placeOrOffset,
            ...rest
        ]);
    }
    /**
     * Inserts an {@glink framework/deep-dive/schema#object-elements object element} at a specific position in the editor content.
     *
     * This is a high-level API:
     * * It takes the {@link #schema schema} into consideration,
     * * It clears the content of passed `selectable` before inserting,
     * * It can move the selection at the end of the process,
     * * It will copy the selected block's attributes to preserve them upon insertion,
     * * It can split elements or wrap inline objects with paragraphs if they are not allowed in target position,
     * * etc.
     *
     * # Notes
     *
     * * If you want to insert a non-object content, see {@link #insertContent} instead.
     * * For lower-level API, see {@link module:engine/model/writer~Writer `Writer`}.
     * * Unlike {@link module:engine/model/writer~Writer `Writer`}, this method does not have to be used inside
     * a {@link #change `change()` block}.
     * * Inserting object into the model is not enough to make CKEditor 5 render that content to the user.
     * CKEditor 5 implements a model-view-controller architecture and what `model.insertObject()` does
     * is only adding nodes to the model. Additionally, you need to define
     * {@glink framework/architecture/editing-engine#conversion converters} between the model and view
     * and define those nodes in the {@glink framework/architecture/editing-engine#schema schema}.
     *
     * # Examples
     *
     * Use the following code to insert an object at the current selection and keep the selection on the inserted element:
     *
     * ```ts
     * const rawHtmlEmbedElement = writer.createElement( 'rawHtml' );
     *
     * model.insertObject( rawHtmlEmbedElement, null, null, {
     * 	setSelection: 'on'
     * } );
     * ```
     *
     * Use the following code to insert an object at the current selection and nudge the selection after the inserted object:
     *
     * ```ts
     * const pageBreakElement = writer.createElement( 'pageBreak' );
     *
     * model.insertObject( pageBreakElement, null, null, {
     * 	setSelection: 'after'
     * } );
     * ```
     *
     * Use the following code to insert an object at the current selection and avoid splitting the content (non-destructive insertion):
     *
     * ```ts
     * const tableElement = writer.createElement( 'table' );
     *
     * model.insertObject( tableElement, null, null, {
     * 	findOptimalPosition: 'auto'
     * } );
     * ```
     *
     * Use the following code to insert an object at the specific range (also: replace the content of the range):
     *
     * ```ts
     * const tableElement = writer.createElement( 'table' );
     * const range = model.createRangeOn( model.document.getRoot().getChild( 1 ) );
     *
     * model.insertObject( tableElement, range );
     * ```
     *
     * @param element An object to be inserted into the model document.
     * @param selectable A selectable where the content should be inserted. If not specified, the current
     * {@link module:engine/model/document~Document#selection document selection} will be used instead.
     * @param placeOrOffset Specifies the exact place or offset for the insertion to take place, relative to `selectable`.
     * @param options Additional options.
     * @param options.findOptimalPosition An option that, when set, adjusts the insertion position (relative to
     * `selectable` and `placeOrOffset`) so that the content of `selectable` is not split upon insertion (a.k.a. non-destructive insertion).
     * * When `'auto'`, the algorithm will decide whether to insert the object before or after `selectable` to avoid content splitting.
     * * When `'before'`, the closest position before `selectable` will be used that will not result in content splitting.
     * * When `'after'`, the closest position after `selectable` will be used that will not result in content splitting.
     *
     * Note that this option only works for block objects. Inline objects are inserted into text and do not split blocks.
     * @param options.setSelection An option that, when set, moves the
     * {@link module:engine/model/document~Document#selection document selection} after inserting the object.
     * * When `'on'`, the document selection will be set on the inserted object.
     * * When `'after'`, the document selection will move to the closest text node after the inserted object. If there is no
     * such text node, a paragraph will be created and the document selection will be moved inside it.
     * at the insertion position.
     */ insertObject(element, selectable, placeOrOffset, options, ...rest) {
        const selection = normalizeSelectable(selectable, placeOrOffset);
        // Note that options are fired as 2 arguments for backward compatibility with the decorated method.
        // Passing all call arguments so it acts like decorated method.
        return this.fire('insertObject', [
            element,
            selection,
            options,
            options,
            ...rest
        ]);
    }
    /**
     * Deletes content of the selection and merge siblings. The resulting selection is always collapsed.
     *
     * **Note:** For the sake of predictability, the resulting selection should always be collapsed.
     * In cases where a feature wants to modify deleting behavior so selection isn't collapsed
     * (e.g. a table feature may want to keep row selection after pressing <kbd>Backspace</kbd>),
     * then that behavior should be implemented in the view's listener. At the same time, the table feature
     * will need to modify this method's behavior too, e.g. to "delete contents and then collapse
     * the selection inside the last selected cell" or "delete the row and collapse selection somewhere near".
     * That needs to be done in order to ensure that other features which use `deleteContent()` will work well with tables.
     *
     * @fires deleteContent
     * @param selection Selection of which the content should be deleted.
     * @param options.leaveUnmerged Whether to merge elements after removing the content of the selection.
     *
     * For example `<heading1>x[x</heading1><paragraph>y]y</paragraph>` will become:
     *
     * * `<heading1>x^y</heading1>` with the option disabled (`leaveUnmerged == false`)
     * * `<heading1>x^</heading1><paragraph>y</paragraph>` with enabled (`leaveUnmerged == true`).
     *
     * Note: {@link module:engine/model/schema~Schema#isObject object} and {@link module:engine/model/schema~Schema#isLimit limit}
     * elements will not be merged.
     *
     * @param options.doNotResetEntireContent Whether to skip replacing the entire content with a
     * paragraph when the entire content was selected.
     *
     * For example `<heading1>[x</heading1><paragraph>y]</paragraph>` will become:
     *
     * * `<paragraph>^</paragraph>` with the option disabled (`doNotResetEntireContent == false`)
     * * `<heading1>^</heading1>` with enabled (`doNotResetEntireContent == true`)
     *
     * @param options.doNotAutoparagraph Whether to create a paragraph if after content deletion selection is moved
     * to a place where text cannot be inserted.
     *
     * For example `<paragraph>x</paragraph>[<imageBlock src="foo.jpg"></imageBlock>]` will become:
     *
     * * `<paragraph>x</paragraph><paragraph>[]</paragraph>` with the option disabled (`doNotAutoparagraph == false`)
     * * `<paragraph>x[]</paragraph>` with the option enabled (`doNotAutoparagraph == true`).
     *
     * **Note:** if there is no valid position for the selection, the paragraph will always be created:
     *
     * `[<imageBlock src="foo.jpg"></imageBlock>]` -> `<paragraph>[]</paragraph>`.
     *
     * @param options.direction The direction in which the content is being consumed.
     * Deleting backward corresponds to using the <kbd>Backspace</kbd> key, while deleting content forward corresponds to
     * the <kbd>Shift</kbd>+<kbd>Backspace</kbd> keystroke.
     */ deleteContent(selection, options) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$deletecontent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, selection, options);
    }
    /**
     * Modifies the selection. Currently, the supported modifications are:
     *
     * * Extending. The selection focus is moved in the specified `options.direction` with a step specified in `options.unit`.
     * Possible values for `unit` are:
     *  * `'character'` (default) - moves selection by one user-perceived character. In most cases this means moving by one
     *  character in `String` sense. However, unicode also defines "combing marks". These are special symbols, that combines
     *  with a symbol before it ("base character") to create one user-perceived character. For example, `q̣̇` is a normal
     *  letter `q` with two "combining marks": upper dot (`Ux0307`) and lower dot (`Ux0323`). For most actions, i.e. extending
     *  selection by one position, it is correct to include both "base character" and all of it's "combining marks". That is
     *  why `'character'` value is most natural and common method of modifying selection.
     *  * `'codePoint'` - moves selection by one unicode code point. In contrary to, `'character'` unit, this will insert
     *  selection between "base character" and "combining mark", because "combining marks" have their own unicode code points.
     *  However, for technical reasons, unicode code points with values above `UxFFFF` are represented in native `String` by
     *  two characters, called "surrogate pairs". Halves of "surrogate pairs" have a meaning only when placed next to each other.
     *  For example `𨭎` is represented in `String` by `\uD862\uDF4E`. Both `\uD862` and `\uDF4E` do not have any meaning
     *  outside the pair (are rendered as ? when alone). Position between them would be incorrect. In this case, selection
     *  extension will include whole "surrogate pair".
     *  * `'word'` - moves selection by a whole word.
     *
     * **Note:** if you extend a forward selection in a backward direction you will in fact shrink it.
     *
     * @fires modifySelection
     * @param selection The selection to modify.
     * @param options.direction The direction in which the selection should be modified.
     * @param options.unit The unit by which selection should be modified.
     * @param options.treatEmojiAsSingleUnit Whether multi-characer emoji sequences should be handled as single unit.
     */ modifySelection(selection, options) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$modifyselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, selection, options);
    }
    /**
     * Gets a clone of the selected content.
     *
     * For example, for the following selection:
     *
     * ```html
     * <paragraph>x</paragraph>
     * <blockQuote>
     * 	<paragraph>y</paragraph>
     * 	<heading1>fir[st</heading1>
     * </blockQuote>
     * <paragraph>se]cond</paragraph>
     * <paragraph>z</paragraph>
     * ```
     *
     * It will return a document fragment with such a content:
     *
     * ```html
     * <blockQuote>
     * 	<heading1>st</heading1>
     * </blockQuote>
     * <paragraph>se</paragraph>
     * ```
     *
     * @fires getSelectedContent
     * @param selection The selection of which content will be returned.
     */ getSelectedContent(selection) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$getselectedcontent$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this, selection);
    }
    /**
     * Checks whether the given {@link module:engine/model/range~Range range} or
     * {@link module:engine/model/element~Element element} has any meaningful content.
     *
     * Meaningful content is:
     *
     * * any text node (`options.ignoreWhitespaces` allows controlling whether this text node must also contain
     * any non-whitespace characters),
     * * or any {@link module:engine/model/schema~Schema#isContent content element},
     * * or any {@link module:engine/model/markercollection~Marker marker} which
     * {@link module:engine/model/markercollection~Marker#_affectsData affects data}.
     *
     * This means that a range containing an empty `<paragraph></paragraph>` is not considered to have a meaningful content.
     * However, a range containing an `<imageBlock></imageBlock>` (which would normally be marked in the schema as an object element)
     * is considered non-empty.
     *
     * @param rangeOrElement Range or element to check.
     * @param options.ignoreWhitespaces Whether text node with whitespaces only should be considered empty.
     * @param options.ignoreMarkers Whether markers should be ignored.
     */ hasContent(rangeOrElement, options = {}) {
        const range = rangeOrElement instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] ? rangeOrElement : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(rangeOrElement);
        if (range.isCollapsed) {
            return false;
        }
        const { ignoreWhitespaces = false, ignoreMarkers = false } = options;
        // Check if there are any markers which affects data in this given range.
        if (!ignoreMarkers) {
            for (const intersectingMarker of this.markers.getMarkersIntersectingRange(range)){
                if (intersectingMarker.affectsData) {
                    return true;
                }
            }
        }
        for (const item of range.getItems()){
            if (this.schema.isContent(item)) {
                if (item.is('$textProxy')) {
                    if (!ignoreWhitespaces) {
                        return true;
                    } else if (item.data.search(/\S/) !== -1) {
                        return true;
                    }
                } else {
                    return true;
                }
            }
        }
        return false;
    }
    /**
     * Check whether given selectable is at a place in the model where it can be edited (returns `true`) or not (returns `false`).
     *
     * Should be used instead of {@link module:core/editor/editor~Editor#isReadOnly} to check whether a user action can happen at
     * given selectable. It may be decorated and used differently in different environment (e.g. multi-root editor can disable
     * a particular root).
     *
     * This method is decorated. Although this method accepts any parameter of `Selectable` type, the
     * {@link ~Model#event:canEditAt `canEditAt` event} is fired with `selectable` normalized to an instance of
     * {@link module:engine/model/selection~Selection} or {@link module:engine/model/documentselection~DocumentSelection}
     *
     * @fires canEditAt
     */ canEditAt(selectable) {
        const selection = normalizeSelectable(selectable);
        return this.fire('canEditAt', [
            selection
        ]);
    }
    /**
     * Creates a position from the given root and path in that root.
     *
     * Note: This method is also available as
     * {@link module:engine/model/writer~Writer#createPositionFromPath `Writer#createPositionFromPath()`}.
     *
     * @param root Root of the position.
     * @param path Position path. See {@link module:engine/model/position~Position#path}.
     * @param stickiness Position stickiness. See {@link module:engine/model/position~PositionStickiness}.
     */ createPositionFromPath(root, path, stickiness) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](root, path, stickiness);
    }
    /**
     * Creates position at the given location. The location can be specified as:
     *
     * * a {@link module:engine/model/position~Position position},
     * * a parent element and offset in that element,
     * * a parent element and `'end'` (the position will be set at the end of that element),
     * * a {@link module:engine/model/item~Item model item} and `'before'` or `'after'`
     * (the position will be set before or after the given model item).
     *
     * This method is a shortcut to other factory methods such as:
     *
     * * {@link module:engine/model/model~Model#createPositionBefore `createPositionBefore()`},
     * * {@link module:engine/model/model~Model#createPositionAfter `createPositionAfter()`}.
     *
     * Note: This method is also available as
     * {@link module:engine/model/writer~Writer#createPositionAt `Writer#createPositionAt()`},
     *
     * @param itemOrPosition
     * @param offset Offset or one of the flags. Used only when first parameter is a {@link module:engine/model/item~Item model item}.
     */ createPositionAt(itemOrPosition, offset) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(itemOrPosition, offset);
    }
    /**
     * Creates a new position after the given {@link module:engine/model/item~Item model item}.
     *
     * Note: This method is also available as
     * {@link module:engine/model/writer~Writer#createPositionAfter `Writer#createPositionAfter()`}.
     *
     * @param item Item after which the position should be placed.
     */ createPositionAfter(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(item);
    }
    /**
     * Creates a new position before the given {@link module:engine/model/item~Item model item}.
     *
     * Note: This method is also available as
     * {@link module:engine/model/writer~Writer#createPositionBefore `Writer#createPositionBefore()`}.
     *
     * @param item Item before which the position should be placed.
     */ createPositionBefore(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item);
    }
    /**
     * Creates a range spanning from the `start` position to the `end` position.
     *
     * Note: This method is also available as
     * {@link module:engine/model/writer~Writer#createRange `Writer#createRange()`}:
     *
     * ```ts
     * model.change( writer => {
     * 	const range = writer.createRange( start, end );
     * } );
     * ```
     *
     * @param start Start position.
     * @param end End position. If not set, the range will be collapsed to the `start` position.
     */ createRange(start, end) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end);
    }
    /**
     * Creates a range inside the given element which starts before the first child of
     * that element and ends after the last child of that element.
     *
     * Note: This method is also available as
     * {@link module:engine/model/writer~Writer#createRangeIn `Writer#createRangeIn()`}:
     *
     * ```ts
     * model.change( writer => {
     * 	const range = writer.createRangeIn( paragraph );
     * } );
     * ```
     *
     * @param element Element which is a parent for the range.
     */ createRangeIn(element) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(element);
    }
    /**
     * Creates a range that starts before the given {@link module:engine/model/item~Item model item} and ends after it.
     *
     * Note: This method is also available on `writer` instance as
     * {@link module:engine/model/writer~Writer#createRangeOn `Writer.createRangeOn()`}:
     *
     * ```ts
     * model.change( writer => {
     * 	const range = writer.createRangeOn( paragraph );
     * } );
     * ```
     *
     * @param item
     */ createRangeOn(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(item);
    }
    createSelection(...args) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](...args);
    }
    /**
     * Creates a {@link module:engine/model/batch~Batch} instance.
     *
     * **Note:** In most cases creating a batch instance is not necessary as they are created when using:
     *
     * * {@link #change `change()`},
     * * {@link #enqueueChange `enqueueChange()`}.
     *
     * @param type {@link module:engine/model/batch~Batch#constructor The type} of the batch.
     */ createBatch(type) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$batch$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](type);
    }
    /**
     * Creates an operation instance from a JSON object (parsed JSON string).
     *
     * This is an alias for {@link module:engine/model/operation/operationfactory~OperationFactory.fromJSON `OperationFactory.fromJSON()`}.
     *
     * @param json Deserialized JSON object.
     */ createOperationFromJSON(json) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$operationfactory$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].fromJSON(json, this.document);
    }
    /**
     * Removes all events listeners set by model instance and destroys {@link module:engine/model/document~Document}.
     */ destroy() {
        this.document.destroy();
        this.stopListening();
    }
    /**
     * Common part of {@link module:engine/model/model~Model#change} and {@link module:engine/model/model~Model#enqueueChange}
     * which calls callbacks and returns array of values returned by these callbacks.
     */ _runPendingChanges() {
        const ret = [];
        this.fire('_beforeChanges');
        try {
            while(this._pendingChanges.length){
                // Create a new writer using batch instance created for this chain of changes.
                const currentBatch = this._pendingChanges[0].batch;
                this._currentWriter = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$writer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this, currentBatch);
                // Execute changes callback and gather the returned value.
                const callbackReturnValue = this._pendingChanges[0].callback(this._currentWriter);
                ret.push(callbackReturnValue);
                this.document._handleChangeBlock(this._currentWriter);
                this._pendingChanges.shift();
                this._currentWriter = null;
            }
        } finally{
            this._pendingChanges.length = 0;
            this._currentWriter = null;
            this.fire('_afterChanges');
        }
        return ret;
    }
}
/**
 * Normalizes a selectable to a Selection or DocumentSelection.
 */ function normalizeSelectable(selectable, placeOrOffset) {
    if (!selectable) {
        return;
    }
    if (selectable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || selectable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        return selectable;
    }
    if (selectable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        if (placeOrOffset || placeOrOffset === 0) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selectable, placeOrOffset);
        } else if (selectable.is('rootElement')) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selectable, 'in');
        } else {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selectable, 'on');
        }
    }
    return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selectable);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/model.js [app-ssr] (ecmascript) <export default as Model>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Model",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$model$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/model.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/treewalker.js [app-ssr] (ecmascript) <export default as TreeWalker>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TreeWalker",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/treewalker.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript) <export default as Range>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Range",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liverange.js [app-ssr] (ecmascript) <export default as LiveRange>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LiveRange",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$liverange$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/liverange.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/nooperation.js [app-ssr] (ecmascript) <export default as NoOperation>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "NoOperation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/nooperation.js [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=e9609_%40ckeditor_ckeditor5-engine_src_model_55e39a79._.js.map