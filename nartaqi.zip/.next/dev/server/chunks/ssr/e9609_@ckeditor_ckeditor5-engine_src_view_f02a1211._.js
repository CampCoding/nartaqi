module.exports = [
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/placeholder.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/placeholder
 */ __turbopack_context__.s([
    "disablePlaceholder",
    ()=>disablePlaceholder,
    "enablePlaceholder",
    ()=>enablePlaceholder,
    "hidePlaceholder",
    ()=>hidePlaceholder,
    "needsPlaceholder",
    ()=>needsPlaceholder,
    "showPlaceholder",
    ()=>showPlaceholder
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript)");
;
;
// Each document stores information about its placeholder elements and check functions.
const documentPlaceholders = new WeakMap();
let hasDisplayedPlaceholderDeprecationWarning = false;
function enablePlaceholder({ view, element, text, isDirectHost = true, keepOnFocus = false }) {
    const doc = view.document;
    // Use a single a single post fixer per—document to update all placeholders.
    if (!documentPlaceholders.has(doc)) {
        documentPlaceholders.set(doc, new Map());
        // If a post-fixer callback makes a change, it should return `true` so other post–fixers
        // can re–evaluate the document again.
        doc.registerPostFixer((writer)=>updateDocumentPlaceholders(doc, writer));
        // Update placeholders on isComposing state change since rendering is disabled while in composition mode.
        doc.on('change:isComposing', ()=>{
            view.change((writer)=>updateDocumentPlaceholders(doc, writer));
        }, {
            priority: 'high'
        });
    }
    if (element.is('editableElement')) {
        element.on('change:placeholder', (evtInfo, evt, text)=>{
            setPlaceholder(text);
        });
    }
    if (element.placeholder) {
        setPlaceholder(element.placeholder);
    } else if (text) {
        setPlaceholder(text);
    }
    if (text) {
        showPlaceholderTextDeprecationWarning();
    }
    function setPlaceholder(text) {
        // Store information about the element placeholder under its document.
        documentPlaceholders.get(doc).set(element, {
            text,
            isDirectHost,
            keepOnFocus,
            hostElement: isDirectHost ? element : null
        });
        // Update the placeholders right away.
        view.change((writer)=>updateDocumentPlaceholders(doc, writer));
    }
}
function disablePlaceholder(view, element) {
    const doc = element.document;
    if (!documentPlaceholders.has(doc)) {
        return;
    }
    view.change((writer)=>{
        const placeholders = documentPlaceholders.get(doc);
        const config = placeholders.get(element);
        writer.removeAttribute('data-placeholder', config.hostElement);
        hidePlaceholder(writer, config.hostElement);
        placeholders.delete(element);
    });
}
function showPlaceholder(writer, element) {
    if (!element.hasClass('ck-placeholder')) {
        writer.addClass('ck-placeholder', element);
        return true;
    }
    return false;
}
function hidePlaceholder(writer, element) {
    if (element.hasClass('ck-placeholder')) {
        writer.removeClass('ck-placeholder', element);
        return true;
    }
    return false;
}
function needsPlaceholder(element, keepOnFocus) {
    if (!element.isAttached()) {
        return false;
    }
    // Anything but uiElement(s) counts as content.
    const hasContent = Array.from(element.getChildren()).some((element)=>!element.is('uiElement'));
    if (hasContent) {
        return false;
    }
    const doc = element.document;
    const viewSelection = doc.selection;
    const selectionAnchor = viewSelection.anchor;
    if (doc.isComposing && selectionAnchor && selectionAnchor.parent === element) {
        return false;
    }
    // Skip the focus check and make the placeholder visible already regardless of document focus state.
    if (keepOnFocus) {
        return true;
    }
    // If the document is blurred.
    if (!doc.isFocused) {
        return true;
    }
    // If document is focused and the element is empty but the selection is not anchored inside it.
    return !!selectionAnchor && selectionAnchor.parent !== element;
}
/**
 * Updates all placeholders associated with a document in a post–fixer callback.
 *
 * @returns True if any changes were made to the view document.
 */ function updateDocumentPlaceholders(doc, writer) {
    const placeholders = documentPlaceholders.get(doc);
    const directHostElements = [];
    let wasViewModified = false;
    // First set placeholders on the direct hosts.
    for (const [element, config] of placeholders){
        if (config.isDirectHost) {
            directHostElements.push(element);
            if (updatePlaceholder(writer, element, config)) {
                wasViewModified = true;
            }
        }
    }
    // Then set placeholders on the indirect hosts but only on those that does not already have an direct host placeholder.
    for (const [element, config] of placeholders){
        if (config.isDirectHost) {
            continue;
        }
        const hostElement = getChildPlaceholderHostSubstitute(element);
        // When not a direct host, it could happen that there is no child element
        // capable of displaying a placeholder.
        if (!hostElement) {
            continue;
        }
        // Don't override placeholder if the host element already has some direct placeholder.
        if (directHostElements.includes(hostElement)) {
            continue;
        }
        // Update the host element (used for setting and removing the placeholder).
        config.hostElement = hostElement;
        if (updatePlaceholder(writer, element, config)) {
            wasViewModified = true;
        }
    }
    return wasViewModified;
}
/**
 * Updates a single placeholder in a post–fixer callback.
 *
 * @returns True if any changes were made to the view document.
 */ function updatePlaceholder(writer, element, config) {
    const { text, isDirectHost, hostElement } = config;
    let wasViewModified = false;
    // This may be necessary when updating the placeholder text to something else.
    if (hostElement.getAttribute('data-placeholder') !== text) {
        writer.setAttribute('data-placeholder', text, hostElement);
        wasViewModified = true;
    }
    // If the host element is not a direct host then placeholder is needed only when there is only one element.
    const isOnlyChild = isDirectHost || element.childCount == 1;
    if (isOnlyChild && needsPlaceholder(hostElement, config.keepOnFocus)) {
        if (showPlaceholder(writer, hostElement)) {
            wasViewModified = true;
        }
    } else if (hidePlaceholder(writer, hostElement)) {
        wasViewModified = true;
    }
    return wasViewModified;
}
/**
 * Gets a child element capable of displaying a placeholder if a parent element can host more
 * than just text (for instance, when it is a root editable element). The child element
 * can then be used in other placeholder helpers as a substitute of its parent.
 */ function getChildPlaceholderHostSubstitute(parent) {
    if (parent.childCount) {
        const firstChild = parent.getChild(0);
        if (firstChild.is('element') && !firstChild.is('uiElement') && !firstChild.is('attributeElement')) {
            return firstChild;
        }
    }
    return null;
}
/**
 * Displays a deprecation warning message in the console, but only once per page load.
 */ function showPlaceholderTextDeprecationWarning() {
    if (!hasDisplayedPlaceholderDeprecationWarning) {
        /**
         * The "text" option in the {@link module:engine/view/placeholder~enablePlaceholder `enablePlaceholder()`}
         * function is deprecated and will be removed soon.
         *
         * See the {@glink updating/guides/update-to-39#view-element-placeholder Migration to v39} guide for
         * more information on how to apply this change.
         *
         * @error enableplaceholder-deprecated-text-option
         */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('enableplaceholder-deprecated-text-option');
    }
    hasDisplayedPlaceholderDeprecationWarning = true;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/typecheckable.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/typecheckable
 */ __turbopack_context__.s([
    "default",
    ()=>TypeCheckable
]);
class TypeCheckable {
    /* istanbul ignore next -- @preserve */ is() {
        // There are a lot of overloads above.
        // Overriding method in derived classes remove them and only `is( type: string ): boolean` is visible which we don't want.
        // One option would be to copy them all to all classes, but that's ugly.
        // It's best when TypeScript compiler doesn't see those overloads, except the one in the top base class.
        // To overload a method, but not let the compiler see it, do after class definition:
        // `MyClass.prototype.is = function( type: string ) {...}`
        throw new Error('is() method is abstract');
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/node.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/node
 */ __turbopack_context__.s([
    "default",
    ()=>Node
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/comparearrays.js [app-ssr] (ecmascript) <export default as compareArrays>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$clone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__clone$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/clone.js [app-ssr] (ecmascript) <export default as clone>");
;
;
;
class Node extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
    /**
     * Creates a tree view node.
     *
     * @param document The document instance to which this node belongs.
     */ constructor(document){
        super();
        this.document = document;
        this.parent = null;
    }
    /**
     * Index of the node in the parent element or null if the node has no parent.
     *
     * Accessing this property throws an error if this node's parent element does not contain it.
     * This means that view tree got broken.
     */ get index() {
        let pos;
        if (!this.parent) {
            return null;
        }
        // No parent or child doesn't exist in parent's children.
        if ((pos = this.parent.getChildIndex(this)) == -1) {
            /**
             * The node's parent does not contain this node. It means that the document tree is corrupted.
             *
             * @error view-node-not-found-in-parent
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-node-not-found-in-parent', this);
        }
        return pos;
    }
    /**
     * Node's next sibling, or `null` if it is the last child.
     */ get nextSibling() {
        const index = this.index;
        return index !== null && this.parent.getChild(index + 1) || null;
    }
    /**
     * Node's previous sibling, or `null` if it is the first child.
     */ get previousSibling() {
        const index = this.index;
        return index !== null && this.parent.getChild(index - 1) || null;
    }
    /**
     * Top-most ancestor of the node. If the node has no parent it is the root itself.
     */ get root() {
        // eslint-disable-next-line @typescript-eslint/no-this-alias, consistent-this
        let root = this;
        while(root.parent){
            root = root.parent;
        }
        return root;
    }
    /**
     * Returns true if the node is in a tree rooted in the document (is a descendant of one of its roots).
     */ isAttached() {
        return this.root.is('rootElement');
    }
    /**
     * Gets a path to the node. The path is an array containing indices of consecutive ancestors of this node,
     * beginning from {@link module:engine/view/node~Node#root root}, down to this node's index.
     *
     * ```ts
     * const abc = downcastWriter.createText( 'abc' );
     * const foo = downcastWriter.createText( 'foo' );
     * const h1 = downcastWriter.createElement( 'h1', null, downcastWriter.createText( 'header' ) );
     * const p = downcastWriter.createElement( 'p', null, [ abc, foo ] );
     * const div = downcastWriter.createElement( 'div', null, [ h1, p ] );
     * foo.getPath(); // Returns [ 1, 3 ]. `foo` is in `p` which is in `div`. `p` starts at offset 1, while `foo` at 3.
     * h1.getPath(); // Returns [ 0 ].
     * div.getPath(); // Returns [].
     * ```
     *
     * @returns The path.
     */ getPath() {
        const path = [];
        // eslint-disable-next-line @typescript-eslint/no-this-alias, consistent-this
        let node = this;
        while(node.parent){
            path.unshift(node.index);
            node = node.parent;
        }
        return path;
    }
    /**
     * Returns ancestors array of this node.
     *
     * @param options Options object.
     * @param options.includeSelf When set to `true` this node will be also included in parent's array.
     * @param options.parentFirst When set to `true`, array will be sorted from node's parent to root element,
     * otherwise root element will be the first item in the array.
     * @returns Array with ancestors.
     */ getAncestors(options = {}) {
        const ancestors = [];
        let parent = options.includeSelf ? this : this.parent;
        while(parent){
            ancestors[options.parentFirst ? 'push' : 'unshift'](parent);
            parent = parent.parent;
        }
        return ancestors;
    }
    /**
     * Returns a {@link module:engine/view/element~Element} or {@link module:engine/view/documentfragment~DocumentFragment}
     * which is a common ancestor of both nodes.
     *
     * @param node The second node.
     * @param options Options object.
     * @param options.includeSelf When set to `true` both nodes will be considered "ancestors" too.
     * Which means that if e.g. node A is inside B, then their common ancestor will be B.
     */ getCommonAncestor(node, options = {}) {
        const ancestorsA = this.getAncestors(options);
        const ancestorsB = node.getAncestors(options);
        let i = 0;
        while(ancestorsA[i] == ancestorsB[i] && ancestorsA[i]){
            i++;
        }
        return i === 0 ? null : ancestorsA[i - 1];
    }
    /**
     * Returns whether this node is before given node. `false` is returned if nodes are in different trees (for example,
     * in different {@link module:engine/view/documentfragment~DocumentFragment}s).
     *
     * @param node Node to compare with.
     */ isBefore(node) {
        // Given node is not before this node if they are same.
        if (this == node) {
            return false;
        }
        // Return `false` if it is impossible to compare nodes.
        if (this.root !== node.root) {
            return false;
        }
        const thisPath = this.getPath();
        const nodePath = node.getPath();
        const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(thisPath, nodePath);
        switch(result){
            case 'prefix':
                return true;
            case 'extension':
                return false;
            default:
                return thisPath[result] < nodePath[result];
        }
    }
    /**
     * Returns whether this node is after given node. `false` is returned if nodes are in different trees (for example,
     * in different {@link module:engine/view/documentfragment~DocumentFragment}s).
     *
     * @param node Node to compare with.
     */ isAfter(node) {
        // Given node is not before this node if they are same.
        if (this == node) {
            return false;
        }
        // Return `false` if it is impossible to compare nodes.
        if (this.root !== node.root) {
            return false;
        }
        // In other cases, just check if the `node` is before, and return the opposite.
        return !this.isBefore(node);
    }
    /**
     * Removes node from parent.
     *
     * @internal
     */ _remove() {
        this.parent._removeChildren(this.index);
    }
    /**
     * @internal
     * @param type Type of the change.
     * @param node Changed node.
     * @fires change
     */ _fireChange(type, node) {
        this.fire(`change:${type}`, node);
        if (this.parent) {
            this.parent._fireChange(type, node);
        }
    }
    /**
     * Custom toJSON method to solve child-parent circular dependencies.
     *
     * @returns Clone of this object with the parent property removed.
     */ toJSON() {
        const json = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$clone$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__clone$3e$__["clone"])(this);
        // Due to circular references we need to remove parent reference.
        delete json.parent;
        return json;
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Node.prototype.is = function(type) {
    return type === 'node' || type === 'view:node';
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/text
 */ __turbopack_context__.s([
    "default",
    ()=>Text
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/node.js [app-ssr] (ecmascript)");
;
class Text extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a tree view text node.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#createText
     * @internal
     * @param document The document instance to which this text node belongs.
     * @param data The text's data.
     */ constructor(document, data){
        super(document);
        this._textData = data;
    }
    /**
     * The text content.
     */ get data() {
        return this._textData;
    }
    /**
     * The `_data` property is controlled by a getter and a setter.
     *
     * The getter is required when using the addition assignment operator on protected property:
     *
     * ```ts
     * const foo = downcastWriter.createText( 'foo' );
     * const bar = downcastWriter.createText( 'bar' );
     *
     * foo._data += bar.data;   // executes: `foo._data = foo._data + bar.data`
     * console.log( foo.data ); // prints: 'foobar'
     * ```
     *
     * If the protected getter didn't exist, `foo._data` will return `undefined` and result of the merge will be invalid.
     *
     * The setter sets data and fires the {@link module:engine/view/node~Node#event:change:text change event}.
     *
     * @internal
     */ get _data() {
        return this.data;
    }
    set _data(data) {
        this._fireChange('text', this);
        this._textData = data;
    }
    /**
     * Checks if this text node is similar to other text node.
     * Both nodes should have the same data to be considered as similar.
     *
     * @param otherNode Node to check if it is same as this node.
     */ isSimilar(otherNode) {
        if (!(otherNode instanceof Text)) {
            return false;
        }
        return this === otherNode || this.data === otherNode.data;
    }
    /**
     * Clones this node.
     *
     * @internal
     * @returns Text node that is a clone of this node.
     */ _clone() {
        return new Text(this.document, this.data);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Text.prototype.is = function(type) {
    return type === '$text' || type === 'view:$text' || // This are legacy values kept for backward compatibility.
    type === 'text' || type === 'view:text' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
    type === 'node' || type === 'view:node';
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/textproxy.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/textproxy
 */ __turbopack_context__.s([
    "default",
    ()=>TextProxy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
class TextProxy extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a text proxy.
     *
     * @internal
     * @param textNode Text node which part is represented by this text proxy.
     * @param offsetInText Offset in {@link module:engine/view/textproxy~TextProxy#textNode text node}
     * from which the text proxy starts.
     * @param length Text proxy length, that is how many text node's characters, starting from `offsetInText` it represents.
     * @constructor
     */ constructor(textNode, offsetInText, length){
        super();
        this.textNode = textNode;
        if (offsetInText < 0 || offsetInText > textNode.data.length) {
            /**
             * Given offsetInText value is incorrect.
             *
             * @error view-textproxy-wrong-offsetintext
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-textproxy-wrong-offsetintext', this);
        }
        if (length < 0 || offsetInText + length > textNode.data.length) {
            /**
             * Given length value is incorrect.
             *
             * @error view-textproxy-wrong-length
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-textproxy-wrong-length', this);
        }
        this.data = textNode.data.substring(offsetInText, offsetInText + length);
        this.offsetInText = offsetInText;
    }
    /**
     * Offset size of this node.
     */ get offsetSize() {
        return this.data.length;
    }
    /**
     * Flag indicating whether `TextProxy` instance covers only part of the original {@link module:engine/view/text~Text text node}
     * (`true`) or the whole text node (`false`).
     *
     * This is `false` when text proxy starts at the very beginning of {@link module:engine/view/textproxy~TextProxy#textNode textNode}
     * ({@link module:engine/view/textproxy~TextProxy#offsetInText offsetInText} equals `0`) and text proxy sizes is equal to
     * text node size.
     */ get isPartial() {
        return this.data.length !== this.textNode.data.length;
    }
    /**
     * Parent of this text proxy, which is same as parent of text node represented by this text proxy.
     */ get parent() {
        return this.textNode.parent;
    }
    /**
     * Root of this text proxy, which is same as root of text node represented by this text proxy.
     */ get root() {
        return this.textNode.root;
    }
    /**
     * {@link module:engine/view/document~Document View document} that owns this text proxy, or `null` if the text proxy is inside
     * {@link module:engine/view/documentfragment~DocumentFragment document fragment}.
     */ get document() {
        return this.textNode.document;
    }
    /**
     * Returns ancestors array of this text proxy.
     *
     * @param options Options object.
     * @param options.includeSelf When set to `true`, textNode will be also included in parent's array.
     * @param options.parentFirst When set to `true`, array will be sorted from text proxy parent to
     * root element, otherwise root element will be the first item in the array.
     * @returns Array with ancestors.
     */ getAncestors(options = {}) {
        const ancestors = [];
        let parent = options.includeSelf ? this.textNode : this.parent;
        while(parent !== null){
            ancestors[options.parentFirst ? 'push' : 'unshift'](parent);
            parent = parent.parent;
        }
        return ancestors;
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
TextProxy.prototype.is = function(type) {
    return type === '$textProxy' || type === 'view:$textProxy' || // This are legacy values kept for backward compatibility.
    type === 'textProxy' || type === 'view:textProxy';
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/matcher.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "default",
    ()=>Matcher
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/isPlainObject.js [app-ssr] (ecmascript) <export default as isPlainObject>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript)");
;
;
class Matcher {
    /**
     * Creates new instance of Matcher.
     *
     * @param pattern Match patterns. See {@link module:engine/view/matcher~Matcher#add add method} for more information.
     */ constructor(...pattern){
        this._patterns = [];
        this.add(...pattern);
    }
    /**
     * Adds pattern or patterns to matcher instance.
     *
     * ```ts
     * // String.
     * matcher.add( 'div' );
     *
     * // Regular expression.
     * matcher.add( /^\w/ );
     *
     * // Single class.
     * matcher.add( {
     * 	classes: 'foobar'
     * } );
     * ```
     *
     * See {@link module:engine/view/matcher~MatcherPattern} for more examples.
     *
     * Multiple patterns can be added in one call:
     *
     * ```ts
     * matcher.add( 'div', { classes: 'foobar' } );
     * ```
     *
     * @param pattern Object describing pattern details. If string or regular expression
     * is provided it will be used to match element's name. Pattern can be also provided in a form
     * of a function - then this function will be called with each {@link module:engine/view/element~Element element} as a parameter.
     * Function's return value will be stored under `match` key of the object returned from
     * {@link module:engine/view/matcher~Matcher#match match} or {@link module:engine/view/matcher~Matcher#matchAll matchAll} methods.
     */ add(...pattern) {
        for (let item of pattern){
            // String or RegExp pattern is used as element's name.
            if (typeof item == 'string' || item instanceof RegExp) {
                item = {
                    name: item
                };
            }
            this._patterns.push(item);
        }
    }
    /**
     * Matches elements for currently stored patterns. Returns match information about first found
     * {@link module:engine/view/element~Element element}, otherwise returns `null`.
     *
     * Example of returned object:
     *
     * ```ts
     * {
     * 	element: <instance of found element>,
     * 	pattern: <pattern used to match found element>,
     * 	match: {
     * 		name: true,
     * 		attributes: [ 'title', 'href' ],
     * 		classes: [ 'foo' ],
     * 		styles: [ 'color', 'position' ]
     * 	}
     * }
     * ```
     *
     * @see module:engine/view/matcher~Matcher#add
     * @see module:engine/view/matcher~Matcher#matchAll
     * @param element View element to match against stored patterns.
     */ match(...element) {
        for (const singleElement of element){
            for (const pattern of this._patterns){
                const match = isElementMatching(singleElement, pattern);
                if (match) {
                    return {
                        element: singleElement,
                        pattern,
                        match
                    };
                }
            }
        }
        return null;
    }
    /**
     * Matches elements for currently stored patterns. Returns array of match information with all found
     * {@link module:engine/view/element~Element elements}. If no element is found - returns `null`.
     *
     * @see module:engine/view/matcher~Matcher#add
     * @see module:engine/view/matcher~Matcher#match
     * @param element View element to match against stored patterns.
     * @returns Array with match information about found elements or `null`. For more information
     * see {@link module:engine/view/matcher~Matcher#match match method} description.
     */ matchAll(...element) {
        const results = [];
        for (const singleElement of element){
            for (const pattern of this._patterns){
                const match = isElementMatching(singleElement, pattern);
                if (match) {
                    results.push({
                        element: singleElement,
                        pattern,
                        match
                    });
                }
            }
        }
        return results.length > 0 ? results : null;
    }
    /**
     * Returns the name of the element to match if there is exactly one pattern added to the matcher instance
     * and it matches element name defined by `string` (not `RegExp`). Otherwise, returns `null`.
     *
     * @returns Element name trying to match.
     */ getElementName() {
        if (this._patterns.length !== 1) {
            return null;
        }
        const pattern = this._patterns[0];
        const name = pattern.name;
        return typeof pattern != 'function' && name && !(name instanceof RegExp) ? name : null;
    }
}
/**
 * Returns match information if {@link module:engine/view/element~Element element} is matching provided pattern.
 * If element cannot be matched to provided pattern - returns `null`.
 *
 * @returns Returns object with match information or null if element is not matching.
 */ function isElementMatching(element, pattern) {
    // If pattern is provided as function - return result of that function;
    if (typeof pattern == 'function') {
        return pattern(element);
    }
    const match = {};
    // Check element's name.
    if (pattern.name) {
        match.name = matchName(pattern.name, element.name);
        if (!match.name) {
            return null;
        }
    }
    // Check element's attributes.
    if (pattern.attributes) {
        match.attributes = matchAttributes(pattern.attributes, element);
        if (!match.attributes) {
            return null;
        }
    }
    // Check element's classes.
    if (pattern.classes) {
        match.classes = matchClasses(pattern.classes, element);
        if (!match.classes) {
            return null;
        }
    }
    // Check element's styles.
    if (pattern.styles) {
        match.styles = matchStyles(pattern.styles, element);
        if (!match.styles) {
            return null;
        }
    }
    return match;
}
/**
 * Checks if name can be matched by provided pattern.
 *
 * @returns Returns `true` if name can be matched, `false` otherwise.
 */ function matchName(pattern, name) {
    // If pattern is provided as RegExp - test against this regexp.
    if (pattern instanceof RegExp) {
        return !!name.match(pattern);
    }
    return pattern === name;
}
/**
 * Checks if an array of key/value pairs can be matched against provided patterns.
 *
 * Patterns can be provided in a following ways:
 * - a boolean value matches any attribute with any value (or no value):
 *
 * ```ts
 * pattern: true
 * ```
 *
 * - a RegExp expression or object matches any attribute name:
 *
 * ```ts
 * pattern: /h[1-6]/
 * ```
 *
 * - an object matches any attribute that has the same name as the object item's key, where object item's value is:
 * 	- equal to `true`, which matches any attribute value:
 *
 * ```ts
 * pattern: {
 * 	required: true
 * }
 * ```
 *
 * 	- a string that is equal to attribute value:
 *
 * ```ts
 * pattern: {
 * 	rel: 'nofollow'
 * }
 * ```
 *
 * 	- a regular expression that matches attribute value,
 *
 * ```ts
 * pattern: {
 * 	src: /^https/
 * }
 * ```
 *
 * - an array with items, where the item is:
 * 	- a string that is equal to attribute value:
 *
 * ```ts
 * pattern: [ 'data-property-1', 'data-property-2' ],
 * ```
 *
 * 	- an object with `key` and `value` property, where `key` is a regular expression matching attribute name and
 * 		`value` is either regular expression matching attribute value or a string equal to attribute value:
 *
 * ```ts
 * pattern: [
 * 	{ key: /^data-property-/, value: true },
 * 	// or:
 * 	{ key: /^data-property-/, value: 'foobar' },
 * 	// or:
 * 	{ key: /^data-property-/, value: /^foo/ }
 * ]
 * ```
 *
 * @param patterns Object with information about attributes to match.
 * @param keys Attribute, style or class keys.
 * @param valueGetter A function providing value for a given item key.
 * @returns Returns array with matched attribute names or `null` if no attributes were matched.
 */ function matchPatterns(patterns, keys, valueGetter) {
    const normalizedPatterns = normalizePatterns(patterns);
    const normalizedItems = Array.from(keys);
    const match = [];
    normalizedPatterns.forEach(([patternKey, patternValue])=>{
        normalizedItems.forEach((itemKey)=>{
            if (isKeyMatched(patternKey, itemKey) && isValueMatched(patternValue, itemKey, valueGetter)) {
                match.push(itemKey);
            }
        });
    });
    // Return matches only if there are at least as many of them as there are patterns.
    // The RegExp pattern can match more than one item.
    if (!normalizedPatterns.length || match.length < normalizedPatterns.length) {
        return undefined;
    }
    return match;
}
/**
 * Bring all the possible pattern forms to an array of arrays where first item is a key and second is a value.
 *
 * Examples:
 *
 * Boolean pattern value:
 *
 * ```ts
 * true
 * ```
 *
 * to
 *
 * ```ts
 * [ [ true, true ] ]
 * ```
 *
 * Textual pattern value:
 *
 * ```ts
 * 'attribute-name-or-class-or-style'
 * ```
 *
 * to
 *
 * ```ts
 * [ [ 'attribute-name-or-class-or-style', true ] ]
 * ```
 *
 * Regular expression:
 *
 * ```ts
 * /^data-.*$/
 * ```
 *
 * to
 *
 * ```ts
 * [ [ /^data-.*$/, true ] ]
 * ```
 *
 * Objects (plain or with `key` and `value` specified explicitly):
 *
 * ```ts
 * {
 * 	src: /^https:.*$/
 * }
 * ```
 *
 * or
 *
 * ```ts
 * [ {
 * 	key: 'src',
 * 	value: /^https:.*$/
 * } ]
 * ```
 *
 * to:
 *
 * ```ts
 * [ [ 'src', /^https:.*$/ ] ]
 * ```
 *
 * @returns Returns an array of objects or null if provided patterns were not in an expected form.
 */ function normalizePatterns(patterns) {
    if (Array.isArray(patterns)) {
        return patterns.map((pattern)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__["isPlainObject"])(pattern)) {
                if (pattern.key === undefined || pattern.value === undefined) {
                    // Documented at the end of matcher.js.
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('matcher-pattern-missing-key-or-value', pattern);
                }
                return [
                    pattern.key,
                    pattern.value
                ];
            }
            // Assume the pattern is either String or RegExp.
            return [
                pattern,
                true
            ];
        });
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__["isPlainObject"])(patterns)) {
        return Object.entries(patterns);
    }
    // Other cases (true, string or regexp).
    return [
        [
            patterns,
            true
        ]
    ];
}
/**
 * @param patternKey A pattern representing a key we want to match.
 * @param itemKey An actual item key (e.g. `'src'`, `'background-color'`, `'ck-widget'`) we're testing against pattern.
 */ function isKeyMatched(patternKey, itemKey) {
    return patternKey === true || patternKey === itemKey || patternKey instanceof RegExp && itemKey.match(patternKey);
}
/**
 * @param patternValue A pattern representing a value we want to match.
 * @param itemKey An item key, e.g. `background`, `href`, 'rel', etc.
 * @param valueGetter A function used to provide a value for a given `itemKey`.
 */ function isValueMatched(patternValue, itemKey, valueGetter) {
    if (patternValue === true) {
        return true;
    }
    const itemValue = valueGetter(itemKey);
    // For now, the reducers are not returning the full tree of properties.
    // Casting to string preserves the old behavior until the root cause is fixed.
    // More can be found in https://github.com/ckeditor/ckeditor5/issues/10399.
    return patternValue === itemValue || patternValue instanceof RegExp && !!String(itemValue).match(patternValue);
}
/**
 * Checks if attributes of provided element can be matched against provided patterns.
 *
 * @param patterns Object with information about attributes to match. Each key of the object will be
 * used as attribute name. Value of each key can be a string or regular expression to match against attribute value.
 * @param  element Element which attributes will be tested.
 * @returns Returns array with matched attribute names or `null` if no attributes were matched.
 */ function matchAttributes(patterns, element) {
    const attributeKeys = new Set(element.getAttributeKeys());
    // `style` and `class` attribute keys are deprecated. Only allow them in object pattern
    // for backward compatibility.
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__["isPlainObject"])(patterns)) {
        if (patterns.style !== undefined) {
            // Documented at the end of matcher.js.
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('matcher-pattern-deprecated-attributes-style-key', patterns);
        }
        if (patterns.class !== undefined) {
            // Documented at the end of matcher.js.
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('matcher-pattern-deprecated-attributes-class-key', patterns);
        }
    } else {
        attributeKeys.delete('style');
        attributeKeys.delete('class');
    }
    return matchPatterns(patterns, attributeKeys, (key)=>element.getAttribute(key));
}
/**
 * Checks if classes of provided element can be matched against provided patterns.
 *
 * @param patterns Array of strings or regular expressions to match against element's classes.
 * @param element Element which classes will be tested.
 * @returns Returns array with matched class names or `null` if no classes were matched.
 */ function matchClasses(patterns, element) {
    // We don't need `getter` here because patterns for classes are always normalized to `[ className, true ]`.
    return matchPatterns(patterns, element.getClassNames(), /* istanbul ignore next -- @preserve */ ()=>{});
}
/**
 * Checks if styles of provided element can be matched against provided patterns.
 *
 * @param patterns Object with information about styles to match. Each key of the object will be
 * used as style name. Value of each key can be a string or regular expression to match against style value.
 * @param element Element which styles will be tested.
 * @returns Returns array with matched style names or `null` if no styles were matched.
 */ function matchStyles(patterns, element) {
    return matchPatterns(patterns, element.getStyleNames(true), (key)=>element.getStyle(key));
} /**
 * The key-value matcher pattern is missing key or value. Both must be present.
 * Refer the documentation: {@link module:engine/view/matcher~MatcherPattern}.
 *
 * @param pattern Pattern with missing properties.
 * @error matcher-pattern-missing-key-or-value
 */  /**
 * The key-value matcher pattern for `attributes` option is using deprecated `style` key.
 *
 * Use `styles` matcher pattern option instead:
 *
 * ```ts
 * // Instead of:
 * const pattern = {
 * 	attributes: {
 * 		key1: 'value1',
 * 		key2: 'value2',
 * 		style: /^border.*$/
 * 	}
 * }
 *
 * // Use:
 * const pattern = {
 * 	attributes: {
 * 		key1: 'value1',
 * 		key2: 'value2'
 * 	},
 * 	styles: /^border.*$/
 * }
 * ```
 *
 * Refer to the {@glink updating/guides/update-to-29##update-to-ckeditor-5-v2910 Migration to v29.1.0} guide
 * and {@link module:engine/view/matcher~MatcherPattern} documentation.
 *
 * @param pattern Pattern with missing properties.
 * @error matcher-pattern-deprecated-attributes-style-key
 */  /**
 * The key-value matcher pattern for `attributes` option is using deprecated `class` key.
 *
 * Use `classes` matcher pattern option instead:
 *
 * ```ts
 * // Instead of:
 * const pattern = {
 * 	attributes: {
 * 		key1: 'value1',
 * 		key2: 'value2',
 * 		class: 'foobar'
 * 	}
 * }
 *
 * // Use:
 * const pattern = {
 * 	attributes: {
 * 		key1: 'value1',
 * 		key2: 'value2'
 * 	},
 * 	classes: 'foobar'
 * }
 * ```
 *
 * Refer to the {@glink updating/guides/update-to-29##update-to-ckeditor-5-v2910 Migration to v29.1.0} guide
 * and the {@link module:engine/view/matcher~MatcherPattern} documentation.
 *
 * @param pattern Pattern with missing properties.
 * @error matcher-pattern-deprecated-attributes-class-key
 */ 
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/stylesmap.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/stylesmap
 */ __turbopack_context__.s([
    "StylesProcessor",
    ()=>StylesProcessor,
    "default",
    ()=>StylesMap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$get$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__get$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/get.js [app-ssr] (ecmascript) <export default as get>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isObject$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/isObject.js [app-ssr] (ecmascript) <export default as isObject>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$merge$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__merge$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/merge.js [app-ssr] (ecmascript) <export default as merge>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$set$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__set$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/set.js [app-ssr] (ecmascript) <export default as set>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$unset$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__unset$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/unset.js [app-ssr] (ecmascript) <export default as unset>");
;
class StylesMap {
    /**
     * Creates Styles instance.
     */ constructor(styleProcessor){
        this._styles = {};
        this._styleProcessor = styleProcessor;
    }
    /**
     * Returns true if style map has no styles set.
     */ get isEmpty() {
        const entries = Object.entries(this._styles);
        return !entries.length;
    }
    /**
     * Number of styles defined.
     */ get size() {
        if (this.isEmpty) {
            return 0;
        }
        return this.getStyleNames().length;
    }
    /**
     * Set styles map to a new value.
     *
     * ```ts
     * styles.setTo( 'border:1px solid blue;margin-top:1px;' );
     * ```
     */ setTo(inlineStyle) {
        this.clear();
        const parsedStyles = parseInlineStyles(inlineStyle);
        for (const [key, value] of parsedStyles){
            this._styleProcessor.toNormalizedForm(key, value, this._styles);
        }
    }
    /**
     * Checks if a given style is set.
     *
     * ```ts
     * styles.setTo( 'margin-left:1px;' );
     *
     * styles.has( 'margin-left' );    // -> true
     * styles.has( 'padding' );        // -> false
     * ```
     *
     * **Note**: This check supports normalized style names.
     *
     * ```ts
     * // Enable 'margin' shorthand processing:
     * editor.data.addStyleProcessorRules( addMarginRules );
     *
     * styles.setTo( 'margin:2px;' );
     *
     * styles.has( 'margin' );         // -> true
     * styles.has( 'margin-top' );     // -> true
     * styles.has( 'margin-left' );    // -> true
     *
     * styles.remove( 'margin-top' );
     *
     * styles.has( 'margin' );         // -> false
     * styles.has( 'margin-top' );     // -> false
     * styles.has( 'margin-left' );    // -> true
     * ```
     *
     * @param name Style name.
     */ has(name) {
        if (this.isEmpty) {
            return false;
        }
        const styles = this._styleProcessor.getReducedForm(name, this._styles);
        const propertyDescriptor = styles.find(([property])=>property === name);
        // Only return a value if it is set;
        return Array.isArray(propertyDescriptor);
    }
    set(nameOrObject, valueOrObject) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isObject$3e$__["isObject"])(nameOrObject)) {
            for (const [key, value] of Object.entries(nameOrObject)){
                this._styleProcessor.toNormalizedForm(key, value, this._styles);
            }
        } else {
            this._styleProcessor.toNormalizedForm(nameOrObject, valueOrObject, this._styles);
        }
    }
    /**
     * Removes given style.
     *
     * ```ts
     * styles.setTo( 'background:#f00;margin-right:2px;' );
     *
     * styles.remove( 'background' );
     *
     * styles.toString();   // -> 'margin-right:2px;'
     * ```
     *
     * ***Note**:* This method uses {@link module:engine/controller/datacontroller~DataController#addStyleProcessorRules
     * enabled style processor rules} to normalize passed values.
     *
     * ```ts
     * // Enable 'margin' shorthand processing:
     * editor.data.addStyleProcessorRules( addMarginRules );
     *
     * styles.setTo( 'margin:1px' );
     *
     * styles.remove( 'margin-top' );
     * styles.remove( 'margin-right' );
     *
     * styles.toString(); // -> 'margin-bottom:1px;margin-left:1px;'
     * ```
     *
     * @param name Style name.
     */ remove(name) {
        const path = toPath(name);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$unset$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__unset$3e$__["unset"])(this._styles, path);
        delete this._styles[name];
        this._cleanEmptyObjectsOnPath(path);
    }
    /**
     * Returns a normalized style object or a single value.
     *
     * ```ts
     * // Enable 'margin' shorthand processing:
     * editor.data.addStyleProcessorRules( addMarginRules );
     *
     * const styles = new Styles();
     * styles.setTo( 'margin:1px 2px 3em;' );
     *
     * styles.getNormalized( 'margin' );
     * // will log:
     * // {
     * //     top: '1px',
     * //     right: '2px',
     * //     bottom: '3em',
     * //     left: '2px'     // normalized value from margin shorthand
     * // }
     *
     * styles.getNormalized( 'margin-left' ); // -> '2px'
     * ```
     *
     * **Note**: This method will only return normalized styles if a style processor was defined.
     *
     * @param name Style name.
     */ getNormalized(name) {
        return this._styleProcessor.getNormalized(name, this._styles);
    }
    /**
     * Returns a normalized style string. Styles are sorted by name.
     *
     * ```ts
     * styles.set( 'margin' , '1px' );
     * styles.set( 'background', '#f00' );
     *
     * styles.toString(); // -> 'background:#f00;margin:1px;'
     * ```
     *
     * **Note**: This method supports normalized styles if defined.
     *
     * ```ts
     * // Enable 'margin' shorthand processing:
     * editor.data.addStyleProcessorRules( addMarginRules );
     *
     * styles.set( 'margin' , '1px' );
     * styles.set( 'background', '#f00' );
     * styles.remove( 'margin-top' );
     * styles.remove( 'margin-right' );
     *
     * styles.toString(); // -> 'background:#f00;margin-bottom:1px;margin-left:1px;'
     * ```
     */ toString() {
        if (this.isEmpty) {
            return '';
        }
        return this.getStylesEntries().map((arr)=>arr.join(':')).sort().join(';') + ';';
    }
    /**
     * Returns property as a value string or undefined if property is not set.
     *
     * ```ts
     * // Enable 'margin' shorthand processing:
     * editor.data.addStyleProcessorRules( addMarginRules );
     *
     * const styles = new Styles();
     * styles.setTo( 'margin:1px;' );
     * styles.set( 'margin-bottom', '3em' );
     *
     * styles.getAsString( 'margin' ); // -> 'margin: 1px 1px 3em;'
     * ```
     *
     * Note, however, that all sub-values must be set for the longhand property name to return a value:
     *
     * ```ts
     * const styles = new Styles();
     * styles.setTo( 'margin:1px;' );
     * styles.remove( 'margin-bottom' );
     *
     * styles.getAsString( 'margin' ); // -> undefined
     * ```
     *
     * In the above scenario, it is not possible to return a `margin` value, so `undefined` is returned.
     * Instead, you should use:
     *
     * ```ts
     * const styles = new Styles();
     * styles.setTo( 'margin:1px;' );
     * styles.remove( 'margin-bottom' );
     *
     * for ( const styleName of styles.getStyleNames() ) {
     * 	console.log( styleName, styles.getAsString( styleName ) );
     * }
     * // 'margin-top', '1px'
     * // 'margin-right', '1px'
     * // 'margin-left', '1px'
     * ```
     *
     * In general, it is recommend to iterate over style names like in the example above. This way, you will always get all
     * the currently set style values. So, if all the 4 margin values would be set
     * the for-of loop above would yield only `'margin'`, `'1px'`:
     *
     * ```ts
     * const styles = new Styles();
     * styles.setTo( 'margin:1px;' );
     *
     * for ( const styleName of styles.getStyleNames() ) {
     * 	console.log( styleName, styles.getAsString( styleName ) );
     * }
     * // 'margin', '1px'
     * ```
     *
     * **Note**: To get a normalized version of a longhand property use the {@link #getNormalized `#getNormalized()`} method.
     */ getAsString(propertyName) {
        if (this.isEmpty) {
            return;
        }
        if (this._styles[propertyName] && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isObject$3e$__["isObject"])(this._styles[propertyName])) {
            // Try return styles set directly - values that are not parsed.
            return this._styles[propertyName];
        }
        const styles = this._styleProcessor.getReducedForm(propertyName, this._styles);
        const propertyDescriptor = styles.find(([property])=>property === propertyName);
        // Only return a value if it is set;
        if (Array.isArray(propertyDescriptor)) {
            return propertyDescriptor[1];
        }
    }
    /**
     * Returns all style properties names as they would appear when using {@link #toString `#toString()`}.
     *
     * When `expand` is set to true and there's a shorthand style property set, it will also return all equivalent styles:
     *
     * ```ts
     * stylesMap.setTo( 'margin: 1em' )
     * ```
     *
     * will be expanded to:
     *
     * ```ts
     * [ 'margin', 'margin-top', 'margin-right', 'margin-bottom', 'margin-left' ]
     * ```
     *
     * @param expand Expand shorthand style properties and all return equivalent style representations.
     */ getStyleNames(expand = false) {
        if (this.isEmpty) {
            return [];
        }
        if (expand) {
            return this._styleProcessor.getStyleNames(this._styles);
        }
        const entries = this.getStylesEntries();
        return entries.map(([key])=>key);
    }
    /**
     * Removes all styles.
     */ clear() {
        this._styles = {};
    }
    /**
     * Returns normalized styles entries for further processing.
     */ getStylesEntries() {
        const parsed = [];
        const keys = Object.keys(this._styles);
        for (const key of keys){
            parsed.push(...this._styleProcessor.getReducedForm(key, this._styles));
        }
        return parsed;
    }
    /**
     * Removes empty objects upon removing an entry from internal object.
     */ _cleanEmptyObjectsOnPath(path) {
        const pathParts = path.split('.');
        const isChildPath = pathParts.length > 1;
        if (!isChildPath) {
            return;
        }
        const parentPath = pathParts.splice(0, pathParts.length - 1).join('.');
        const parentObject = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$get$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__get$3e$__["get"])(this._styles, parentPath);
        if (!parentObject) {
            return;
        }
        const isParentEmpty = !Object.keys(parentObject).length;
        if (isParentEmpty) {
            this.remove(parentPath);
        }
    }
}
class StylesProcessor {
    /**
     * Creates StylesProcessor instance.
     *
     * @internal
     */ constructor(){
        this._normalizers = new Map();
        this._extractors = new Map();
        this._reducers = new Map();
        this._consumables = new Map();
    }
    /**
     * Parse style string value to a normalized object and appends it to styles object.
     *
     * ```ts
     * const styles = {};
     *
     * stylesProcessor.toNormalizedForm( 'margin', '1px', styles );
     *
     * // styles will consist: { margin: { top: '1px', right: '1px', bottom: '1px', left: '1px; } }
     * ```
     *
     * **Note**: To define normalizer callbacks use {@link #setNormalizer}.
     *
     * @param name Name of style property.
     * @param propertyValue Value of style property.
     * @param styles Object holding normalized styles.
     */ toNormalizedForm(name, propertyValue, styles) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isObject$3e$__["isObject"])(propertyValue)) {
            appendStyleValue(styles, toPath(name), propertyValue);
            return;
        }
        if (this._normalizers.has(name)) {
            const normalizer = this._normalizers.get(name);
            const { path, value } = normalizer(propertyValue);
            appendStyleValue(styles, path, value);
        } else {
            appendStyleValue(styles, name, propertyValue);
        }
    }
    /**
     * Returns a normalized version of a style property.
     *
     * ```ts
     * const styles = {
     * 	margin: { top: '1px', right: '1px', bottom: '1px', left: '1px; },
     * 	background: { color: '#f00' }
     * };
     *
     * stylesProcessor.getNormalized( 'background' );
     * // will return: { color: '#f00' }
     *
     * stylesProcessor.getNormalized( 'margin-top' );
     * // will return: '1px'
     * ```
     *
     * **Note**: In some cases extracting single value requires defining an extractor callback {@link #setExtractor}.
     *
     * @param name Name of style property.
     * @param styles Object holding normalized styles.
     */ getNormalized(name, styles) {
        if (!name) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$merge$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__merge$3e$__["merge"])({}, styles);
        }
        // Might be empty string.
        if (styles[name] !== undefined) {
            return styles[name];
        }
        if (this._extractors.has(name)) {
            const extractor = this._extractors.get(name);
            if (typeof extractor === 'string') {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$get$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__get$3e$__["get"])(styles, extractor);
            }
            const value = extractor(name, styles);
            if (value) {
                return value;
            }
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$get$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__get$3e$__["get"])(styles, toPath(name));
    }
    /**
     * Returns a reduced form of style property form normalized object.
     *
     * For default margin reducer, the below code:
     *
     * ```ts
     * stylesProcessor.getReducedForm( 'margin', {
     * 	margin: { top: '1px', right: '1px', bottom: '2px', left: '1px; }
     * } );
     * ```
     *
     * will return:
     *
     * ```ts
     * [
     * 	[ 'margin', '1px 1px 2px' ]
     * ]
     * ```
     *
     * because it might be represented as a shorthand 'margin' value. However if one of margin long hand values is missing it should return:
     *
     * ```ts
     * [
     * 	[ 'margin-top', '1px' ],
     * 	[ 'margin-right', '1px' ],
     * 	[ 'margin-bottom', '2px' ]
     * 	// the 'left' value is missing - cannot use 'margin' shorthand.
     * ]
     * ```
     *
     * **Note**: To define reducer callbacks use {@link #setReducer}.
     *
     * @param name Name of style property.
     */ getReducedForm(name, styles) {
        const normalizedValue = this.getNormalized(name, styles);
        // Might be empty string.
        if (normalizedValue === undefined) {
            return [];
        }
        if (this._reducers.has(name)) {
            const reducer = this._reducers.get(name);
            return reducer(normalizedValue);
        }
        return [
            [
                name,
                normalizedValue
            ]
        ];
    }
    /**
     * Return all style properties. Also expand shorthand properties (e.g. `margin`, `background`) if respective extractor is available.
     *
     * @param styles Object holding normalized styles.
     */ getStyleNames(styles) {
        // Find all extractable styles that have a value.
        const expandedStyleNames = Array.from(this._consumables.keys()).filter((name)=>{
            const style = this.getNormalized(name, styles);
            if (style && typeof style == 'object') {
                return Object.keys(style).length;
            }
            return style;
        });
        // For simple styles (for example `color`) we don't have a map of those styles
        // but they are 1 to 1 with normalized object keys.
        const styleNamesKeysSet = new Set([
            ...expandedStyleNames,
            ...Object.keys(styles)
        ]);
        return Array.from(styleNamesKeysSet);
    }
    /**
     * Returns related style names.
     *
     * ```ts
     * stylesProcessor.getRelatedStyles( 'margin' );
     * // will return: [ 'margin-top', 'margin-right', 'margin-bottom', 'margin-left' ];
     *
     * stylesProcessor.getRelatedStyles( 'margin-top' );
     * // will return: [ 'margin' ];
     * ```
     *
     * **Note**: To define new style relations load an existing style processor or use
     * {@link module:engine/view/stylesmap~StylesProcessor#setStyleRelation `StylesProcessor.setStyleRelation()`}.
     */ getRelatedStyles(name) {
        return this._consumables.get(name) || [];
    }
    /**
     * Adds a normalizer method for a style property.
     *
     * A normalizer returns describing how the value should be normalized.
     *
     * For instance 'margin' style is a shorthand for four margin values:
     *
     * - 'margin-top'
     * - 'margin-right'
     * - 'margin-bottom'
     * - 'margin-left'
     *
     * and can be written in various ways if some values are equal to others. For instance `'margin: 1px 2em;'` is a shorthand for
     * `'margin-top: 1px;margin-right: 2em;margin-bottom: 1px;margin-left: 2em'`.
     *
     * A normalizer should parse various margin notations as a single object:
     *
     * ```ts
     * const styles = {
     * 	margin: {
     * 		top: '1px',
     * 		right: '2em',
     * 		bottom: '1px',
     * 		left: '2em'
     * 	}
     * };
     * ```
     *
     * Thus a normalizer for 'margin' style should return an object defining style path and value to store:
     *
     * ```ts
     * const returnValue = {
     * 	path: 'margin',
     * 	value: {
     * 		top: '1px',
     * 		right: '2em',
     * 		bottom: '1px',
     * 		left: '2em'
     * 	}
     * };
     * ```
     *
     * Additionally to fully support all margin notations there should be also defined 4 normalizers for longhand margin notations. Below
     * is an example for 'margin-top' style property normalizer:
     *
     * ```ts
     * stylesProcessor.setNormalizer( 'margin-top', valueString => {
     * 	return {
     * 		path: 'margin.top',
     * 		value: valueString
     * 	}
     * } );
     * ```
     */ setNormalizer(name, callback) {
        this._normalizers.set(name, callback);
    }
    /**
     * Adds a extractor callback for a style property.
     *
     * Most normalized style values are stored as one level objects. It is assumed that `'margin-top'` style will be stored as:
     *
     * ```ts
     * const styles = {
     * 	margin: {
     * 		top: 'value'
     * 	}
     * }
     * ```
     *
     * However, some styles can have conflicting notations and thus it might be harder to extract a style value from shorthand. For instance
     * the 'border-top-style' can be defined using `'border-top:solid'`, `'border-style:solid none none none'` or by `'border:solid'`
     * shorthands. The default border styles processors stores styles as:
     *
     * ```ts
     * const styles = {
     * 	border: {
     * 		style: {
     * 			top: 'solid'
     * 		}
     * 	}
     * }
     * ```
     *
     * as it is better to modify border style independently from other values. On the other part the output of the border might be
     * desired as `border-top`, `border-left`, etc notation.
     *
     * In the above example an extractor should return a side border value that combines style, color and width:
     *
     * ```ts
     * styleProcessor.setExtractor( 'border-top', styles => {
     * 	return {
     * 		color: styles.border.color.top,
     * 		style: styles.border.style.top,
     * 		width: styles.border.width.top
     * 	}
     * } );
     * ```
     *
     * @param callbackOrPath Callback that return a requested value or path string for single values.
     */ setExtractor(name, callbackOrPath) {
        this._extractors.set(name, callbackOrPath);
    }
    /**
     * Adds a reducer callback for a style property.
     *
     * Reducer returns a minimal notation for given style name. For longhand properties it is not required to write a reducer as
     * by default the direct value from style path is taken.
     *
     * For shorthand styles a reducer should return minimal style notation either by returning single name-value tuple or multiple tuples
     * if a shorthand cannot be used. For instance for a margin shorthand a reducer might return:
     *
     * ```ts
     * const marginShortHandTuple = [
     * 	[ 'margin', '1px 1px 2px' ]
     * ];
     * ```
     *
     * or a longhand tuples for defined values:
     *
     * ```ts
     * // Considering margin.bottom and margin.left are undefined.
     * const marginLonghandsTuples = [
     * 	[ 'margin-top', '1px' ],
     * 	[ 'margin-right', '1px' ]
     * ];
     * ```
     *
     * A reducer obtains a normalized style value:
     *
     * ```ts
     * // Simplified reducer that always outputs 4 values which are always present:
     * stylesProcessor.setReducer( 'margin', margin => {
     * 	return [
     * 		[ 'margin', `${ margin.top } ${ margin.right } ${ margin.bottom } ${ margin.left }` ]
     * 	]
     * } );
     * ```
     */ setReducer(name, callback) {
        this._reducers.set(name, callback);
    }
    /**
     * Defines a style shorthand relation to other style notations.
     *
     * ```ts
     * stylesProcessor.setStyleRelation( 'margin', [
     * 	'margin-top',
     * 	'margin-right',
     * 	'margin-bottom',
     * 	'margin-left'
     * ] );
     * ```
     *
     * This enables expanding of style names for shorthands. For instance, if defined,
     * {@link module:engine/conversion/viewconsumable~ViewConsumable view consumable} items are automatically created
     * for long-hand margin style notation alongside the `'margin'` item.
     *
     * This means that when an element being converted has a style `margin`, a converter for `margin-left` will work just
     * fine since the view consumable will contain a consumable `margin-left` item (thanks to the relation) and
     * `element.getStyle( 'margin-left' )` will work as well assuming that the style processor was correctly configured.
     * However, once `margin-left` is consumed, `margin` will not be consumable anymore.
     */ setStyleRelation(shorthandName, styleNames) {
        this._mapStyleNames(shorthandName, styleNames);
        for (const alsoName of styleNames){
            this._mapStyleNames(alsoName, [
                shorthandName
            ]);
        }
    }
    /**
     * Set two-way binding of style names.
     */ _mapStyleNames(name, styleNames) {
        if (!this._consumables.has(name)) {
            this._consumables.set(name, []);
        }
        this._consumables.get(name).push(...styleNames);
    }
}
/**
 * Parses inline styles and puts property - value pairs into styles map.
 *
 * @param stylesString Styles to parse.
 * @returns Map of parsed properties and values.
 */ function parseInlineStyles(stylesString) {
    // `null` if no quote was found in input string or last found quote was a closing quote. See below.
    let quoteType = null;
    let propertyNameStart = 0;
    let propertyValueStart = 0;
    let propertyName = null;
    const stylesMap = new Map();
    // Do not set anything if input string is empty.
    if (stylesString === '') {
        return stylesMap;
    }
    // Fix inline styles that do not end with `;` so they are compatible with algorithm below.
    if (stylesString.charAt(stylesString.length - 1) != ';') {
        stylesString = stylesString + ';';
    }
    // Seek the whole string for "special characters".
    for(let i = 0; i < stylesString.length; i++){
        const char = stylesString.charAt(i);
        if (quoteType === null) {
            // No quote found yet or last found quote was a closing quote.
            switch(char){
                case ':':
                    // Most of time colon means that property name just ended.
                    // Sometimes however `:` is found inside property value (for example in background image url).
                    if (!propertyName) {
                        // Treat this as end of property only if property name is not already saved.
                        // Save property name.
                        propertyName = stylesString.substr(propertyNameStart, i - propertyNameStart);
                        // Save this point as the start of property value.
                        propertyValueStart = i + 1;
                    }
                    break;
                case '"':
                case '\'':
                    // Opening quote found (this is an opening quote, because `quoteType` is `null`).
                    quoteType = char;
                    break;
                case ';':
                    {
                        // Property value just ended.
                        // Use previously stored property value start to obtain property value.
                        const propertyValue = stylesString.substr(propertyValueStart, i - propertyValueStart);
                        if (propertyName) {
                            // Save parsed part.
                            stylesMap.set(propertyName.trim(), propertyValue.trim());
                        }
                        propertyName = null;
                        // Save this point as property name start. Property name starts immediately after previous property value ends.
                        propertyNameStart = i + 1;
                        break;
                    }
            }
        } else if (char === quoteType) {
            // If a quote char is found and it is a closing quote, mark this fact by `null`-ing `quoteType`.
            quoteType = null;
        }
    }
    return stylesMap;
}
/**
 * Return lodash compatible path from style name.
 */ function toPath(name) {
    return name.replace('-', '.');
}
/**
 * Appends style definition to the styles object.
 */ function appendStyleValue(stylesObject, nameOrPath, valueOrObject) {
    let valueToSet = valueOrObject;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isObject$3e$__["isObject"])(valueOrObject)) {
        valueToSet = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$merge$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__merge$3e$__["merge"])({}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$get$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__get$3e$__["get"])(stylesObject, nameOrPath), valueOrObject);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$set$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__set$3e$__["set"])(stylesObject, nameOrPath, valueToSet);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/element
 */ __turbopack_context__.s([
    "default",
    ()=>Element
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/node.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/textproxy.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/isiterable.js [app-ssr] (ecmascript) <export default as isIterable>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/toarray.js [app-ssr] (ecmascript) <export default as toArray>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/tomap.js [app-ssr] (ecmascript) <export default as toMap>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/matcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/stylesmap.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
class Element extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a view element.
     *
     * Attributes can be passed in various formats:
     *
     * ```ts
     * new Element( viewDocument, 'div', { class: 'editor', contentEditable: 'true' } ); // object
     * new Element( viewDocument, 'div', [ [ 'class', 'editor' ], [ 'contentEditable', 'true' ] ] ); // map-like iterator
     * new Element( viewDocument, 'div', mapOfAttributes ); // map
     * ```
     *
     * @internal
     * @param document The document instance to which this element belongs.
     * @param name Node name.
     * @param attrs Collection of attributes.
     * @param children A list of nodes to be inserted into created element.
     */ constructor(document, name, attrs, children){
        super(document);
        /**
         * A list of attribute names that should be rendered in the editing pipeline even though filtering mechanisms
         * implemented in the {@link module:engine/view/domconverter~DomConverter} (for instance,
         * {@link module:engine/view/domconverter~DomConverter#shouldRenderAttribute}) would filter them out.
         *
         * These attributes can be specified as an option when the element is created by
         * the {@link module:engine/view/downcastwriter~DowncastWriter}. To check whether an unsafe an attribute should
         * be permitted, use the {@link #shouldRenderUnsafeAttribute} method.
         *
         * @internal
         */ this._unsafeAttributesToRender = [];
        /**
         * Map of custom properties.
         * Custom properties can be added to element instance, will be cloned but not rendered into DOM.
         */ this._customProperties = new Map();
        this.name = name;
        this._attrs = parseAttributes(attrs);
        this._children = [];
        if (children) {
            this._insertChild(0, children);
        }
        this._classes = new Set();
        if (this._attrs.has('class')) {
            // Remove class attribute and handle it by class set.
            const classString = this._attrs.get('class');
            parseClasses(this._classes, classString);
            this._attrs.delete('class');
        }
        this._styles = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document.stylesProcessor);
        if (this._attrs.has('style')) {
            // Remove style attribute and handle it by styles map.
            this._styles.setTo(this._attrs.get('style'));
            this._attrs.delete('style');
        }
    }
    /**
     * Number of element's children.
     */ get childCount() {
        return this._children.length;
    }
    /**
     * Is `true` if there are no nodes inside this element, `false` otherwise.
     */ get isEmpty() {
        return this._children.length === 0;
    }
    /**
     * Gets child at the given index.
     *
     * @param index Index of child.
     * @returns Child node.
     */ getChild(index) {
        return this._children[index];
    }
    /**
     * Gets index of the given child node. Returns `-1` if child node is not found.
     *
     * @param node Child node.
     * @returns Index of the child node.
     */ getChildIndex(node) {
        return this._children.indexOf(node);
    }
    /**
     * Gets child nodes iterator.
     *
     * @returns Child nodes iterator.
     */ getChildren() {
        return this._children[Symbol.iterator]();
    }
    /**
     * Returns an iterator that contains the keys for attributes. Order of inserting attributes is not preserved.
     *
     * @returns Keys for attributes.
     */ *getAttributeKeys() {
        if (this._classes.size > 0) {
            yield 'class';
        }
        if (!this._styles.isEmpty) {
            yield 'style';
        }
        yield* this._attrs.keys();
    }
    /**
     * Returns iterator that iterates over this element's attributes.
     *
     * Attributes are returned as arrays containing two items. First one is attribute key and second is attribute value.
     * This format is accepted by native `Map` object and also can be passed in `Node` constructor.
     */ *getAttributes() {
        yield* this._attrs.entries();
        if (this._classes.size > 0) {
            yield [
                'class',
                this.getAttribute('class')
            ];
        }
        if (!this._styles.isEmpty) {
            yield [
                'style',
                this.getAttribute('style')
            ];
        }
    }
    /**
     * Gets attribute by key. If attribute is not present - returns undefined.
     *
     * @param key Attribute key.
     * @returns Attribute value.
     */ getAttribute(key) {
        if (key == 'class') {
            if (this._classes.size > 0) {
                return [
                    ...this._classes
                ].join(' ');
            }
            return undefined;
        }
        if (key == 'style') {
            const inlineStyle = this._styles.toString();
            return inlineStyle == '' ? undefined : inlineStyle;
        }
        return this._attrs.get(key);
    }
    /**
     * Returns a boolean indicating whether an attribute with the specified key exists in the element.
     *
     * @param key Attribute key.
     * @returns `true` if attribute with the specified key exists in the element, `false` otherwise.
     */ hasAttribute(key) {
        if (key == 'class') {
            return this._classes.size > 0;
        }
        if (key == 'style') {
            return !this._styles.isEmpty;
        }
        return this._attrs.has(key);
    }
    /**
     * Checks if this element is similar to other element.
     * Both elements should have the same name and attributes to be considered as similar. Two similar elements
     * can contain different set of children nodes.
     */ isSimilar(otherElement) {
        if (!(otherElement instanceof Element)) {
            return false;
        }
        // If exactly the same Element is provided - return true immediately.
        if (this === otherElement) {
            return true;
        }
        // Check element name.
        if (this.name != otherElement.name) {
            return false;
        }
        // Check number of attributes, classes and styles.
        if (this._attrs.size !== otherElement._attrs.size || this._classes.size !== otherElement._classes.size || this._styles.size !== otherElement._styles.size) {
            return false;
        }
        // Check if attributes are the same.
        for (const [key, value] of this._attrs){
            if (!otherElement._attrs.has(key) || otherElement._attrs.get(key) !== value) {
                return false;
            }
        }
        // Check if classes are the same.
        for (const className of this._classes){
            if (!otherElement._classes.has(className)) {
                return false;
            }
        }
        // Check if styles are the same.
        for (const property of this._styles.getStyleNames()){
            if (!otherElement._styles.has(property) || otherElement._styles.getAsString(property) !== this._styles.getAsString(property)) {
                return false;
            }
        }
        return true;
    }
    /**
     * Returns true if class is present.
     * If more then one class is provided - returns true only when all classes are present.
     *
     * ```ts
     * element.hasClass( 'foo' ); // Returns true if 'foo' class is present.
     * element.hasClass( 'foo', 'bar' ); // Returns true if 'foo' and 'bar' classes are both present.
     * ```
     */ hasClass(...className) {
        for (const name of className){
            if (!this._classes.has(name)) {
                return false;
            }
        }
        return true;
    }
    /**
     * Returns iterator that contains all class names.
     */ getClassNames() {
        return this._classes.keys();
    }
    /**
     * Returns style value for the given property mae.
     * If the style does not exist `undefined` is returned.
     *
     * **Note**: This method can work with normalized style names if
     * {@link module:engine/controller/datacontroller~DataController#addStyleProcessorRules a particular style processor rule is enabled}.
     * See {@link module:engine/view/stylesmap~StylesMap#getAsString `StylesMap#getAsString()`} for details.
     *
     * For an element with style set to `'margin:1px'`:
     *
     * ```ts
     * // Enable 'margin' shorthand processing:
     * editor.data.addStyleProcessorRules( addMarginRules );
     *
     * const element = view.change( writer => {
     * 	const element = writer.createElement();
     * 	writer.setStyle( 'margin', '1px' );
     * 	writer.setStyle( 'margin-bottom', '3em' );
     *
     * 	return element;
     * } );
     *
     * element.getStyle( 'margin' ); // -> 'margin: 1px 1px 3em;'
     * ```
     */ getStyle(property) {
        return this._styles.getAsString(property);
    }
    /**
     * Returns a normalized style object or single style value.
     *
     * For an element with style set to: margin:1px 2px 3em;
     *
     * ```ts
     * element.getNormalizedStyle( 'margin' ) );
     * ```
     *
     * will return:
     *
     * ```ts
     * {
     * 	top: '1px',
     * 	right: '2px',
     * 	bottom: '3em',
     * 	left: '2px'    // a normalized value from margin shorthand
     * }
     * ```
     *
     * and reading for single style value:
     *
     * ```ts
     * styles.getNormalizedStyle( 'margin-left' );
     * ```
     *
     * Will return a `2px` string.
     *
     * **Note**: This method will return normalized values only if
     * {@link module:engine/controller/datacontroller~DataController#addStyleProcessorRules a particular style processor rule is enabled}.
     * See {@link module:engine/view/stylesmap~StylesMap#getNormalized `StylesMap#getNormalized()`} for details.
     *
     * @param property Name of CSS property
     */ getNormalizedStyle(property) {
        return this._styles.getNormalized(property);
    }
    /**
     * Returns iterator that contains all style names.
     *
     * @param expand Expand shorthand style properties and return all equivalent style representations.
     */ getStyleNames(expand) {
        return this._styles.getStyleNames(expand);
    }
    /**
     * Returns true if style keys are present.
     * If more then one style property is provided - returns true only when all properties are present.
     *
     * ```ts
     * element.hasStyle( 'color' ); // Returns true if 'border-top' style is present.
     * element.hasStyle( 'color', 'border-top' ); // Returns true if 'color' and 'border-top' styles are both present.
     * ```
     */ hasStyle(...property) {
        for (const name of property){
            if (!this._styles.has(name)) {
                return false;
            }
        }
        return true;
    }
    /**
     * Returns ancestor element that match specified pattern.
     * Provided patterns should be compatible with {@link module:engine/view/matcher~Matcher Matcher} as it is used internally.
     *
     * @see module:engine/view/matcher~Matcher
     * @param patterns Patterns used to match correct ancestor. See {@link module:engine/view/matcher~Matcher}.
     * @returns Found element or `null` if no matching ancestor was found.
     */ findAncestor(...patterns) {
        const matcher = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](...patterns);
        let parent = this.parent;
        while(parent && !parent.is('documentFragment')){
            if (matcher.match(parent)) {
                return parent;
            }
            parent = parent.parent;
        }
        return null;
    }
    /**
     * Returns the custom property value for the given key.
     */ getCustomProperty(key) {
        return this._customProperties.get(key);
    }
    /**
     * Returns an iterator which iterates over this element's custom properties.
     * Iterator provides `[ key, value ]` pairs for each stored property.
     */ *getCustomProperties() {
        yield* this._customProperties.entries();
    }
    /**
     * Returns identity string based on element's name, styles, classes and other attributes.
     * Two elements that {@link #isSimilar are similar} will have same identity string.
     * It has the following format:
     *
     * ```ts
     * 'name class="class1,class2" style="style1:value1;style2:value2" attr1="val1" attr2="val2"'
     * ```
     *
     * For example:
     *
     * ```ts
     * const element = writer.createContainerElement( 'foo', {
     * 	banana: '10',
     * 	apple: '20',
     * 	style: 'color: red; border-color: white;',
     * 	class: 'baz'
     * } );
     *
     * // returns 'foo class="baz" style="border-color:white;color:red" apple="20" banana="10"'
     * element.getIdentity();
     * ```
     *
     * **Note**: Classes, styles and other attributes are sorted alphabetically.
     */ getIdentity() {
        const classes = Array.from(this._classes).sort().join(',');
        const styles = this._styles.toString();
        const attributes = Array.from(this._attrs).map((i)=>`${i[0]}="${i[1]}"`).sort().join(' ');
        return this.name + (classes == '' ? '' : ` class="${classes}"`) + (!styles ? '' : ` style="${styles}"`) + (attributes == '' ? '' : ` ${attributes}`);
    }
    /**
     * Decides whether an unsafe attribute is whitelisted and should be rendered in the editing pipeline even though filtering mechanisms
     * like {@link module:engine/view/domconverter~DomConverter#shouldRenderAttribute} say it should not.
     *
     * Unsafe attribute names can be specified when creating an element via {@link module:engine/view/downcastwriter~DowncastWriter}.
     *
     * @param attributeName The name of the attribute to be checked.
     */ shouldRenderUnsafeAttribute(attributeName) {
        return this._unsafeAttributesToRender.includes(attributeName);
    }
    /**
     * Clones provided element.
     *
     * @internal
     * @param deep If set to `true` clones element and all its children recursively. When set to `false`,
     * element will be cloned without any children.
     * @returns Clone of this element.
     */ _clone(deep = false) {
        const childrenClone = [];
        if (deep) {
            for (const child of this.getChildren()){
                childrenClone.push(child._clone(deep));
            }
        }
        // ContainerElement and AttributeElement should be also cloned properly.
        const cloned = new this.constructor(this.document, this.name, this._attrs, childrenClone);
        // Classes and styles are cloned separately - this solution is faster than adding them back to attributes and
        // parse once again in constructor.
        cloned._classes = new Set(this._classes);
        cloned._styles.set(this._styles.getNormalized());
        // Clone custom properties.
        cloned._customProperties = new Map(this._customProperties);
        // Clone filler offset method.
        // We can't define this method in a prototype because it's behavior which
        // is changed by e.g. toWidget() function from ckeditor5-widget. Perhaps this should be one of custom props.
        cloned.getFillerOffset = this.getFillerOffset;
        // Clone unsafe attributes list.
        cloned._unsafeAttributesToRender = this._unsafeAttributesToRender;
        return cloned;
    }
    /**
     * {@link module:engine/view/element~Element#_insertChild Insert} a child node or a list of child nodes at the end of this node
     * and sets the parent of these nodes to this element.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#insert
     * @internal
     * @param items Items to be inserted.
     * @fires change
     * @returns Number of appended nodes.
     */ _appendChild(items) {
        return this._insertChild(this.childCount, items);
    }
    /**
     * Inserts a child node or a list of child nodes on the given index and sets the parent of these nodes to
     * this element.
     *
     * @internal
     * @see module:engine/view/downcastwriter~DowncastWriter#insert
     * @param index Position where nodes should be inserted.
     * @param items Items to be inserted.
     * @fires change
     * @returns Number of inserted nodes.
     */ _insertChild(index, items) {
        this._fireChange('children', this);
        let count = 0;
        const nodes = normalize(this.document, items);
        for (const node of nodes){
            // If node that is being added to this element is already inside another element, first remove it from the old parent.
            if (node.parent !== null) {
                node._remove();
            }
            node.parent = this;
            node.document = this.document;
            this._children.splice(index, 0, node);
            index++;
            count++;
        }
        return count;
    }
    /**
     * Removes number of child nodes starting at the given index and set the parent of these nodes to `null`.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#remove
     * @internal
     * @param index Number of the first node to remove.
     * @param howMany Number of nodes to remove.
     * @fires change
     * @returns The array of removed nodes.
     */ _removeChildren(index, howMany = 1) {
        this._fireChange('children', this);
        for(let i = index; i < index + howMany; i++){
            this._children[i].parent = null;
        }
        return this._children.splice(index, howMany);
    }
    /**
     * Adds or overwrite attribute with a specified key and value.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#setAttribute
     * @internal
     * @param key Attribute key.
     * @param value Attribute value.
     * @fires change
     */ _setAttribute(key, value) {
        const stringValue = String(value);
        this._fireChange('attributes', this);
        if (key == 'class') {
            parseClasses(this._classes, stringValue);
        } else if (key == 'style') {
            this._styles.setTo(stringValue);
        } else {
            this._attrs.set(key, stringValue);
        }
    }
    /**
     * Removes attribute from the element.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#removeAttribute
     * @internal
     * @param key Attribute key.
     * @returns Returns true if an attribute existed and has been removed.
     * @fires change
     */ _removeAttribute(key) {
        this._fireChange('attributes', this);
        // Remove class attribute.
        if (key == 'class') {
            if (this._classes.size > 0) {
                this._classes.clear();
                return true;
            }
            return false;
        }
        // Remove style attribute.
        if (key == 'style') {
            if (!this._styles.isEmpty) {
                this._styles.clear();
                return true;
            }
            return false;
        }
        // Remove other attributes.
        return this._attrs.delete(key);
    }
    /**
     * Adds specified class.
     *
     * ```ts
     * element._addClass( 'foo' ); // Adds 'foo' class.
     * element._addClass( [ 'foo', 'bar' ] ); // Adds 'foo' and 'bar' classes.
     * ```
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#addClass
     * @internal
     * @fires change
     */ _addClass(className) {
        this._fireChange('attributes', this);
        for (const name of (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(className)){
            this._classes.add(name);
        }
    }
    /**
     * Removes specified class.
     *
     * ```ts
     * element._removeClass( 'foo' );  // Removes 'foo' class.
     * element._removeClass( [ 'foo', 'bar' ] ); // Removes both 'foo' and 'bar' classes.
     * ```
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#removeClass
     * @internal
     * @fires change
     */ _removeClass(className) {
        this._fireChange('attributes', this);
        for (const name of (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(className)){
            this._classes.delete(name);
        }
    }
    _setStyle(property, value) {
        this._fireChange('attributes', this);
        if (typeof property != 'string') {
            this._styles.set(property);
        } else {
            this._styles.set(property, value);
        }
    }
    /**
     * Removes specified style.
     *
     * ```ts
     * element._removeStyle( 'color' );  // Removes 'color' style.
     * element._removeStyle( [ 'color', 'border-top' ] ); // Removes both 'color' and 'border-top' styles.
     * ```
     *
     * **Note**: This method can work with normalized style names if
     * {@link module:engine/controller/datacontroller~DataController#addStyleProcessorRules a particular style processor rule is enabled}.
     * See {@link module:engine/view/stylesmap~StylesMap#remove `StylesMap#remove()`} for details.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#removeStyle
     * @internal
     * @fires change
     */ _removeStyle(property) {
        this._fireChange('attributes', this);
        for (const name of (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(property)){
            this._styles.remove(name);
        }
    }
    /**
     * Sets a custom property. Unlike attributes, custom properties are not rendered to the DOM,
     * so they can be used to add special data to elements.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#setCustomProperty
     * @internal
     */ _setCustomProperty(key, value) {
        this._customProperties.set(key, value);
    }
    /**
     * Removes the custom property stored under the given key.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#removeCustomProperty
     * @internal
     * @returns Returns true if property was removed.
     */ _removeCustomProperty(key) {
        return this._customProperties.delete(key);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Element.prototype.is = function(type, name) {
    if (!name) {
        return type === 'element' || type === 'view:element' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'node' || type === 'view:node';
    } else {
        return name === this.name && (type === 'element' || type === 'view:element');
    }
};
/**
 * Parses attributes provided to the element constructor before they are applied to an element. If attributes are passed
 * as an object (instead of `Iterable`), the object is transformed to the map. Attributes with `null` value are removed.
 * Attributes with non-`String` value are converted to `String`.
 *
 * @param attrs Attributes to parse.
 * @returns Parsed attributes.
 */ function parseAttributes(attrs) {
    const attrsMap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$tomap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toMap$3e$__["toMap"])(attrs);
    for (const [key, value] of attrsMap){
        if (value === null) {
            attrsMap.delete(key);
        } else if (typeof value != 'string') {
            attrsMap.set(key, String(value));
        }
    }
    return attrsMap;
}
/**
 * Parses class attribute and puts all classes into classes set.
 * Classes set s cleared before insertion.
 *
 * @param classesSet Set to insert parsed classes.
 * @param classesString String with classes to parse.
 */ function parseClasses(classesSet, classesString) {
    const classArray = classesString.split(/\s+/);
    classesSet.clear();
    classArray.forEach((name)=>classesSet.add(name));
}
/**
 * Converts strings to Text and non-iterables to arrays.
 */ function normalize(document, nodes) {
    // Separate condition because string is iterable.
    if (typeof nodes == 'string') {
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](document, nodes)
        ];
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__["isIterable"])(nodes)) {
        nodes = [
            nodes
        ];
    }
    // Array.from to enable .map() on non-arrays.
    return Array.from(nodes).map((node)=>{
        if (typeof node == 'string') {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](document, node);
        }
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](document, node.data);
        }
        return node;
    });
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/containerelement.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/containerelement
 */ __turbopack_context__.s([
    "default",
    ()=>ContainerElement,
    "getFillerOffset",
    ()=>getFillerOffset
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
;
class ContainerElement extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a container element.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#createContainerElement
     * @see module:engine/view/element~Element
     * @internal
     * @param document The document instance to which this element belongs.
     * @param name Node name.
     * @param attrs Collection of attributes.
     * @param children A list of nodes to be inserted into created element.
     */ constructor(document, name, attrs, children){
        super(document, name, attrs, children);
        this.getFillerOffset = getFillerOffset;
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
ContainerElement.prototype.is = function(type, name) {
    if (!name) {
        return type === 'containerElement' || type === 'view:containerElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'element' || type === 'view:element' || type === 'node' || type === 'view:node';
    } else {
        return name === this.name && (type === 'containerElement' || type === 'view:containerElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'element' || type === 'view:element');
    }
};
function getFillerOffset() {
    const children = [
        ...this.getChildren()
    ];
    const lastChild = children[this.childCount - 1];
    // Block filler is required after a `<br>` if it's the last element in its container. See #1422.
    if (lastChild && lastChild.is('element', 'br')) {
        return this.childCount;
    }
    for (const child of children){
        // If there's any non-UI element – don't render the bogus.
        if (!child.is('uiElement')) {
            return null;
        }
    }
    // If there are only UI elements – render the bogus at the end of the element.
    return this.childCount;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/editableelement.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/editableelement
 */ __turbopack_context__.s([
    "default",
    ()=>EditableElement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/containerelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/observablemixin.js [app-ssr] (ecmascript) <export default as ObservableMixin>");
;
;
class EditableElement extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
    /**
     * Creates an editable element.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#createEditableElement
     * @internal
     * @param document The document instance to which this element belongs.
     * @param name Node name.
     * @param attrs Collection of attributes.
     * @param children A list of nodes to be inserted into created element.
     */ constructor(document, name, attributes, children){
        super(document, name, attributes, children);
        this.set('isReadOnly', false);
        this.set('isFocused', false);
        this.set('placeholder', undefined);
        this.bind('isReadOnly').to(document);
        this.bind('isFocused').to(document, 'isFocused', (isFocused)=>isFocused && document.selection.editableElement == this);
        // Update focus state based on selection changes.
        this.listenTo(document.selection, 'change', ()=>{
            this.isFocused = document.isFocused && document.selection.editableElement == this;
        });
    }
    destroy() {
        this.stopListening();
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
EditableElement.prototype.is = function(type, name) {
    if (!name) {
        return type === 'editableElement' || type === 'view:editableElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'containerElement' || type === 'view:containerElement' || type === 'element' || type === 'view:element' || type === 'node' || type === 'view:node';
    } else {
        return name === this.name && (type === 'editableElement' || type === 'view:editableElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'containerElement' || type === 'view:containerElement' || type === 'element' || type === 'view:element');
    }
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/rooteditableelement.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/rooteditableelement
 */ __turbopack_context__.s([
    "default",
    ()=>RootEditableElement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$editableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/editableelement.js [app-ssr] (ecmascript)");
;
const rootNameSymbol = Symbol('rootName');
class RootEditableElement extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$editableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates root editable element.
     *
     * @param document The document instance to which this element belongs.
     * @param name Node name.
     */ constructor(document, name){
        super(document, name);
        this.rootName = 'main';
    }
    /**
     * Name of this root inside {@link module:engine/view/document~Document} that is an owner of this root. If no
     * other name is set, `main` name is used.
     *
     * @readonly
     */ get rootName() {
        return this.getCustomProperty(rootNameSymbol);
    }
    set rootName(rootName) {
        this._setCustomProperty(rootNameSymbol, rootName);
    }
    /**
     * Overrides old element name and sets new one.
     * This is needed because view roots are created before they are attached to the DOM.
     * The name of the root element is temporary at this stage. It has to be changed when the
     * view root element is attached to the DOM element.
     *
     * @internal
     * @param name The new name of element.
     */ set _name(name) {
        this.name = name;
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
RootEditableElement.prototype.is = function(type, name) {
    if (!name) {
        return type === 'rootElement' || type === 'view:rootElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'editableElement' || type === 'view:editableElement' || type === 'containerElement' || type === 'view:containerElement' || type === 'element' || type === 'view:element' || type === 'node' || type === 'view:node';
    } else {
        return name === this.name && (type === 'rootElement' || type === 'view:rootElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'editableElement' || type === 'view:editableElement' || type === 'containerElement' || type === 'view:containerElement' || type === 'element' || type === 'view:element');
    }
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/treewalker.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/treewalker
 */ __turbopack_context__.s([
    "default",
    ()=>TreeWalker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/textproxy.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
;
;
;
class TreeWalker {
    /**
     * Creates a range iterator. All parameters are optional, but you have to specify either `boundaries` or `startPosition`.
     *
     * @param options Object with configuration.
     */ constructor(options = {}){
        if (!options.boundaries && !options.startPosition) {
            /**
             * Neither boundaries nor starting position have been defined.
             *
             * @error view-tree-walker-no-start-position
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-tree-walker-no-start-position', null);
        }
        if (options.direction && options.direction != 'forward' && options.direction != 'backward') {
            /**
             * Only `backward` and `forward` direction allowed.
             *
             * @error view-tree-walker-unknown-direction
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-tree-walker-unknown-direction', options.startPosition, {
                direction: options.direction
            });
        }
        this.boundaries = options.boundaries || null;
        if (options.startPosition) {
            this._position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(options.startPosition);
        } else {
            this._position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(options.boundaries[options.direction == 'backward' ? 'end' : 'start']);
        }
        this.direction = options.direction || 'forward';
        this.singleCharacters = !!options.singleCharacters;
        this.shallow = !!options.shallow;
        this.ignoreElementEnd = !!options.ignoreElementEnd;
        this._boundaryStartParent = this.boundaries ? this.boundaries.start.parent : null;
        this._boundaryEndParent = this.boundaries ? this.boundaries.end.parent : null;
    }
    /**
     * Iterable interface.
     */ [Symbol.iterator]() {
        return this;
    }
    /**
     * Iterator position. If start position is not defined then position depends on {@link #direction}. If direction is
     * `'forward'` position starts form the beginning, when direction is `'backward'` position starts from the end.
     */ get position() {
        return this._position;
    }
    /**
     * Moves {@link #position} in the {@link #direction} skipping values as long as the callback function returns `true`.
     *
     * For example:
     *
     * ```ts
     * walker.skip( value => value.type == 'text' ); // <p>{}foo</p> -> <p>foo[]</p>
     * walker.skip( value => true ); // Move the position to the end: <p>{}foo</p> -> <p>foo</p>[]
     * walker.skip( value => false ); // Do not move the position.
     * ```
     *
     * @param skip Callback function. Gets {@link module:engine/view/treewalker~TreeWalkerValue} and should
     * return `true` if the value should be skipped or `false` if not.
     */ skip(skip) {
        let nextResult;
        let prevPosition;
        do {
            prevPosition = this.position;
            nextResult = this.next();
        }while (!nextResult.done && skip(nextResult.value))
        if (!nextResult.done) {
            this._position = prevPosition;
        }
    }
    /**
     * Gets the next tree walker's value.
     *
     * @returns Object implementing iterator interface, returning
     * information about taken step.
     */ next() {
        if (this.direction == 'forward') {
            return this._next();
        } else {
            return this._previous();
        }
    }
    /**
     * Makes a step forward in view. Moves the {@link #position} to the next position and returns the encountered value.
     */ _next() {
        let position = this.position.clone();
        const previousPosition = this.position;
        const parent = position.parent;
        // We are at the end of the root.
        if (parent.parent === null && position.offset === parent.childCount) {
            return {
                done: true,
                value: undefined
            };
        }
        // We reached the walker boundary.
        if (parent === this._boundaryEndParent && position.offset == this.boundaries.end.offset) {
            return {
                done: true,
                value: undefined
            };
        }
        // Get node just after current position.
        let node;
        // Text is a specific parent because it contains string instead of child nodes.
        if (parent instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            if (position.isAtEnd) {
                // Prevent returning "elementEnd" for Text node. Skip that value and return the next walker step.
                this._position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(parent);
                return this._next();
            }
            node = parent.data[position.offset];
        } else {
            node = parent.getChild(position.offset);
        }
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            if (!this.shallow) {
                position = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, 0);
            } else {
                // We are past the walker boundaries.
                if (this.boundaries && this.boundaries.end.isBefore(position)) {
                    return {
                        done: true,
                        value: undefined
                    };
                }
                position.offset++;
            }
            this._position = position;
            return this._formatReturnValue('elementStart', node, previousPosition, position, 1);
        }
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            if (this.singleCharacters) {
                position = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, 0);
                this._position = position;
                return this._next();
            }
            let charactersCount = node.data.length;
            let item;
            // If text stick out of walker range, we need to cut it and wrap in TextProxy.
            if (node == this._boundaryEndParent) {
                charactersCount = this.boundaries.end.offset;
                item = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, 0, charactersCount);
                position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(item);
            } else {
                item = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, 0, node.data.length);
                // If not just keep moving forward.
                position.offset++;
            }
            this._position = position;
            return this._formatReturnValue('text', item, previousPosition, position, charactersCount);
        }
        if (typeof node == 'string') {
            let textLength;
            if (this.singleCharacters) {
                textLength = 1;
            } else {
                // Check if text stick out of walker range.
                const endOffset = parent === this._boundaryEndParent ? this.boundaries.end.offset : parent.data.length;
                textLength = endOffset - position.offset;
            }
            const textProxy = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, position.offset, textLength);
            position.offset += textLength;
            this._position = position;
            return this._formatReturnValue('text', textProxy, previousPosition, position, textLength);
        }
        // `node` is not set, we reached the end of current `parent`.
        position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(parent);
        this._position = position;
        if (this.ignoreElementEnd) {
            return this._next();
        }
        return this._formatReturnValue('elementEnd', parent, previousPosition, position);
    }
    /**
     * Makes a step backward in view. Moves the {@link #position} to the previous position and returns the encountered value.
     */ _previous() {
        let position = this.position.clone();
        const previousPosition = this.position;
        const parent = position.parent;
        // We are at the beginning of the root.
        if (parent.parent === null && position.offset === 0) {
            return {
                done: true,
                value: undefined
            };
        }
        // We reached the walker boundary.
        if (parent == this._boundaryStartParent && position.offset == this.boundaries.start.offset) {
            return {
                done: true,
                value: undefined
            };
        }
        // Get node just before current position.
        let node;
        // Text {@link module:engine/view/text~Text} element is a specific parent because contains string instead of child nodes.
        if (parent instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            if (position.isAtStart) {
                // Prevent returning "elementStart" for Text node. Skip that value and return the next walker step.
                this._position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(parent);
                return this._previous();
            }
            node = parent.data[position.offset - 1];
        } else {
            node = parent.getChild(position.offset - 1);
        }
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            if (this.shallow) {
                position.offset--;
                this._position = position;
                return this._formatReturnValue('elementStart', node, previousPosition, position, 1);
            }
            position = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, node.childCount);
            this._position = position;
            if (this.ignoreElementEnd) {
                return this._previous();
            }
            return this._formatReturnValue('elementEnd', node, previousPosition, position);
        }
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            if (this.singleCharacters) {
                position = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, node.data.length);
                this._position = position;
                return this._previous();
            }
            let charactersCount = node.data.length;
            let item;
            // If text stick out of walker range, we need to cut it and wrap in TextProxy.
            if (node == this._boundaryStartParent) {
                const offset = this.boundaries.start.offset;
                item = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, offset, node.data.length - offset);
                charactersCount = item.data.length;
                position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item);
            } else {
                item = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](node, 0, node.data.length);
                // If not just keep moving backward.
                position.offset--;
            }
            this._position = position;
            return this._formatReturnValue('text', item, previousPosition, position, charactersCount);
        }
        if (typeof node == 'string') {
            let textLength;
            if (!this.singleCharacters) {
                // Check if text stick out of walker range.
                const startOffset = parent === this._boundaryStartParent ? this.boundaries.start.offset : 0;
                textLength = position.offset - startOffset;
            } else {
                textLength = 1;
            }
            position.offset -= textLength;
            const textProxy = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, position.offset, textLength);
            this._position = position;
            return this._formatReturnValue('text', textProxy, previousPosition, position, textLength);
        }
        // `node` is not set, we reached the beginning of current `parent`.
        position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(parent);
        this._position = position;
        return this._formatReturnValue('elementStart', parent, previousPosition, position, 1);
    }
    /**
     * Format returned data and adjust `previousPosition` and `nextPosition` if reach the bound of the {@link module:engine/view/text~Text}.
     *
     * @param type Type of step.
     * @param item Item between old and new position.
     * @param previousPosition Previous position of iterator.
     * @param nextPosition Next position of iterator.
     * @param length Length of the item.
     */ _formatReturnValue(type, item, previousPosition, nextPosition, length) {
        // Text is a specific parent, because contains string instead of children.
        // Walker doesn't enter to the Text except situations when walker is iterating over every single character,
        // or the bound starts/ends inside the Text. So when the position is at the beginning or at the end of the Text
        // we move it just before or just after Text.
        if (item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            // Position is at the end of Text.
            if (item.offsetInText + item.data.length == item.textNode.data.length) {
                if (this.direction == 'forward' && !(this.boundaries && this.boundaries.end.isEqual(this.position))) {
                    nextPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(item.textNode);
                    // When we change nextPosition of returned value we need also update walker current position.
                    this._position = nextPosition;
                } else {
                    previousPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(item.textNode);
                }
            }
            // Position is at the begining ot the text.
            if (item.offsetInText === 0) {
                if (this.direction == 'backward' && !(this.boundaries && this.boundaries.start.isEqual(this.position))) {
                    nextPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item.textNode);
                    // When we change nextPosition of returned value we need also update walker current position.
                    this._position = nextPosition;
                } else {
                    previousPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item.textNode);
                }
            }
        }
        return {
            done: false,
            value: {
                type,
                item,
                previousPosition,
                nextPosition,
                length
            }
        };
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/position
 */ __turbopack_context__.s([
    "default",
    ()=>Position
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/comparearrays.js [app-ssr] (ecmascript) <export default as compareArrays>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$editableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/editableelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/treewalker.js [app-ssr] (ecmascript)");
;
;
;
;
class Position extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a position.
     *
     * @param parent Position parent.
     * @param offset Position offset.
     */ constructor(parent, offset){
        super();
        this.parent = parent;
        this.offset = offset;
    }
    /**
     * Node directly after the position. Equals `null` when there is no node after position or position is located
     * inside text node.
     */ get nodeAfter() {
        if (this.parent.is('$text')) {
            return null;
        }
        return this.parent.getChild(this.offset) || null;
    }
    /**
     * Node directly before the position. Equals `null` when there is no node before position or position is located
     * inside text node.
     */ get nodeBefore() {
        if (this.parent.is('$text')) {
            return null;
        }
        return this.parent.getChild(this.offset - 1) || null;
    }
    /**
     * Is `true` if position is at the beginning of its {@link module:engine/view/position~Position#parent parent}, `false` otherwise.
     */ get isAtStart() {
        return this.offset === 0;
    }
    /**
     * Is `true` if position is at the end of its {@link module:engine/view/position~Position#parent parent}, `false` otherwise.
     */ get isAtEnd() {
        const endOffset = this.parent.is('$text') ? this.parent.data.length : this.parent.childCount;
        return this.offset === endOffset;
    }
    /**
     * Position's root, that is the root of the position's parent element.
     */ get root() {
        return this.parent.root;
    }
    /**
     * {@link module:engine/view/editableelement~EditableElement EditableElement} instance that contains this position, or `null` if
     * position is not inside an editable element.
     */ get editableElement() {
        let editable = this.parent;
        while(!(editable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$editableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])){
            if (editable.parent) {
                editable = editable.parent;
            } else {
                return null;
            }
        }
        return editable;
    }
    /**
     * Returns a new instance of Position with offset incremented by `shift` value.
     *
     * @param shift How position offset should get changed. Accepts negative values.
     * @returns Shifted position.
     */ getShiftedBy(shift) {
        const shifted = Position._createAt(this);
        const offset = shifted.offset + shift;
        shifted.offset = offset < 0 ? 0 : offset;
        return shifted;
    }
    /**
     * Gets the farthest position which matches the callback using
     * {@link module:engine/view/treewalker~TreeWalker TreeWalker}.
     *
     * For example:
     *
     * ```ts
     * getLastMatchingPosition( value => value.type == 'text' ); // <p>{}foo</p> -> <p>foo[]</p>
     * getLastMatchingPosition( value => value.type == 'text', { direction: 'backward' } ); // <p>foo[]</p> -> <p>{}foo</p>
     * getLastMatchingPosition( value => false ); // Do not move the position.
     * ```
     *
     * @param skip Callback function. Gets {@link module:engine/view/treewalker~TreeWalkerValue} and should
     * return `true` if the value should be skipped or `false` if not.
     * @param options Object with configuration options. See {@link module:engine/view/treewalker~TreeWalker}.
     * @returns The position after the last item which matches the `skip` callback test.
     */ getLastMatchingPosition(skip, options = {}) {
        options.startPosition = this;
        const treeWalker = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](options);
        treeWalker.skip(skip);
        return treeWalker.position;
    }
    /**
     * Returns ancestors array of this position, that is this position's parent and it's ancestors.
     *
     * @returns Array with ancestors.
     */ getAncestors() {
        if (this.parent.is('documentFragment')) {
            return [
                this.parent
            ];
        } else {
            return this.parent.getAncestors({
                includeSelf: true
            });
        }
    }
    /**
     * Returns a {@link module:engine/view/node~Node} or {@link module:engine/view/documentfragment~DocumentFragment}
     * which is a common ancestor of both positions.
     */ getCommonAncestor(position) {
        const ancestorsA = this.getAncestors();
        const ancestorsB = position.getAncestors();
        let i = 0;
        while(ancestorsA[i] == ancestorsB[i] && ancestorsA[i]){
            i++;
        }
        return i === 0 ? null : ancestorsA[i - 1];
    }
    /**
     * Checks whether this position equals given position.
     *
     * @param otherPosition Position to compare with.
     * @returns True if positions are same.
     */ isEqual(otherPosition) {
        return this.parent == otherPosition.parent && this.offset == otherPosition.offset;
    }
    /**
     * Checks whether this position is located before given position. When method returns `false` it does not mean that
     * this position is after give one. Two positions may be located inside separate roots and in that situation this
     * method will still return `false`.
     *
     * @see module:engine/view/position~Position#isAfter
     * @see module:engine/view/position~Position#compareWith
     * @param otherPosition Position to compare with.
     * @returns Returns `true` if this position is before given position.
     */ isBefore(otherPosition) {
        return this.compareWith(otherPosition) == 'before';
    }
    /**
     * Checks whether this position is located after given position. When method returns `false` it does not mean that
     * this position is before give one. Two positions may be located inside separate roots and in that situation this
     * method will still return `false`.
     *
     * @see module:engine/view/position~Position#isBefore
     * @see module:engine/view/position~Position#compareWith
     * @param otherPosition Position to compare with.
     * @returns Returns `true` if this position is after given position.
     */ isAfter(otherPosition) {
        return this.compareWith(otherPosition) == 'after';
    }
    /**
     * Checks whether this position is before, after or in same position that other position. Two positions may be also
     * different when they are located in separate roots.
     *
     * @param otherPosition Position to compare with.
     */ compareWith(otherPosition) {
        if (this.root !== otherPosition.root) {
            return 'different';
        }
        if (this.isEqual(otherPosition)) {
            return 'same';
        }
        // Get path from root to position's parent element.
        const thisPath = this.parent.is('node') ? this.parent.getPath() : [];
        const otherPath = otherPosition.parent.is('node') ? otherPosition.parent.getPath() : [];
        // Add the positions' offsets to the parents offsets.
        thisPath.push(this.offset);
        otherPath.push(otherPosition.offset);
        // Compare both path arrays to find common ancestor.
        const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$comparearrays$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__compareArrays$3e$__["compareArrays"])(thisPath, otherPath);
        switch(result){
            case 'prefix':
                return 'before';
            case 'extension':
                return 'after';
            default:
                // Cast to number to avoid having 'same' as a type of `result`.
                return thisPath[result] < otherPath[result] ? 'before' : 'after';
        }
    }
    /**
     * Creates a {@link module:engine/view/treewalker~TreeWalker TreeWalker} instance with this positions as a start position.
     *
     * @param options Object with configuration options. See {@link module:engine/view/treewalker~TreeWalker}
     */ getWalker(options = {}) {
        options.startPosition = this;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](options);
    }
    /**
     * Clones this position.
     */ clone() {
        return new Position(this.parent, this.offset);
    }
    /**
     * Creates position at the given location. The location can be specified as:
     *
     * * a {@link module:engine/view/position~Position position},
     * * parent element and offset (offset defaults to `0`),
     * * parent element and `'end'` (sets position at the end of that element),
     * * {@link module:engine/view/item~Item view item} and `'before'` or `'after'` (sets position before or after given view item).
     *
     * This method is a shortcut to other constructors such as:
     *
     * * {@link module:engine/view/position~Position._createBefore},
     * * {@link module:engine/view/position~Position._createAfter}.
     *
     * @internal
     * @param offset Offset or one of the flags. Used only when first parameter is a {@link module:engine/view/item~Item view item}.
     */ static _createAt(itemOrPosition, offset) {
        if (itemOrPosition instanceof Position) {
            return new this(itemOrPosition.parent, itemOrPosition.offset);
        } else {
            const node = itemOrPosition;
            if (offset == 'end') {
                offset = node.is('$text') ? node.data.length : node.childCount;
            } else if (offset == 'before') {
                return this._createBefore(node);
            } else if (offset == 'after') {
                return this._createAfter(node);
            } else if (offset !== 0 && !offset) {
                /**
                 * {@link module:engine/view/view~View#createPositionAt `View#createPositionAt()`}
                 * requires the offset to be specified when the first parameter is a view item.
                 *
                 * @error view-createpositionat-offset-required
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-createpositionat-offset-required', node);
            }
            return new Position(node, offset);
        }
    }
    /**
     * Creates a new position after given view item.
     *
     * @internal
     * @param item View item after which the position should be located.
     */ static _createAfter(item) {
        // TextProxy is not a instance of Node so we need do handle it in specific way.
        if (item.is('$textProxy')) {
            return new Position(item.textNode, item.offsetInText + item.data.length);
        }
        if (!item.parent) {
            /**
             * You can not make a position after a root.
             *
             * @error view-position-after-root
             * @param {module:engine/view/node~Node} root
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-position-after-root', item, {
                root: item
            });
        }
        return new Position(item.parent, item.index + 1);
    }
    /**
     * Creates a new position before given view item.
     *
     * @internal
     * @param item View item before which the position should be located.
     */ static _createBefore(item) {
        // TextProxy is not a instance of Node so we need do handle it in specific way.
        if (item.is('$textProxy')) {
            return new Position(item.textNode, item.offsetInText);
        }
        if (!item.parent) {
            /**
             * You cannot make a position before a root.
             *
             * @error view-position-before-root
             * @param {module:engine/view/node~Node} root
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-position-before-root', item, {
                root: item
            });
        }
        return new Position(item.parent, item.index);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Position.prototype.is = function(type) {
    return type === 'position' || type === 'view:position';
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/range.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/range
 */ __turbopack_context__.s([
    "default",
    ()=>Range
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/treewalker.js [app-ssr] (ecmascript)");
;
;
;
class Range extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a range spanning from `start` position to `end` position.
     *
     * **Note:** Constructor creates it's own {@link module:engine/view/position~Position} instances basing on passed values.
     *
     * @param start Start position.
     * @param end End position. If not set, range will be collapsed at the `start` position.
     */ constructor(start, end = null){
        super();
        this.start = start.clone();
        this.end = end ? end.clone() : start.clone();
    }
    /**
     * Iterable interface.
     *
     * Iterates over all {@link module:engine/view/item~Item view items} that are in this range and returns
     * them together with additional information like length or {@link module:engine/view/position~Position positions},
     * grouped as {@link module:engine/view/treewalker~TreeWalkerValue}.
     *
     * This iterator uses {@link module:engine/view/treewalker~TreeWalker TreeWalker} with `boundaries` set to this range and
     * `ignoreElementEnd` option
     * set to `true`.
     */ *[Symbol.iterator]() {
        yield* new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
            boundaries: this,
            ignoreElementEnd: true
        });
    }
    /**
     * Returns whether the range is collapsed, that is it start and end positions are equal.
     */ get isCollapsed() {
        return this.start.isEqual(this.end);
    }
    /**
     * Returns whether this range is flat, that is if {@link module:engine/view/range~Range#start start} position and
     * {@link module:engine/view/range~Range#end end} position are in the same {@link module:engine/view/position~Position#parent parent}.
     */ get isFlat() {
        return this.start.parent === this.end.parent;
    }
    /**
     * Range root element.
     */ get root() {
        return this.start.root;
    }
    /**
     * Creates a maximal range that has the same content as this range but is expanded in both ways (at the beginning
     * and at the end).
     *
     * For example:
     *
     * ```html
     * <p>Foo</p><p><b>{Bar}</b></p> -> <p>Foo</p>[<p><b>Bar</b>]</p>
     * <p><b>foo</b>{bar}<span></span></p> -> <p><b>foo[</b>bar<span></span>]</p>
     * ```
     *
     * Note that in the sample above:
     *
     * - `<p>` have type of {@link module:engine/view/containerelement~ContainerElement},
     * - `<b>` have type of {@link module:engine/view/attributeelement~AttributeElement},
     * - `<span>` have type of {@link module:engine/view/uielement~UIElement}.
     *
     * @returns Enlarged range.
     */ getEnlarged() {
        let start = this.start.getLastMatchingPosition(enlargeTrimSkip, {
            direction: 'backward'
        });
        let end = this.end.getLastMatchingPosition(enlargeTrimSkip);
        // Fix positions, in case if they are in Text node.
        if (start.parent.is('$text') && start.isAtStart) {
            start = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(start.parent);
        }
        if (end.parent.is('$text') && end.isAtEnd) {
            end = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(end.parent);
        }
        return new Range(start, end);
    }
    /**
     * Creates a minimum range that has the same content as this range but is trimmed in both ways (at the beginning
     * and at the end).
     *
     * For example:
     *
     * ```html
     * <p>Foo</p>[<p><b>Bar</b>]</p> -> <p>Foo</p><p><b>{Bar}</b></p>
     * <p><b>foo[</b>bar<span></span>]</p> -> <p><b>foo</b>{bar}<span></span></p>
     * ```
     *
     * Note that in the sample above:
     *
     * - `<p>` have type of {@link module:engine/view/containerelement~ContainerElement},
     * - `<b>` have type of {@link module:engine/view/attributeelement~AttributeElement},
     * - `<span>` have type of {@link module:engine/view/uielement~UIElement}.
     *
     * @returns Shrunk range.
     */ getTrimmed() {
        let start = this.start.getLastMatchingPosition(enlargeTrimSkip);
        if (start.isAfter(this.end) || start.isEqual(this.end)) {
            return new Range(start, start);
        }
        let end = this.end.getLastMatchingPosition(enlargeTrimSkip, {
            direction: 'backward'
        });
        const nodeAfterStart = start.nodeAfter;
        const nodeBeforeEnd = end.nodeBefore;
        // Because TreeWalker prefers positions next to text node, we need to move them manually into these text nodes.
        if (nodeAfterStart && nodeAfterStart.is('$text')) {
            start = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodeAfterStart, 0);
        }
        if (nodeBeforeEnd && nodeBeforeEnd.is('$text')) {
            end = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodeBeforeEnd, nodeBeforeEnd.data.length);
        }
        return new Range(start, end);
    }
    /**
     * Two ranges are equal if their start and end positions are equal.
     *
     * @param otherRange Range to compare with.
     * @returns `true` if ranges are equal, `false` otherwise
     */ isEqual(otherRange) {
        return this == otherRange || this.start.isEqual(otherRange.start) && this.end.isEqual(otherRange.end);
    }
    /**
     * Checks whether this range contains given {@link module:engine/view/position~Position position}.
     *
     * @param position Position to check.
     * @returns `true` if given {@link module:engine/view/position~Position position} is contained in this range, `false` otherwise.
     */ containsPosition(position) {
        return position.isAfter(this.start) && position.isBefore(this.end);
    }
    /**
     * Checks whether this range contains given {@link module:engine/view/range~Range range}.
     *
     * @param otherRange Range to check.
     * @param loose Whether the check is loose or strict. If the check is strict (`false`), compared range cannot
     * start or end at the same position as this range boundaries. If the check is loose (`true`), compared range can start, end or
     * even be equal to this range. Note that collapsed ranges are always compared in strict mode.
     * @returns `true` if given {@link module:engine/view/range~Range range} boundaries are contained by this range, `false`
     * otherwise.
     */ containsRange(otherRange, loose = false) {
        if (otherRange.isCollapsed) {
            loose = false;
        }
        const containsStart = this.containsPosition(otherRange.start) || loose && this.start.isEqual(otherRange.start);
        const containsEnd = this.containsPosition(otherRange.end) || loose && this.end.isEqual(otherRange.end);
        return containsStart && containsEnd;
    }
    /**
     * Computes which part(s) of this {@link module:engine/view/range~Range range} is not a part of given
     * {@link module:engine/view/range~Range range}.
     * Returned array contains zero, one or two {@link module:engine/view/range~Range ranges}.
     *
     * Examples:
     *
     * ```ts
     * let foo = downcastWriter.createText( 'foo' );
     * let img = downcastWriter.createContainerElement( 'img' );
     * let bar = downcastWriter.createText( 'bar' );
     * let p = downcastWriter.createContainerElement( 'p', null, [ foo, img, bar ] );
     *
     * let range = view.createRange( view.createPositionAt( foo, 2 ), view.createPositionAt( bar, 1 ); // "o", img, "b" are in range.
     * let otherRange = view.createRange( // "oo", img, "ba" are in range.
     * 	view.createPositionAt( foo, 1 ),
     * 	view.createPositionAt( bar, 2 )
     * );
     * let transformed = range.getDifference( otherRange );
     * // transformed array has no ranges because `otherRange` contains `range`
     *
     * otherRange = view.createRange( view.createPositionAt( foo, 1 ), view.createPositionAt( p, 2 ); // "oo", img are in range.
     * transformed = range.getDifference( otherRange );
     * // transformed array has one range: from ( p, 2 ) to ( bar, 1 )
     *
     * otherRange = view.createRange( view.createPositionAt( p, 1 ), view.createPositionAt( p, 2 ) ); // img is in range.
     * transformed = range.getDifference( otherRange );
     * // transformed array has two ranges: from ( foo, 1 ) to ( p, 1 ) and from ( p, 2 ) to ( bar, 1 )
     * ```
     *
     * @param otherRange Range to differentiate against.
     * @returns The difference between ranges.
     */ getDifference(otherRange) {
        const ranges = [];
        if (this.isIntersecting(otherRange)) {
            // Ranges intersect.
            if (this.containsPosition(otherRange.start)) {
                // Given range start is inside this range. This means that we have to
                // add shrunken range - from the start to the middle of this range.
                ranges.push(new Range(this.start, otherRange.start));
            }
            if (this.containsPosition(otherRange.end)) {
                // Given range end is inside this range. This means that we have to
                // add shrunken range - from the middle of this range to the end.
                ranges.push(new Range(otherRange.end, this.end));
            }
        } else {
            // Ranges do not intersect, return the original range.
            ranges.push(this.clone());
        }
        return ranges;
    }
    /**
     * Returns an intersection of this {@link module:engine/view/range~Range range} and given {@link module:engine/view/range~Range range}.
     * Intersection is a common part of both of those ranges. If ranges has no common part, returns `null`.
     *
     * Examples:
     *
     * ```ts
     * let foo = downcastWriter.createText( 'foo' );
     * let img = downcastWriter.createContainerElement( 'img' );
     * let bar = downcastWriter.createText( 'bar' );
     * let p = downcastWriter.createContainerElement( 'p', null, [ foo, img, bar ] );
     *
     * let range = view.createRange( view.createPositionAt( foo, 2 ), view.createPositionAt( bar, 1 ); // "o", img, "b" are in range.
     * let otherRange = view.createRange( view.createPositionAt( foo, 1 ), view.createPositionAt( p, 2 ); // "oo", img are in range.
     * let transformed = range.getIntersection( otherRange ); // range from ( foo, 1 ) to ( p, 2 ).
     *
     * otherRange = view.createRange( view.createPositionAt( bar, 1 ), view.createPositionAt( bar, 3 ); "ar" is in range.
     * transformed = range.getIntersection( otherRange ); // null - no common part.
     * ```
     *
     * @param otherRange Range to check for intersection.
     * @returns A common part of given ranges or `null` if ranges have no common part.
     */ getIntersection(otherRange) {
        if (this.isIntersecting(otherRange)) {
            // Ranges intersect, so a common range will be returned.
            // At most, it will be same as this range.
            let commonRangeStart = this.start;
            let commonRangeEnd = this.end;
            if (this.containsPosition(otherRange.start)) {
                // Given range start is inside this range. This means thaNt we have to
                // shrink common range to the given range start.
                commonRangeStart = otherRange.start;
            }
            if (this.containsPosition(otherRange.end)) {
                // Given range end is inside this range. This means that we have to
                // shrink common range to the given range end.
                commonRangeEnd = otherRange.end;
            }
            return new Range(commonRangeStart, commonRangeEnd);
        }
        // Ranges do not intersect, so they do not have common part.
        return null;
    }
    /**
     * Creates a {@link module:engine/view/treewalker~TreeWalker TreeWalker} instance with this range as a boundary.
     *
     * @param options Object with configuration options. See {@link module:engine/view/treewalker~TreeWalker}.
     */ getWalker(options = {}) {
        options.boundaries = this;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](options);
    }
    /**
     * Returns a {@link module:engine/view/node~Node} or {@link module:engine/view/documentfragment~DocumentFragment}
     * which is a common ancestor of range's both ends (in which the entire range is contained).
     */ getCommonAncestor() {
        return this.start.getCommonAncestor(this.end);
    }
    /**
     * Returns an {@link module:engine/view/element~Element Element} contained by the range.
     * The element will be returned when it is the **only** node within the range and **fully–contained**
     * at the same time.
     */ getContainedElement() {
        if (this.isCollapsed) {
            return null;
        }
        let nodeAfterStart = this.start.nodeAfter;
        let nodeBeforeEnd = this.end.nodeBefore;
        // Handle the situation when the range position is at the beginning / at the end of a text node.
        // In such situation `.nodeAfter` and `.nodeBefore` are `null` but the range still might be spanning
        // over one element.
        //
        // <p>Foo{<span class="widget"></span>}bar</p> vs <p>Foo[<span class="widget"></span>]bar</p>
        //
        // These are basically the same range, only the difference is if the range position is at
        // at the end/at the beginning of a text node or just before/just after the text node.
        //
        if (this.start.parent.is('$text') && this.start.isAtEnd && this.start.parent.nextSibling) {
            nodeAfterStart = this.start.parent.nextSibling;
        }
        if (this.end.parent.is('$text') && this.end.isAtStart && this.end.parent.previousSibling) {
            nodeBeforeEnd = this.end.parent.previousSibling;
        }
        if (nodeAfterStart && nodeAfterStart.is('element') && nodeAfterStart === nodeBeforeEnd) {
            return nodeAfterStart;
        }
        return null;
    }
    /**
     * Clones this range.
     */ clone() {
        return new Range(this.start, this.end);
    }
    /**
     * Returns an iterator that iterates over all {@link module:engine/view/item~Item view items} that are in this range and returns
     * them.
     *
     * This method uses {@link module:engine/view/treewalker~TreeWalker} with `boundaries` set to this range and `ignoreElementEnd` option
     * set to `true`. However it returns only {@link module:engine/view/item~Item items},
     * not {@link module:engine/view/treewalker~TreeWalkerValue}.
     *
     * You may specify additional options for the tree walker. See {@link module:engine/view/treewalker~TreeWalker} for
     * a full list of available options.
     *
     * @param options Object with configuration options. See {@link module:engine/view/treewalker~TreeWalker}.
     */ *getItems(options = {}) {
        options.boundaries = this;
        options.ignoreElementEnd = true;
        const treeWalker = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](options);
        for (const value of treeWalker){
            yield value.item;
        }
    }
    /**
     * Returns an iterator that iterates over all {@link module:engine/view/position~Position positions} that are boundaries or
     * contained in this range.
     *
     * This method uses {@link module:engine/view/treewalker~TreeWalker} with `boundaries` set to this range. However it returns only
     * {@link module:engine/view/position~Position positions}, not {@link module:engine/view/treewalker~TreeWalkerValue}.
     *
     * You may specify additional options for the tree walker. See {@link module:engine/view/treewalker~TreeWalker} for
     * a full list of available options.
     *
     * @param options Object with configuration options. See {@link module:engine/view/treewalker~TreeWalker}.
     */ *getPositions(options = {}) {
        options.boundaries = this;
        const treeWalker = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](options);
        yield treeWalker.position;
        for (const value of treeWalker){
            yield value.nextPosition;
        }
    }
    /**
     * Checks and returns whether this range intersects with the given range.
     *
     * @param otherRange Range to compare with.
     * @returns True if ranges intersect.
     */ isIntersecting(otherRange) {
        return this.start.isBefore(otherRange.end) && this.end.isAfter(otherRange.start);
    }
    /**
     * Creates a range from the given parents and offsets.
     *
     * @internal
     * @param startElement Start position parent element.
     * @param startOffset Start position offset.
     * @param endElement End position parent element.
     * @param endOffset End position offset.
     * @returns Created range.
     */ static _createFromParentsAndOffsets(startElement, startOffset, endElement, endOffset) {
        return new this(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](startElement, startOffset), new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](endElement, endOffset));
    }
    /**
     * Creates a new range, spreading from specified {@link module:engine/view/position~Position position} to a position moved by
     * given `shift`. If `shift` is a negative value, shifted position is treated as the beginning of the range.
     *
     * @internal
     * @param position Beginning of the range.
     * @param shift How long the range should be.
     */ static _createFromPositionAndShift(position, shift) {
        const start = position;
        const end = position.getShiftedBy(shift);
        return shift > 0 ? new this(start, end) : new this(end, start);
    }
    /**
     * Creates a range inside an {@link module:engine/view/element~Element element} which starts before the first child of
     * that element and ends after the last child of that element.
     *
     * @internal
     * @param element Element which is a parent for the range.
     */ static _createIn(element) {
        return this._createFromParentsAndOffsets(element, 0, element, element.childCount);
    }
    /**
     * Creates a range that starts before given {@link module:engine/view/item~Item view item} and ends after it.
     *
     * @internal
     */ static _createOn(item) {
        const size = item.is('$textProxy') ? item.offsetSize : 1;
        return this._createFromPositionAndShift(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item), size);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Range.prototype.is = function(type) {
    return type === 'range' || type === 'view:range';
};
/**
 * Function used by getEnlarged and getTrimmed methods.
 */ function enlargeTrimSkip(value) {
    if (value.item.is('attributeElement') || value.item.is('uiElement')) {
        return true;
    }
    return false;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/selection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/selection
 */ __turbopack_context__.s([
    "default",
    ()=>Selection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/node.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$count$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__count$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/count.js [app-ssr] (ecmascript) <export default as count>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/isiterable.js [app-ssr] (ecmascript) <export default as isIterable>");
;
;
;
;
;
;
class Selection extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
    /**
     * Creates new selection instance.
     *
     * **Note**: The selection constructor is available as a factory method:
     *
     * * {@link module:engine/view/view~View#createSelection `View#createSelection()`},
     * * {@link module:engine/view/upcastwriter~UpcastWriter#createSelection `UpcastWriter#createSelection()`}.
     *
     * ```ts
     * // Creates empty selection without ranges.
     * const selection = writer.createSelection();
     *
     * // Creates selection at the given range.
     * const range = writer.createRange( start, end );
     * const selection = writer.createSelection( range );
     *
     * // Creates selection at the given ranges
     * const ranges = [ writer.createRange( start1, end2 ), writer.createRange( star2, end2 ) ];
     * const selection = writer.createSelection( ranges );
     *
     * // Creates selection from the other selection.
     * const otherSelection = writer.createSelection();
     * const selection = writer.createSelection( otherSelection );
     *
     * // Creates selection from the document selection.
     * const selection = writer.createSelection( editor.editing.view.document.selection );
     *
     * // Creates selection at the given position.
     * const position = writer.createPositionFromPath( root, path );
     * const selection = writer.createSelection( position );
     *
     * // Creates collapsed selection at the position of given item and offset.
     * const paragraph = writer.createContainerElement( 'paragraph' );
     * const selection = writer.createSelection( paragraph, offset );
     *
     * // Creates a range inside an {@link module:engine/view/element~Element element} which starts before the
     * // first child of that element and ends after the last child of that element.
     * const selection = writer.createSelection( paragraph, 'in' );
     *
     * // Creates a range on an {@link module:engine/view/item~Item item} which starts before the item and ends
     * // just after the item.
     * const selection = writer.createSelection( paragraph, 'on' );
     * ```
     *
     * `Selection`'s constructor allow passing additional options (`backward`, `fake` and `label`) as the last argument.
     *
     * ```ts
     * // Creates backward selection.
     * const selection = writer.createSelection( range, { backward: true } );
     * ```
     *
     * Fake selection does not render as browser native selection over selected elements and is hidden to the user.
     * This way, no native selection UI artifacts are displayed to the user and selection over elements can be
     * represented in other way, for example by applying proper CSS class.
     *
     * Additionally fake's selection label can be provided. It will be used to describe fake selection in DOM
     * (and be  properly handled by screen readers).
     *
     * ```ts
     * // Creates fake selection with label.
     * const selection = writer.createSelection( range, { fake: true, label: 'foo' } );
     * ```
     *
     * @internal
     */ constructor(...args){
        super();
        this._ranges = [];
        this._lastRangeBackward = false;
        this._isFake = false;
        this._fakeSelectionLabel = '';
        if (args.length) {
            this.setTo(...args);
        }
    }
    /**
     * Returns true if selection instance is marked as `fake`.
     *
     * @see #setTo
     */ get isFake() {
        return this._isFake;
    }
    /**
     * Returns fake selection label.
     *
     * @see #setTo
     */ get fakeSelectionLabel() {
        return this._fakeSelectionLabel;
    }
    /**
     * Selection anchor. Anchor may be described as a position where the selection starts. Together with
     * {@link #focus focus} they define the direction of selection, which is important
     * when expanding/shrinking selection. Anchor is always the start or end of the most recent added range.
     * It may be a bit unintuitive when there are multiple ranges in selection.
     *
     * @see #focus
     */ get anchor() {
        if (!this._ranges.length) {
            return null;
        }
        const range = this._ranges[this._ranges.length - 1];
        const anchor = this._lastRangeBackward ? range.end : range.start;
        return anchor.clone();
    }
    /**
     * Selection focus. Focus is a position where the selection ends.
     *
     * @see #anchor
     */ get focus() {
        if (!this._ranges.length) {
            return null;
        }
        const range = this._ranges[this._ranges.length - 1];
        const focus = this._lastRangeBackward ? range.start : range.end;
        return focus.clone();
    }
    /**
     * Returns whether the selection is collapsed. Selection is collapsed when there is exactly one range which is
     * collapsed.
     */ get isCollapsed() {
        return this.rangeCount === 1 && this._ranges[0].isCollapsed;
    }
    /**
     * Returns number of ranges in selection.
     */ get rangeCount() {
        return this._ranges.length;
    }
    /**
     * Specifies whether the {@link #focus} precedes {@link #anchor}.
     */ get isBackward() {
        return !this.isCollapsed && this._lastRangeBackward;
    }
    /**
     * {@link module:engine/view/editableelement~EditableElement EditableElement} instance that contains this selection, or `null`
     * if the selection is not inside an editable element.
     */ get editableElement() {
        if (this.anchor) {
            return this.anchor.editableElement;
        }
        return null;
    }
    /**
     * Returns an iterable that contains copies of all ranges added to the selection.
     */ *getRanges() {
        for (const range of this._ranges){
            yield range.clone();
        }
    }
    /**
     * Returns copy of the first range in the selection. First range is the one which
     * {@link module:engine/view/range~Range#start start} position {@link module:engine/view/position~Position#isBefore is before} start
     * position of all other ranges (not to confuse with the first range added to the selection).
     * Returns `null` if no ranges are added to selection.
     */ getFirstRange() {
        let first = null;
        for (const range of this._ranges){
            if (!first || range.start.isBefore(first.start)) {
                first = range;
            }
        }
        return first ? first.clone() : null;
    }
    /**
     * Returns copy of the last range in the selection. Last range is the one which {@link module:engine/view/range~Range#end end}
     * position {@link module:engine/view/position~Position#isAfter is after} end position of all other ranges (not to confuse
     * with the last range added to the selection). Returns `null` if no ranges are added to selection.
     */ getLastRange() {
        let last = null;
        for (const range of this._ranges){
            if (!last || range.end.isAfter(last.end)) {
                last = range;
            }
        }
        return last ? last.clone() : null;
    }
    /**
     * Returns copy of the first position in the selection. First position is the position that
     * {@link module:engine/view/position~Position#isBefore is before} any other position in the selection ranges.
     * Returns `null` if no ranges are added to selection.
     */ getFirstPosition() {
        const firstRange = this.getFirstRange();
        return firstRange ? firstRange.start.clone() : null;
    }
    /**
     * Returns copy of the last position in the selection. Last position is the position that
     * {@link module:engine/view/position~Position#isAfter is after} any other position in the selection ranges.
     * Returns `null` if no ranges are added to selection.
     */ getLastPosition() {
        const lastRange = this.getLastRange();
        return lastRange ? lastRange.end.clone() : null;
    }
    /**
     * Checks whether, this selection is equal to given selection. Selections are equal if they have same directions,
     * same number of ranges and all ranges from one selection equal to a range from other selection.
     *
     * @param otherSelection Selection to compare with.
     * @returns `true` if selections are equal, `false` otherwise.
     */ isEqual(otherSelection) {
        if (this.isFake != otherSelection.isFake) {
            return false;
        }
        if (this.isFake && this.fakeSelectionLabel != otherSelection.fakeSelectionLabel) {
            return false;
        }
        if (this.rangeCount != otherSelection.rangeCount) {
            return false;
        } else if (this.rangeCount === 0) {
            return true;
        }
        if (!this.anchor.isEqual(otherSelection.anchor) || !this.focus.isEqual(otherSelection.focus)) {
            return false;
        }
        for (const thisRange of this._ranges){
            let found = false;
            for (const otherRange of otherSelection._ranges){
                if (thisRange.isEqual(otherRange)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                return false;
            }
        }
        return true;
    }
    /**
     * Checks whether this selection is similar to given selection. Selections are similar if they have same directions, same
     * number of ranges, and all {@link module:engine/view/range~Range#getTrimmed trimmed} ranges from one selection are
     * equal to any trimmed range from other selection.
     *
     * @param otherSelection Selection to compare with.
     * @returns `true` if selections are similar, `false` otherwise.
     */ isSimilar(otherSelection) {
        if (this.isBackward != otherSelection.isBackward) {
            return false;
        }
        const numOfRangesA = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$count$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__count$3e$__["count"])(this.getRanges());
        const numOfRangesB = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$count$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__count$3e$__["count"])(otherSelection.getRanges());
        // If selections have different number of ranges, they cannot be similar.
        if (numOfRangesA != numOfRangesB) {
            return false;
        }
        // If both selections have no ranges, they are similar.
        if (numOfRangesA == 0) {
            return true;
        }
        // Check if each range in one selection has a similar range in other selection.
        for (let rangeA of this.getRanges()){
            rangeA = rangeA.getTrimmed();
            let found = false;
            for (let rangeB of otherSelection.getRanges()){
                rangeB = rangeB.getTrimmed();
                if (rangeA.start.isEqual(rangeB.start) && rangeA.end.isEqual(rangeB.end)) {
                    found = true;
                    break;
                }
            }
            // For `rangeA`, neither range in `otherSelection` was similar. So selections are not similar.
            if (!found) {
                return false;
            }
        }
        // There were no ranges that weren't matched. Selections are similar.
        return true;
    }
    /**
     * Returns the selected element. {@link module:engine/view/element~Element Element} is considered as selected if there is only
     * one range in the selection, and that range contains exactly one element.
     * Returns `null` if there is no selected element.
     */ getSelectedElement() {
        if (this.rangeCount !== 1) {
            return null;
        }
        return this.getFirstRange().getContainedElement();
    }
    /**
     * Sets this selection's ranges and direction to the specified location based on the given
     * {@link module:engine/view/selection~Selectable selectable}.
     *
     * ```ts
     * // Sets selection to the given range.
     * const range = writer.createRange( start, end );
     * selection.setTo( range );
     *
     * // Sets selection to given ranges.
     * const ranges = [ writer.createRange( start1, end2 ), writer.createRange( star2, end2 ) ];
     * selection.setTo( range );
     *
     * // Sets selection to the other selection.
     * const otherSelection = writer.createSelection();
     * selection.setTo( otherSelection );
     *
     * // Sets selection to contents of DocumentSelection.
     * selection.setTo( editor.editing.view.document.selection );
     *
     * // Sets collapsed selection at the given position.
     * const position = writer.createPositionAt( root, path );
     * selection.setTo( position );
     *
     * // Sets collapsed selection at the position of given item and offset.
     * selection.setTo( paragraph, offset );
     * ```
     *
     * Creates a range inside an {@link module:engine/view/element~Element element} which starts before the first child of
     * that element and ends after the last child of that element.
     *
     * ```ts
     * selection.setTo( paragraph, 'in' );
     * ```
     *
     * Creates a range on an {@link module:engine/view/item~Item item} which starts before the item and ends just after the item.
     *
     * ```ts
     * selection.setTo( paragraph, 'on' );
     *
     * // Clears selection. Removes all ranges.
     * selection.setTo( null );
     * ```
     *
     * `Selection#setTo()` method allow passing additional options (`backward`, `fake` and `label`) as the last argument.
     *
     * ```ts
     * // Sets selection as backward.
     * selection.setTo( range, { backward: true } );
     * ```
     *
     * Fake selection does not render as browser native selection over selected elements and is hidden to the user.
     * This way, no native selection UI artifacts are displayed to the user and selection over elements can be
     * represented in other way, for example by applying proper CSS class.
     *
     * Additionally fake's selection label can be provided. It will be used to describe fake selection in DOM
     * (and be  properly handled by screen readers).
     *
     * ```ts
     * // Creates fake selection with label.
     * selection.setTo( range, { fake: true, label: 'foo' } );
     * ```
     *
     * @fires change
     */ setTo(...args) {
        let [selectable, placeOrOffset, options] = args;
        if (typeof placeOrOffset == 'object') {
            options = placeOrOffset;
            placeOrOffset = undefined;
        }
        if (selectable === null) {
            this._setRanges([]);
            this._setFakeOptions(options);
        } else if (selectable instanceof Selection || selectable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            this._setRanges(selectable.getRanges(), selectable.isBackward);
            this._setFakeOptions({
                fake: selectable.isFake,
                label: selectable.fakeSelectionLabel
            });
        } else if (selectable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            this._setRanges([
                selectable
            ], options && options.backward);
            this._setFakeOptions(options);
        } else if (selectable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            this._setRanges([
                new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selectable)
            ]);
            this._setFakeOptions(options);
        } else if (selectable instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            const backward = !!options && !!options.backward;
            let range;
            if (placeOrOffset === undefined) {
                /**
                 * selection.setTo requires the second parameter when the first parameter is a node.
                 *
                 * @error view-selection-setto-required-second-parameter
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-selection-setto-required-second-parameter', this);
            } else if (placeOrOffset == 'in') {
                range = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(selectable);
            } else if (placeOrOffset == 'on') {
                range = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(selectable);
            } else {
                range = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(selectable, placeOrOffset));
            }
            this._setRanges([
                range
            ], backward);
            this._setFakeOptions(options);
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__["isIterable"])(selectable)) {
            // We assume that the selectable is an iterable of ranges.
            // Array.from() is used to prevent setting ranges to the old iterable
            this._setRanges(selectable, options && options.backward);
            this._setFakeOptions(options);
        } else {
            /**
             * Cannot set selection to given place.
             *
             * @error view-selection-setto-not-selectable
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-selection-setto-not-selectable', this);
        }
        this.fire('change');
    }
    /**
     * Moves {@link #focus} to the specified location.
     *
     * The location can be specified in the same form as {@link module:engine/view/view~View#createPositionAt view.createPositionAt()}
     * parameters.
     *
     * @fires change
     * @param offset Offset or one of the flags. Used only when first parameter is a {@link module:engine/view/item~Item view item}.
     */ setFocus(itemOrPosition, offset) {
        if (this.anchor === null) {
            /**
             * Cannot set selection focus if there are no ranges in selection.
             *
             * @error view-selection-setfocus-no-ranges
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-selection-setfocus-no-ranges', this);
        }
        const newFocus = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(itemOrPosition, offset);
        if (newFocus.compareWith(this.focus) == 'same') {
            return;
        }
        const anchor = this.anchor;
        this._ranges.pop();
        if (newFocus.compareWith(anchor) == 'before') {
            this._addRange(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](newFocus, anchor), true);
        } else {
            this._addRange(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](anchor, newFocus));
        }
        this.fire('change');
    }
    /**
     * Replaces all ranges that were added to the selection with given array of ranges. Last range of the array
     * is treated like the last added range and is used to set {@link #anchor anchor} and {@link #focus focus}.
     * Accepts a flag describing in which way the selection is made.
     *
     * @param newRanges Iterable object of ranges to set.
     * @param isLastBackward Flag describing if last added range was selected forward - from start to end
     * (`false`) or backward - from end to start (`true`). Defaults to `false`.
     */ _setRanges(newRanges, isLastBackward = false) {
        // New ranges should be copied to prevent removing them by setting them to `[]` first.
        // Only applies to situations when selection is set to the same selection or same selection's ranges.
        newRanges = Array.from(newRanges);
        this._ranges = [];
        for (const range of newRanges){
            this._addRange(range);
        }
        this._lastRangeBackward = !!isLastBackward;
    }
    /**
     * Sets this selection instance to be marked as `fake`. A fake selection does not render as browser native selection
     * over selected elements and is hidden to the user. This way, no native selection UI artifacts are displayed to
     * the user and selection over elements can be represented in other way, for example by applying proper CSS class.
     *
     * Additionally fake's selection label can be provided. It will be used to describe fake selection in DOM (and be
     * properly handled by screen readers).
     */ _setFakeOptions(options = {}) {
        this._isFake = !!options.fake;
        this._fakeSelectionLabel = options.fake ? options.label || '' : '';
    }
    /**
     * Adds a range to the selection. Added range is copied. This means that passed range is not saved in the
     * selection instance and you can safely operate on it.
     *
     * Accepts a flag describing in which way the selection is made - passed range might be selected from
     * {@link module:engine/view/range~Range#start start} to {@link module:engine/view/range~Range#end end}
     * or from {@link module:engine/view/range~Range#end end} to {@link module:engine/view/range~Range#start start}.
     * The flag is used to set {@link #anchor anchor} and {@link #focus focus} properties.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-selection-range-intersects` if added range intersects
     * with ranges already stored in Selection instance.
     */ _addRange(range, isBackward = false) {
        if (!(range instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            /**
             * Selection range set to an object that is not an instance of {@link module:engine/view/range~Range}.
             *
             * @error view-selection-add-range-not-range
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-selection-add-range-not-range', this);
        }
        this._pushRange(range);
        this._lastRangeBackward = !!isBackward;
    }
    /**
     * Adds range to selection - creates copy of given range so it can be safely used and modified.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-selection-range-intersects` if added range intersects
     * with ranges already stored in selection instance.
     */ _pushRange(range) {
        for (const storedRange of this._ranges){
            if (range.isIntersecting(storedRange)) {
                /**
                 * Trying to add a range that intersects with another range from selection.
                 *
                 * @error view-selection-range-intersects
                 * @param {module:engine/view/range~Range} addedRange Range that was added to the selection.
                 * @param {module:engine/view/range~Range} intersectingRange Range from selection that intersects with `addedRange`.
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-selection-range-intersects', this, {
                    addedRange: range,
                    intersectingRange: storedRange
                });
            }
        }
        this._ranges.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](range.start, range.end));
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
Selection.prototype.is = function(type) {
    return type === 'selection' || type === 'view:selection';
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentselection.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/documentselection
 */ __turbopack_context__.s([
    "default",
    ()=>DocumentSelection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/selection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
;
;
;
class DocumentSelection extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
    constructor(...args){
        super();
        this._selection = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        // Delegate change event to be fired on DocumentSelection instance.
        this._selection.delegate('change').to(this);
        // Set selection data.
        if (args.length) {
            this._selection.setTo(...args);
        }
    }
    /**
     * Returns true if selection instance is marked as `fake`.
     *
     * @see #_setTo
     */ get isFake() {
        return this._selection.isFake;
    }
    /**
     * Returns fake selection label.
     *
     * @see #_setTo
     */ get fakeSelectionLabel() {
        return this._selection.fakeSelectionLabel;
    }
    /**
     * Selection anchor. Anchor may be described as a position where the selection starts. Together with
     * {@link #focus focus} they define the direction of selection, which is important
     * when expanding/shrinking selection. Anchor is always the start or end of the most recent added range.
     * It may be a bit unintuitive when there are multiple ranges in selection.
     *
     * @see #focus
     */ get anchor() {
        return this._selection.anchor;
    }
    /**
     * Selection focus. Focus is a position where the selection ends.
     *
     * @see #anchor
     */ get focus() {
        return this._selection.focus;
    }
    /**
     * Returns whether the selection is collapsed. Selection is collapsed when there is exactly one range which is
     * collapsed.
     */ get isCollapsed() {
        return this._selection.isCollapsed;
    }
    /**
     * Returns number of ranges in selection.
     */ get rangeCount() {
        return this._selection.rangeCount;
    }
    /**
     * Specifies whether the {@link #focus} precedes {@link #anchor}.
     */ get isBackward() {
        return this._selection.isBackward;
    }
    /**
     * {@link module:engine/view/editableelement~EditableElement EditableElement} instance that contains this selection, or `null`
     * if the selection is not inside an editable element.
     */ get editableElement() {
        return this._selection.editableElement;
    }
    /**
     * Used for the compatibility with the {@link module:engine/view/selection~Selection#isEqual} method.
     *
     * @internal
     */ get _ranges() {
        return this._selection._ranges;
    }
    /**
     * Returns an iterable that contains copies of all ranges added to the selection.
     */ *getRanges() {
        yield* this._selection.getRanges();
    }
    /**
     * Returns copy of the first range in the selection. First range is the one which
     * {@link module:engine/view/range~Range#start start} position {@link module:engine/view/position~Position#isBefore is before} start
     * position of all other ranges (not to confuse with the first range added to the selection).
     * Returns `null` if no ranges are added to selection.
     */ getFirstRange() {
        return this._selection.getFirstRange();
    }
    /**
     * Returns copy of the last range in the selection. Last range is the one which {@link module:engine/view/range~Range#end end}
     * position {@link module:engine/view/position~Position#isAfter is after} end position of all other ranges (not to confuse
     * with the last range added to the selection). Returns `null` if no ranges are added to selection.
     */ getLastRange() {
        return this._selection.getLastRange();
    }
    /**
     * Returns copy of the first position in the selection. First position is the position that
     * {@link module:engine/view/position~Position#isBefore is before} any other position in the selection ranges.
     * Returns `null` if no ranges are added to selection.
     */ getFirstPosition() {
        return this._selection.getFirstPosition();
    }
    /**
     * Returns copy of the last position in the selection. Last position is the position that
     * {@link module:engine/view/position~Position#isAfter is after} any other position in the selection ranges.
     * Returns `null` if no ranges are added to selection.
     */ getLastPosition() {
        return this._selection.getLastPosition();
    }
    /**
     * Returns the selected element. {@link module:engine/view/element~Element Element} is considered as selected if there is only
     * one range in the selection, and that range contains exactly one element.
     * Returns `null` if there is no selected element.
     */ getSelectedElement() {
        return this._selection.getSelectedElement();
    }
    /**
     * Checks whether, this selection is equal to given selection. Selections are equal if they have same directions,
     * same number of ranges and all ranges from one selection equal to a range from other selection.
     *
     * @param otherSelection Selection to compare with.
     * @returns `true` if selections are equal, `false` otherwise.
     */ isEqual(otherSelection) {
        return this._selection.isEqual(otherSelection);
    }
    /**
     * Checks whether this selection is similar to given selection. Selections are similar if they have same directions, same
     * number of ranges, and all {@link module:engine/view/range~Range#getTrimmed trimmed} ranges from one selection are
     * equal to any trimmed range from other selection.
     *
     * @param otherSelection Selection to compare with.
     * @returns `true` if selections are similar, `false` otherwise.
     */ isSimilar(otherSelection) {
        return this._selection.isSimilar(otherSelection);
    }
    /**
     * Sets this selection's ranges and direction to the specified location based on the given
     * {@link module:engine/view/selection~Selectable selectable}.
     *
     * ```ts
     * // Sets selection to the given range.
     * const range = writer.createRange( start, end );
     * documentSelection._setTo( range );
     *
     * // Sets selection to given ranges.
     * const ranges = [ writer.createRange( start1, end2 ), writer.createRange( start2, end2 ) ];
     * documentSelection._setTo( range );
     *
     * // Sets selection to the other selection.
     * const otherSelection = writer.createSelection();
     * documentSelection._setTo( otherSelection );
     *
     * // Sets collapsed selection at the given position.
     * const position = writer.createPositionAt( root, offset );
     * documentSelection._setTo( position );
     *
     * // Sets collapsed selection at the position of given item and offset.
     * documentSelection._setTo( paragraph, offset );
     * ```
     *
     * Creates a range inside an {@link module:engine/view/element~Element element} which starts before the first child of
     * that element and ends after the last child of that element.
     *
     * ```ts
     * documentSelection._setTo( paragraph, 'in' );
     * ```
     *
     * Creates a range on an {@link module:engine/view/item~Item item} which starts before the item and ends just after the item.
     *
     * ```ts
     * documentSelection._setTo( paragraph, 'on' );
     *
     * // Clears selection. Removes all ranges.
     * documentSelection._setTo( null );
     * ```
     *
     * `Selection#_setTo()` method allow passing additional options (`backward`, `fake` and `label`) as the last argument.
     *
     * ```ts
     * // Sets selection as backward.
     * documentSelection._setTo( range, { backward: true } );
     * ```
     *
     * Fake selection does not render as browser native selection over selected elements and is hidden to the user.
     * This way, no native selection UI artifacts are displayed to the user and selection over elements can be
     * represented in other way, for example by applying proper CSS class.
     *
     * Additionally fake's selection label can be provided. It will be used to des cribe fake selection in DOM
     * (and be  properly handled by screen readers).
     *
     * ```ts
     * // Creates fake selection with label.
     * documentSelection._setTo( range, { fake: true, label: 'foo' } );
     * ```
     *
     * @internal
     * @fires change
     */ _setTo(...args) {
        this._selection.setTo(...args);
    }
    /**
     * Moves {@link #focus} to the specified location.
     *
     * The location can be specified in the same form as {@link module:engine/view/view~View#createPositionAt view.createPositionAt()}
     * parameters.
     *
     * @internal
     * @fires change
     * @param offset Offset or one of the flags. Used only when first parameter is a {@link module:engine/view/item~Item view item}.
     */ _setFocus(itemOrPosition, offset) {
        this._selection.setFocus(itemOrPosition, offset);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
DocumentSelection.prototype.is = function(type) {
    return type === 'selection' || type == 'documentSelection' || type == 'view:selection' || type == 'view:documentSelection';
};
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingeventinfo.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/bubblingeventinfo
 */ __turbopack_context__.s([
    "default",
    ()=>BubblingEventInfo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$eventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EventInfo$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/eventinfo.js [app-ssr] (ecmascript) <export default as EventInfo>");
;
class BubblingEventInfo extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$eventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EventInfo$3e$__["EventInfo"] {
    /**
     * @param source The emitter.
     * @param name The event name.
     * @param startRange The view range that the bubbling should start from.
     */ constructor(source, name, startRange){
        super(source, name);
        this.startRange = startRange;
        this._eventPhase = 'none';
        this._currentTarget = null;
    }
    /**
     * The current event phase.
     */ get eventPhase() {
        return this._eventPhase;
    }
    /**
     * The current bubbling target.
     */ get currentTarget() {
        return this._currentTarget;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingemittermixin.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/bubblingemittermixin
 */ __turbopack_context__.s([
    "default",
    ()=>BubblingEmitterMixin
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$eventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EventInfo$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/eventinfo.js [app-ssr] (ecmascript) <export default as EventInfo>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/toarray.js [app-ssr] (ecmascript) <export default as toArray>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingeventinfo.js [app-ssr] (ecmascript)");
;
;
const contextsSymbol = Symbol('bubbling contexts');
function BubblingEmitterMixin(base) {
    class Mixin extends base {
        fire(eventOrInfo, ...eventArgs) {
            try {
                const eventInfo = eventOrInfo instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$eventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EventInfo$3e$__["EventInfo"] ? eventOrInfo : new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$eventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EventInfo$3e$__["EventInfo"](this, eventOrInfo);
                const eventContexts = getBubblingContexts(this);
                if (!eventContexts.size) {
                    return;
                }
                updateEventInfo(eventInfo, 'capturing', this);
                // The capture phase of the event.
                if (fireListenerFor(eventContexts, '$capture', eventInfo, ...eventArgs)) {
                    return eventInfo.return;
                }
                const startRange = eventInfo.startRange || this.selection.getFirstRange();
                const selectedElement = startRange ? startRange.getContainedElement() : null;
                const isCustomContext = selectedElement ? Boolean(getCustomContext(eventContexts, selectedElement)) : false;
                let node = selectedElement || getDeeperRangeParent(startRange);
                updateEventInfo(eventInfo, 'atTarget', node);
                // For the not yet bubbling event trigger for $text node if selection can be there and it's not a custom context selected.
                if (!isCustomContext) {
                    if (fireListenerFor(eventContexts, '$text', eventInfo, ...eventArgs)) {
                        return eventInfo.return;
                    }
                    updateEventInfo(eventInfo, 'bubbling', node);
                }
                while(node){
                    // Root node handling.
                    if (node.is('rootElement')) {
                        if (fireListenerFor(eventContexts, '$root', eventInfo, ...eventArgs)) {
                            return eventInfo.return;
                        }
                    } else if (node.is('element')) {
                        if (fireListenerFor(eventContexts, node.name, eventInfo, ...eventArgs)) {
                            return eventInfo.return;
                        }
                    }
                    // Check custom contexts (i.e., a widget).
                    if (fireListenerFor(eventContexts, node, eventInfo, ...eventArgs)) {
                        return eventInfo.return;
                    }
                    node = node.parent;
                    updateEventInfo(eventInfo, 'bubbling', node);
                }
                updateEventInfo(eventInfo, 'bubbling', this);
                // Document context.
                fireListenerFor(eventContexts, '$document', eventInfo, ...eventArgs);
                return eventInfo.return;
            } catch (err) {
                // @if CK_DEBUG // throw err;
                /* istanbul ignore next -- @preserve */ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"].rethrowUnexpectedError(err, this);
            }
        }
        _addEventListener(event, callback, options) {
            const contexts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(options.context || '$document');
            const eventContexts = getBubblingContexts(this);
            for (const context of contexts){
                let emitter = eventContexts.get(context);
                if (!emitter) {
                    emitter = new ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])())();
                    eventContexts.set(context, emitter);
                }
                this.listenTo(emitter, event, callback, options);
            }
        }
        _removeEventListener(event, callback) {
            const eventContexts = getBubblingContexts(this);
            for (const emitter of eventContexts.values()){
                this.stopListening(emitter, event, callback);
            }
        }
    }
    return Mixin;
}
// Backward compatibility with `mix`.
{
    const mixin = BubblingEmitterMixin(Object);
    [
        'fire',
        '_addEventListener',
        '_removeEventListener'
    ].forEach((key)=>{
        BubblingEmitterMixin[key] = mixin.prototype[key];
    });
}/**
 * Update the event info bubbling fields.
 *
 * @param eventInfo The event info object to update.
 * @param eventPhase The current event phase.
 * @param currentTarget The current bubbling target.
 */ function updateEventInfo(eventInfo, eventPhase, currentTarget) {
    if (eventInfo instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
        eventInfo._eventPhase = eventPhase;
        eventInfo._currentTarget = currentTarget;
    }
}
/**
 * Fires the listener for the specified context. Returns `true` if event was stopped.
 *
 * @param eventInfo The `EventInfo` object.
 * @param eventArgs Additional arguments to be passed to the callbacks.
 * @returns True if event stop was called.
 */ function fireListenerFor(eventContexts, context, eventInfo, ...eventArgs) {
    const emitter = typeof context == 'string' ? eventContexts.get(context) : getCustomContext(eventContexts, context);
    if (!emitter) {
        return false;
    }
    emitter.fire(eventInfo, ...eventArgs);
    return eventInfo.stop.called;
}
/**
 * Returns an emitter for a specified view node.
 */ function getCustomContext(eventContexts, node) {
    for (const [context, emitter] of eventContexts){
        if (typeof context == 'function' && context(node)) {
            return emitter;
        }
    }
    return null;
}
/**
 * Returns bubbling contexts map for the source (emitter).
 */ function getBubblingContexts(source) {
    if (!source[contextsSymbol]) {
        source[contextsSymbol] = new Map();
    }
    return source[contextsSymbol];
}
/**
 * Returns the deeper parent element for the range.
 */ function getDeeperRangeParent(range) {
    if (!range) {
        return null;
    }
    const startParent = range.start.parent;
    const endParent = range.end.parent;
    const startPath = startParent.getPath();
    const endPath = endParent.getPath();
    return startPath.length > endPath.length ? startParent : endParent;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/document.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/document
 */ __turbopack_context__.s([
    "default",
    ()=>Document
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingemittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingemittermixin.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$collection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Collection$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/collection.js [app-ssr] (ecmascript) <export default as Collection>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/observablemixin.js [app-ssr] (ecmascript) <export default as ObservableMixin>");
;
;
;
class Document extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingemittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])()) {
    /**
     * Creates a Document instance.
     *
     * @param stylesProcessor The styles processor instance.
     */ constructor(stylesProcessor){
        super();
        /**
         * Post-fixer callbacks registered to the view document.
         */ this._postFixers = new Set();
        this.selection = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        this.roots = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$collection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Collection$3e$__["Collection"]({
            idProperty: 'rootName'
        });
        this.stylesProcessor = stylesProcessor;
        this.set('isReadOnly', false);
        this.set('isFocused', false);
        this.set('isSelecting', false);
        this.set('isComposing', false);
    }
    /**
     * Gets a {@link module:engine/view/document~Document#roots view root element} with the specified name. If the name is not
     * specific "main" root is returned.
     *
     * @param name Name of the root.
     * @returns The view root element with the specified name or null when there is no root of given name.
     */ getRoot(name = 'main') {
        return this.roots.get(name);
    }
    /**
     * Allows registering post-fixer callbacks. A post-fixers mechanism allows to update the view tree just before it is rendered
     * to the DOM.
     *
     * Post-fixers are executed right after all changes from the outermost change block were applied but
     * before the {@link module:engine/view/view~View#event:render render event} is fired. If a post-fixer callback made
     * a change, it should return `true`. When this happens, all post-fixers are fired again to check if something else should
     * not be fixed in the new document tree state.
     *
     * View post-fixers are useful when you want to apply some fixes whenever the view structure changes. Keep in mind that
     * changes executed in a view post-fixer should not break model-view mapping.
     *
     * The types of changes which should be safe:
     *
     * * adding or removing attribute from elements,
     * * changes inside of {@link module:engine/view/uielement~UIElement UI elements},
     * * {@link module:engine/controller/editingcontroller~EditingController#reconvertItem marking some of the model elements to be
     * re-converted}.
     *
     * Try to avoid changes which touch view structure:
     *
     * * you should not add or remove nor wrap or unwrap any view elements,
     * * you should not change the editor data model in a view post-fixer.
     *
     * As a parameter, a post-fixer callback receives a {@link module:engine/view/downcastwriter~DowncastWriter downcast writer}.
     *
     * Typically, a post-fixer will look like this:
     *
     * ```ts
     * editor.editing.view.document.registerPostFixer( writer => {
     * 	if ( checkSomeCondition() ) {
     * 		writer.doSomething();
     *
     * 		// Let other post-fixers know that something changed.
     * 		return true;
     * 	}
     *
     * 	return false;
     * } );
     * ```
     *
     * Note that nothing happens right after you register a post-fixer (e.g. execute such a code in the console).
     * That is because adding a post-fixer does not execute it.
     * The post-fixer will be executed as soon as any change in the document needs to cause its rendering.
     * If you want to re-render the editor's view after registering the post-fixer then you should do it manually by calling
     * {@link module:engine/view/view~View#forceRender `view.forceRender()`}.
     *
     * If you need to register a callback which is executed when DOM elements are already updated,
     * use {@link module:engine/view/view~View#event:render render event}.
     */ registerPostFixer(postFixer) {
        this._postFixers.add(postFixer);
    }
    /**
     * Destroys this instance. Makes sure that all observers are destroyed and listeners removed.
     */ destroy() {
        this.roots.forEach((root)=>root.destroy());
        this.stopListening();
    }
    /**
     * Performs post-fixer loops. Executes post-fixer callbacks as long as none of them has done any changes to the model.
     *
     * @internal
     */ _callPostFixers(writer) {
        let wasFixed = false;
        do {
            for (const callback of this._postFixers){
                wasFixed = callback(writer);
                if (wasFixed) {
                    break;
                }
            }
        }while (wasFixed)
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/attributeelement.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/attributeelement
 */ __turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
// Default attribute priority.
const DEFAULT_PRIORITY = 10;
/**
 * Attribute elements are used to represent formatting elements in the view (think – `<b>`, `<span style="font-size: 2em">`, etc.).
 * Most often they are created when downcasting model text attributes.
 *
 * Editing engine does not define a fixed HTML DTD. This is why a feature developer needs to choose between various
 * types (container element, {@link module:engine/view/attributeelement~AttributeElement attribute element},
 * {@link module:engine/view/emptyelement~EmptyElement empty element}, etc) when developing a feature.
 *
 * To create a new attribute element instance use the
 * {@link module:engine/view/downcastwriter~DowncastWriter#createAttributeElement `DowncastWriter#createAttributeElement()`} method.
 */ class AttributeElement extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates an attribute element.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#createAttributeElement
     * @see module:engine/view/element~Element
     * @protected
     * @param document The document instance to which this element belongs.
     * @param name Node name.
     * @param attrs Collection of attributes.
     * @param children A list of nodes to be inserted into created element.
     */ constructor(document, name, attrs, children){
        super(document, name, attrs, children);
        /**
         * Element priority. Decides in what order elements are wrapped by {@link module:engine/view/downcastwriter~DowncastWriter}.
         *
         * @internal
         * @readonly
         */ this._priority = DEFAULT_PRIORITY;
        /**
         * Element identifier. If set, it is used by {@link module:engine/view/element~Element#isSimilar},
         * and then two elements are considered similar if, and only if they have the same `_id`.
         *
         * @internal
         * @readonly
         */ this._id = null;
        /**
         * Keeps all the attribute elements that have the same {@link module:engine/view/attributeelement~AttributeElement#id ids}
         * and still exist in the view tree.
         *
         * This property is managed by {@link module:engine/view/downcastwriter~DowncastWriter}.
         */ this._clonesGroup = null;
        this.getFillerOffset = getFillerOffset;
    }
    /**
     * Element priority. Decides in what order elements are wrapped by {@link module:engine/view/downcastwriter~DowncastWriter}.
     */ get priority() {
        return this._priority;
    }
    /**
     * Element identifier. If set, it is used by {@link module:engine/view/element~Element#isSimilar},
     * and then two elements are considered similar if, and only if they have the same `id`.
     */ get id() {
        return this._id;
    }
    /**
     * Returns all {@link module:engine/view/attributeelement~AttributeElement attribute elements} that has the
     * same {@link module:engine/view/attributeelement~AttributeElement#id id} and are in the view tree (were not removed).
     *
     * Note: If this element has been removed from the tree, returned set will not include it.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError attribute-element-get-elements-with-same-id-no-id}
     * if this element has no `id`.
     *
     * @returns Set containing all the attribute elements
     * with the same `id` that were added and not removed from the view tree.
     */ getElementsWithSameId() {
        if (this.id === null) {
            /**
             * Cannot get elements with the same id for an attribute element without id.
             *
             * @error attribute-element-get-elements-with-same-id-no-id
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('attribute-element-get-elements-with-same-id-no-id', this);
        }
        return new Set(this._clonesGroup);
    }
    /**
     * Checks if this element is similar to other element.
     *
     * If none of elements has set {@link module:engine/view/attributeelement~AttributeElement#id}, then both elements
     * should have the same name, attributes and priority to be considered as similar. Two similar elements can contain
     * different set of children nodes.
     *
     * If at least one element has {@link module:engine/view/attributeelement~AttributeElement#id} set, then both
     * elements have to have the same {@link module:engine/view/attributeelement~AttributeElement#id} value to be
     * considered similar.
     *
     * Similarity is important for {@link module:engine/view/downcastwriter~DowncastWriter}. For example:
     *
     * * two following similar elements can be merged together into one, longer element,
     * * {@link module:engine/view/downcastwriter~DowncastWriter#unwrap} checks similarity of passed element and processed element to
     * decide whether processed element should be unwrapped,
     * * etc.
     */ isSimilar(otherElement) {
        // If any element has an `id` set, just compare the ids.
        if (this.id !== null || otherElement.id !== null) {
            return this.id === otherElement.id;
        }
        return super.isSimilar(otherElement) && this.priority == otherElement.priority;
    }
    /**
     * Clones provided element with priority.
     *
     * @internal
     * @param deep If set to `true` clones element and all its children recursively. When set to `false`,
     * element will be cloned without any children.
     * @returns Clone of this element.
     */ _clone(deep = false) {
        const cloned = super._clone(deep);
        // Clone priority too.
        cloned._priority = this._priority;
        // And id too.
        cloned._id = this._id;
        return cloned;
    }
}
AttributeElement.DEFAULT_PRIORITY = DEFAULT_PRIORITY;
const __TURBOPACK__default__export__ = AttributeElement;
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
AttributeElement.prototype.is = function(type, name) {
    if (!name) {
        return type === 'attributeElement' || type === 'view:attributeElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'element' || type === 'view:element' || type === 'node' || type === 'view:node';
    } else {
        return name === this.name && (type === 'attributeElement' || type === 'view:attributeElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'element' || type === 'view:element');
    }
};
/**
 * Returns block {@link module:engine/view/filler~Filler filler} offset or `null` if block filler is not needed.
 *
 * @returns Block filler offset or `null` if block filler is not needed.
 */ function getFillerOffset() {
    // <b>foo</b> does not need filler.
    if (nonUiChildrenCount(this)) {
        return null;
    }
    let element = this.parent;
    // <p><b></b></p> needs filler -> <p><b><br></b></p>
    while(element && element.is('attributeElement')){
        if (nonUiChildrenCount(element) > 1) {
            return null;
        }
        element = element.parent;
    }
    if (!element || nonUiChildrenCount(element) > 1) {
        return null;
    }
    // Render block filler at the end of element (after all ui elements).
    return this.childCount;
}
/**
 * Returns total count of children that are not {@link module:engine/view/uielement~UIElement UIElements}.
 */ function nonUiChildrenCount(element) {
    return Array.from(element.getChildren()).filter((element)=>!element.is('uiElement')).length;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/emptyelement.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/emptyelement
 */ __turbopack_context__.s([
    "default",
    ()=>EmptyElement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/node.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
;
class EmptyElement extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates new instance of EmptyElement.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-emptyelement-cannot-add` when third parameter is passed,
     * to inform that usage of EmptyElement is incorrect (adding child nodes to EmptyElement is forbidden).
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#createEmptyElement
     * @internal
     * @param document The document instance to which this element belongs.
     * @param name Node name.
     * @param attrs Collection of attributes.
     * @param children A list of nodes to be inserted into created element.
     */ constructor(document, name, attributes, children){
        super(document, name, attributes, children);
        this.getFillerOffset = getFillerOffset;
    }
    /**
     * Overrides {@link module:engine/view/element~Element#_insertChild} method.
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-emptyelement-cannot-add` to prevent
     * adding any child nodes to EmptyElement.
     *
     * @internal
     */ _insertChild(index, items) {
        if (items && (items instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || Array.from(items).length > 0)) {
            /**
             * Cannot add children to {@link module:engine/view/emptyelement~EmptyElement}.
             *
             * @error view-emptyelement-cannot-add
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-emptyelement-cannot-add', [
                this,
                items
            ]);
        }
        return 0;
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
EmptyElement.prototype.is = function(type, name) {
    if (!name) {
        return type === 'emptyElement' || type === 'view:emptyElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'element' || type === 'view:element' || type === 'node' || type === 'view:node';
    } else {
        return name === this.name && (type === 'emptyElement' || type === 'view:emptyElement' || type === 'element' || type === 'view:element');
    }
};
/**
 * Returns `null` because block filler is not needed for EmptyElements.
 */ function getFillerOffset() {
    return null;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/uielement.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/uielement
 */ __turbopack_context__.s([
    "default",
    ()=>UIElement,
    "injectUiElementHandling",
    ()=>injectUiElementHandling
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/node.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/keyboard.js [app-ssr] (ecmascript)");
;
;
;
class UIElement extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates new instance of UIElement.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-uielement-cannot-add` when third parameter is passed,
     * to inform that usage of UIElement is incorrect (adding child nodes to UIElement is forbidden).
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#createUIElement
     * @internal
     * @param document The document instance to which this element belongs.
     * @param name Node name.
     * @param attrs Collection of attributes.
     * @param children A list of nodes to be inserted into created element.
     */ constructor(document, name, attrs, children){
        super(document, name, attrs, children);
        this.getFillerOffset = getFillerOffset;
    }
    /**
     * Overrides {@link module:engine/view/element~Element#_insertChild} method.
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-uielement-cannot-add` to prevent adding any child nodes
     * to UIElement.
     *
     * @internal
     */ _insertChild(index, items) {
        if (items && (items instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || Array.from(items).length > 0)) {
            /**
             * Cannot add children to {@link module:engine/view/uielement~UIElement}.
             *
             * @error view-uielement-cannot-add
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-uielement-cannot-add', [
                this,
                items
            ]);
        }
        return 0;
    }
    /**
     * Renders this {@link module:engine/view/uielement~UIElement} to DOM. This method is called by
     * {@link module:engine/view/domconverter~DomConverter}.
     * Do not use inheritance to create custom rendering method, replace `render()` method instead:
     *
     * ```ts
     * const myUIElement = downcastWriter.createUIElement( 'span' );
     * myUIElement.render = function( domDocument, domConverter ) {
     * 	const domElement = this.toDomElement( domDocument );
     *
     * 	domConverter.setContentOf( domElement, '<b>this is ui element</b>' );
     *
     * 	return domElement;
     * };
     * ```
     *
     * If changes in your UI element should trigger some editor UI update you should call
     * the {@link module:ui/editorui/editorui~EditorUI#update `editor.ui.update()`} method
     * after rendering your UI element.
     *
     * @param domConverter Instance of the DomConverter used to optimize the output.
     */ render(domDocument, domConverter // eslint-disable-line @typescript-eslint/no-unused-vars
    ) {
        // Provide basic, default output.
        return this.toDomElement(domDocument);
    }
    /**
     * Creates DOM element based on this view UIElement.
     * Note that each time this method is called new DOM element is created.
     */ toDomElement(domDocument) {
        const domElement = domDocument.createElement(this.name);
        for (const key of this.getAttributeKeys()){
            domElement.setAttribute(key, this.getAttribute(key));
        }
        return domElement;
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
UIElement.prototype.is = function(type, name) {
    if (!name) {
        return type === 'uiElement' || type === 'view:uiElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === 'element' || type === 'view:element' || type === 'node' || type === 'view:node';
    } else {
        return name === this.name && (type === 'uiElement' || type === 'view:uiElement' || type === 'element' || type === 'view:element');
    }
};
function injectUiElementHandling(view) {
    view.document.on('arrowKey', (evt, data)=>jumpOverUiElement(evt, data, view.domConverter), {
        priority: 'low'
    });
}
/**
 * Returns `null` because block filler is not needed for UIElements.
 */ function getFillerOffset() {
    return null;
}
/**
 * Selection cannot be placed in a `UIElement`. Whenever it is placed there, it is moved before it. This
 * causes a situation when it is impossible to jump over `UIElement` using right arrow key, because the selection
 * ends up in ui element (in DOM) and is moved back to the left. This handler fixes this situation.
 */ function jumpOverUiElement(evt, data, domConverter) {
    if (data.keyCode == __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["keyCodes"].arrowright) {
        const domSelection = data.domTarget.ownerDocument.defaultView.getSelection();
        const domSelectionCollapsed = domSelection.rangeCount == 1 && domSelection.getRangeAt(0).collapsed;
        // Jump over UI element if selection is collapsed or shift key is pressed. These are the cases when selection would extend.
        if (domSelectionCollapsed || data.shiftKey) {
            const domParent = domSelection.focusNode;
            const domOffset = domSelection.focusOffset;
            const viewPosition = domConverter.domPositionToView(domParent, domOffset);
            // In case if dom element is not converted to view or is not mapped or something. Happens for example in some tests.
            if (viewPosition === null) {
                return;
            }
            // Skip all following ui elements.
            let jumpedOverAnyUiElement = false;
            const nextViewPosition = viewPosition.getLastMatchingPosition((value)=>{
                if (value.item.is('uiElement')) {
                    // Remember that there was at least one ui element.
                    jumpedOverAnyUiElement = true;
                }
                // Jump over ui elements, jump over empty attribute elements, move up from inside of attribute element.
                if (value.item.is('uiElement') || value.item.is('attributeElement')) {
                    return true;
                }
                // Don't jump over text or don't get out of container element.
                return false;
            });
            // If anything has been skipped, fix position.
            // This `if` could be possibly omitted but maybe it is better not to mess with DOM selection if not needed.
            if (jumpedOverAnyUiElement) {
                const newDomPosition = domConverter.viewPositionToDom(nextViewPosition);
                if (domSelectionCollapsed) {
                    // Selection was collapsed, so collapse it at further position.
                    domSelection.collapse(newDomPosition.parent, newDomPosition.offset);
                } else {
                    // Selection was not collapse, so extend it instead of collapsing.
                    domSelection.extend(newDomPosition.parent, newDomPosition.offset);
                }
            }
        }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/rawelement.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /* eslint-disable @typescript-eslint/no-unused-vars */ /**
 * @module engine/view/rawelement
 */ __turbopack_context__.s([
    "default",
    ()=>RawElement
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/node.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
;
class RawElement extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates a new instance of a raw element.
     *
     * Throws the `view-rawelement-cannot-add` {@link module:utils/ckeditorerror~CKEditorError CKEditorError} when the `children`
     * parameter is passed to inform that the usage of `RawElement` is incorrect (adding child nodes to `RawElement` is forbidden).
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#createRawElement
     * @internal
     * @param document The document instance to which this element belongs.
     * @param name Node name.
     * @param attrs Collection of attributes.
     * @param children A list of nodes to be inserted into created element.
     */ constructor(document, name, attrs, children){
        super(document, name, attrs, children);
        // Returns `null` because filler is not needed for raw elements.
        this.getFillerOffset = getFillerOffset;
    }
    /**
     * Overrides the {@link module:engine/view/element~Element#_insertChild} method.
     * Throws the `view-rawelement-cannot-add` {@link module:utils/ckeditorerror~CKEditorError CKEditorError} to prevent
     * adding any child nodes to a raw element.
     *
     * @internal
     */ _insertChild(index, items) {
        if (items && (items instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$node$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || Array.from(items).length > 0)) {
            /**
             * Cannot add children to a {@link module:engine/view/rawelement~RawElement} instance.
             *
             * @error view-rawelement-cannot-add
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-rawelement-cannot-add', [
                this,
                items
            ]);
        }
        return 0;
    }
    /**
     * This allows rendering the children of a {@link module:engine/view/rawelement~RawElement} on the DOM level.
     * This method is called by the {@link module:engine/view/domconverter~DomConverter} with the raw DOM element
     * passed as an argument, leaving the number and shape of the children up to the integrator.
     *
     * This method **must be defined** for the raw element to work:
     *
     * ```ts
     * const myRawElement = downcastWriter.createRawElement( 'div' );
     *
     * myRawElement.render = function( domElement, domConverter ) {
     * 	domConverter.setContentOf( domElement, '<b>This is the raw content of myRawElement.</b>' );
     * };
     * ```
     *
     * @param domElement The native DOM element representing the raw view element.
     * @param domConverter Instance of the DomConverter used to optimize the output.
     */ render(domElement, domConverter) {}
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
RawElement.prototype.is = function(type, name) {
    if (!name) {
        return type === 'rawElement' || type === 'view:rawElement' || // From super.is(). This is highly utilised method and cannot call super. See ckeditor/ckeditor5#6529.
        type === this.name || type === 'view:' + this.name || type === 'element' || type === 'view:element' || type === 'node' || type === 'view:node';
    } else {
        return name === this.name && (type === 'rawElement' || type === 'view:rawElement' || type === 'element' || type === 'view:element');
    }
};
/**
 * Returns `null` because block filler is not needed for raw elements.
 */ function getFillerOffset() {
    return null;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentfragment.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/documentfragment
 */ __turbopack_context__.s([
    "default",
    ()=>DocumentFragment
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/typecheckable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/textproxy.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/isiterable.js [app-ssr] (ecmascript) <export default as isIterable>");
;
;
;
;
class DocumentFragment extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$typecheckable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
    /**
     * Creates new DocumentFragment instance.
     *
     * @internal
     * @param document The document to which this document fragment belongs.
     * @param children A list of nodes to be inserted into the created document fragment.
     */ constructor(document, children){
        super();
        /**
         * Array of child nodes.
         */ this._children = [];
        /**
         * Map of custom properties.
         * Custom properties can be added to document fragment instance.
         */ this._customProperties = new Map();
        this.document = document;
        if (children) {
            this._insertChild(0, children);
        }
    }
    /**
     * Iterable interface.
     *
     * Iterates over nodes added to this document fragment.
     */ [Symbol.iterator]() {
        return this._children[Symbol.iterator]();
    }
    /**
     * Number of child nodes in this document fragment.
     */ get childCount() {
        return this._children.length;
    }
    /**
     * Is `true` if there are no nodes inside this document fragment, `false` otherwise.
     */ get isEmpty() {
        return this.childCount === 0;
    }
    /**
     * Artificial root of `DocumentFragment`. Returns itself. Added for compatibility reasons.
     */ get root() {
        return this;
    }
    /**
     * Artificial parent of `DocumentFragment`. Returns `null`. Added for compatibility reasons.
     */ get parent() {
        return null;
    }
    /**
     * Artificial element name. Returns `undefined`. Added for compatibility reasons.
     */ get name() {
        return undefined;
    }
    /**
     * Artificial element getFillerOffset. Returns `undefined`. Added for compatibility reasons.
     */ get getFillerOffset() {
        return undefined;
    }
    /**
     * Returns the custom property value for the given key.
     */ getCustomProperty(key) {
        return this._customProperties.get(key);
    }
    /**
     * Returns an iterator which iterates over this document fragment's custom properties.
     * Iterator provides `[ key, value ]` pairs for each stored property.
     */ *getCustomProperties() {
        yield* this._customProperties.entries();
    }
    /**
     * {@link module:engine/view/documentfragment~DocumentFragment#_insertChild Insert} a child node or a list of child nodes at the end
     * and sets the parent of these nodes to this fragment.
     *
     * @internal
     * @param items Items to be inserted.
     * @returns Number of appended nodes.
     */ _appendChild(items) {
        return this._insertChild(this.childCount, items);
    }
    /**
     * Gets child at the given index.
     *
     * @param index Index of child.
     * @returns Child node.
     */ getChild(index) {
        return this._children[index];
    }
    /**
     * Gets index of the given child node. Returns `-1` if child node is not found.
     *
     * @param node Child node.
     * @returns Index of the child node.
     */ getChildIndex(node) {
        return this._children.indexOf(node);
    }
    /**
     * Gets child nodes iterator.
     *
     * @returns Child nodes iterator.
     */ getChildren() {
        return this._children[Symbol.iterator]();
    }
    /**
     * Inserts a child node or a list of child nodes on the given index and sets the parent of these nodes to
     * this fragment.
     *
     * @internal
     * @param index Position where nodes should be inserted.
     * @param items Items to be inserted.
     * @returns Number of inserted nodes.
     */ _insertChild(index, items) {
        this._fireChange('children', this);
        let count = 0;
        const nodes = normalize(this.document, items);
        for (const node of nodes){
            // If node that is being added to this element is already inside another element, first remove it from the old parent.
            if (node.parent !== null) {
                node._remove();
            }
            node.parent = this;
            this._children.splice(index, 0, node);
            index++;
            count++;
        }
        return count;
    }
    /**
     * Removes number of child nodes starting at the given index and set the parent of these nodes to `null`.
     *
     * @internal
     * @param index Number of the first node to remove.
     * @param howMany Number of nodes to remove.
     * @returns The array of removed nodes.
     */ _removeChildren(index, howMany = 1) {
        this._fireChange('children', this);
        for(let i = index; i < index + howMany; i++){
            this._children[i].parent = null;
        }
        return this._children.splice(index, howMany);
    }
    /**
     * Fires `change` event with given type of the change.
     *
     * @internal
     * @param type Type of the change.
     * @param node Changed node.
     */ _fireChange(type, node) {
        this.fire('change:' + type, node);
    }
    /**
     * Sets a custom property. They can be used to add special data to elements.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#setCustomProperty
     * @internal
     */ _setCustomProperty(key, value) {
        this._customProperties.set(key, value);
    }
    /**
     * Removes the custom property stored under the given key.
     *
     * @see module:engine/view/downcastwriter~DowncastWriter#removeCustomProperty
     * @internal
     * @returns Returns true if property was removed.
     */ _removeCustomProperty(key) {
        return this._customProperties.delete(key);
    }
}
// The magic of type inference using `is` method is centralized in `TypeCheckable` class.
// Proper overload would interfere with that.
DocumentFragment.prototype.is = function(type) {
    return type === 'documentFragment' || type === 'view:documentFragment';
};
/**
 * Converts strings to Text and non-iterables to arrays.
 */ function normalize(document, nodes) {
    // Separate condition because string is iterable.
    if (typeof nodes == 'string') {
        return [
            new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](document, nodes)
        ];
    }
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__["isIterable"])(nodes)) {
        nodes = [
            nodes
        ];
    }
    // Array.from to enable .map() on non-arrays.
    return Array.from(nodes).map((node)=>{
        if (typeof node == 'string') {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](document, node);
        }
        if (node instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](document, node.data);
        }
        return node;
    });
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/downcastwriter.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/downcastwriter
 */ __turbopack_context__.s([
    "default",
    ()=>DowncastWriter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/selection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/containerelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/attributeelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$emptyelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/emptyelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/uielement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rawelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/rawelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/isiterable.js [app-ssr] (ecmascript) <export default as isIterable>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$editableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/editableelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/isPlainObject.js [app-ssr] (ecmascript) <export default as isPlainObject>");
;
;
;
;
;
;
;
;
;
;
;
;
;
class DowncastWriter {
    /**
     * @param document The view document instance.
     */ constructor(document){
        /**
         * Holds references to the attribute groups that share the same {@link module:engine/view/attributeelement~AttributeElement#id id}.
         * The keys are `id`s, the values are `Set`s holding {@link module:engine/view/attributeelement~AttributeElement}s.
         */ this._cloneGroups = new Map();
        /**
         * The slot factory used by the `elementToStructure` downcast helper.
         */ this._slotFactory = null;
        this.document = document;
    }
    setSelection(...args) {
        this.document.selection._setTo(...args);
    }
    /**
     * Moves {@link module:engine/view/documentselection~DocumentSelection#focus selection's focus} to the specified location.
     *
     * The location can be specified in the same form as {@link module:engine/view/view~View#createPositionAt view.createPositionAt()}
     * parameters.
     *
     * @param Offset or one of the flags. Used only when the first parameter is a {@link module:engine/view/item~Item view item}.
     */ setSelectionFocus(itemOrPosition, offset) {
        this.document.selection._setFocus(itemOrPosition, offset);
    }
    /**
     * Creates a new {@link module:engine/view/documentfragment~DocumentFragment} instance.
     *
     * @param children A list of nodes to be inserted into the created document fragment.
     * @returns The created document fragment.
     */ createDocumentFragment(children) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, children);
    }
    /**
     * Creates a new {@link module:engine/view/text~Text text node}.
     *
     * ```ts
     * writer.createText( 'foo' );
     * ```
     *
     * @param data The text's data.
     * @returns The created text node.
     */ createText(data) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, data);
    }
    /**
     * Creates a new {@link module:engine/view/attributeelement~AttributeElement}.
     *
     * ```ts
     * writer.createAttributeElement( 'strong' );
     * writer.createAttributeElement( 'a', { href: 'foo.bar' } );
     *
     * // Make `<a>` element contain other attributes element so the `<a>` element is not broken.
     * writer.createAttributeElement( 'a', { href: 'foo.bar' }, { priority: 5 } );
     *
     * // Set `id` of a marker element so it is not joined or merged with "normal" elements.
     * writer.createAttributeElement( 'span', { class: 'my-marker' }, { id: 'marker:my' } );
     * ```
     *
     * @param name Name of the element.
     * @param attributes Element's attributes.
     * @param options Element's options.
     * @param options.priority Element's {@link module:engine/view/attributeelement~AttributeElement#priority priority}.
     * @param options.id Element's {@link module:engine/view/attributeelement~AttributeElement#id id}.
     * @param options.renderUnsafeAttributes A list of attribute names that should be rendered in the editing
     * pipeline even though they would normally be filtered out by unsafe attribute detection mechanisms.
     * @returns Created element.
     */ createAttributeElement(name, attributes, options = {}) {
        const attributeElement = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, name, attributes);
        if (typeof options.priority === 'number') {
            attributeElement._priority = options.priority;
        }
        if (options.id) {
            attributeElement._id = options.id;
        }
        if (options.renderUnsafeAttributes) {
            attributeElement._unsafeAttributesToRender.push(...options.renderUnsafeAttributes);
        }
        return attributeElement;
    }
    createContainerElement(name, attributes, childrenOrOptions = {}, options = {}) {
        let children = null;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__["isPlainObject"])(childrenOrOptions)) {
            options = childrenOrOptions;
        } else {
            children = childrenOrOptions;
        }
        const containerElement = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, name, attributes, children);
        if (options.renderUnsafeAttributes) {
            containerElement._unsafeAttributesToRender.push(...options.renderUnsafeAttributes);
        }
        return containerElement;
    }
    /**
     * Creates a new {@link module:engine/view/editableelement~EditableElement}.
     *
     * ```ts
     * writer.createEditableElement( 'div' );
     * writer.createEditableElement( 'div', { id: 'foo-1234' } );
     * ```
     *
     * Note: The editable element is to be used in the editing pipeline. Usually, together with
     * {@link module:widget/utils~toWidgetEditable `toWidgetEditable()`}.
     *
     * @param name Name of the element.
     * @param attributes Elements attributes.
     * @param options Element's options.
     * @param options.renderUnsafeAttributes A list of attribute names that should be rendered in the editing
     * pipeline even though they would normally be filtered out by unsafe attribute detection mechanisms.
     * @returns Created element.
     */ createEditableElement(name, attributes, options = {}) {
        const editableElement = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$editableelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, name, attributes);
        if (options.renderUnsafeAttributes) {
            editableElement._unsafeAttributesToRender.push(...options.renderUnsafeAttributes);
        }
        return editableElement;
    }
    /**
     * Creates a new {@link module:engine/view/emptyelement~EmptyElement}.
     *
     * ```ts
     * writer.createEmptyElement( 'img' );
     * writer.createEmptyElement( 'img', { id: 'foo-1234' } );
     * ```
     *
     * @param name Name of the element.
     * @param attributes Elements attributes.
     * @param options Element's options.
     * @param options.renderUnsafeAttributes A list of attribute names that should be rendered in the editing
     * pipeline even though they would normally be filtered out by unsafe attribute detection mechanisms.
     * @returns Created element.
     */ createEmptyElement(name, attributes, options = {}) {
        const emptyElement = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$emptyelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, name, attributes);
        if (options.renderUnsafeAttributes) {
            emptyElement._unsafeAttributesToRender.push(...options.renderUnsafeAttributes);
        }
        return emptyElement;
    }
    /**
     * Creates a new {@link module:engine/view/uielement~UIElement}.
     *
     * ```ts
     * writer.createUIElement( 'span' );
     * writer.createUIElement( 'span', { id: 'foo-1234' } );
     * ```
     *
     * A custom render function can be provided as the third parameter:
     *
     * ```ts
     * writer.createUIElement( 'span', null, function( domDocument ) {
     * 	const domElement = this.toDomElement( domDocument );
     * 	domElement.innerHTML = '<b>this is ui element</b>';
     *
     * 	return domElement;
     * } );
     * ```
     *
     * Unlike {@link #createRawElement raw elements}, UI elements are by no means editor content, for instance,
     * they are ignored by the editor selection system.
     *
     * You should not use UI elements as data containers. Check out {@link #createRawElement} instead.
     *
     * @param name The name of the element.
     * @param attributes Element attributes.
     * @param renderFunction A custom render function.
     * @returns The created element.
     */ createUIElement(name, attributes, renderFunction) {
        const uiElement = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, name, attributes);
        if (renderFunction) {
            uiElement.render = renderFunction;
        }
        return uiElement;
    }
    /**
     * Creates a new {@link module:engine/view/rawelement~RawElement}.
     *
     * ```ts
     * writer.createRawElement( 'span', { id: 'foo-1234' }, function( domElement ) {
     * 	domElement.innerHTML = '<b>This is the raw content of the raw element.</b>';
     * } );
     * ```
     *
     * Raw elements work as data containers ("wrappers", "sandboxes") but their children are not managed or
     * even recognized by the editor. This encapsulation allows integrations to maintain custom DOM structures
     * in the editor content without, for instance, worrying about compatibility with other editor features.
     * Raw elements are a perfect tool for integration with external frameworks and data sources.
     *
     * Unlike {@link #createUIElement UI elements}, raw elements act like "real" editor content (similar to
     * {@link module:engine/view/containerelement~ContainerElement} or {@link module:engine/view/emptyelement~EmptyElement}),
     * and they are considered by the editor selection.
     *
     * You should not use raw elements to render the UI in the editor content. Check out {@link #createUIElement `#createUIElement()`}
     * instead.
     *
     * @param name The name of the element.
     * @param attributes Element attributes.
     * @param renderFunction A custom render function.
     * @param options Element's options.
     * @param options.renderUnsafeAttributes A list of attribute names that should be rendered in the editing
     * pipeline even though they would normally be filtered out by unsafe attribute detection mechanisms.
     * @returns The created element.
     */ createRawElement(name, attributes, renderFunction, options = {}) {
        const rawElement = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rawelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, name, attributes);
        if (renderFunction) {
            rawElement.render = renderFunction;
        }
        if (options.renderUnsafeAttributes) {
            rawElement._unsafeAttributesToRender.push(...options.renderUnsafeAttributes);
        }
        return rawElement;
    }
    /**
     * Adds or overwrites the element's attribute with a specified key and value.
     *
     * ```ts
     * writer.setAttribute( 'href', 'http://ckeditor.com', linkElement );
     * ```
     *
     * @param key The attribute key.
     * @param value The attribute value.
     */ setAttribute(key, value, element) {
        element._setAttribute(key, value);
    }
    /**
     * Removes attribute from the element.
     *
     * ```ts
     * writer.removeAttribute( 'href', linkElement );
     * ```
     *
     * @param key Attribute key.
     */ removeAttribute(key, element) {
        element._removeAttribute(key);
    }
    /**
     * Adds specified class to the element.
     *
     * ```ts
     * writer.addClass( 'foo', linkElement );
     * writer.addClass( [ 'foo', 'bar' ], linkElement );
     * ```
     */ addClass(className, element) {
        element._addClass(className);
    }
    /**
     * Removes specified class from the element.
     *
     * ```ts
     * writer.removeClass( 'foo', linkElement );
     * writer.removeClass( [ 'foo', 'bar' ], linkElement );
     * ```
     */ removeClass(className, element) {
        element._removeClass(className);
    }
    setStyle(property, value, element) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__["isPlainObject"])(property) && element === undefined) {
            value._setStyle(property);
        } else {
            element._setStyle(property, value);
        }
    }
    /**
     * Removes specified style from the element.
     *
     * ```ts
     * writer.removeStyle( 'color', element ); // Removes 'color' style.
     * writer.removeStyle( [ 'color', 'border-top' ], element ); // Removes both 'color' and 'border-top' styles.
     * ```
     *
     * **Note**: This method can work with normalized style names if
     * {@link module:engine/controller/datacontroller~DataController#addStyleProcessorRules a particular style processor rule is enabled}.
     * See {@link module:engine/view/stylesmap~StylesMap#remove `StylesMap#remove()`} for details.
     */ removeStyle(property, element) {
        element._removeStyle(property);
    }
    /**
     * Sets a custom property on element. Unlike attributes, custom properties are not rendered to the DOM,
     * so they can be used to add special data to elements.
     */ setCustomProperty(key, value, element) {
        element._setCustomProperty(key, value);
    }
    /**
     * Removes a custom property stored under the given key.
     *
     * @returns Returns true if property was removed.
     */ removeCustomProperty(key, element) {
        return element._removeCustomProperty(key);
    }
    /**
     * Breaks attribute elements at the provided position or at the boundaries of a provided range. It breaks attribute elements
     * up to their first ancestor that is a container element.
     *
     * In following examples `<p>` is a container, `<b>` and `<u>` are attribute elements:
     *
     * ```html
     * <p>foo<b><u>bar{}</u></b></p> -> <p>foo<b><u>bar</u></b>[]</p>
     * <p>foo<b><u>{}bar</u></b></p> -> <p>foo{}<b><u>bar</u></b></p>
     * <p>foo<b><u>b{}ar</u></b></p> -> <p>foo<b><u>b</u></b>[]<b><u>ar</u></b></p>
     * <p><b>fo{o</b><u>ba}r</u></p> -> <p><b>fo</b><b>o</b><u>ba</u><u>r</u></b></p>
     * ```
     *
     * **Note:** {@link module:engine/view/documentfragment~DocumentFragment DocumentFragment} is treated like a container.
     *
     * **Note:** The difference between {@link module:engine/view/downcastwriter~DowncastWriter#breakAttributes breakAttributes()} and
     * {@link module:engine/view/downcastwriter~DowncastWriter#breakContainer breakContainer()} is that `breakAttributes()` breaks all
     * {@link module:engine/view/attributeelement~AttributeElement attribute elements} that are ancestors of a given `position`,
     * up to the first encountered {@link module:engine/view/containerelement~ContainerElement container element}.
     * `breakContainer()` assumes that a given `position` is directly in the container element and breaks that container element.
     *
     * Throws the `view-writer-invalid-range-container` {@link module:utils/ckeditorerror~CKEditorError CKEditorError}
     * when the {@link module:engine/view/range~Range#start start}
     * and {@link module:engine/view/range~Range#end end} positions of a passed range are not placed inside same parent container.
     *
     * Throws the `view-writer-cannot-break-empty-element` {@link module:utils/ckeditorerror~CKEditorError CKEditorError}
     * when trying to break attributes inside an {@link module:engine/view/emptyelement~EmptyElement EmptyElement}.
     *
     * Throws the `view-writer-cannot-break-ui-element` {@link module:utils/ckeditorerror~CKEditorError CKEditorError}
     * when trying to break attributes inside a {@link module:engine/view/uielement~UIElement UIElement}.
     *
     * @see module:engine/view/attributeelement~AttributeElement
     * @see module:engine/view/containerelement~ContainerElement
     * @see module:engine/view/downcastwriter~DowncastWriter#breakContainer
     * @param positionOrRange The position where to break attribute elements.
     * @returns The new position or range, after breaking the attribute elements.
     */ breakAttributes(positionOrRange) {
        if (positionOrRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            return this._breakAttributes(positionOrRange);
        } else {
            return this._breakAttributesRange(positionOrRange);
        }
    }
    /**
     * Breaks a {@link module:engine/view/containerelement~ContainerElement container view element} into two, at the given position.
     * The position has to be directly inside the container element and cannot be in the root. It does not break the conrainer view element
     * if the position is at the beginning or at the end of its parent element.
     *
     * ```html
     * <p>foo^bar</p> -> <p>foo</p><p>bar</p>
     * <div><p>foo</p>^<p>bar</p></div> -> <div><p>foo</p></div><div><p>bar</p></div>
     * <p>^foobar</p> -> ^<p>foobar</p>
     * <p>foobar^</p> -> <p>foobar</p>^
     * ```
     *
     * **Note:** The difference between {@link module:engine/view/downcastwriter~DowncastWriter#breakAttributes breakAttributes()} and
     * {@link module:engine/view/downcastwriter~DowncastWriter#breakContainer breakContainer()} is that `breakAttributes()` breaks all
     * {@link module:engine/view/attributeelement~AttributeElement attribute elements} that are ancestors of a given `position`,
     * up to the first encountered {@link module:engine/view/containerelement~ContainerElement container element}.
     * `breakContainer()` assumes that the given `position` is directly in the container element and breaks that container element.
     *
     * @see module:engine/view/attributeelement~AttributeElement
     * @see module:engine/view/containerelement~ContainerElement
     * @see module:engine/view/downcastwriter~DowncastWriter#breakAttributes
     * @param position The position where to break the element.
     * @returns The position between broken elements. If an element has not been broken,
     * the returned position is placed either before or after it.
     */ breakContainer(position) {
        const element = position.parent;
        if (!element.is('containerElement')) {
            /**
             * Trying to break an element which is not a container element.
             *
             * @error view-writer-break-non-container-element
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-break-non-container-element', this.document);
        }
        if (!element.parent) {
            /**
             * Trying to break root element.
             *
             * @error view-writer-break-root
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-break-root', this.document);
        }
        if (position.isAtStart) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(element);
        } else if (!position.isAtEnd) {
            const newElement = element._clone(false);
            this.insert(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(element), newElement);
            const sourceRange = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(element, 'end'));
            const targetPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](newElement, 0);
            this.move(sourceRange, targetPosition);
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(element);
    }
    /**
     * Merges {@link module:engine/view/attributeelement~AttributeElement attribute elements}. It also merges text nodes if needed.
     * Only {@link module:engine/view/attributeelement~AttributeElement#isSimilar similar} attribute elements can be merged.
     *
     * In following examples `<p>` is a container and `<b>` is an attribute element:
     *
     * ```html
     * <p>foo[]bar</p> -> <p>foo{}bar</p>
     * <p><b>foo</b>[]<b>bar</b></p> -> <p><b>foo{}bar</b></p>
     * <p><b foo="bar">a</b>[]<b foo="baz">b</b></p> -> <p><b foo="bar">a</b>[]<b foo="baz">b</b></p>
     * ```
     *
     * It will also take care about empty attributes when merging:
     *
     * ```html
     * <p><b>[]</b></p> -> <p>[]</p>
     * <p><b>foo</b><i>[]</i><b>bar</b></p> -> <p><b>foo{}bar</b></p>
     * ```
     *
     * **Note:** Difference between {@link module:engine/view/downcastwriter~DowncastWriter#mergeAttributes mergeAttributes} and
     * {@link module:engine/view/downcastwriter~DowncastWriter#mergeContainers mergeContainers} is that `mergeAttributes` merges two
     * {@link module:engine/view/attributeelement~AttributeElement attribute elements} or {@link module:engine/view/text~Text text nodes}
     * while `mergeContainer` merges two {@link module:engine/view/containerelement~ContainerElement container elements}.
     *
     * @see module:engine/view/attributeelement~AttributeElement
     * @see module:engine/view/containerelement~ContainerElement
     * @see module:engine/view/downcastwriter~DowncastWriter#mergeContainers
     * @param position Merge position.
     * @returns Position after merge.
     */ mergeAttributes(position) {
        const positionOffset = position.offset;
        const positionParent = position.parent;
        // When inside text node - nothing to merge.
        if (positionParent.is('$text')) {
            return position;
        }
        // When inside empty attribute - remove it.
        if (positionParent.is('attributeElement') && positionParent.childCount === 0) {
            const parent = positionParent.parent;
            const offset = positionParent.index;
            positionParent._remove();
            this._removeFromClonedElementsGroup(positionParent);
            return this.mergeAttributes(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, offset));
        }
        const nodeBefore = positionParent.getChild(positionOffset - 1);
        const nodeAfter = positionParent.getChild(positionOffset);
        // Position should be placed between two nodes.
        if (!nodeBefore || !nodeAfter) {
            return position;
        }
        // When position is between two text nodes.
        if (nodeBefore.is('$text') && nodeAfter.is('$text')) {
            return mergeTextNodes(nodeBefore, nodeAfter);
        } else if (nodeBefore.is('attributeElement') && nodeAfter.is('attributeElement') && nodeBefore.isSimilar(nodeAfter)) {
            // Move all children nodes from node placed after selection and remove that node.
            const count = nodeBefore.childCount;
            nodeBefore._appendChild(nodeAfter.getChildren());
            nodeAfter._remove();
            this._removeFromClonedElementsGroup(nodeAfter);
            // New position is located inside the first node, before new nodes.
            // Call this method recursively to merge again if needed.
            return this.mergeAttributes(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodeBefore, count));
        }
        return position;
    }
    /**
     * Merges two {@link module:engine/view/containerelement~ContainerElement container elements} that are before and after given position.
     * Precisely, the element after the position is removed and it's contents are moved to element before the position.
     *
     * ```html
     * <p>foo</p>^<p>bar</p> -> <p>foo^bar</p>
     * <div>foo</div>^<p>bar</p> -> <div>foo^bar</div>
     * ```
     *
     * **Note:** Difference between {@link module:engine/view/downcastwriter~DowncastWriter#mergeAttributes mergeAttributes} and
     * {@link module:engine/view/downcastwriter~DowncastWriter#mergeContainers mergeContainers} is that `mergeAttributes` merges two
     * {@link module:engine/view/attributeelement~AttributeElement attribute elements} or {@link module:engine/view/text~Text text nodes}
     * while `mergeContainer` merges two {@link module:engine/view/containerelement~ContainerElement container elements}.
     *
     * @see module:engine/view/attributeelement~AttributeElement
     * @see module:engine/view/containerelement~ContainerElement
     * @see module:engine/view/downcastwriter~DowncastWriter#mergeAttributes
     * @param position Merge position.
     * @returns Position after merge.
     */ mergeContainers(position) {
        const prev = position.nodeBefore;
        const next = position.nodeAfter;
        if (!prev || !next || !prev.is('containerElement') || !next.is('containerElement')) {
            /**
             * Element before and after given position cannot be merged.
             *
             * @error view-writer-merge-containers-invalid-position
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-merge-containers-invalid-position', this.document);
        }
        const lastChild = prev.getChild(prev.childCount - 1);
        const newPosition = lastChild instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(lastChild, 'end') : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(prev, 'end');
        this.move(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(next), __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(prev, 'end'));
        this.remove(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(next));
        return newPosition;
    }
    /**
     * Inserts a node or nodes at specified position. Takes care about breaking attributes before insertion
     * and merging them afterwards.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-writer-insert-invalid-node` when nodes to insert
     * contains instances that are not {@link module:engine/view/text~Text Texts},
     * {@link module:engine/view/attributeelement~AttributeElement AttributeElements},
     * {@link module:engine/view/containerelement~ContainerElement ContainerElements},
     * {@link module:engine/view/emptyelement~EmptyElement EmptyElements},
     * {@link module:engine/view/rawelement~RawElement RawElements} or
     * {@link module:engine/view/uielement~UIElement UIElements}.
     *
     * @param position Insertion position.
     * @param nodes Node or nodes to insert.
     * @returns Range around inserted nodes.
     */ insert(position, nodes) {
        nodes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$isiterable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isIterable$3e$__["isIterable"])(nodes) ? [
            ...nodes
        ] : [
            nodes
        ];
        // Check if nodes to insert are instances of AttributeElements, ContainerElements, EmptyElements, UIElements or Text.
        validateNodesToInsert(nodes, this.document);
        // Group nodes in batches of nodes that require or do not require breaking an AttributeElements.
        const nodeGroups = nodes.reduce((groups, node)=>{
            const lastGroup = groups[groups.length - 1];
            // Break attributes on nodes that do exist in the model tree so they can have attributes, other elements
            // can't have an attribute in model and won't get wrapped with an AttributeElement while down-casted.
            const breakAttributes = !node.is('uiElement');
            if (!lastGroup || lastGroup.breakAttributes != breakAttributes) {
                groups.push({
                    breakAttributes,
                    nodes: [
                        node
                    ]
                });
            } else {
                lastGroup.nodes.push(node);
            }
            return groups;
        }, []);
        // Insert nodes in batches.
        let start = null;
        let end = position;
        for (const { nodes, breakAttributes } of nodeGroups){
            const range = this._insertNodes(end, nodes, breakAttributes);
            if (!start) {
                start = range.start;
            }
            end = range.end;
        }
        // When no nodes were inserted - return collapsed range.
        if (!start) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position);
        }
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end);
    }
    /**
     * Removes provided range from the container.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-writer-invalid-range-container` when
     * {@link module:engine/view/range~Range#start start} and {@link module:engine/view/range~Range#end end} positions are not placed inside
     * same parent container.
     *
     * @param rangeOrItem Range to remove from container
     * or an {@link module:engine/view/item~Item item} to remove. If range is provided, after removing, it will be updated
     * to a collapsed range showing the new position.
     * @returns Document fragment containing removed nodes.
     */ remove(rangeOrItem) {
        const range = rangeOrItem instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] ? rangeOrItem : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(rangeOrItem);
        validateRangeContainer(range, this.document);
        // If range is collapsed - nothing to remove.
        if (range.isCollapsed) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document);
        }
        // Break attributes at range start and end.
        const { start: breakStart, end: breakEnd } = this._breakAttributesRange(range, true);
        const parentContainer = breakStart.parent;
        const count = breakEnd.offset - breakStart.offset;
        // Remove nodes in range.
        const removed = parentContainer._removeChildren(breakStart.offset, count);
        for (const node of removed){
            this._removeFromClonedElementsGroup(node);
        }
        // Merge after removing.
        const mergePosition = this.mergeAttributes(breakStart);
        range.start = mergePosition;
        range.end = mergePosition.clone();
        // Return removed nodes.
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, removed);
    }
    /**
     * Removes matching elements from given range.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-writer-invalid-range-container` when
     * {@link module:engine/view/range~Range#start start} and {@link module:engine/view/range~Range#end end} positions are not placed inside
     * same parent container.
     *
     * @param range Range to clear.
     * @param element Element to remove.
     */ clear(range, element) {
        validateRangeContainer(range, this.document);
        // Create walker on given range.
        // We walk backward because when we remove element during walk it modifies range end position.
        const walker = range.getWalker({
            direction: 'backward',
            ignoreElementEnd: true
        });
        // Let's walk.
        for (const current of walker){
            const item = current.item;
            let rangeToRemove;
            // When current item matches to the given element.
            if (item.is('element') && element.isSimilar(item)) {
                // Create range on this element.
                rangeToRemove = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(item);
            // When range starts inside Text or TextProxy element.
            } else if (!current.nextPosition.isAfter(range.start) && item.is('$textProxy')) {
                // We need to check if parent of this text matches to given element.
                const parentElement = item.getAncestors().find((ancestor)=>{
                    return ancestor.is('element') && element.isSimilar(ancestor);
                });
                // If it is then create range inside this element.
                if (parentElement) {
                    rangeToRemove = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(parentElement);
                }
            }
            // If we have found element to remove.
            if (rangeToRemove) {
                // We need to check if element range stick out of the given range and truncate if it is.
                if (rangeToRemove.end.isAfter(range.end)) {
                    rangeToRemove.end = range.end;
                }
                if (rangeToRemove.start.isBefore(range.start)) {
                    rangeToRemove.start = range.start;
                }
                // At the end we remove range with found element.
                this.remove(rangeToRemove);
            }
        }
    }
    /**
     * Moves nodes from provided range to target position.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-writer-invalid-range-container` when
     * {@link module:engine/view/range~Range#start start} and {@link module:engine/view/range~Range#end end} positions are not placed inside
     * same parent container.
     *
     * @param sourceRange Range containing nodes to move.
     * @param targetPosition Position to insert.
     * @returns Range in target container. Inserted nodes are placed between
     * {@link module:engine/view/range~Range#start start} and {@link module:engine/view/range~Range#end end} positions.
     */ move(sourceRange, targetPosition) {
        let nodes;
        if (targetPosition.isAfter(sourceRange.end)) {
            targetPosition = this._breakAttributes(targetPosition, true);
            const parent = targetPosition.parent;
            const countBefore = parent.childCount;
            sourceRange = this._breakAttributesRange(sourceRange, true);
            nodes = this.remove(sourceRange);
            targetPosition.offset += parent.childCount - countBefore;
        } else {
            nodes = this.remove(sourceRange);
        }
        return this.insert(targetPosition, nodes);
    }
    /**
     * Wraps elements within range with provided {@link module:engine/view/attributeelement~AttributeElement AttributeElement}.
     * If a collapsed range is provided, it will be wrapped only if it is equal to view selection.
     *
     * If a collapsed range was passed and is same as selection, the selection
     * will be moved to the inside of the wrapped attribute element.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError} `view-writer-invalid-range-container`
     * when {@link module:engine/view/range~Range#start}
     * and {@link module:engine/view/range~Range#end} positions are not placed inside same parent container.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError} `view-writer-wrap-invalid-attribute` when passed attribute element is not
     * an instance of {@link module:engine/view/attributeelement~AttributeElement AttributeElement}.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError} `view-writer-wrap-nonselection-collapsed-range` when passed range
     * is collapsed and different than view selection.
     *
     * @param range Range to wrap.
     * @param attribute Attribute element to use as wrapper.
     * @returns range Range after wrapping, spanning over wrapping attribute element.
     */ wrap(range, attribute) {
        if (!(attribute instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-wrap-invalid-attribute', this.document);
        }
        validateRangeContainer(range, this.document);
        if (!range.isCollapsed) {
            // Non-collapsed range. Wrap it with the attribute element.
            return this._wrapRange(range, attribute);
        } else {
            // Collapsed range. Wrap position.
            let position = range.start;
            if (position.parent.is('element') && !_hasNonUiChildren(position.parent)) {
                position = position.getLastMatchingPosition((value)=>value.item.is('uiElement'));
            }
            position = this._wrapPosition(position, attribute);
            const viewSelection = this.document.selection;
            // If wrapping position is equal to view selection, move view selection inside wrapping attribute element.
            if (viewSelection.isCollapsed && viewSelection.getFirstPosition().isEqual(range.start)) {
                this.setSelection(position);
            }
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position);
        }
    }
    /**
     * Unwraps nodes within provided range from attribute element.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-writer-invalid-range-container` when
     * {@link module:engine/view/range~Range#start start} and {@link module:engine/view/range~Range#end end} positions are not placed inside
     * same parent container.
     */ unwrap(range, attribute) {
        if (!(attribute instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            /**
             * The `attribute` passed to {@link module:engine/view/downcastwriter~DowncastWriter#unwrap `DowncastWriter#unwrap()`}
             * must be an instance of {@link module:engine/view/attributeelement~AttributeElement `AttributeElement`}.
             *
             * @error view-writer-unwrap-invalid-attribute
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-unwrap-invalid-attribute', this.document);
        }
        validateRangeContainer(range, this.document);
        // If range is collapsed - nothing to unwrap.
        if (range.isCollapsed) {
            return range;
        }
        // Break attributes at range start and end.
        const { start: breakStart, end: breakEnd } = this._breakAttributesRange(range, true);
        const parentContainer = breakStart.parent;
        // Unwrap children located between break points.
        const newRange = this._unwrapChildren(parentContainer, breakStart.offset, breakEnd.offset, attribute);
        // Merge attributes at the both ends and return a new range.
        const start = this.mergeAttributes(newRange.start);
        // If start position was merged - move end position back.
        if (!start.isEqual(newRange.start)) {
            newRange.end.offset--;
        }
        const end = this.mergeAttributes(newRange.end);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end);
    }
    /**
     * Renames element by creating a copy of renamed element but with changed name and then moving contents of the
     * old element to the new one. Keep in mind that this will invalidate all {@link module:engine/view/position~Position positions} which
     * has renamed element as {@link module:engine/view/position~Position#parent a parent}.
     *
     * New element has to be created because `Element#tagName` property in DOM is readonly.
     *
     * Since this function creates a new element and removes the given one, the new element is returned to keep reference.
     *
     * @param newName New name for element.
     * @param viewElement Element to be renamed.
     * @returns Element created due to rename.
     */ rename(newName, viewElement) {
        const newElement = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, newName, viewElement.getAttributes());
        this.insert(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(viewElement), newElement);
        this.move(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(viewElement), __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(newElement, 0));
        this.remove(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(viewElement));
        return newElement;
    }
    /**
     * Cleans up memory by removing obsolete cloned elements group from the writer.
     *
     * Should be used whenever all {@link module:engine/view/attributeelement~AttributeElement attribute elements}
     * with the same {@link module:engine/view/attributeelement~AttributeElement#id id} are going to be removed from the view and
     * the group will no longer be needed.
     *
     * Cloned elements group are not removed automatically in case if the group is still needed after all its elements
     * were removed from the view.
     *
     * Keep in mind that group names are equal to the `id` property of the attribute element.
     *
     * @param groupName Name of the group to clear.
     */ clearClonedElementsGroup(groupName) {
        this._cloneGroups.delete(groupName);
    }
    /**
     * Creates position at the given location. The location can be specified as:
     *
     * * a {@link module:engine/view/position~Position position},
     * * parent element and offset (offset defaults to `0`),
     * * parent element and `'end'` (sets position at the end of that element),
     * * {@link module:engine/view/item~Item view item} and `'before'` or `'after'` (sets position before or after given view item).
     *
     * This method is a shortcut to other constructors such as:
     *
     * * {@link #createPositionBefore},
     * * {@link #createPositionAfter},
     *
     * @param offset Offset or one of the flags. Used only when the first parameter is a {@link module:engine/view/item~Item view item}.
     */ createPositionAt(itemOrPosition, offset) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(itemOrPosition, offset);
    }
    /**
     * Creates a new position after given view item.
     *
     * @param item View item after which the position should be located.
     */ createPositionAfter(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(item);
    }
    /**
     * Creates a new position before given view item.
     *
     * @param item View item before which the position should be located.
     */ createPositionBefore(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item);
    }
    /**
     * Creates a range spanning from `start` position to `end` position.
     *
     * **Note:** This factory method creates its own {@link module:engine/view/position~Position} instances basing on passed values.
     *
     * @param start Start position.
     * @param end End position. If not set, range will be collapsed at `start` position.
     */ createRange(start, end) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end);
    }
    /**
     * Creates a range that starts before given {@link module:engine/view/item~Item view item} and ends after it.
     */ createRangeOn(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(item);
    }
    /**
     * Creates a range inside an {@link module:engine/view/element~Element element} which starts before the first child of
     * that element and ends after the last child of that element.
     *
     * @param element Element which is a parent for the range.
     */ createRangeIn(element) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(element);
    }
    createSelection(...args) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](...args);
    }
    /**
     * Creates placeholders for child elements of the {@link module:engine/conversion/downcasthelpers~DowncastHelpers#elementToStructure
     * `elementToStructure()`} conversion helper.
     *
     * ```ts
     * const viewSlot = conversionApi.writer.createSlot();
     * const viewPosition = conversionApi.writer.createPositionAt( viewElement, 0 );
     *
     * conversionApi.writer.insert( viewPosition, viewSlot );
     * ```
     *
     * It could be filtered down to a specific subset of children (only `<foo>` model elements in this case):
     *
     * ```ts
     * const viewSlot = conversionApi.writer.createSlot( node => node.is( 'element', 'foo' ) );
     * const viewPosition = conversionApi.writer.createPositionAt( viewElement, 0 );
     *
     * conversionApi.writer.insert( viewPosition, viewSlot );
     * ```
     *
     * While providing a filtered slot, make sure to provide slots for all child nodes. A single node can not be downcasted into
     * multiple slots.
     *
     * **Note**: You should not change the order of nodes. View elements should be in the same order as model nodes.
     *
     * @param modeOrFilter The filter for child nodes.
     * @returns The slot element to be placed in to the view structure while processing
     * {@link module:engine/conversion/downcasthelpers~DowncastHelpers#elementToStructure `elementToStructure()`}.
     */ createSlot(modeOrFilter = 'children') {
        if (!this._slotFactory) {
            /**
             * The `createSlot()` method is only allowed inside the `elementToStructure` downcast helper callback.
             *
             * @error view-writer-invalid-create-slot-context
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-invalid-create-slot-context', this.document);
        }
        return this._slotFactory(this, modeOrFilter);
    }
    /**
     * Registers a slot factory.
     *
     * @internal
     * @param slotFactory The slot factory.
     */ _registerSlotFactory(slotFactory) {
        this._slotFactory = slotFactory;
    }
    /**
     * Clears the registered slot factory.
     *
     * @internal
     */ _clearSlotFactory() {
        this._slotFactory = null;
    }
    /**
     * Inserts a node or nodes at the specified position. Takes care of breaking attributes before insertion
     * and merging them afterwards if requested by the breakAttributes param.
     *
     * @param position Insertion position.
     * @param nodes Node or nodes to insert.
     * @param breakAttributes Whether attributes should be broken.
     * @returns Range around inserted nodes.
     */ _insertNodes(position, nodes, breakAttributes) {
        let parentElement;
        // Break attributes on nodes that do exist in the model tree so they can have attributes, other elements
        // can't have an attribute in model and won't get wrapped with an AttributeElement while down-casted.
        if (breakAttributes) {
            parentElement = getParentContainer(position);
        } else {
            parentElement = position.parent.is('$text') ? position.parent.parent : position.parent;
        }
        if (!parentElement) {
            /**
             * Position's parent container cannot be found.
             *
             * @error view-writer-invalid-position-container
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-invalid-position-container', this.document);
        }
        let insertionPosition;
        if (breakAttributes) {
            insertionPosition = this._breakAttributes(position, true);
        } else {
            insertionPosition = position.parent.is('$text') ? breakTextNode(position) : position;
        }
        const length = parentElement._insertChild(insertionPosition.offset, nodes);
        for (const node of nodes){
            this._addToClonedElementsGroup(node);
        }
        const endPosition = insertionPosition.getShiftedBy(length);
        const start = this.mergeAttributes(insertionPosition);
        // If start position was merged - move end position.
        if (!start.isEqual(insertionPosition)) {
            endPosition.offset--;
        }
        const end = this.mergeAttributes(endPosition);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end);
    }
    /**
     * Wraps children with provided `wrapElement`. Only children contained in `parent` element between
     * `startOffset` and `endOffset` will be wrapped.
     */ _wrapChildren(parent, startOffset, endOffset, wrapElement) {
        let i = startOffset;
        const wrapPositions = [];
        while(i < endOffset){
            const child = parent.getChild(i);
            const isText = child.is('$text');
            const isAttribute = child.is('attributeElement');
            //
            // (In all examples, assume that `wrapElement` is `<span class="foo">` element.)
            //
            // Check if `wrapElement` can be joined with the wrapped element. One of requirements is having same name.
            // If possible, join elements.
            //
            // <p><span class="bar">abc</span></p>  -->  <p><span class="foo bar">abc</span></p>
            //
            if (isAttribute && this._wrapAttributeElement(wrapElement, child)) {
                wrapPositions.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, i));
            } else if (isText || !isAttribute || shouldABeOutsideB(wrapElement, child)) {
                // Clone attribute.
                const newAttribute = wrapElement._clone();
                // Wrap current node with new attribute.
                child._remove();
                newAttribute._appendChild(child);
                parent._insertChild(i, newAttribute);
                this._addToClonedElementsGroup(newAttribute);
                wrapPositions.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, i));
            } else /* if ( isAttribute ) */ {
                this._wrapChildren(child, 0, child.childCount, wrapElement);
            }
            i++;
        }
        // Merge at each wrap.
        let offsetChange = 0;
        for (const position of wrapPositions){
            position.offset -= offsetChange;
            // Do not merge with elements outside selected children.
            if (position.offset == startOffset) {
                continue;
            }
            const newPosition = this.mergeAttributes(position);
            // If nodes were merged - other merge offsets will change.
            if (!newPosition.isEqual(position)) {
                offsetChange++;
                endOffset--;
            }
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromParentsAndOffsets(parent, startOffset, parent, endOffset);
    }
    /**
     * Unwraps children from provided `unwrapElement`. Only children contained in `parent` element between
     * `startOffset` and `endOffset` will be unwrapped.
     */ _unwrapChildren(parent, startOffset, endOffset, unwrapElement) {
        let i = startOffset;
        const unwrapPositions = [];
        // Iterate over each element between provided offsets inside parent.
        // We don't use tree walker or range iterator because we will be removing and merging potentially multiple nodes,
        // so it could get messy. It is safer to it manually in this case.
        while(i < endOffset){
            const child = parent.getChild(i);
            // Skip all text nodes. There should be no container element's here either.
            if (!child.is('attributeElement')) {
                i++;
                continue;
            }
            //
            // (In all examples, assume that `unwrapElement` is `<span class="foo">` element.)
            //
            // If the child is similar to the given attribute element, unwrap it - it will be completely removed.
            //
            // <p><span class="foo">abc</span>xyz</p>  -->  <p>abcxyz</p>
            //
            if (child.isSimilar(unwrapElement)) {
                const unwrapped = child.getChildren();
                const count = child.childCount;
                // Replace wrapper element with its children
                child._remove();
                parent._insertChild(i, unwrapped);
                this._removeFromClonedElementsGroup(child);
                // Save start and end position of moved items.
                unwrapPositions.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, i), new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, i + count));
                // Skip elements that were unwrapped. Assuming there won't be another element to unwrap in child elements.
                i += count;
                endOffset += count - 1;
                continue;
            }
            //
            // If the child is not similar but is an attribute element, try partial unwrapping - remove the same attributes/styles/classes.
            // Partial unwrapping will happen only if the elements have the same name.
            //
            // <p><span class="foo bar">abc</span>xyz</p>  -->  <p><span class="bar">abc</span>xyz</p>
            // <p><i class="foo">abc</i>xyz</p>            -->  <p><i class="foo">abc</i>xyz</p>
            //
            if (this._unwrapAttributeElement(unwrapElement, child)) {
                unwrapPositions.push(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, i), new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](parent, i + 1));
                i++;
                continue;
            }
            //
            // If other nested attribute is found, look through it's children for elements to unwrap.
            //
            // <p><i><span class="foo">abc</span></i><p>  -->  <p><i>abc</i><p>
            //
            this._unwrapChildren(child, 0, child.childCount, unwrapElement);
            i++;
        }
        // Merge at each unwrap.
        let offsetChange = 0;
        for (const position of unwrapPositions){
            position.offset -= offsetChange;
            // Do not merge with elements outside selected children.
            if (position.offset == startOffset || position.offset == endOffset) {
                continue;
            }
            const newPosition = this.mergeAttributes(position);
            // If nodes were merged - other merge offsets will change.
            if (!newPosition.isEqual(position)) {
                offsetChange++;
                endOffset--;
            }
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromParentsAndOffsets(parent, startOffset, parent, endOffset);
    }
    /**
     * Helper function for `view.writer.wrap`. Wraps range with provided attribute element.
     * This method will also merge newly added attribute element with its siblings whenever possible.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError} `view-writer-wrap-invalid-attribute` when passed attribute element is not
     * an instance of {@link module:engine/view/attributeelement~AttributeElement AttributeElement}.
     *
     * @returns New range after wrapping, spanning over wrapping attribute element.
     */ _wrapRange(range, attribute) {
        // Break attributes at range start and end.
        const { start: breakStart, end: breakEnd } = this._breakAttributesRange(range, true);
        const parentContainer = breakStart.parent;
        // Wrap all children with attribute.
        const newRange = this._wrapChildren(parentContainer, breakStart.offset, breakEnd.offset, attribute);
        // Merge attributes at the both ends and return a new range.
        const start = this.mergeAttributes(newRange.start);
        // If start position was merged - move end position back.
        if (!start.isEqual(newRange.start)) {
            newRange.end.offset--;
        }
        const end = this.mergeAttributes(newRange.end);
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end);
    }
    /**
     * Helper function for {@link #wrap}. Wraps position with provided attribute element.
     * This method will also merge newly added attribute element with its siblings whenever possible.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError} `view-writer-wrap-invalid-attribute` when passed attribute element is not
     * an instance of {@link module:engine/view/attributeelement~AttributeElement AttributeElement}.
     *
     * @returns New position after wrapping.
     */ _wrapPosition(position, attribute) {
        // Return same position when trying to wrap with attribute similar to position parent.
        if (attribute.isSimilar(position.parent)) {
            return movePositionToTextNode(position.clone());
        }
        // When position is inside text node - break it and place new position between two text nodes.
        if (position.parent.is('$text')) {
            position = breakTextNode(position);
        }
        // Create fake element that will represent position, and will not be merged with other attributes.
        const fakeElement = this.createAttributeElement('_wrapPosition-fake-element');
        fakeElement._priority = Number.POSITIVE_INFINITY;
        fakeElement.isSimilar = ()=>false;
        // Insert fake element in position location.
        position.parent._insertChild(position.offset, fakeElement);
        // Range around inserted fake attribute element.
        const wrapRange = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position, position.getShiftedBy(1));
        // Wrap fake element with attribute (it will also merge if possible).
        this.wrap(wrapRange, attribute);
        // Remove fake element and place new position there.
        const newPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](fakeElement.parent, fakeElement.index);
        fakeElement._remove();
        // If position is placed between text nodes - merge them and return position inside.
        const nodeBefore = newPosition.nodeBefore;
        const nodeAfter = newPosition.nodeAfter;
        if (nodeBefore instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] && nodeAfter instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            return mergeTextNodes(nodeBefore, nodeAfter);
        }
        // If position is next to text node - move position inside.
        return movePositionToTextNode(newPosition);
    }
    /**
     * Wraps one {@link module:engine/view/attributeelement~AttributeElement AttributeElement} into another by
     * merging them if possible. When merging is possible - all attributes, styles and classes are moved from wrapper
     * element to element being wrapped.
     *
     * @param wrapper Wrapper AttributeElement.
     * @param toWrap AttributeElement to wrap using wrapper element.
     * @returns Returns `true` if elements are merged.
     */ _wrapAttributeElement(wrapper, toWrap) {
        if (!canBeJoined(wrapper, toWrap)) {
            return false;
        }
        // Can't merge if name or priority differs.
        if (wrapper.name !== toWrap.name || wrapper.priority !== toWrap.priority) {
            return false;
        }
        // Check if attributes can be merged.
        for (const key of wrapper.getAttributeKeys()){
            // Classes and styles should be checked separately.
            if (key === 'class' || key === 'style') {
                continue;
            }
            // If some attributes are different we cannot wrap.
            if (toWrap.hasAttribute(key) && toWrap.getAttribute(key) !== wrapper.getAttribute(key)) {
                return false;
            }
        }
        // Check if styles can be merged.
        for (const key of wrapper.getStyleNames()){
            if (toWrap.hasStyle(key) && toWrap.getStyle(key) !== wrapper.getStyle(key)) {
                return false;
            }
        }
        // Move all attributes/classes/styles from wrapper to wrapped AttributeElement.
        for (const key of wrapper.getAttributeKeys()){
            // Classes and styles should be checked separately.
            if (key === 'class' || key === 'style') {
                continue;
            }
            // Move only these attributes that are not present - other are similar.
            if (!toWrap.hasAttribute(key)) {
                this.setAttribute(key, wrapper.getAttribute(key), toWrap);
            }
        }
        for (const key of wrapper.getStyleNames()){
            if (!toWrap.hasStyle(key)) {
                this.setStyle(key, wrapper.getStyle(key), toWrap);
            }
        }
        for (const key of wrapper.getClassNames()){
            if (!toWrap.hasClass(key)) {
                this.addClass(key, toWrap);
            }
        }
        return true;
    }
    /**
     * Unwraps {@link module:engine/view/attributeelement~AttributeElement AttributeElement} from another by removing
     * corresponding attributes, classes and styles. All attributes, classes and styles from wrapper should be present
     * inside element being unwrapped.
     *
     * @param wrapper Wrapper AttributeElement.
     * @param toUnwrap AttributeElement to unwrap using wrapper element.
     * @returns Returns `true` if elements are unwrapped.
     **/ _unwrapAttributeElement(wrapper, toUnwrap) {
        if (!canBeJoined(wrapper, toUnwrap)) {
            return false;
        }
        // Can't unwrap if name or priority differs.
        if (wrapper.name !== toUnwrap.name || wrapper.priority !== toUnwrap.priority) {
            return false;
        }
        // Check if AttributeElement has all wrapper attributes.
        for (const key of wrapper.getAttributeKeys()){
            // Classes and styles should be checked separately.
            if (key === 'class' || key === 'style') {
                continue;
            }
            // If some attributes are missing or different we cannot unwrap.
            if (!toUnwrap.hasAttribute(key) || toUnwrap.getAttribute(key) !== wrapper.getAttribute(key)) {
                return false;
            }
        }
        // Check if AttributeElement has all wrapper classes.
        if (!toUnwrap.hasClass(...wrapper.getClassNames())) {
            return false;
        }
        // Check if AttributeElement has all wrapper styles.
        for (const key of wrapper.getStyleNames()){
            // If some styles are missing or different we cannot unwrap.
            if (!toUnwrap.hasStyle(key) || toUnwrap.getStyle(key) !== wrapper.getStyle(key)) {
                return false;
            }
        }
        // Remove all wrapper's attributes from unwrapped element.
        for (const key of wrapper.getAttributeKeys()){
            // Classes and styles should be checked separately.
            if (key === 'class' || key === 'style') {
                continue;
            }
            this.removeAttribute(key, toUnwrap);
        }
        // Remove all wrapper's classes from unwrapped element.
        this.removeClass(Array.from(wrapper.getClassNames()), toUnwrap);
        // Remove all wrapper's styles from unwrapped element.
        this.removeStyle(Array.from(wrapper.getStyleNames()), toUnwrap);
        return true;
    }
    /**
     * Helper function used by other `DowncastWriter` methods. Breaks attribute elements at the boundaries of given range.
     *
     * @param range Range which `start` and `end` positions will be used to break attributes.
     * @param forceSplitText If set to `true`, will break text nodes even if they are directly in container element.
     * This behavior will result in incorrect view state, but is needed by other view writing methods which then fixes view state.
     * @returns New range with located at break positions.
     */ _breakAttributesRange(range, forceSplitText = false) {
        const rangeStart = range.start;
        const rangeEnd = range.end;
        validateRangeContainer(range, this.document);
        // Break at the collapsed position. Return new collapsed range.
        if (range.isCollapsed) {
            const position = this._breakAttributes(range.start, forceSplitText);
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position, position);
        }
        const breakEnd = this._breakAttributes(rangeEnd, forceSplitText);
        const count = breakEnd.parent.childCount;
        const breakStart = this._breakAttributes(rangeStart, forceSplitText);
        // Calculate new break end offset.
        breakEnd.offset += breakEnd.parent.childCount - count;
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](breakStart, breakEnd);
    }
    /**
     * Helper function used by other `DowncastWriter` methods. Breaks attribute elements at given position.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-writer-cannot-break-empty-element` when break position
     * is placed inside {@link module:engine/view/emptyelement~EmptyElement EmptyElement}.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-writer-cannot-break-ui-element` when break position
     * is placed inside {@link module:engine/view/uielement~UIElement UIElement}.
     *
     * @param position Position where to break attributes.
     * @param forceSplitText If set to `true`, will break text nodes even if they are directly in container element.
     * This behavior will result in incorrect view state, but is needed by other view writing methods which then fixes view state.
     * @returns New position after breaking the attributes.
     */ _breakAttributes(position, forceSplitText = false) {
        const positionOffset = position.offset;
        const positionParent = position.parent;
        // If position is placed inside EmptyElement - throw an exception as we cannot break inside.
        if (position.parent.is('emptyElement')) {
            /**
             * Cannot break an `EmptyElement` instance.
             *
             * This error is thrown if
             * {@link module:engine/view/downcastwriter~DowncastWriter#breakAttributes `DowncastWriter#breakAttributes()`}
             * was executed in an incorrect position.
             *
             * @error view-writer-cannot-break-empty-element
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-cannot-break-empty-element', this.document);
        }
        // If position is placed inside UIElement - throw an exception as we cannot break inside.
        if (position.parent.is('uiElement')) {
            /**
             * Cannot break a `UIElement` instance.
             *
             * This error is thrown if
             * {@link module:engine/view/downcastwriter~DowncastWriter#breakAttributes `DowncastWriter#breakAttributes()`}
             * was executed in an incorrect position.
             *
             * @error view-writer-cannot-break-ui-element
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-cannot-break-ui-element', this.document);
        }
        // If position is placed inside RawElement - throw an exception as we cannot break inside.
        if (position.parent.is('rawElement')) {
            /**
             * Cannot break a `RawElement` instance.
             *
             * This error is thrown if
             * {@link module:engine/view/downcastwriter~DowncastWriter#breakAttributes `DowncastWriter#breakAttributes()`}
             * was executed in an incorrect position.
             *
             * @error view-writer-cannot-break-raw-element
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-cannot-break-raw-element', this.document);
        }
        // There are no attributes to break and text nodes breaking is not forced.
        if (!forceSplitText && positionParent.is('$text') && isContainerOrFragment(positionParent.parent)) {
            return position.clone();
        }
        // Position's parent is container, so no attributes to break.
        if (isContainerOrFragment(positionParent)) {
            return position.clone();
        }
        // Break text and start again in new position.
        if (positionParent.is('$text')) {
            return this._breakAttributes(breakTextNode(position), forceSplitText);
        }
        const length = positionParent.childCount;
        // <p>foo<b><u>bar{}</u></b></p>
        // <p>foo<b><u>bar</u>[]</b></p>
        // <p>foo<b><u>bar</u></b>[]</p>
        if (positionOffset == length) {
            const newPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionParent.parent, positionParent.index + 1);
            return this._breakAttributes(newPosition, forceSplitText);
        } else {
            // <p>foo<b><u>{}bar</u></b></p>
            // <p>foo<b>[]<u>bar</u></b></p>
            // <p>foo{}<b><u>bar</u></b></p>
            if (positionOffset === 0) {
                const newPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionParent.parent, positionParent.index);
                return this._breakAttributes(newPosition, forceSplitText);
            } else {
                const offsetAfter = positionParent.index + 1;
                // Break element.
                const clonedNode = positionParent._clone();
                // Insert cloned node to position's parent node.
                positionParent.parent._insertChild(offsetAfter, clonedNode);
                this._addToClonedElementsGroup(clonedNode);
                // Get nodes to move.
                const count = positionParent.childCount - positionOffset;
                const nodesToMove = positionParent._removeChildren(positionOffset, count);
                // Move nodes to cloned node.
                clonedNode._appendChild(nodesToMove);
                // Create new position to work on.
                const newPosition = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](positionParent.parent, offsetAfter);
                return this._breakAttributes(newPosition, forceSplitText);
            }
        }
    }
    /**
     * Stores the information that an {@link module:engine/view/attributeelement~AttributeElement attribute element} was
     * added to the tree. Saves the reference to the group in the given element and updates the group, so other elements
     * from the group now keep a reference to the given attribute element.
     *
     * The clones group can be obtained using {@link module:engine/view/attributeelement~AttributeElement#getElementsWithSameId}.
     *
     * Does nothing if added element has no {@link module:engine/view/attributeelement~AttributeElement#id id}.
     *
     * @param element Attribute element to save.
     */ _addToClonedElementsGroup(element) {
        // Add only if the element is in document tree.
        if (!element.root.is('rootElement')) {
            return;
        }
        // Traverse the element's children recursively to find other attribute elements that also might got inserted.
        // The loop is at the beginning so we can make fast returns later in the code.
        if (element.is('element')) {
            for (const child of element.getChildren()){
                this._addToClonedElementsGroup(child);
            }
        }
        const id = element.id;
        if (!id) {
            return;
        }
        let group = this._cloneGroups.get(id);
        if (!group) {
            group = new Set();
            this._cloneGroups.set(id, group);
        }
        group.add(element);
        element._clonesGroup = group;
    }
    /**
     * Removes all the information about the given {@link module:engine/view/attributeelement~AttributeElement attribute element}
     * from its clones group.
     *
     * Keep in mind, that the element will still keep a reference to the group (but the group will not keep a reference to it).
     * This allows to reference the whole group even if the element was already removed from the tree.
     *
     * Does nothing if the element has no {@link module:engine/view/attributeelement~AttributeElement#id id}.
     *
     * @param element Attribute element to remove.
     */ _removeFromClonedElementsGroup(element) {
        // Traverse the element's children recursively to find other attribute elements that also got removed.
        // The loop is at the beginning so we can make fast returns later in the code.
        if (element.is('element')) {
            for (const child of element.getChildren()){
                this._removeFromClonedElementsGroup(child);
            }
        }
        const id = element.id;
        if (!id) {
            return;
        }
        const group = this._cloneGroups.get(id);
        if (!group) {
            return;
        }
        group.delete(element);
    // Not removing group from element on purpose!
    // If other parts of code have reference to this element, they will be able to get references to other elements from the group.
    }
}
// Helper function for `view.writer.wrap`. Checks if given element has any children that are not ui elements.
function _hasNonUiChildren(parent) {
    return Array.from(parent.getChildren()).some((child)=>!child.is('uiElement'));
}
/**
 * The `attribute` passed to {@link module:engine/view/downcastwriter~DowncastWriter#wrap `DowncastWriter#wrap()`}
 * must be an instance of {@link module:engine/view/attributeelement~AttributeElement `AttributeElement`}.
 *
 * @error view-writer-wrap-invalid-attribute
 */ /**
 * Returns first parent container of specified {@link module:engine/view/position~Position Position}.
 * Position's parent node is checked as first, then next parents are checked.
 * Note that {@link module:engine/view/documentfragment~DocumentFragment DocumentFragment} is treated like a container.
 *
 * @param position Position used as a start point to locate parent container.
 * @returns Parent container element or `undefined` if container is not found.
 */ function getParentContainer(position) {
    let parent = position.parent;
    while(!isContainerOrFragment(parent)){
        if (!parent) {
            return undefined;
        }
        parent = parent.parent;
    }
    return parent;
}
/**
 * Checks if first {@link module:engine/view/attributeelement~AttributeElement AttributeElement} provided to the function
 * can be wrapped outside second element. It is done by comparing elements'
 * {@link module:engine/view/attributeelement~AttributeElement#priority priorities}, if both have same priority
 * {@link module:engine/view/element~Element#getIdentity identities} are compared.
 */ function shouldABeOutsideB(a, b) {
    if (a.priority < b.priority) {
        return true;
    } else if (a.priority > b.priority) {
        return false;
    }
    // When priorities are equal and names are different - use identities.
    return a.getIdentity() < b.getIdentity();
}
/**
 * Returns new position that is moved to near text node. Returns same position if there is no text node before of after
 * specified position.
 *
 * ```html
 * <p>foo[]</p>  ->  <p>foo{}</p>
 * <p>[]foo</p>  ->  <p>{}foo</p>
 * ```
 *
 * @returns Position located inside text node or same position if there is no text nodes
 * before or after position location.
 */ function movePositionToTextNode(position) {
    const nodeBefore = position.nodeBefore;
    if (nodeBefore && nodeBefore.is('$text')) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodeBefore, nodeBefore.data.length);
    }
    const nodeAfter = position.nodeAfter;
    if (nodeAfter && nodeAfter.is('$text')) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodeAfter, 0);
    }
    return position;
}
/**
 * Breaks text node into two text nodes when possible.
 *
 * ```html
 * <p>foo{}bar</p> -> <p>foo[]bar</p>
 * <p>{}foobar</p> -> <p>[]foobar</p>
 * <p>foobar{}</p> -> <p>foobar[]</p>
 * ```
 *
 * @param position Position that need to be placed inside text node.
 * @returns New position after breaking text node.
 */ function breakTextNode(position) {
    if (position.offset == position.parent.data.length) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position.parent.parent, position.parent.index + 1);
    }
    if (position.offset === 0) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position.parent.parent, position.parent.index);
    }
    // Get part of the text that need to be moved.
    const textToMove = position.parent.data.slice(position.offset);
    // Leave rest of the text in position's parent.
    position.parent._data = position.parent.data.slice(0, position.offset);
    // Insert new text node after position's parent text node.
    position.parent.parent._insertChild(position.parent.index + 1, new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position.root.document, textToMove));
    // Return new position between two newly created text nodes.
    return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](position.parent.parent, position.parent.index + 1);
}
/**
 * Merges two text nodes into first node. Removes second node and returns merge position.
 *
 * @param t1 First text node to merge. Data from second text node will be moved at the end of this text node.
 * @param t2 Second text node to merge. This node will be removed after merging.
 * @returns Position after merging text nodes.
 */ function mergeTextNodes(t1, t2) {
    // Merge text data into first text node and remove second one.
    const nodeBeforeLength = t1.data.length;
    t1._data += t2.data;
    t2._remove();
    return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](t1, nodeBeforeLength);
}
const validNodesToInsert = [
    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$containerelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$emptyelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$rawelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
];
/**
 * Checks if provided nodes are valid to insert.
 *
 * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-writer-insert-invalid-node` when nodes to insert
 * contains instances that are not supported ones (see error description for valid ones.
 */ function validateNodesToInsert(nodes, errorContext) {
    for (const node of nodes){
        if (!validNodesToInsert.some((validNode)=>node instanceof validNode)) {
            /**
             * One of the nodes to be inserted is of an invalid type.
             *
             * Nodes to be inserted with {@link module:engine/view/downcastwriter~DowncastWriter#insert `DowncastWriter#insert()`} should be
             * of the following types:
             *
             * * {@link module:engine/view/attributeelement~AttributeElement AttributeElement},
             * * {@link module:engine/view/containerelement~ContainerElement ContainerElement},
             * * {@link module:engine/view/emptyelement~EmptyElement EmptyElement},
             * * {@link module:engine/view/uielement~UIElement UIElement},
             * * {@link module:engine/view/rawelement~RawElement RawElement},
             * * {@link module:engine/view/text~Text Text}.
             *
             * @error view-writer-insert-invalid-node-type
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-insert-invalid-node-type', errorContext);
        }
        if (!node.is('$text')) {
            validateNodesToInsert(node.getChildren(), errorContext);
        }
    }
}
/**
 * Checks if node is ContainerElement or DocumentFragment, because in most cases they should be treated the same way.
 *
 * @returns Returns `true` if node is instance of ContainerElement or DocumentFragment.
 */ function isContainerOrFragment(node) {
    return node && (node.is('containerElement') || node.is('documentFragment'));
}
/**
 * Checks if {@link module:engine/view/range~Range#start range start} and {@link module:engine/view/range~Range#end range end} are placed
 * inside same {@link module:engine/view/containerelement~ContainerElement container element}.
 * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `view-writer-invalid-range-container` when validation fails.
 */ function validateRangeContainer(range, errorContext) {
    const startContainer = getParentContainer(range.start);
    const endContainer = getParentContainer(range.end);
    if (!startContainer || !endContainer || startContainer !== endContainer) {
        /**
         * The container of the given range is invalid.
         *
         * This may happen if {@link module:engine/view/range~Range#start range start} and
         * {@link module:engine/view/range~Range#end range end} positions are not placed inside the same container element or
         * a parent container for these positions cannot be found.
         *
         * Methods like {@link module:engine/view/downcastwriter~DowncastWriter#wrap `DowncastWriter#remove()`},
         * {@link module:engine/view/downcastwriter~DowncastWriter#wrap `DowncastWriter#clean()`},
         * {@link module:engine/view/downcastwriter~DowncastWriter#wrap `DowncastWriter#wrap()`},
         * {@link module:engine/view/downcastwriter~DowncastWriter#wrap `DowncastWriter#unwrap()`} need to be called
         * on a range that has its start and end positions located in the same container element. Both positions can be
         * nested within other elements (e.g. an attribute element) but the closest container ancestor must be the same.
         *
         * @error view-writer-invalid-range-container
         */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-writer-invalid-range-container', errorContext);
    }
}
/**
 * Checks if two attribute elements can be joined together. Elements can be joined together if, and only if
 * they do not have ids specified.
 */ function canBeJoined(a, b) {
    return a.id === null && b.id === null;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/filler.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "BR_FILLER",
    ()=>BR_FILLER,
    "INLINE_FILLER",
    ()=>INLINE_FILLER,
    "INLINE_FILLER_LENGTH",
    ()=>INLINE_FILLER_LENGTH,
    "MARKED_NBSP_FILLER",
    ()=>MARKED_NBSP_FILLER,
    "NBSP_FILLER",
    ()=>NBSP_FILLER,
    "getDataWithoutFiller",
    ()=>getDataWithoutFiller,
    "injectQuirksHandling",
    ()=>injectQuirksHandling,
    "isInlineFiller",
    ()=>isInlineFiller,
    "startsWithFiller",
    ()=>startsWithFiller
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/keyboard.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/istext.js [app-ssr] (ecmascript) <export default as isText>");
;
const NBSP_FILLER = (domDocument)=>domDocument.createTextNode('\u00A0');
const MARKED_NBSP_FILLER = (domDocument)=>{
    const span = domDocument.createElement('span');
    span.dataset.ckeFiller = 'true';
    span.innerText = '\u00A0';
    return span;
};
const BR_FILLER = (domDocument)=>{
    const fillerBr = domDocument.createElement('br');
    fillerBr.dataset.ckeFiller = 'true';
    return fillerBr;
};
const INLINE_FILLER_LENGTH = 7;
const INLINE_FILLER = '\u2060'.repeat(INLINE_FILLER_LENGTH);
function startsWithFiller(domNode) {
    if (typeof domNode == 'string') {
        return domNode.substr(0, INLINE_FILLER_LENGTH) === INLINE_FILLER;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(domNode) && domNode.data.substr(0, INLINE_FILLER_LENGTH) === INLINE_FILLER;
}
function isInlineFiller(domText) {
    return domText.data.length == INLINE_FILLER_LENGTH && startsWithFiller(domText);
}
function getDataWithoutFiller(domText) {
    const data = typeof domText == 'string' ? domText : domText.data;
    if (startsWithFiller(domText)) {
        return data.slice(INLINE_FILLER_LENGTH);
    }
    return data;
}
function injectQuirksHandling(view) {
    view.document.on('arrowKey', jumpOverInlineFiller, {
        priority: 'low'
    });
}
/**
 * Move cursor from the end of the inline filler to the beginning of it when, so the filler does not break navigation.
 */ function jumpOverInlineFiller(evt, data) {
    if (data.keyCode == __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["keyCodes"].arrowleft) {
        const domSelection = data.domTarget.ownerDocument.defaultView.getSelection();
        if (domSelection.rangeCount == 1 && domSelection.getRangeAt(0).collapsed) {
            const domParent = domSelection.getRangeAt(0).startContainer;
            const domOffset = domSelection.getRangeAt(0).startOffset;
            if (startsWithFiller(domParent) && domOffset <= INLINE_FILLER_LENGTH) {
                domSelection.collapse(domParent, 0);
            }
        }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/renderer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/renderer
 */ __turbopack_context__.s([
    "default",
    ()=>Renderer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/filler.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/observablemixin.js [app-ssr] (ecmascript) <export default as ObservableMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$diff$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__diff$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/diff.js [app-ssr] (ecmascript) <export default as diff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/env.js [app-ssr] (ecmascript) <export default as env>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$fastdiff$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fastDiff$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/fastdiff.js [app-ssr] (ecmascript) <export default as fastDiff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$insertat$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__insertAt$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/insertat.js [app-ssr] (ecmascript) <export default as insertAt>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$iscomment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isComment$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/iscomment.js [app-ssr] (ecmascript) <export default as isComment>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$isnode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isNode$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/isnode.js [app-ssr] (ecmascript) <export default as isNode>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/istext.js [app-ssr] (ecmascript) <export default as isText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$remove$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__remove$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/remove.js [app-ssr] (ecmascript) <export default as remove>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$indexof$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__indexOf$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/indexof.js [app-ssr] (ecmascript) <export default as indexOf>");
;
;
;
;
;
class Renderer extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])() {
    /**
     * Creates a renderer instance.
     *
     * @param domConverter Converter instance.
     * @param selection View selection.
     */ constructor(domConverter, selection){
        super();
        /**
         * Set of DOM Documents instances.
         */ this.domDocuments = new Set();
        /**
         * Set of nodes which attributes changed and may need to be rendered.
         */ this.markedAttributes = new Set();
        /**
         * Set of elements which child lists changed and may need to be rendered.
         */ this.markedChildren = new Set();
        /**
         * Set of text nodes which text data changed and may need to be rendered.
         */ this.markedTexts = new Set();
        /**
         * The text node in which the inline filler was rendered.
         */ this._inlineFiller = null;
        /**
         * DOM element containing fake selection.
         */ this._fakeSelectionContainer = null;
        this.domConverter = domConverter;
        this.selection = selection;
        this.set('isFocused', false);
        this.set('isSelecting', false);
        // Rendering the selection and inline filler manipulation should be postponed in (non-Android) Blink until the user finishes
        // creating the selection in DOM to avoid accidental selection collapsing
        // (https://github.com/ckeditor/ckeditor5/issues/10562, https://github.com/ckeditor/ckeditor5/issues/10723).
        // When the user stops selecting, all pending changes should be rendered ASAP, though.
        if (__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isBlink && !__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid) {
            this.on('change:isSelecting', ()=>{
                if (!this.isSelecting) {
                    this.render();
                }
            });
        }
        this.set('isComposing', false);
        this.on('change:isComposing', ()=>{
            if (!this.isComposing) {
                this.render();
            }
        });
    }
    /**
     * Marks a view node to be updated in the DOM by {@link #render `render()`}.
     *
     * Note that only view nodes whose parents have corresponding DOM elements need to be marked to be synchronized.
     *
     * @see #markedAttributes
     * @see #markedChildren
     * @see #markedTexts
     *
     * @param type Type of the change.
     * @param node ViewNode to be marked.
     */ markToSync(type, node) {
        if (type === 'text') {
            if (this.domConverter.mapViewToDom(node.parent)) {
                this.markedTexts.add(node);
            }
        } else {
            // If the node has no DOM element it is not rendered yet,
            // its children/attributes do not need to be marked to be sync.
            if (!this.domConverter.mapViewToDom(node)) {
                return;
            }
            if (type === 'attributes') {
                this.markedAttributes.add(node);
            } else if (type === 'children') {
                this.markedChildren.add(node);
            } else {
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const unreachable = type;
                /**
                 * Unknown type passed to Renderer.markToSync.
                 *
                 * @error view-renderer-unknown-type
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-renderer-unknown-type', this);
            }
        }
    }
    /**
     * Renders all buffered changes ({@link #markedAttributes}, {@link #markedChildren} and {@link #markedTexts}) and
     * the current view selection (if needed) to the DOM by applying a minimal set of changes to it.
     *
     * Renderer tries not to break the text composition (e.g. IME) and x-index of the selection,
     * so it does as little as it is needed to update the DOM.
     *
     * Renderer also handles {@link module:engine/view/filler fillers}. Especially, it checks if the inline filler is needed
     * at the selection position and adds or removes it. To prevent breaking text composition inline filler will not be
     * removed as long as the selection is in the text node which needed it at first.
     */ render() {
        // Ignore rendering while in the composition mode. Composition events are not cancellable and browser will modify the DOM tree.
        // All marked elements, attributes, etc. will wait until next render after the composition ends.
        // On Android composition events are immediately applied to the model, so we don't need to skip rendering,
        // and we should not do it because the difference between view and DOM could lead to position mapping problems.
        if (this.isComposing && !__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid) {
            // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
            // @if CK_DEBUG_TYPING // 	console.info( '%c[Renderer]%c Rendering aborted while isComposing',
            // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', ''
            // @if CK_DEBUG_TYPING // 	);
            // @if CK_DEBUG_TYPING // }
            return;
        }
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.group( '%c[Renderer]%c Rendering',
        // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', ''
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        let inlineFillerPosition = null;
        const isInlineFillerRenderingPossible = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isBlink && !__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid ? !this.isSelecting : true;
        // Refresh mappings.
        for (const element of this.markedChildren){
            this._updateChildrenMappings(element);
        }
        // Don't manipulate inline fillers while the selection is being made in (non-Android) Blink to prevent accidental
        // DOM selection collapsing
        // (https://github.com/ckeditor/ckeditor5/issues/10562, https://github.com/ckeditor/ckeditor5/issues/10723).
        if (isInlineFillerRenderingPossible) {
            // There was inline filler rendered in the DOM but it's not
            // at the selection position any more, so we can remove it
            // (cause even if it's needed, it must be placed in another location).
            if (this._inlineFiller && !this._isSelectionInInlineFiller()) {
                this._removeInlineFiller();
            }
            // If we've got the filler, let's try to guess its position in the view.
            if (this._inlineFiller) {
                inlineFillerPosition = this._getInlineFillerPosition();
            } else if (this._needsInlineFillerAtSelection()) {
                inlineFillerPosition = this.selection.getFirstPosition();
                // Do not use `markToSync` so it will be added even if the parent is already added.
                this.markedChildren.add(inlineFillerPosition.parent);
            }
        } else if (this._inlineFiller && this._inlineFiller.parentNode) {
            // While the user is making selection, preserve the inline filler at its original position.
            inlineFillerPosition = this.domConverter.domPositionToView(this._inlineFiller);
            // While down-casting the document selection attributes, all existing empty
            // attribute elements (for selection position) are removed from the view and DOM,
            // so make sure that we were able to map filler position.
            // https://github.com/ckeditor/ckeditor5/issues/12026
            if (inlineFillerPosition && inlineFillerPosition.parent.is('$text')) {
                // The inline filler position is expected to be before the text node.
                inlineFillerPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(inlineFillerPosition.parent);
            }
        }
        for (const element of this.markedAttributes){
            this._updateAttrs(element);
        }
        for (const element of this.markedChildren){
            this._updateChildren(element, {
                inlineFillerPosition
            });
        }
        for (const node of this.markedTexts){
            if (!this.markedChildren.has(node.parent) && this.domConverter.mapViewToDom(node.parent)) {
                this._updateText(node, {
                    inlineFillerPosition
                });
            }
        }
        // * Check whether the inline filler is required and where it really is in the DOM.
        //   At this point in most cases it will be in the DOM, but there are exceptions.
        //   For example, if the inline filler was deep in the created DOM structure, it will not be created.
        //   Similarly, if it was removed at the beginning of this function and then neither text nor children were updated,
        //   it will not be present. Fix those and similar scenarios.
        // * Don't manipulate inline fillers while the selection is being made in (non-Android) Blink to prevent accidental
        //   DOM selection collapsing
        //   (https://github.com/ckeditor/ckeditor5/issues/10562, https://github.com/ckeditor/ckeditor5/issues/10723).
        if (isInlineFillerRenderingPossible) {
            if (inlineFillerPosition) {
                const fillerDomPosition = this.domConverter.viewPositionToDom(inlineFillerPosition);
                const domDocument = fillerDomPosition.parent.ownerDocument;
                if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["startsWithFiller"])(fillerDomPosition.parent)) {
                    // Filler has not been created at filler position. Create it now.
                    this._inlineFiller = addInlineFiller(domDocument, fillerDomPosition.parent, fillerDomPosition.offset);
                } else {
                    // Filler has been found, save it.
                    this._inlineFiller = fillerDomPosition.parent;
                }
            } else {
                // There is no filler needed.
                this._inlineFiller = null;
            }
        }
        // First focus the new editing host, then update the selection.
        // Otherwise, FF may throw an error (https://github.com/ckeditor/ckeditor5/issues/721).
        this._updateFocus();
        this._updateSelection();
        this.domConverter._clearTemporaryCustomProperties();
        this.markedTexts.clear();
        this.markedAttributes.clear();
        this.markedChildren.clear();
    // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
    // @if CK_DEBUG_TYPING // 	console.groupEnd();
    // @if CK_DEBUG_TYPING // }
    }
    /**
     * Updates mappings of view element's children.
     *
     * Children that were replaced in the view structure by similar elements (same tag name) are treated as 'replaced'.
     * This means that their mappings can be updated so the new view elements are mapped to the existing DOM elements.
     * Thanks to that these elements do not need to be re-rendered completely.
     *
     * @param viewElement The view element whose children mappings will be updated.
     */ _updateChildrenMappings(viewElement) {
        const domElement = this.domConverter.mapViewToDom(viewElement);
        if (!domElement) {
            // If there is no `domElement` it means that it was already removed from DOM and there is no need to process it.
            return;
        }
        // Removing nodes from the DOM as we iterate can cause `actualDomChildren`
        // (which is a live-updating `NodeList`) to get out of sync with the
        // indices that we compute as we iterate over `actions`.
        // This would produce incorrect element mappings.
        //
        // Converting live list to an array to make the list static.
        const actualDomChildren = Array.from(domElement.childNodes);
        const expectedDomChildren = Array.from(this.domConverter.viewChildrenToDom(viewElement, {
            withChildren: false
        }));
        const diff = this._diffNodeLists(actualDomChildren, expectedDomChildren);
        const actions = this._findUpdateActions(diff, actualDomChildren, expectedDomChildren, areSimilarElements);
        if (actions.indexOf('update') !== -1) {
            const counter = {
                equal: 0,
                insert: 0,
                delete: 0
            };
            for (const action of actions){
                if (action === 'update') {
                    const insertIndex = counter.equal + counter.insert;
                    const deleteIndex = counter.equal + counter.delete;
                    const viewChild = viewElement.getChild(insertIndex);
                    // UIElement and RawElement are special cases. Their children are not stored in a view (#799)
                    // so we cannot use them with replacing flow (since they use view children during rendering
                    // which will always result in rendering empty elements).
                    if (viewChild && !viewChild.is('uiElement') && !viewChild.is('rawElement')) {
                        this._updateElementMappings(viewChild, actualDomChildren[deleteIndex]);
                    }
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$remove$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__remove$3e$__["remove"])(expectedDomChildren[insertIndex]);
                    counter.equal++;
                } else {
                    counter[action]++;
                }
            }
        }
    }
    /**
     * Updates mappings of a given view element.
     *
     * @param viewElement The view element whose mappings will be updated.
     * @param domElement The DOM element representing the given view element.
     */ _updateElementMappings(viewElement, domElement) {
        // Remap 'DomConverter' bindings.
        this.domConverter.unbindDomElement(domElement);
        this.domConverter.bindElements(domElement, viewElement);
        // View element may have children which needs to be updated, but are not marked, mark them to update.
        this.markedChildren.add(viewElement);
        // Because we replace new view element mapping with the existing one, the corresponding DOM element
        // will not be rerendered. The new view element may have different attributes than the previous one.
        // Since its corresponding DOM element will not be rerendered, new attributes will not be added
        // to the DOM, so we need to mark it here to make sure its attributes gets updated. See #1427 for more
        // detailed case study.
        // Also there are cases where replaced element is removed from the view structure and then has
        // its attributes changed or removed. In such cases the element will not be present in `markedAttributes`
        // and also may be the same (`element.isSimilar()`) as the reused element not having its attributes updated.
        // To prevent such situations we always mark reused element to have its attributes rerenderd (#1560).
        this.markedAttributes.add(viewElement);
    }
    /**
     * Gets the position of the inline filler based on the current selection.
     * Here, we assume that we know that the filler is needed and
     * {@link #_isSelectionInInlineFiller is at the selection position}, and, since it is needed,
     * it is somewhere at the selection position.
     *
     * Note: The filler position cannot be restored based on the filler's DOM text node, because
     * when this method is called (before rendering), the bindings will often be broken. View-to-DOM
     * bindings are only dependable after rendering.
     */ _getInlineFillerPosition() {
        const firstPos = this.selection.getFirstPosition();
        if (firstPos.parent.is('$text')) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(firstPos.parent);
        } else {
            return firstPos;
        }
    }
    /**
     * Returns `true` if the selection has not left the inline filler's text node.
     * If it is `true`, it means that the filler had been added for a reason and the selection did not
     * leave the filler's text node. For example, the user can be in the middle of a composition so it should not be touched.
     *
     * @returns `true` if the inline filler and selection are in the same place.
     */ _isSelectionInInlineFiller() {
        if (this.selection.rangeCount != 1 || !this.selection.isCollapsed) {
            return false;
        }
        // Note, we can't check if selection's position equals position of the
        // this._inlineFiller node, because of #663. We may not be able to calculate
        // the filler's position in the view at this stage.
        // Instead, we check it the other way – whether selection is anchored in
        // that text node or next to it.
        // Possible options are:
        // "FILLER{}"
        // "FILLERadded-text{}"
        const selectionPosition = this.selection.getFirstPosition();
        const position = this.domConverter.viewPositionToDom(selectionPosition);
        if (position && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(position.parent) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["startsWithFiller"])(position.parent)) {
            return true;
        }
        return false;
    }
    /**
     * Removes the inline filler.
     */ _removeInlineFiller() {
        const domFillerNode = this._inlineFiller;
        // Something weird happened and the stored node doesn't contain the filler's text.
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["startsWithFiller"])(domFillerNode)) {
            /**
             * The inline filler node was lost. Most likely, something overwrote the filler text node
             * in the DOM.
             *
             * @error view-renderer-filler-was-lost
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-renderer-filler-was-lost', this);
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInlineFiller"])(domFillerNode)) {
            domFillerNode.remove();
        } else {
            domFillerNode.data = domFillerNode.data.substr(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["INLINE_FILLER_LENGTH"]);
        }
        this._inlineFiller = null;
    }
    /**
     * Checks if the inline {@link module:engine/view/filler filler} should be added.
     *
     * @returns `true` if the inline filler should be added.
     */ _needsInlineFillerAtSelection() {
        if (this.selection.rangeCount != 1 || !this.selection.isCollapsed) {
            return false;
        }
        const selectionPosition = this.selection.getFirstPosition();
        const selectionParent = selectionPosition.parent;
        const selectionOffset = selectionPosition.offset;
        // If there is no DOM root we do not care about fillers.
        if (!this.domConverter.mapViewToDom(selectionParent.root)) {
            return false;
        }
        if (!selectionParent.is('element')) {
            return false;
        }
        // Prevent adding inline filler inside elements with contenteditable=false.
        // https://github.com/ckeditor/ckeditor5-engine/issues/1170
        if (!isEditable(selectionParent)) {
            return false;
        }
        const nodeBefore = selectionPosition.nodeBefore;
        const nodeAfter = selectionPosition.nodeAfter;
        if (nodeBefore instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || nodeAfter instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            return false;
        }
        // We have block filler, we do not need inline one.
        if (selectionOffset === selectionParent.getFillerOffset() && (!nodeBefore || !nodeBefore.is('element', 'br'))) {
            return false;
        }
        // Do not use inline filler while typing outside inline elements on Android.
        // The deleteContentBackward would remove part of the inline filler instead of removing last letter in a link.
        if (__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid && (nodeBefore || nodeAfter)) {
            return false;
        }
        return true;
    }
    /**
     * Checks if text needs to be updated and possibly updates it.
     *
     * @param viewText View text to update.
     * @param options.inlineFillerPosition The position where the inline filler should be rendered.
     */ _updateText(viewText, options) {
        const domText = this.domConverter.findCorrespondingDomText(viewText);
        const newDomText = this.domConverter.viewToDom(viewText);
        let expectedText = newDomText.data;
        const filler = options.inlineFillerPosition;
        if (filler && filler.parent == viewText.parent && filler.offset == viewText.index) {
            expectedText = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["INLINE_FILLER"] + expectedText;
        }
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.group( '%c[Renderer]%c Update text',
        // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', ''
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        updateTextNode(domText, expectedText);
    // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
    // @if CK_DEBUG_TYPING // 	console.groupEnd();
    // @if CK_DEBUG_TYPING // }
    }
    /**
     * Checks if attribute list needs to be updated and possibly updates it.
     *
     * @param viewElement The view element to update.
     */ _updateAttrs(viewElement) {
        const domElement = this.domConverter.mapViewToDom(viewElement);
        if (!domElement) {
            // If there is no `domElement` it means that 'viewElement' is outdated as its mapping was updated
            // in 'this._updateChildrenMappings()'. There is no need to process it as new view element which
            // replaced old 'viewElement' mapping was also added to 'this.markedAttributes'
            // in 'this._updateChildrenMappings()' so it will be processed separately.
            return;
        }
        const domAttrKeys = Array.from(domElement.attributes).map((attr)=>attr.name);
        const viewAttrKeys = viewElement.getAttributeKeys();
        // Add or overwrite attributes.
        for (const key of viewAttrKeys){
            this.domConverter.setDomElementAttribute(domElement, key, viewElement.getAttribute(key), viewElement);
        }
        // Remove from DOM attributes which do not exists in the view.
        for (const key of domAttrKeys){
            // All other attributes not present in the DOM should be removed.
            if (!viewElement.hasAttribute(key)) {
                this.domConverter.removeDomElementAttribute(domElement, key);
            }
        }
    }
    /**
     * Checks if elements child list needs to be updated and possibly updates it.
     *
     * Note that on Android, to reduce the risk of composition breaks, it tries to update data of an existing
     * child text nodes instead of replacing them completely.
     *
     * @param viewElement View element to update.
     * @param options.inlineFillerPosition The position where the inline filler should be rendered.
     */ _updateChildren(viewElement, options) {
        const domElement = this.domConverter.mapViewToDom(viewElement);
        if (!domElement) {
            // If there is no `domElement` it means that it was already removed from DOM.
            // There is no need to process it. It will be processed when re-inserted.
            return;
        }
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.group( '%c[Renderer]%c Update children',
        // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', ''
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        // IME on Android inserts a new text node while typing after a link
        // instead of updating an existing text node that follows the link.
        // We must normalize those text nodes so the diff won't get confused.
        // https://github.com/ckeditor/ckeditor5/issues/12574.
        if (__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid) {
            let previousDomNode = null;
            for (const domNode of Array.from(domElement.childNodes)){
                if (previousDomNode && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(previousDomNode) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(domNode)) {
                    domElement.normalize();
                    break;
                }
                previousDomNode = domNode;
            }
        }
        const inlineFillerPosition = options.inlineFillerPosition;
        const actualDomChildren = domElement.childNodes;
        const expectedDomChildren = Array.from(this.domConverter.viewChildrenToDom(viewElement, {
            bind: true
        }));
        // Inline filler element has to be created as it is present in the DOM, but not in the view. It is required
        // during diffing so text nodes could be compared correctly and also during rendering to maintain
        // proper order and indexes while updating the DOM.
        if (inlineFillerPosition && inlineFillerPosition.parent === viewElement) {
            addInlineFiller(domElement.ownerDocument, expectedDomChildren, inlineFillerPosition.offset);
        }
        const diff = this._diffNodeLists(actualDomChildren, expectedDomChildren);
        // We need to make sure that we update the existing text node and not replace it with another one.
        // The composition and different "language" browser extensions are fragile to text node being completely replaced.
        const actions = this._findUpdateActions(diff, actualDomChildren, expectedDomChildren, areTextNodes);
        let i = 0;
        const nodesToUnbind = new Set();
        // Handle deletions first.
        // This is to prevent a situation where an element that already exists in `actualDomChildren` is inserted at a different
        // index in `actualDomChildren`. Since `actualDomChildren` is a `NodeList`, this works like move, not like an insert,
        // and it disrupts the whole algorithm. See https://github.com/ckeditor/ckeditor5/issues/6367.
        //
        // It doesn't matter in what order we remove or add nodes, as long as we remove and add correct nodes at correct indexes.
        for (const action of actions){
            if (action === 'delete') {
                // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
                // @if CK_DEBUG_TYPING // 	console.info( '%c[Renderer]%c Remove node',
                // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', '', actualDomChildren[ i ]
                // @if CK_DEBUG_TYPING // 	);
                // @if CK_DEBUG_TYPING // }
                nodesToUnbind.add(actualDomChildren[i]);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$remove$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__remove$3e$__["remove"])(actualDomChildren[i]);
            } else if (action === 'equal' || action === 'update') {
                i++;
            }
        }
        i = 0;
        for (const action of actions){
            if (action === 'insert') {
                // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
                // @if CK_DEBUG_TYPING // 	console.info( '%c[Renderer]%c Insert node',
                // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', '', expectedDomChildren[ i ]
                // @if CK_DEBUG_TYPING // 	);
                // @if CK_DEBUG_TYPING // }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$insertat$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__insertAt$3e$__["insertAt"])(domElement, i, expectedDomChildren[i]);
                i++;
            } else if (action === 'update') {
                // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
                // @if CK_DEBUG_TYPING // 	console.group( '%c[Renderer]%c Update text node',
                // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', ''
                // @if CK_DEBUG_TYPING // 	);
                // @if CK_DEBUG_TYPING // }
                updateTextNode(actualDomChildren[i], expectedDomChildren[i].data);
                i++;
            // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
            // @if CK_DEBUG_TYPING // 	console.groupEnd();
            // @if CK_DEBUG_TYPING // }
            } else if (action === 'equal') {
                // Force updating text nodes inside elements which did not change and do not need to be re-rendered (#1125).
                // Do it here (not in the loop above) because only after insertions the `i` index is correct.
                this._markDescendantTextToSync(this.domConverter.domToView(expectedDomChildren[i]));
                i++;
            }
        }
        // Unbind removed nodes. When node does not have a parent it means that it was removed from DOM tree during
        // comparison with the expected DOM. We don't need to check child nodes, because if child node was reinserted,
        // it was moved to DOM tree out of the removed node.
        for (const node of nodesToUnbind){
            if (!node.parentNode) {
                this.domConverter.unbindDomElement(node);
            }
        }
    // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
    // @if CK_DEBUG_TYPING // 	console.groupEnd();
    // @if CK_DEBUG_TYPING // }
    }
    /**
     * Shorthand for diffing two arrays or node lists of DOM nodes.
     *
     * @param actualDomChildren Actual DOM children
     * @param expectedDomChildren Expected DOM children.
     * @returns The list of actions based on the {@link module:utils/diff~diff} function.
     */ _diffNodeLists(actualDomChildren, expectedDomChildren) {
        actualDomChildren = filterOutFakeSelectionContainer(actualDomChildren, this._fakeSelectionContainer);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$diff$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__diff$3e$__["diff"])(actualDomChildren, expectedDomChildren, sameNodes.bind(null, this.domConverter));
    }
    /**
     * Finds DOM nodes that were replaced with the similar nodes (same tag name) in the view. All nodes are compared
     * within one `insert`/`delete` action group, for example:
     *
     * ```
     * Actual DOM:		<p><b>Foo</b>Bar<i>Baz</i><b>Bax</b></p>
     * Expected DOM:	<p>Bar<b>123</b><i>Baz</i><b>456</b></p>
     * Input actions:	[ insert, insert, delete, delete, equal, insert, delete ]
     * Output actions:	[ insert, replace, delete, equal, replace ]
     * ```
     *
     * @param actions Actions array which is a result of the {@link module:utils/diff~diff} function.
     * @param actualDom Actual DOM children
     * @param expectedDom Expected DOM children.
     * @param comparator A comparator function that should return `true` if the given node should be reused
     * (either by the update of a text node data or an element children list for similar elements).
     * @returns Actions array modified with the `update` actions.
     */ _findUpdateActions(actions, actualDom, expectedDom, comparator) {
        // If there is no both 'insert' and 'delete' actions, no need to check for replaced elements.
        if (actions.indexOf('insert') === -1 || actions.indexOf('delete') === -1) {
            return actions;
        }
        let newActions = [];
        let actualSlice = [];
        let expectedSlice = [];
        const counter = {
            equal: 0,
            insert: 0,
            delete: 0
        };
        for (const action of actions){
            if (action === 'insert') {
                expectedSlice.push(expectedDom[counter.equal + counter.insert]);
            } else if (action === 'delete') {
                actualSlice.push(actualDom[counter.equal + counter.delete]);
            } else {
                newActions = newActions.concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$diff$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__diff$3e$__["diff"])(actualSlice, expectedSlice, comparator).map((action)=>action === 'equal' ? 'update' : action));
                newActions.push('equal');
                // Reset stored elements on 'equal'.
                actualSlice = [];
                expectedSlice = [];
            }
            counter[action]++;
        }
        return newActions.concat((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$diff$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__diff$3e$__["diff"])(actualSlice, expectedSlice, comparator).map((action)=>action === 'equal' ? 'update' : action));
    }
    /**
     * Marks text nodes to be synchronized.
     *
     * If a text node is passed, it will be marked. If an element is passed, all descendant text nodes inside it will be marked.
     *
     * @param viewNode View node to sync.
     */ _markDescendantTextToSync(viewNode) {
        if (!viewNode) {
            return;
        }
        if (viewNode.is('$text')) {
            this.markedTexts.add(viewNode);
        } else if (viewNode.is('element')) {
            for (const child of viewNode.getChildren()){
                this._markDescendantTextToSync(child);
            }
        }
    }
    /**
     * Checks if the selection needs to be updated and possibly updates it.
     */ _updateSelection() {
        // Block updating DOM selection in (non-Android) Blink while the user is selecting to prevent accidental selection collapsing.
        // Note: Structural changes in DOM must trigger selection rendering, though. Nodes the selection was anchored
        // to, may disappear in DOM which would break the selection (e.g. in real-time collaboration scenarios).
        // https://github.com/ckeditor/ckeditor5/issues/10562, https://github.com/ckeditor/ckeditor5/issues/10723
        if (__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isBlink && !__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid && this.isSelecting && !this.markedChildren.size) {
            return;
        }
        // If there is no selection - remove DOM and fake selections.
        if (this.selection.rangeCount === 0) {
            this._removeDomSelection();
            this._removeFakeSelection();
            return;
        }
        const domRoot = this.domConverter.mapViewToDom(this.selection.editableElement);
        // Do nothing if there is no focus, or there is no DOM element corresponding to selection's editable element.
        if (!this.isFocused || !domRoot) {
            return;
        }
        // Render fake selection - create the fake selection container (if needed) and move DOM selection to it.
        if (this.selection.isFake) {
            this._updateFakeSelection(domRoot);
        } else if (this._fakeSelectionContainer && this._fakeSelectionContainer.isConnected) {
            this._removeFakeSelection();
            this._updateDomSelection(domRoot);
        } else if (!(this.isComposing && __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid)) {
            this._updateDomSelection(domRoot);
        }
    }
    /**
     * Updates the fake selection.
     *
     * @param domRoot A valid DOM root where the fake selection container should be added.
     */ _updateFakeSelection(domRoot) {
        const domDocument = domRoot.ownerDocument;
        if (!this._fakeSelectionContainer) {
            this._fakeSelectionContainer = createFakeSelectionContainer(domDocument);
        }
        const container = this._fakeSelectionContainer;
        // Bind fake selection container with the current selection *position*.
        this.domConverter.bindFakeSelection(container, this.selection);
        if (!this._fakeSelectionNeedsUpdate(domRoot)) {
            return;
        }
        if (!container.parentElement || container.parentElement != domRoot) {
            domRoot.appendChild(container);
        }
        container.textContent = this.selection.fakeSelectionLabel || '\u00A0';
        const domSelection = domDocument.getSelection();
        const domRange = domDocument.createRange();
        domSelection.removeAllRanges();
        domRange.selectNodeContents(container);
        domSelection.addRange(domRange);
    }
    /**
     * Updates the DOM selection.
     *
     * @param domRoot A valid DOM root where the DOM selection should be rendered.
     */ _updateDomSelection(domRoot) {
        const domSelection = domRoot.ownerDocument.defaultView.getSelection();
        // Let's check whether DOM selection needs updating at all.
        if (!this._domSelectionNeedsUpdate(domSelection)) {
            return;
        }
        // Multi-range selection is not available in most browsers, and, at least in Chrome, trying to
        // set such selection, that is not continuous, throws an error. Because of that, we will just use anchor
        // and focus of view selection.
        // Since we are not supporting multi-range selection, we also do not need to check if proper editable is
        // selected. If there is any editable selected, it is okay (editable is taken from selection anchor).
        const anchor = this.domConverter.viewPositionToDom(this.selection.anchor);
        const focus = this.domConverter.viewPositionToDom(this.selection.focus);
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.info( '%c[Renderer]%c Update DOM selection:',
        // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', '', anchor, focus
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        domSelection.setBaseAndExtent(anchor.parent, anchor.offset, focus.parent, focus.offset);
        // Firefox–specific hack (https://github.com/ckeditor/ckeditor5-engine/issues/1439).
        if (__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isGecko) {
            fixGeckoSelectionAfterBr(focus, domSelection);
        }
    }
    /**
     * Checks whether a given DOM selection needs to be updated.
     *
     * @param domSelection The DOM selection to check.
     */ _domSelectionNeedsUpdate(domSelection) {
        if (!this.domConverter.isDomSelectionCorrect(domSelection)) {
            // Current DOM selection is in incorrect position. We need to update it.
            return true;
        }
        const oldViewSelection = domSelection && this.domConverter.domSelectionToView(domSelection);
        if (oldViewSelection && this.selection.isEqual(oldViewSelection)) {
            return false;
        }
        // If selection is not collapsed, it does not need to be updated if it is similar.
        if (!this.selection.isCollapsed && this.selection.isSimilar(oldViewSelection)) {
            // Selection did not changed and is correct, do not update.
            return false;
        }
        // Selections are not similar.
        return true;
    }
    /**
     * Checks whether the fake selection needs to be updated.
     *
     * @param domRoot A valid DOM root where a new fake selection container should be added.
     */ _fakeSelectionNeedsUpdate(domRoot) {
        const container = this._fakeSelectionContainer;
        const domSelection = domRoot.ownerDocument.getSelection();
        // Fake selection needs to be updated if there's no fake selection container, or the container currently sits
        // in a different root.
        if (!container || container.parentElement !== domRoot) {
            return true;
        }
        // Make sure that the selection actually is within the fake selection.
        if (domSelection.anchorNode !== container && !container.contains(domSelection.anchorNode)) {
            return true;
        }
        return container.textContent !== this.selection.fakeSelectionLabel;
    }
    /**
     * Removes the DOM selection.
     */ _removeDomSelection() {
        for (const doc of this.domDocuments){
            const domSelection = doc.getSelection();
            if (domSelection.rangeCount) {
                const activeDomElement = doc.activeElement;
                const viewElement = this.domConverter.mapDomToView(activeDomElement);
                if (activeDomElement && viewElement) {
                    domSelection.removeAllRanges();
                }
            }
        }
    }
    /**
     * Removes the fake selection.
     */ _removeFakeSelection() {
        const container = this._fakeSelectionContainer;
        if (container) {
            container.remove();
        }
    }
    /**
     * Checks if focus needs to be updated and possibly updates it.
     */ _updateFocus() {
        if (this.isFocused) {
            const editable = this.selection.editableElement;
            if (editable) {
                this.domConverter.focus(editable);
            }
        }
    }
}
/**
 * Checks if provided element is editable.
 */ function isEditable(element) {
    if (element.getAttribute('contenteditable') == 'false') {
        return false;
    }
    const parent = element.findAncestor((element)=>element.hasAttribute('contenteditable'));
    return !parent || parent.getAttribute('contenteditable') == 'true';
}
/**
 * Adds inline filler at a given position.
 *
 * The position can be given as an array of DOM nodes and an offset in that array,
 * or a DOM parent element and an offset in that element.
 *
 * @returns The DOM text node that contains an inline filler.
 */ function addInlineFiller(domDocument, domParentOrArray, offset) {
    const childNodes = domParentOrArray instanceof Array ? domParentOrArray : domParentOrArray.childNodes;
    const nodeAfterFiller = childNodes[offset];
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(nodeAfterFiller)) {
        nodeAfterFiller.data = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["INLINE_FILLER"] + nodeAfterFiller.data;
        return nodeAfterFiller;
    } else {
        const fillerNode = domDocument.createTextNode(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["INLINE_FILLER"]);
        if (Array.isArray(domParentOrArray)) {
            childNodes.splice(offset, 0, fillerNode);
        } else {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$insertat$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__insertAt$3e$__["insertAt"])(domParentOrArray, offset, fillerNode);
        }
        return fillerNode;
    }
}
/**
 * Whether two DOM nodes should be considered as similar.
 * Nodes are considered similar if they have the same tag name.
 */ function areSimilarElements(node1, node2) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$isnode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isNode$3e$__["isNode"])(node1) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$isnode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isNode$3e$__["isNode"])(node2) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(node1) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(node2) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$iscomment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isComment$3e$__["isComment"])(node1) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$iscomment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isComment$3e$__["isComment"])(node2) && node1.tagName.toLowerCase() === node2.tagName.toLowerCase();
}
/**
 * Whether two DOM nodes are text nodes.
 */ function areTextNodes(node1, node2) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$isnode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isNode$3e$__["isNode"])(node1) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$isnode$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isNode$3e$__["isNode"])(node2) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(node1) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(node2);
}
/**
 * Whether two dom nodes should be considered as the same.
 * Two nodes which are considered the same are:
 *
 * * Text nodes with the same text.
 * * Element nodes represented by the same object.
 * * Two block filler elements.
 *
 * @param blockFillerMode Block filler mode, see {@link module:engine/view/domconverter~DomConverter#blockFillerMode}.
 */ function sameNodes(domConverter, actualDomChild, expectedDomChild) {
    // Elements.
    if (actualDomChild === expectedDomChild) {
        return true;
    } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(actualDomChild) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(expectedDomChild)) {
        return actualDomChild.data === expectedDomChild.data;
    } else if (domConverter.isBlockFiller(actualDomChild) && domConverter.isBlockFiller(expectedDomChild)) {
        return true;
    }
    // Not matching types.
    return false;
}
/**
 * The following is a Firefox–specific hack (https://github.com/ckeditor/ckeditor5-engine/issues/1439).
 * When the native DOM selection is at the end of the block and preceded by <br /> e.g.
 *
 * ```html
 * <p>foo<br/>[]</p>
 * ```
 *
 * which happens a lot when using the soft line break, the browser fails to (visually) move the
 * caret to the new line. A quick fix is as simple as force–refreshing the selection with the same range.
 */ function fixGeckoSelectionAfterBr(focus, domSelection) {
    let parent = focus.parent;
    let offset = focus.offset;
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(parent) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInlineFiller"])(parent)) {
        offset = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$indexof$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__indexOf$3e$__["indexOf"])(parent) + 1;
        parent = parent.parentNode;
    }
    // This fix works only when the focus point is at the very end of an element.
    // There is no point in running it in cases unrelated to the browser bug.
    if (parent.nodeType != Node.ELEMENT_NODE || offset != parent.childNodes.length - 1) {
        return;
    }
    const childAtOffset = parent.childNodes[offset];
    // To stay on the safe side, the fix being as specific as possible, it targets only the
    // selection which is at the very end of the element and preceded by <br />.
    if (childAtOffset && childAtOffset.tagName == 'BR') {
        domSelection.addRange(domSelection.getRangeAt(0));
    }
}
function filterOutFakeSelectionContainer(domChildList, fakeSelectionContainer) {
    const childList = Array.from(domChildList);
    if (childList.length == 0 || !fakeSelectionContainer) {
        return childList;
    }
    const last = childList[childList.length - 1];
    if (last == fakeSelectionContainer) {
        childList.pop();
    }
    return childList;
}
/**
 * Creates a fake selection container for a given document.
 */ function createFakeSelectionContainer(domDocument) {
    const container = domDocument.createElement('div');
    container.className = 'ck-fake-selection-container';
    Object.assign(container.style, {
        position: 'fixed',
        top: 0,
        left: '-9999px',
        // See https://github.com/ckeditor/ckeditor5/issues/752.
        width: '42px'
    });
    // Fill it with a text node so we can update it later.
    container.textContent = '\u00A0';
    return container;
}
/**
 * Checks if text needs to be updated and possibly updates it by removing and inserting only parts
 * of the data from the existing text node to reduce impact on the IME composition.
 *
 * @param domText DOM text node to update.
 * @param expectedText The expected data of a text node.
 */ function updateTextNode(domText, expectedText) {
    const actualText = domText.data;
    if (actualText == expectedText) {
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.info( '%c[Renderer]%c Text node does not need update:',
        // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', '',
        // @if CK_DEBUG_TYPING // 		`"${ domText.data }" (${ domText.data.length })`
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        return;
    }
    // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
    // @if CK_DEBUG_TYPING // 	console.info( '%c[Renderer]%c Update text node:',
    // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', '',
    // @if CK_DEBUG_TYPING // 		`"${ domText.data }" (${ domText.data.length }) -> "${ expectedText }" (${ expectedText.length })`
    // @if CK_DEBUG_TYPING // 	);
    // @if CK_DEBUG_TYPING // }
    const actions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$fastdiff$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__fastDiff$3e$__["fastDiff"])(actualText, expectedText);
    for (const action of actions){
        if (action.type === 'insert') {
            domText.insertData(action.index, action.values.join(''));
        } else {
            domText.deleteData(action.index, action.howMany);
        }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/domconverter.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/domconverter
 */ /* globals Node, NodeFilter, DOMParser */ __turbopack_context__.s([
    "default",
    ()=>DomConverter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/uielement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/selection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/treewalker.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/matcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/filler.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$global$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__global$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/global.js [app-ssr] (ecmascript) <export default as global>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$indexof$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__indexOf$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/indexof.js [app-ssr] (ecmascript) <export default as indexOf>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$getancestors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__getAncestors$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/getancestors.js [app-ssr] (ecmascript) <export default as getAncestors>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/istext.js [app-ssr] (ecmascript) <export default as isText>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$iscomment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isComment$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/iscomment.js [app-ssr] (ecmascript) <export default as isComment>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$isvalidattributename$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isValidAttributeName$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/isvalidattributename.js [app-ssr] (ecmascript) <export default as isValidAttributeName>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$first$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__first$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/first.js [app-ssr] (ecmascript) <export default as first>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/env.js [app-ssr] (ecmascript) <export default as env>");
;
;
;
;
;
;
;
;
;
;
;
const BR_FILLER_REF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BR_FILLER"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$global$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__global$3e$__["global"].document); // eslint-disable-line new-cap
const NBSP_FILLER_REF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NBSP_FILLER"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$global$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__global$3e$__["global"].document); // eslint-disable-line new-cap
const MARKED_NBSP_FILLER_REF = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MARKED_NBSP_FILLER"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$global$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__global$3e$__["global"].document); // eslint-disable-line new-cap
const UNSAFE_ATTRIBUTE_NAME_PREFIX = 'data-ck-unsafe-attribute-';
const UNSAFE_ELEMENT_REPLACEMENT_ATTRIBUTE = 'data-ck-unsafe-element';
class DomConverter {
    /**
     * Creates a DOM converter.
     *
     * @param document The view document instance.
     * @param options An object with configuration options.
     * @param options.blockFillerMode The type of the block filler to use.
     * Default value depends on the options.renderingMode:
     *  'nbsp' when options.renderingMode == 'data',
     *  'br' when options.renderingMode == 'editing'.
     * @param options.renderingMode Whether to leave the View-to-DOM conversion result unchanged
     * or improve editing experience by filtering out interactive data.
     */ constructor(document, { blockFillerMode, renderingMode = 'editing' } = {}){
        /**
         * The DOM-to-view mapping.
         */ this._domToViewMapping = new WeakMap();
        /**
         * The view-to-DOM mapping.
         */ this._viewToDomMapping = new WeakMap();
        /**
         * Holds the mapping between fake selection containers and corresponding view selections.
         */ this._fakeSelectionMapping = new WeakMap();
        /**
         * Matcher for view elements whose content should be treated as raw data
         * and not processed during the conversion from DOM nodes to view elements.
         */ this._rawContentElementMatcher = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        /**
         * Matcher for inline object view elements. This is an extension of a simple {@link #inlineObjectElements} array of element names.
         */ this._inlineObjectElementMatcher = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]();
        /**
         * Set of elements with temporary custom properties that require clearing after render.
         */ this._elementsWithTemporaryCustomProperties = new Set();
        this.document = document;
        this.renderingMode = renderingMode;
        this.blockFillerMode = blockFillerMode || (renderingMode === 'editing' ? 'br' : 'nbsp');
        this.preElements = [
            'pre'
        ];
        this.blockElements = [
            'address',
            'article',
            'aside',
            'blockquote',
            'caption',
            'center',
            'dd',
            'details',
            'dir',
            'div',
            'dl',
            'dt',
            'fieldset',
            'figcaption',
            'figure',
            'footer',
            'form',
            'h1',
            'h2',
            'h3',
            'h4',
            'h5',
            'h6',
            'header',
            'hgroup',
            'legend',
            'li',
            'main',
            'menu',
            'nav',
            'ol',
            'p',
            'pre',
            'section',
            'summary',
            'table',
            'tbody',
            'td',
            'tfoot',
            'th',
            'thead',
            'tr',
            'ul'
        ];
        this.inlineObjectElements = [
            'object',
            'iframe',
            'input',
            'button',
            'textarea',
            'select',
            'option',
            'video',
            'embed',
            'audio',
            'img',
            'canvas'
        ];
        this.unsafeElements = [
            'script',
            'style'
        ];
        this._domDocument = this.renderingMode === 'editing' ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$global$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__global$3e$__["global"].document : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$global$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__global$3e$__["global"].document.implementation.createHTMLDocument('');
    }
    /**
     * Binds a given DOM element that represents fake selection to a **position** of a
     * {@link module:engine/view/documentselection~DocumentSelection document selection}.
     * Document selection copy is stored and can be retrieved by the
     * {@link module:engine/view/domconverter~DomConverter#fakeSelectionToView} method.
     */ bindFakeSelection(domElement, viewDocumentSelection) {
        this._fakeSelectionMapping.set(domElement, new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewDocumentSelection));
    }
    /**
     * Returns a {@link module:engine/view/selection~Selection view selection} instance corresponding to a given
     * DOM element that represents fake selection. Returns `undefined` if binding to the given DOM element does not exist.
     */ fakeSelectionToView(domElement) {
        return this._fakeSelectionMapping.get(domElement);
    }
    /**
     * Binds DOM and view elements, so it will be possible to get corresponding elements using
     * {@link module:engine/view/domconverter~DomConverter#mapDomToView} and
     * {@link module:engine/view/domconverter~DomConverter#mapViewToDom}.
     *
     * @param domElement The DOM element to bind.
     * @param viewElement The view element to bind.
     */ bindElements(domElement, viewElement) {
        this._domToViewMapping.set(domElement, viewElement);
        this._viewToDomMapping.set(viewElement, domElement);
    }
    /**
     * Unbinds a given DOM element from the view element it was bound to. Unbinding is deep, meaning that all children of
     * the DOM element will be unbound too.
     *
     * @param domElement The DOM element to unbind.
     */ unbindDomElement(domElement) {
        const viewElement = this._domToViewMapping.get(domElement);
        if (viewElement) {
            this._domToViewMapping.delete(domElement);
            this._viewToDomMapping.delete(viewElement);
            for (const child of Array.from(domElement.children)){
                this.unbindDomElement(child);
            }
        }
    }
    /**
     * Binds DOM and view document fragments, so it will be possible to get corresponding document fragments using
     * {@link module:engine/view/domconverter~DomConverter#mapDomToView} and
     * {@link module:engine/view/domconverter~DomConverter#mapViewToDom}.
     *
     * @param domFragment The DOM document fragment to bind.
     * @param viewFragment The view document fragment to bind.
     */ bindDocumentFragments(domFragment, viewFragment) {
        this._domToViewMapping.set(domFragment, viewFragment);
        this._viewToDomMapping.set(viewFragment, domFragment);
    }
    /**
     * Decides whether a given pair of attribute key and value should be passed further down the pipeline.
     *
     * @param elementName Element name in lower case.
     */ shouldRenderAttribute(attributeKey, attributeValue, elementName) {
        if (this.renderingMode === 'data') {
            return true;
        }
        attributeKey = attributeKey.toLowerCase();
        if (attributeKey.startsWith('on')) {
            return false;
        }
        if (attributeKey === 'srcdoc' && attributeValue.match(/\bon\S+\s*=|javascript:|<\s*\/*script/i)) {
            return false;
        }
        if (elementName === 'img' && (attributeKey === 'src' || attributeKey === 'srcset')) {
            return true;
        }
        if (elementName === 'source' && attributeKey === 'srcset') {
            return true;
        }
        if (attributeValue.match(/^\s*(javascript:|data:(image\/svg|text\/x?html))/i)) {
            return false;
        }
        return true;
    }
    /**
     * Set `domElement`'s content using provided `html` argument. Apply necessary filtering for the editing pipeline.
     *
     * @param domElement DOM element that should have `html` set as its content.
     * @param html Textual representation of the HTML that will be set on `domElement`.
     */ setContentOf(domElement, html) {
        // For data pipeline we pass the HTML as-is.
        if (this.renderingMode === 'data') {
            domElement.innerHTML = html;
            return;
        }
        const document = new DOMParser().parseFromString(html, 'text/html');
        const fragment = document.createDocumentFragment();
        const bodyChildNodes = document.body.childNodes;
        while(bodyChildNodes.length > 0){
            fragment.appendChild(bodyChildNodes[0]);
        }
        const treeWalker = document.createTreeWalker(fragment, NodeFilter.SHOW_ELEMENT);
        const nodes = [];
        let currentNode;
        // eslint-disable-next-line no-cond-assign
        while(currentNode = treeWalker.nextNode()){
            nodes.push(currentNode);
        }
        for (const currentNode of nodes){
            // Go through nodes to remove those that are prohibited in editing pipeline.
            for (const attributeName of currentNode.getAttributeNames()){
                this.setDomElementAttribute(currentNode, attributeName, currentNode.getAttribute(attributeName));
            }
            const elementName = currentNode.tagName.toLowerCase();
            // There are certain nodes, that should be renamed to <span> in editing pipeline.
            if (this._shouldRenameElement(elementName)) {
                _logUnsafeElement(elementName);
                currentNode.replaceWith(this._createReplacementDomElement(elementName, currentNode));
            }
        }
        // Empty the target element.
        while(domElement.firstChild){
            domElement.firstChild.remove();
        }
        domElement.append(fragment);
    }
    /**
     * Converts the view to the DOM. For all text nodes, not bound elements and document fragments new items will
     * be created. For bound elements and document fragments the method will return corresponding items.
     *
     * @param viewNode View node or document fragment to transform.
     * @param options Conversion options.
     * @param options.bind Determines whether new elements will be bound.
     * @param options.withChildren If `false`, node's and document fragment's children will not be converted.
     * @returns Converted node or DocumentFragment.
     */ viewToDom(viewNode, options = {}) {
        if (viewNode.is('$text')) {
            const textData = this._processDataFromViewText(viewNode);
            return this._domDocument.createTextNode(textData);
        } else {
            const viewElementOrFragment = viewNode;
            if (this.mapViewToDom(viewElementOrFragment)) {
                // Do not reuse element that is marked to not reuse (for example an IMG element
                // so it can immediately display a placeholder background instead of waiting for the new src to load).
                if (viewElementOrFragment.getCustomProperty('editingPipeline:doNotReuseOnce')) {
                    this._elementsWithTemporaryCustomProperties.add(viewElementOrFragment);
                } else {
                    return this.mapViewToDom(viewElementOrFragment);
                }
            }
            let domElement;
            if (viewElementOrFragment.is('documentFragment')) {
                // Create DOM document fragment.
                domElement = this._domDocument.createDocumentFragment();
                if (options.bind) {
                    this.bindDocumentFragments(domElement, viewElementOrFragment);
                }
            } else if (viewElementOrFragment.is('uiElement')) {
                if (viewElementOrFragment.name === '$comment') {
                    domElement = this._domDocument.createComment(viewElementOrFragment.getCustomProperty('$rawContent'));
                } else {
                    // UIElement has its own render() method (see #799).
                    domElement = viewElementOrFragment.render(this._domDocument, this);
                }
                if (options.bind) {
                    this.bindElements(domElement, viewElementOrFragment);
                }
                return domElement;
            } else {
                // Create DOM element.
                if (this._shouldRenameElement(viewElementOrFragment.name)) {
                    _logUnsafeElement(viewElementOrFragment.name);
                    domElement = this._createReplacementDomElement(viewElementOrFragment.name);
                } else if (viewElementOrFragment.hasAttribute('xmlns')) {
                    domElement = this._domDocument.createElementNS(viewElementOrFragment.getAttribute('xmlns'), viewElementOrFragment.name);
                } else {
                    domElement = this._domDocument.createElement(viewElementOrFragment.name);
                }
                // RawElement take care of their children in RawElement#render() method which can be customized
                // (see https://github.com/ckeditor/ckeditor5/issues/4469).
                if (viewElementOrFragment.is('rawElement')) {
                    viewElementOrFragment.render(domElement, this);
                }
                if (options.bind) {
                    this.bindElements(domElement, viewElementOrFragment);
                }
                // Copy element's attributes.
                for (const key of viewElementOrFragment.getAttributeKeys()){
                    this.setDomElementAttribute(domElement, key, viewElementOrFragment.getAttribute(key), viewElementOrFragment);
                }
            }
            if (options.withChildren !== false) {
                for (const child of this.viewChildrenToDom(viewElementOrFragment, options)){
                    if (domElement instanceof HTMLTemplateElement) {
                        domElement.content.appendChild(child);
                    } else {
                        domElement.appendChild(child);
                    }
                }
            }
            return domElement;
        }
    }
    /**
     * Sets the attribute on a DOM element.
     *
     * **Note**: To remove the attribute, use {@link #removeDomElementAttribute}.
     *
     * @param domElement The DOM element the attribute should be set on.
     * @param key The name of the attribute.
     * @param value The value of the attribute.
     * @param relatedViewElement The view element related to the `domElement` (if there is any).
     * It helps decide whether the attribute set is unsafe. For instance, view elements created via the
     * {@link module:engine/view/downcastwriter~DowncastWriter} methods can allow certain attributes that would normally be filtered out.
     */ setDomElementAttribute(domElement, key, value, relatedViewElement) {
        const shouldRenderAttribute = this.shouldRenderAttribute(key, value, domElement.tagName.toLowerCase()) || relatedViewElement && relatedViewElement.shouldRenderUnsafeAttribute(key);
        if (!shouldRenderAttribute) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('domconverter-unsafe-attribute-detected', {
                domElement,
                key,
                value
            });
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$isvalidattributename$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isValidAttributeName$3e$__["isValidAttributeName"])(key)) {
            /**
             * Invalid attribute name was ignored during rendering.
             *
             * @error domconverter-invalid-attribute-detected
             */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('domconverter-invalid-attribute-detected', {
                domElement,
                key,
                value
            });
            return;
        }
        // The old value was safe but the new value is unsafe.
        if (domElement.hasAttribute(key) && !shouldRenderAttribute) {
            domElement.removeAttribute(key);
        } else if (domElement.hasAttribute(UNSAFE_ATTRIBUTE_NAME_PREFIX + key) && shouldRenderAttribute) {
            domElement.removeAttribute(UNSAFE_ATTRIBUTE_NAME_PREFIX + key);
        }
        // If the attribute should not be rendered, rename it (instead of removing) to give developers some idea of what
        // is going on (https://github.com/ckeditor/ckeditor5/issues/10801).
        domElement.setAttribute(shouldRenderAttribute ? key : UNSAFE_ATTRIBUTE_NAME_PREFIX + key, value);
    }
    /**
     * Removes an attribute from a DOM element.
     *
     * **Note**: To set the attribute, use {@link #setDomElementAttribute}.
     *
     * @param domElement The DOM element the attribute should be removed from.
     * @param key The name of the attribute.
     */ removeDomElementAttribute(domElement, key) {
        // See #_createReplacementDomElement() to learn what this is.
        if (key == UNSAFE_ELEMENT_REPLACEMENT_ATTRIBUTE) {
            return;
        }
        domElement.removeAttribute(key);
        // See setDomElementAttribute() to learn what this is.
        domElement.removeAttribute(UNSAFE_ATTRIBUTE_NAME_PREFIX + key);
    }
    /**
     * Converts children of the view element to DOM using the
     * {@link module:engine/view/domconverter~DomConverter#viewToDom} method.
     * Additionally, this method adds block {@link module:engine/view/filler filler} to the list of children, if needed.
     *
     * @param viewElement Parent view element.
     * @param options See {@link module:engine/view/domconverter~DomConverter#viewToDom} options parameter.
     * @returns DOM nodes.
     */ *viewChildrenToDom(viewElement, options = {}) {
        const fillerPositionOffset = viewElement.getFillerOffset && viewElement.getFillerOffset();
        let offset = 0;
        for (const childView of viewElement.getChildren()){
            if (fillerPositionOffset === offset) {
                yield this._getBlockFiller();
            }
            const transparentRendering = childView.is('element') && !!childView.getCustomProperty('dataPipeline:transparentRendering') && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$first$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__first$3e$__["first"])(childView.getAttributes());
            if (transparentRendering && this.renderingMode == 'data') {
                yield* this.viewChildrenToDom(childView, options);
            } else {
                if (transparentRendering) {
                    /**
                     * The `dataPipeline:transparentRendering` flag is supported only in the data pipeline.
                     *
                     * @error domconverter-transparent-rendering-unsupported-in-editing-pipeline
                     */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('domconverter-transparent-rendering-unsupported-in-editing-pipeline', {
                        viewElement: childView
                    });
                }
                yield this.viewToDom(childView, options);
            }
            offset++;
        }
        if (fillerPositionOffset === offset) {
            yield this._getBlockFiller();
        }
    }
    /**
     * Converts view {@link module:engine/view/range~Range} to DOM range.
     * Inline and block {@link module:engine/view/filler fillers} are handled during the conversion.
     *
     * @param viewRange View range.
     * @returns DOM range.
     */ viewRangeToDom(viewRange) {
        const domStart = this.viewPositionToDom(viewRange.start);
        const domEnd = this.viewPositionToDom(viewRange.end);
        const domRange = this._domDocument.createRange();
        domRange.setStart(domStart.parent, domStart.offset);
        domRange.setEnd(domEnd.parent, domEnd.offset);
        return domRange;
    }
    /**
     * Converts view {@link module:engine/view/position~Position} to DOM parent and offset.
     *
     * Inline and block {@link module:engine/view/filler fillers} are handled during the conversion.
     * If the converted position is directly before inline filler it is moved inside the filler.
     *
     * @param viewPosition View position.
     * @returns DOM position or `null` if view position could not be converted to DOM.
     * DOM position has two properties:
     * * `parent` - DOM position parent.
     * * `offset` - DOM position offset.
     */ viewPositionToDom(viewPosition) {
        const viewParent = viewPosition.parent;
        if (viewParent.is('$text')) {
            const domParent = this.findCorrespondingDomText(viewParent);
            if (!domParent) {
                // Position is in a view text node that has not been rendered to DOM yet.
                return null;
            }
            let offset = viewPosition.offset;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["startsWithFiller"])(domParent)) {
                offset += __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["INLINE_FILLER_LENGTH"];
            }
            return {
                parent: domParent,
                offset
            };
        } else {
            // viewParent is instance of ViewElement.
            let domParent, domBefore, domAfter;
            if (viewPosition.offset === 0) {
                domParent = this.mapViewToDom(viewParent);
                if (!domParent) {
                    // Position is in a view element that has not been rendered to DOM yet.
                    return null;
                }
                domAfter = domParent.childNodes[0];
            } else {
                const nodeBefore = viewPosition.nodeBefore;
                domBefore = nodeBefore.is('$text') ? this.findCorrespondingDomText(nodeBefore) : this.mapViewToDom(nodeBefore);
                if (!domBefore) {
                    // Position is after a view element that has not been rendered to DOM yet.
                    return null;
                }
                domParent = domBefore.parentNode;
                domAfter = domBefore.nextSibling;
            }
            // If there is an inline filler at position return position inside the filler. We should never return
            // the position before the inline filler.
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(domAfter) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["startsWithFiller"])(domAfter)) {
                return {
                    parent: domAfter,
                    offset: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["INLINE_FILLER_LENGTH"]
                };
            }
            const offset = domBefore ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$indexof$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__indexOf$3e$__["indexOf"])(domBefore) + 1 : 0;
            return {
                parent: domParent,
                offset
            };
        }
    }
    /**
     * Converts DOM to view. For all text nodes, not bound elements and document fragments new items will
     * be created. For bound elements and document fragments function will return corresponding items. For
     * {@link module:engine/view/filler fillers} `null` will be returned.
     * For all DOM elements rendered by {@link module:engine/view/uielement~UIElement} that UIElement will be returned.
     *
     * @param domNode DOM node or document fragment to transform.
     * @param options Conversion options.
     * @param options.bind Determines whether new elements will be bound. False by default.
     * @param options.withChildren If `true`, node's and document fragment's children will be converted too. True by default.
     * @param options.keepOriginalCase If `false`, node's tag name will be converted to lower case. False by default.
     * @param options.skipComments If `false`, comment nodes will be converted to `$comment`
     * {@link module:engine/view/uielement~UIElement view UI elements}. False by default.
     * @returns Converted node or document fragment or `null` if DOM node is a {@link module:engine/view/filler filler}
     * or the given node is an empty text node.
     */ domToView(domNode, options = {}) {
        const inlineNodes = [];
        const generator = this._domToView(domNode, options, inlineNodes);
        // Get the first yielded value or a returned value.
        const node = generator.next().value;
        if (!node) {
            return null;
        }
        // Trigger children handling.
        generator.next();
        // Whitespace cleaning.
        this._processDomInlineNodes(null, inlineNodes, options);
        // Text not got trimmed to an empty string so there is no result node.
        if (node.is('$text') && node.data.length == 0) {
            return null;
        }
        return node;
    }
    /**
     * Converts children of the DOM element to view nodes using
     * the {@link module:engine/view/domconverter~DomConverter#domToView} method.
     * Additionally this method omits block {@link module:engine/view/filler filler}, if it exists in the DOM parent.
     *
     * @param domElement Parent DOM element.
     * @param options See {@link module:engine/view/domconverter~DomConverter#domToView} options parameter.
     * @param inlineNodes An array that will be populated with inline nodes. It's used internally for whitespace processing.
     * @returns View nodes.
     */ *domChildrenToView(domElement, options = {}, inlineNodes = []) {
        // Get child nodes from content document fragment if element is template
        let childNodes = [];
        if (domElement instanceof HTMLTemplateElement) {
            childNodes = [
                ...domElement.content.childNodes
            ];
        } else {
            childNodes = [
                ...domElement.childNodes
            ];
        }
        for(let i = 0; i < childNodes.length; i++){
            const domChild = childNodes[i];
            const generator = this._domToView(domChild, options, inlineNodes);
            // Get the first yielded value or a returned value.
            const viewChild = generator.next().value;
            if (viewChild !== null) {
                // Whitespace cleaning before entering a block element (between block elements).
                if (this._isBlockViewElement(viewChild)) {
                    this._processDomInlineNodes(domElement, inlineNodes, options);
                }
                yield viewChild;
                // Trigger children handling.
                generator.next();
            }
        }
        // Whitespace cleaning before leaving a block element (content of block element).
        this._processDomInlineNodes(domElement, inlineNodes, options);
    }
    /**
     * Converts DOM selection to view {@link module:engine/view/selection~Selection}.
     * Ranges which cannot be converted will be omitted.
     *
     * @param domSelection DOM selection.
     * @returns View selection.
     */ domSelectionToView(domSelection) {
        // See: https://github.com/ckeditor/ckeditor5/issues/9635.
        if (isGeckoRestrictedDomSelection(domSelection)) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]([]);
        }
        // DOM selection might be placed in fake selection container.
        // If container contains fake selection - return corresponding view selection.
        if (domSelection.rangeCount === 1) {
            let container = domSelection.getRangeAt(0).startContainer;
            // The DOM selection might be moved to the text node inside the fake selection container.
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(container)) {
                container = container.parentNode;
            }
            const viewSelection = this.fakeSelectionToView(container);
            if (viewSelection) {
                return viewSelection;
            }
        }
        const isBackward = this.isDomSelectionBackward(domSelection);
        const viewRanges = [];
        for(let i = 0; i < domSelection.rangeCount; i++){
            // DOM Range have correct start and end, no matter what is the DOM Selection direction. So we don't have to fix anything.
            const domRange = domSelection.getRangeAt(i);
            const viewRange = this.domRangeToView(domRange);
            if (viewRange) {
                viewRanges.push(viewRange);
            }
        }
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewRanges, {
            backward: isBackward
        });
    }
    /**
     * Converts DOM Range to view {@link module:engine/view/range~Range}.
     * If the start or end position can not be converted `null` is returned.
     *
     * @param domRange DOM range.
     * @returns View range.
     */ domRangeToView(domRange) {
        const viewStart = this.domPositionToView(domRange.startContainer, domRange.startOffset);
        const viewEnd = this.domPositionToView(domRange.endContainer, domRange.endOffset);
        if (viewStart && viewEnd) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewStart, viewEnd);
        }
        return null;
    }
    /**
     * Converts DOM parent and offset to view {@link module:engine/view/position~Position}.
     *
     * If the position is inside a {@link module:engine/view/filler filler} which has no corresponding view node,
     * position of the filler will be converted and returned.
     *
     * If the position is inside DOM element rendered by {@link module:engine/view/uielement~UIElement}
     * that position will be converted to view position before that UIElement.
     *
     * If structures are too different and it is not possible to find corresponding position then `null` will be returned.
     *
     * @param domParent DOM position parent.
     * @param domOffset DOM position offset. You can skip it when converting the inline filler node.
     * @returns View position.
     */ domPositionToView(domParent, domOffset = 0) {
        if (this.isBlockFiller(domParent)) {
            return this.domPositionToView(domParent.parentNode, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$indexof$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__indexOf$3e$__["indexOf"])(domParent));
        }
        // If position is somewhere inside UIElement or a RawElement - return position before that element.
        const viewElement = this.mapDomToView(domParent);
        if (viewElement && (viewElement.is('uiElement') || viewElement.is('rawElement'))) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(viewElement);
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(domParent)) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInlineFiller"])(domParent)) {
                return this.domPositionToView(domParent.parentNode, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$indexof$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__indexOf$3e$__["indexOf"])(domParent));
            }
            const viewParent = this.findCorrespondingViewText(domParent);
            let offset = domOffset;
            if (!viewParent) {
                return null;
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["startsWithFiller"])(domParent)) {
                offset -= __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["INLINE_FILLER_LENGTH"];
                offset = offset < 0 ? 0 : offset;
            }
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewParent, offset);
        } else {
            if (domOffset === 0) {
                const viewParent = this.mapDomToView(domParent);
                if (viewParent) {
                    return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewParent, 0);
                }
            } else {
                const domBefore = domParent.childNodes[domOffset - 1];
                // Jump over an inline filler (and also on Firefox jump over a block filler while pressing backspace in an empty paragraph).
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(domBefore) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInlineFiller"])(domBefore) || domBefore && this.isBlockFiller(domBefore)) {
                    return this.domPositionToView(domBefore.parentNode, (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$indexof$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__indexOf$3e$__["indexOf"])(domBefore));
                }
                const viewBefore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(domBefore) ? this.findCorrespondingViewText(domBefore) : this.mapDomToView(domBefore);
                // TODO #663
                if (viewBefore && viewBefore.parent) {
                    return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewBefore.parent, viewBefore.index + 1);
                }
            }
            return null;
        }
    }
    /**
     * Returns corresponding view {@link module:engine/view/element~Element Element} or
     * {@link module:engine/view/documentfragment~DocumentFragment} for provided DOM element or
     * document fragment. If there is no view item {@link module:engine/view/domconverter~DomConverter#bindElements bound}
     * to the given DOM - `undefined` is returned.
     *
     * For all DOM elements rendered by a {@link module:engine/view/uielement~UIElement} or
     * a {@link module:engine/view/rawelement~RawElement}, the parent `UIElement` or `RawElement` will be returned.
     *
     * @param domElementOrDocumentFragment DOM element or document fragment.
     * @returns Corresponding view element, document fragment or `undefined` if no element was bound.
     */ mapDomToView(domElementOrDocumentFragment) {
        const hostElement = this.getHostViewElement(domElementOrDocumentFragment);
        return hostElement || this._domToViewMapping.get(domElementOrDocumentFragment);
    }
    /**
     * Finds corresponding text node. Text nodes are not {@link module:engine/view/domconverter~DomConverter#bindElements bound},
     * corresponding text node is returned based on the sibling or parent.
     *
     * If the directly previous sibling is a {@link module:engine/view/domconverter~DomConverter#bindElements bound} element, it is used
     * to find the corresponding text node.
     *
     * If this is a first child in the parent and the parent is a {@link module:engine/view/domconverter~DomConverter#bindElements bound}
     * element, it is used to find the corresponding text node.
     *
     * For all text nodes rendered by a {@link module:engine/view/uielement~UIElement} or
     * a {@link module:engine/view/rawelement~RawElement}, the parent `UIElement` or `RawElement` will be returned.
     *
     * Otherwise `null` is returned.
     *
     * Note that for the block or inline {@link module:engine/view/filler filler} this method returns `null`.
     *
     * @param domText DOM text node.
     * @returns Corresponding view text node or `null`, if it was not possible to find a corresponding node.
     */ findCorrespondingViewText(domText) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInlineFiller"])(domText)) {
            return null;
        }
        // If DOM text was rendered by a UIElement or a RawElement - return this parent element.
        const hostElement = this.getHostViewElement(domText);
        if (hostElement) {
            return hostElement;
        }
        const previousSibling = domText.previousSibling;
        // Try to use previous sibling to find the corresponding text node.
        if (previousSibling) {
            if (!this.isElement(previousSibling)) {
                // The previous is text or comment.
                return null;
            }
            const viewElement = this.mapDomToView(previousSibling);
            if (viewElement) {
                const nextSibling = viewElement.nextSibling;
                // It might be filler which has no corresponding view node.
                if (nextSibling instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                    return nextSibling;
                } else {
                    return null;
                }
            }
        } else {
            const viewElement = this.mapDomToView(domText.parentNode);
            if (viewElement) {
                const firstChild = viewElement.getChild(0);
                // It might be filler which has no corresponding view node.
                if (firstChild instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                    return firstChild;
                } else {
                    return null;
                }
            }
        }
        return null;
    }
    mapViewToDom(documentFragmentOrElement) {
        return this._viewToDomMapping.get(documentFragmentOrElement);
    }
    /**
     * Finds corresponding text node. Text nodes are not {@link module:engine/view/domconverter~DomConverter#bindElements bound},
     * corresponding text node is returned based on the sibling or parent.
     *
     * If the directly previous sibling is a {@link module:engine/view/domconverter~DomConverter#bindElements bound} element, it is used
     * to find the corresponding text node.
     *
     * If this is a first child in the parent and the parent is a {@link module:engine/view/domconverter~DomConverter#bindElements bound}
     * element, it is used to find the corresponding text node.
     *
     * Otherwise `null` is returned.
     *
     * @param viewText View text node.
     * @returns Corresponding DOM text node or `null`, if it was not possible to find a corresponding node.
     */ findCorrespondingDomText(viewText) {
        const previousSibling = viewText.previousSibling;
        // Try to use previous sibling to find the corresponding text node.
        if (previousSibling && this.mapViewToDom(previousSibling)) {
            return this.mapViewToDom(previousSibling).nextSibling;
        }
        // If this is a first node, try to use parent to find the corresponding text node.
        if (!previousSibling && viewText.parent && this.mapViewToDom(viewText.parent)) {
            return this.mapViewToDom(viewText.parent).childNodes[0];
        }
        return null;
    }
    /**
     * Focuses DOM editable that is corresponding to provided {@link module:engine/view/editableelement~EditableElement}.
     */ focus(viewEditable) {
        const domEditable = this.mapViewToDom(viewEditable);
        if (domEditable && domEditable.ownerDocument.activeElement !== domEditable) {
            // Save the scrollX and scrollY positions before the focus.
            const { scrollX, scrollY } = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$global$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__global$3e$__["global"].window;
            const scrollPositions = [];
            // Save all scrollLeft and scrollTop values starting from domEditable up to
            // document#documentElement.
            forEachDomElementAncestor(domEditable, (node)=>{
                const { scrollLeft, scrollTop } = node;
                scrollPositions.push([
                    scrollLeft,
                    scrollTop
                ]);
            });
            domEditable.focus();
            // Restore scrollLeft and scrollTop values starting from domEditable up to
            // document#documentElement.
            // https://github.com/ckeditor/ckeditor5-engine/issues/951
            // https://github.com/ckeditor/ckeditor5-engine/issues/957
            forEachDomElementAncestor(domEditable, (node)=>{
                const [scrollLeft, scrollTop] = scrollPositions.shift();
                node.scrollLeft = scrollLeft;
                node.scrollTop = scrollTop;
            });
            // Restore the scrollX and scrollY positions after the focus.
            // https://github.com/ckeditor/ckeditor5-engine/issues/951
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$global$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__global$3e$__["global"].window.scrollTo(scrollX, scrollY);
        }
    }
    /**
     * Remove DOM selection from blurred editable, so it won't interfere with clicking on dropdowns (especially on iOS).
     *
     * @internal
     */ _clearDomSelection() {
        const domEditable = this.mapViewToDom(this.document.selection.editableElement);
        if (!domEditable) {
            return;
        }
        // Check if DOM selection is inside editor editable element.
        const domSelection = domEditable.ownerDocument.defaultView.getSelection();
        const newViewSelection = this.domSelectionToView(domSelection);
        const selectionInEditable = newViewSelection && newViewSelection.rangeCount > 0;
        if (selectionInEditable) {
            domSelection.removeAllRanges();
        }
    }
    /**
     * Returns `true` when `node.nodeType` equals `Node.ELEMENT_NODE`.
     *
     * @param node Node to check.
     */ isElement(node) {
        return node && node.nodeType == Node.ELEMENT_NODE;
    }
    /**
     * Returns `true` when `node.nodeType` equals `Node.DOCUMENT_FRAGMENT_NODE`.
     *
     * @param node Node to check.
     */ isDocumentFragment(node) {
        return node && node.nodeType == Node.DOCUMENT_FRAGMENT_NODE;
    }
    /**
     * Checks if the node is an instance of the block filler for this DOM converter.
     *
     * ```ts
     * const converter = new DomConverter( viewDocument, { blockFillerMode: 'br' } );
     *
     * converter.isBlockFiller( BR_FILLER( document ) ); // true
     * converter.isBlockFiller( NBSP_FILLER( document ) ); // false
     * ```
     *
     * **Note:**: For the `'nbsp'` mode the method also checks context of a node so it cannot be a detached node.
     *
     * **Note:** A special case in the `'nbsp'` mode exists where the `<br>` in `<p><br></p>` is treated as a block filler.
     *
     * @param domNode DOM node to check.
     * @returns True if a node is considered a block filler for given mode.
     */ isBlockFiller(domNode) {
        if (this.blockFillerMode == 'br') {
            return domNode.isEqualNode(BR_FILLER_REF);
        }
        // Special case for <p><br></p> in which <br> should be treated as filler even when we are not in the 'br' mode. See ckeditor5#5564.
        if (domNode.tagName === 'BR' && hasBlockParent(domNode, this.blockElements) && domNode.parentNode.childNodes.length === 1) {
            return true;
        }
        // If not in 'br' mode, try recognizing both marked and regular nbsp block fillers.
        return domNode.isEqualNode(MARKED_NBSP_FILLER_REF) || isNbspBlockFiller(domNode, this.blockElements);
    }
    /**
     * Returns `true` if given selection is a backward selection, that is, if it's `focus` is before `anchor`.
     *
     * @param DOM Selection instance to check.
     */ isDomSelectionBackward(selection) {
        if (selection.isCollapsed) {
            return false;
        }
        // Since it takes multiple lines of code to check whether a "DOM Position" is before/after another "DOM Position",
        // we will use the fact that range will collapse if it's end is before it's start.
        const range = this._domDocument.createRange();
        try {
            range.setStart(selection.anchorNode, selection.anchorOffset);
            range.setEnd(selection.focusNode, selection.focusOffset);
        } catch (e) {
            // Safari sometimes gives us a selection that makes Range.set{Start,End} throw.
            // See https://github.com/ckeditor/ckeditor5/issues/12375.
            return false;
        }
        const backward = range.collapsed;
        range.detach();
        return backward;
    }
    /**
     * Returns a parent {@link module:engine/view/uielement~UIElement} or {@link module:engine/view/rawelement~RawElement}
     * that hosts the provided DOM node. Returns `null` if there is no such parent.
     */ getHostViewElement(domNode) {
        const ancestors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$getancestors$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__getAncestors$3e$__["getAncestors"])(domNode);
        // Remove domNode from the list.
        ancestors.pop();
        while(ancestors.length){
            const domNode = ancestors.pop();
            const viewNode = this._domToViewMapping.get(domNode);
            if (viewNode && (viewNode.is('uiElement') || viewNode.is('rawElement'))) {
                return viewNode;
            }
        }
        return null;
    }
    /**
     * Checks if the given selection's boundaries are at correct places.
     *
     * The following places are considered as incorrect for selection boundaries:
     *
     * * before or in the middle of an inline filler sequence,
     * * inside a DOM element which represents {@link module:engine/view/uielement~UIElement a view UI element},
     * * inside a DOM element which represents {@link module:engine/view/rawelement~RawElement a view raw element}.
     *
     * @param domSelection The DOM selection object to be checked.
     * @returns `true` if the given selection is at a correct place, `false` otherwise.
     */ isDomSelectionCorrect(domSelection) {
        return this._isDomSelectionPositionCorrect(domSelection.anchorNode, domSelection.anchorOffset) && this._isDomSelectionPositionCorrect(domSelection.focusNode, domSelection.focusOffset);
    }
    /**
     * Registers a {@link module:engine/view/matcher~MatcherPattern} for view elements whose content should be treated as raw data
     * and not processed during the conversion from DOM nodes to view elements.
     *
     * This is affecting how {@link module:engine/view/domconverter~DomConverter#domToView} and
     * {@link module:engine/view/domconverter~DomConverter#domChildrenToView} process DOM nodes.
     *
     * The raw data can be later accessed by a
     * {@link module:engine/view/element~Element#getCustomProperty custom property of a view element} called `"$rawContent"`.
     *
     * @param pattern Pattern matching a view element whose content should
     * be treated as raw data.
     */ registerRawContentMatcher(pattern) {
        this._rawContentElementMatcher.add(pattern);
    }
    /**
     * Registers a {@link module:engine/view/matcher~MatcherPattern} for inline object view elements.
     *
     * This is affecting how {@link module:engine/view/domconverter~DomConverter#domToView} and
     * {@link module:engine/view/domconverter~DomConverter#domChildrenToView} process DOM nodes.
     *
     * This is an extension of a simple {@link #inlineObjectElements} array of element names.
     *
     * @param pattern Pattern matching a view element which should be treated as an inline object.
     */ registerInlineObjectMatcher(pattern) {
        this._inlineObjectElementMatcher.add(pattern);
    }
    /**
     * Clear temporary custom properties.
     *
     * @internal
     */ _clearTemporaryCustomProperties() {
        for (const element of this._elementsWithTemporaryCustomProperties){
            element._removeCustomProperty('editingPipeline:doNotReuseOnce');
        }
        this._elementsWithTemporaryCustomProperties.clear();
    }
    /**
     * Returns the block {@link module:engine/view/filler filler} node based on the current {@link #blockFillerMode} setting.
     */ _getBlockFiller() {
        switch(this.blockFillerMode){
            case 'nbsp':
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["NBSP_FILLER"])(this._domDocument); // eslint-disable-line new-cap
            case 'markedNbsp':
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MARKED_NBSP_FILLER"])(this._domDocument); // eslint-disable-line new-cap
            case 'br':
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BR_FILLER"])(this._domDocument); // eslint-disable-line new-cap
        }
    }
    /**
     * Checks if the given DOM position is a correct place for selection boundary. See {@link #isDomSelectionCorrect}.
     *
     * @param domParent Position parent.
     * @param offset Position offset.
     * @returns `true` if given position is at a correct place for selection boundary, `false` otherwise.
     */ _isDomSelectionPositionCorrect(domParent, offset) {
        // If selection is before or in the middle of inline filler string, it is incorrect.
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(domParent) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["startsWithFiller"])(domParent) && offset < __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["INLINE_FILLER_LENGTH"]) {
            // Selection in a text node, at wrong position (before or in the middle of filler).
            return false;
        }
        if (this.isElement(domParent) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["startsWithFiller"])(domParent.childNodes[offset])) {
            // Selection in an element node, before filler text node.
            return false;
        }
        const viewParent = this.mapDomToView(domParent);
        // The position is incorrect when anchored inside a UIElement or a RawElement.
        // Note: In case of UIElement and RawElement, mapDomToView() returns a parent element for any DOM child
        // so there's no need to perform any additional checks.
        if (viewParent && (viewParent.is('uiElement') || viewParent.is('rawElement'))) {
            return false;
        }
        return true;
    }
    /**
     * Internal generator for {@link #domToView}. Also used by {@link #domChildrenToView}.
     * Separates DOM nodes conversion from whitespaces processing.
     *
     * @param domNode DOM node or document fragment to transform.
     * @param inlineNodes An array of recently encountered inline nodes truncated to the block element boundaries.
     * Used later to process whitespaces.
     */ *_domToView(domNode, options, inlineNodes) {
        if (this.isBlockFiller(domNode)) {
            return null;
        }
        // When node is inside a UIElement or a RawElement return that parent as it's view representation.
        const hostElement = this.getHostViewElement(domNode);
        if (hostElement) {
            return hostElement;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$iscomment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isComment$3e$__["isComment"])(domNode) && options.skipComments) {
            return null;
        }
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$istext$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isText$3e$__["isText"])(domNode)) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isInlineFiller"])(domNode)) {
                return null;
            } else {
                const textData = domNode.data;
                if (textData === '') {
                    return null;
                }
                const textNode = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, textData);
                inlineNodes.push(textNode);
                return textNode;
            }
        } else {
            let viewElement = this.mapDomToView(domNode);
            if (viewElement) {
                if (this._isInlineObjectElement(viewElement)) {
                    inlineNodes.push(viewElement);
                }
                return viewElement;
            }
            if (this.isDocumentFragment(domNode)) {
                // Create view document fragment.
                viewElement = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document);
                if (options.bind) {
                    this.bindDocumentFragments(domNode, viewElement);
                }
            } else {
                // Create view element.
                viewElement = this._createViewElement(domNode, options);
                if (options.bind) {
                    this.bindElements(domNode, viewElement);
                }
                // Copy element's attributes.
                const attrs = domNode.attributes;
                if (attrs) {
                    for(let l = attrs.length, i = 0; i < l; i++){
                        viewElement._setAttribute(attrs[i].name, attrs[i].value);
                    }
                }
                // Treat this element's content as a raw data if it was registered as such.
                if (this._isViewElementWithRawContent(viewElement, options)) {
                    viewElement._setCustomProperty('$rawContent', domNode.innerHTML);
                    if (!this._isBlockViewElement(viewElement)) {
                        inlineNodes.push(viewElement);
                    }
                    return viewElement;
                }
                // Comment node is also treated as an element with raw data.
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$iscomment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isComment$3e$__["isComment"])(domNode)) {
                    viewElement._setCustomProperty('$rawContent', domNode.data);
                    return viewElement;
                }
            }
            // Yield the element first so the flow of nested inline nodes is not reversed inside elements.
            yield viewElement;
            const nestedInlineNodes = [];
            if (options.withChildren !== false) {
                for (const child of this.domChildrenToView(domNode, options, nestedInlineNodes)){
                    viewElement._appendChild(child);
                }
            }
            // Check if this is an inline object after processing child nodes so matcher
            // for inline objects can verify if the element is empty.
            if (this._isInlineObjectElement(viewElement)) {
                inlineNodes.push(viewElement);
            } else {
                // It's an inline element that is not an object (like <b>, <i>) or a block element.
                for (const inlineNode of nestedInlineNodes){
                    inlineNodes.push(inlineNode);
                }
            }
        }
    }
    /**
     * Internal helper that walks the list of inline view nodes already generated from DOM nodes
     * and handles whitespaces and NBSPs.
     *
     * @param domParent The DOM parent of the given inline nodes. This should be a document fragment or
     * a block element to whitespace processing start cleaning.
     * @param inlineNodes An array of recently encountered inline nodes truncated to the block element boundaries.
     */ _processDomInlineNodes(domParent, inlineNodes, options) {
        if (!inlineNodes.length) {
            return;
        }
        // Process text nodes only after reaching a block or document fragment,
        // do not alter whitespaces while processing an inline element like <b> or <i>.
        if (domParent && !this.isDocumentFragment(domParent) && !this._isBlockDomElement(domParent)) {
            return;
        }
        let prevNodeEndsWithSpace = false;
        for(let i = 0; i < inlineNodes.length; i++){
            const node = inlineNodes[i];
            if (!node.is('$text')) {
                prevNodeEndsWithSpace = false;
                continue;
            }
            let data;
            let nodeEndsWithSpace = false;
            if (_hasViewParentOfType(node, this.preElements)) {
                data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDataWithoutFiller"])(node.data);
            } else {
                // Change all consecutive whitespace characters (from the [ \n\t\r] set –
                // see https://github.com/ckeditor/ckeditor5-engine/issues/822#issuecomment-311670249) to a single space character.
                // That's how multiple whitespaces are treated when rendered, so we normalize those whitespaces.
                // We're replacing 1+ (and not 2+) to also normalize singular \n\t\r characters (#822).
                data = node.data.replace(/[ \n\t\r]{1,}/g, ' ');
                nodeEndsWithSpace = /[^\S\u00A0]/.test(data.charAt(data.length - 1));
                const prevNode = i > 0 ? inlineNodes[i - 1] : null;
                const nextNode = i + 1 < inlineNodes.length ? inlineNodes[i + 1] : null;
                const shouldLeftTrim = !prevNode || prevNode.is('element') && prevNode.name == 'br' || prevNodeEndsWithSpace;
                const shouldRightTrim = nextNode ? false : !(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["startsWithFiller"])(node.data);
                // Do not try to clear whitespaces if this is flat mapping for the purpose of mutation observer and differ in rendering.
                if (options.withChildren !== false) {
                    // If the previous dom text node does not exist or it ends by whitespace character, remove space character from the
                    // beginning of this text node. Such space character is treated as a whitespace.
                    if (shouldLeftTrim) {
                        data = data.replace(/^ /, '');
                    }
                    // If the next text node does not exist remove space character from the end of this text node.
                    if (shouldRightTrim) {
                        data = data.replace(/ $/, '');
                    }
                }
                // At the beginning and end of a block element, Firefox inserts normal space + <br> instead of non-breaking space.
                // This means that the text node starts/end with normal space instead of non-breaking space.
                // This causes a problem because the normal space would be removed in `.replace` calls above. To prevent that,
                // the inline filler is removed only after the data is initially processed (by the `.replace` above). See ckeditor5#692.
                data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDataWithoutFiller"])(data);
                // At this point we should have removed all whitespaces from DOM text data.
                //
                // Now, We will reverse the process that happens in `_processDataFromViewText`.
                //
                // We have to change &nbsp; chars, that were in DOM text data because of rendering reasons, to spaces.
                // First, change all ` \u00A0` pairs (space + &nbsp;) to two spaces. DOM converter changes two spaces from model/view to
                // ` \u00A0` to ensure proper rendering. Since here we convert back, we recognize those pairs and change them back to `  `.
                data = data.replace(/ \u00A0/g, '  ');
                const isNextNodeInlineObjectElement = nextNode && nextNode.is('element') && nextNode.name != 'br';
                const isNextNodeStartingWithSpace = nextNode && nextNode.is('$text') && nextNode.data.charAt(0) == ' ';
                // Then, let's change the last nbsp to a space.
                if (/[ \u00A0]\u00A0$/.test(data) || !nextNode || isNextNodeInlineObjectElement || isNextNodeStartingWithSpace) {
                    data = data.replace(/\u00A0$/, ' ');
                }
                // Then, change &nbsp; character that is at the beginning of the text node to space character.
                // We do that replacement only if this is the first node or the previous node ends on whitespace character.
                if (shouldLeftTrim || prevNode && prevNode.is('element') && prevNode.name != 'br') {
                    data = data.replace(/^\u00A0/, ' ');
                }
            }
            // At this point, all whitespaces should be removed and all &nbsp; created for rendering reasons should be
            // changed to normal space. All left &nbsp; are &nbsp; inserted intentionally.
            if (data.length == 0 && node.parent) {
                node._remove();
                inlineNodes.splice(i, 1);
                i--;
            } else {
                node._data = data;
                prevNodeEndsWithSpace = nodeEndsWithSpace;
            }
        }
        inlineNodes.length = 0;
    }
    /**
     * Takes text data from a given {@link module:engine/view/text~Text#data} and processes it so
     * it is correctly displayed in the DOM.
     *
     * Following changes are done:
     *
     * * a space at the beginning is changed to `&nbsp;` if this is the first text node in its container
     * element or if a previous text node ends with a space character,
     * * space at the end of the text node is changed to `&nbsp;` if there are two spaces at the end of a node or if next node
     * starts with a space or if it is the last text node in its container,
     * * remaining spaces are replaced to a chain of spaces and `&nbsp;` (e.g. `'x   x'` becomes `'x &nbsp; x'`).
     *
     * Content of {@link #preElements} is not processed.
     *
     * @param node View text node to process.
     * @returns Processed text data.
     */ _processDataFromViewText(node) {
        let data = node.data;
        // If any of node ancestors has a name which is in `preElements` array, then currently processed
        // view text node is (will be) in preformatted element. We should not change whitespaces then.
        if (node.getAncestors().some((parent)=>this.preElements.includes(parent.name))) {
            return data;
        }
        // 1. Replace the first space with a nbsp if the previous node ends with a space or there is no previous node
        // (container element boundary).
        if (data.charAt(0) == ' ') {
            const prevNode = this._getTouchingInlineViewNode(node, false);
            const prevEndsWithSpace = prevNode && prevNode.is('$textProxy') && this._nodeEndsWithSpace(prevNode);
            if (prevEndsWithSpace || !prevNode) {
                data = '\u00A0' + data.substr(1);
            }
        }
        // 2. Replace the last space with nbsp if there are two spaces at the end or if the next node starts with space or there is no
        // next node (container element boundary).
        //
        // Keep in mind that Firefox prefers $nbsp; before tag, not inside it:
        //
        // Foo <span>&nbsp;bar</span>  <-- bad.
        // Foo&nbsp;<span> bar</span>  <-- good.
        //
        // More here: https://github.com/ckeditor/ckeditor5-engine/issues/1747.
        if (data.charAt(data.length - 1) == ' ') {
            const nextNode = this._getTouchingInlineViewNode(node, true);
            const nextStartsWithSpace = nextNode && nextNode.is('$textProxy') && nextNode.data.charAt(0) == ' ';
            if (data.charAt(data.length - 2) == ' ' || !nextNode || nextStartsWithSpace) {
                data = data.substr(0, data.length - 1) + '\u00A0';
            }
        }
        // 3. Create space+nbsp pairs.
        return data.replace(/ {2}/g, ' \u00A0');
    }
    /**
     * Checks whether given node ends with a space character after changing appropriate space characters to `&nbsp;`s.
     *
     * @param  node Node to check.
     * @returns `true` if given `node` ends with space, `false` otherwise.
     */ _nodeEndsWithSpace(node) {
        if (node.getAncestors().some((parent)=>this.preElements.includes(parent.name))) {
            return false;
        }
        const data = this._processDataFromViewText(node);
        return data.charAt(data.length - 1) == ' ';
    }
    /**
     * Helper function. For given {@link module:engine/view/text~Text view text node}, it finds previous or next sibling
     * that is contained in the same container element. If there is no such sibling, `null` is returned.
     *
     * @param node Reference node.
     * @returns Touching text node, an inline object
     * or `null` if there is no next or previous touching text node.
     */ _getTouchingInlineViewNode(node, getNext) {
        const treeWalker = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$treewalker$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]({
            startPosition: getNext ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(node) : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(node),
            direction: getNext ? 'forward' : 'backward'
        });
        for (const value of treeWalker){
            // <br> found – it works like a block boundary, so do not scan further.
            if (value.item.is('element', 'br')) {
                return null;
            } else if (this._isInlineObjectElement(value.item)) {
                return value.item;
            } else if (value.item.is('containerElement')) {
                return null;
            } else if (value.item.is('$textProxy')) {
                return value.item;
            }
        }
        return null;
    }
    /**
     * Returns `true` if a DOM node belongs to {@link #blockElements}. `false` otherwise.
     */ _isBlockDomElement(node) {
        return this.isElement(node) && this.blockElements.includes(node.tagName.toLowerCase());
    }
    /**
     * Returns `true` if a view node belongs to {@link #blockElements}. `false` otherwise.
     */ _isBlockViewElement(node) {
        return node.is('element') && this.blockElements.includes(node.name);
    }
    /**
     * Returns `true` if a DOM node belongs to {@link #inlineObjectElements}. `false` otherwise.
     */ _isInlineObjectElement(node) {
        if (!node.is('element')) {
            return false;
        }
        return node.name == 'br' || this.inlineObjectElements.includes(node.name) || !!this._inlineObjectElementMatcher.match(node);
    }
    /**
     * Creates view element basing on the node type.
     *
     * @param node DOM node to check.
     * @param options Conversion options. See {@link module:engine/view/domconverter~DomConverter#domToView} options parameter.
     */ _createViewElement(node, options) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$iscomment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isComment$3e$__["isComment"])(node)) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, '$comment');
        }
        const viewName = options.keepOriginalCase ? node.tagName : node.tagName.toLowerCase();
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, viewName);
    }
    /**
     * Checks if view element's content should be treated as a raw data.
     *
     * @param viewElement View element to check.
     * @param options Conversion options. See {@link module:engine/view/domconverter~DomConverter#domToView} options parameter.
     */ _isViewElementWithRawContent(viewElement, options) {
        return options.withChildren !== false && viewElement.is('element') && !!this._rawContentElementMatcher.match(viewElement);
    }
    /**
     * Checks whether a given element name should be renamed in a current rendering mode.
     *
     * @param elementName The name of view element.
     */ _shouldRenameElement(elementName) {
        const name = elementName.toLowerCase();
        return this.renderingMode === 'editing' && this.unsafeElements.includes(name);
    }
    /**
     * Return a <span> element with a special attribute holding the name of the original element.
     * Optionally, copy all the attributes of the original element if that element is provided.
     *
     * @param elementName The name of view element.
     * @param originalDomElement The original DOM element to copy attributes and content from.
     */ _createReplacementDomElement(elementName, originalDomElement) {
        const newDomElement = this._domDocument.createElement('span');
        // Mark the span replacing a script as hidden.
        newDomElement.setAttribute(UNSAFE_ELEMENT_REPLACEMENT_ATTRIBUTE, elementName);
        if (originalDomElement) {
            while(originalDomElement.firstChild){
                newDomElement.appendChild(originalDomElement.firstChild);
            }
            for (const attributeName of originalDomElement.getAttributeNames()){
                newDomElement.setAttribute(attributeName, originalDomElement.getAttribute(attributeName));
            }
        }
        return newDomElement;
    }
}
/**
 * Helper function.
 * Used to check if given native `Element` or `Text` node has parent with tag name from `types` array.
 *
 * @returns`true` if such parent exists or `false` if it does not.
 */ function _hasViewParentOfType(node, types) {
    return node.getAncestors().some((parent)=>parent.is('element') && types.includes(parent.name));
}
/**
 * A helper that executes given callback for each DOM node's ancestor, starting from the given node
 * and ending in document#documentElement.
 *
 * @param callback A callback to be executed for each ancestor.
 */ function forEachDomElementAncestor(element, callback) {
    let node = element;
    while(node){
        callback(node);
        node = node.parentElement;
    }
}
/**
 * Checks if given node is a nbsp block filler.
 *
 * A &nbsp; is a block filler only if it is a single child of a block element.
 *
 * @param domNode DOM node.
 */ function isNbspBlockFiller(domNode, blockElements) {
    const isNBSP = domNode.isEqualNode(NBSP_FILLER_REF);
    return isNBSP && hasBlockParent(domNode, blockElements) && domNode.parentNode.childNodes.length === 1;
}
/**
 * Checks if domNode has block parent.
 *
 * @param domNode DOM node.
 */ function hasBlockParent(domNode, blockElements) {
    const parent = domNode.parentNode;
    return !!parent && !!parent.tagName && blockElements.includes(parent.tagName.toLowerCase());
}
/**
 * Log to console the information about element that was replaced.
 * Check UNSAFE_ELEMENTS for all recognized unsafe elements.
 *
 * @param elementName The name of the view element.
 */ function _logUnsafeElement(elementName) {
    if (elementName === 'script') {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('domconverter-unsafe-script-element-detected');
    }
    if (elementName === 'style') {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["logWarning"])('domconverter-unsafe-style-element-detected');
    }
}
/**
 * In certain cases, Firefox mysteriously assigns so called "restricted objects" to native DOM Range properties.
 * Any attempt at accessing restricted object's properties causes errors.
 * See: https://github.com/ckeditor/ckeditor5/issues/9635.
 */ function isGeckoRestrictedDomSelection(domSelection) {
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isGecko) {
        return false;
    }
    if (!domSelection.rangeCount) {
        return false;
    }
    const container = domSelection.getRangeAt(0).startContainer;
    try {
        Object.prototype.toString.call(container);
    } catch (error) {
        return true;
    }
    return false;
} /**
 * While rendering the editor content, the {@link module:engine/view/domconverter~DomConverter} detected a `<script>` element that may
 * disrupt the editing experience. To avoid this, the `<script>` element was replaced with `<span data-ck-unsafe-element="script"></span>`.
 *
 * @error domconverter-unsafe-script-element-detected
 */  /**
 * While rendering the editor content, the {@link module:engine/view/domconverter~DomConverter} detected a `<style>` element that may affect
 * the editing experience. To avoid this, the `<style>` element was replaced with `<span data-ck-unsafe-element="style"></span>`.
 *
 * @error domconverter-unsafe-style-element-detected
 */  /**
 * The {@link module:engine/view/domconverter~DomConverter} detected an interactive attribute in the
 * {@glink framework/architecture/editing-engine#editing-pipeline editing pipeline}. For the best
 * editing experience, the attribute was renamed to `data-ck-unsafe-attribute-[original attribute name]`.
 *
 * If you are the author of the plugin that generated this attribute and you want it to be preserved
 * in the editing pipeline, you can configure this when creating the element
 * using {@link module:engine/view/downcastwriter~DowncastWriter} during the
 * {@glink framework/architecture/editing-engine#conversion model–view conversion}. Methods such as
 * {@link module:engine/view/downcastwriter~DowncastWriter#createContainerElement},
 * {@link module:engine/view/downcastwriter~DowncastWriter#createAttributeElement}, or
 * {@link module:engine/view/downcastwriter~DowncastWriter#createEmptyElement}
 * accept an option that will disable filtering of specific attributes:
 *
 * ```ts
 * const paragraph = writer.createContainerElement( 'p',
 * 	{
 * 		class: 'clickable-paragraph',
 * 		onclick: 'alert( "Paragraph clicked!" )'
 * 	},
 * 	{
 * 		// Make sure the "onclick" attribute will pass through.
 * 		renderUnsafeAttributes: [ 'onclick' ]
 * 	}
 * );
 * ```
 *
 * @error domconverter-unsafe-attribute-detected
 * @param domElement The DOM element the attribute was set on.
 * @param key The original name of the attribute
 * @param value The value of the original attribute
 */ 
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/observer
 */ __turbopack_context__.s([
    "default",
    ()=>Observer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DomEmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/emittermixin.js [app-ssr] (ecmascript) <export default as DomEmitterMixin>");
;
class Observer extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DomEmitterMixin$3e$__["DomEmitterMixin"])() {
    /**
     * Creates an instance of the observer.
     */ constructor(view){
        super();
        /**
         * The state of the observer. If it is disabled, no events will be fired.
         */ this._isEnabled = false;
        this.view = view;
        this.document = view.document;
    }
    /**
     * The state of the observer. If it is disabled, no events will be fired.
     */ get isEnabled() {
        return this._isEnabled;
    }
    /**
     * Enables the observer. This method is called when the observer is registered to the
     * {@link module:engine/view/view~View} and after {@link module:engine/view/view~View#forceRender rendering}
     * (all observers are {@link #disable disabled} before rendering).
     *
     * A typical use case for disabling observers is that mutation observers need to be disabled for the rendering.
     * However, a child class may not need to be disabled, so it can implement an empty method.
     *
     * @see module:engine/view/observer/observer~Observer#disable
     */ enable() {
        this._isEnabled = true;
    }
    /**
     * Disables the observer. This method is called before
     * {@link module:engine/view/view~View#forceRender rendering} to prevent firing events during rendering.
     *
     * @see module:engine/view/observer/observer~Observer#enable
     */ disable() {
        this._isEnabled = false;
    }
    /**
     * Disables and destroys the observer, among others removes event listeners created by the observer.
     */ destroy() {
        this.disable();
        this.stopListening();
    }
    /**
     * Checks whether a given DOM event should be ignored (should not be turned into a synthetic view document event).
     *
     * Currently, an event will be ignored only if its target or any of its ancestors has the `data-cke-ignore-events` attribute.
     * This attribute can be used inside the structures generated by
     * {@link module:engine/view/downcastwriter~DowncastWriter#createUIElement `DowncastWriter#createUIElement()`} to ignore events
     * fired within a UI that should be excluded from CKEditor 5's realms.
     *
     * @param domTarget The DOM event target to check (usually an element, sometimes a text node and
     * potentially sometimes a document, too).
     * @returns Whether this event should be ignored by the observer.
     */ checkShouldIgnoreEventFromTarget(domTarget) {
        if (domTarget && domTarget.nodeType === 3) {
            domTarget = domTarget.parentNode;
        }
        if (!domTarget || domTarget.nodeType !== 1) {
            return false;
        }
        return domTarget.matches('[data-cke-ignore-events], [data-cke-ignore-events] *');
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventdata.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/domeventdata
 */ __turbopack_context__.s([
    "default",
    ()=>DomEventData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$assignIn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__extend$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/assignIn.js [app-ssr] (ecmascript) <export default as extend>");
;
class DomEventData {
    /**
     * @param view The instance of the view controller.
     * @param domEvent The DOM event.
     * @param additionalData Additional properties that the instance should contain.
     */ constructor(view, domEvent, additionalData){
        this.view = view;
        this.document = view.document;
        this.domEvent = domEvent;
        this.domTarget = domEvent.target;
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$assignIn$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__extend$3e$__["extend"])(this, additionalData);
    }
    /**
     * The tree view element representing the target.
     */ get target() {
        return this.view.domConverter.mapDomToView(this.domTarget);
    }
    /**
     * Prevents the native's event default action.
     */ preventDefault() {
        this.domEvent.preventDefault();
    }
    /**
     * Stops native event propagation.
     */ stopPropagation() {
        this.domEvent.stopPropagation();
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/domeventobserver
 */ __turbopack_context__.s([
    "default",
    ()=>DomEventObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventdata$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventdata.js [app-ssr] (ecmascript)");
;
;
class DomEventObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    constructor(){
        super(...arguments);
        /**
         * If set to `true` DOM events will be listened on the capturing phase.
         * Default value is `false`.
         */ this.useCapture = false;
    }
    /**
     * @inheritDoc
     */ observe(domElement) {
        const types = typeof this.domEventType == 'string' ? [
            this.domEventType
        ] : this.domEventType;
        types.forEach((type)=>{
            this.listenTo(domElement, type, (eventInfo, domEvent)=>{
                if (this.isEnabled && !this.checkShouldIgnoreEventFromTarget(domEvent.target)) {
                    this.onDomEvent(domEvent);
                }
            }, {
                useCapture: this.useCapture
            });
        });
    }
    /**
     * @inheritDoc
     */ stopObserving(domElement) {
        this.stopListening(domElement);
    }
    /**
     * Calls `Document#fire()` if observer {@link #isEnabled is enabled}.
     *
     * @see module:utils/emittermixin~Emitter#fire
     * @param eventType The event type (name).
     * @param domEvent The DOM event.
     * @param additionalData The additional data which should extend the
     * {@link module:engine/view/observer/domeventdata~DomEventData event data} object.
     */ fire(eventType, domEvent, additionalData) {
        if (this.isEnabled) {
            this.document.fire(eventType, new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventdata$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.view, domEvent, additionalData));
        }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/keyobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/keyobserver
 */ __turbopack_context__.s([
    "default",
    ()=>KeyObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/keyboard.js [app-ssr] (ecmascript)");
;
;
class KeyObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    constructor(){
        super(...arguments);
        /**
         * @inheritDoc
         */ this.domEventType = [
            'keydown',
            'keyup'
        ];
    }
    /**
     * @inheritDoc
     */ onDomEvent(domEvt) {
        const data = {
            keyCode: domEvt.keyCode,
            altKey: domEvt.altKey,
            ctrlKey: domEvt.ctrlKey,
            shiftKey: domEvt.shiftKey,
            metaKey: domEvt.metaKey,
            get keystroke () {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getCode"])(this);
            }
        };
        this.fire(domEvt.type, domEvt, data);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/fakeselectionobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/fakeselectionobserver
 */ __turbopack_context__.s([
    "default",
    ()=>FakeSelectionObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/selection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/keyboard.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$debounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__debounce$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/debounce.js [app-ssr] (ecmascript) <export default as debounce>");
;
;
;
;
class FakeSelectionObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Creates new FakeSelectionObserver instance.
     */ constructor(view){
        super(view);
        this._fireSelectionChangeDoneDebounced = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$debounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__debounce$3e$__["debounce"])((data)=>{
            this.document.fire('selectionChangeDone', data);
        }, 200);
    }
    /**
     * @inheritDoc
     */ observe() {
        const document = this.document;
        document.on('arrowKey', (eventInfo, data)=>{
            const selection = document.selection;
            if (selection.isFake && this.isEnabled) {
                // Prevents default key down handling - no selection change will occur.
                data.preventDefault();
            }
        }, {
            context: '$capture'
        });
        document.on('arrowKey', (eventInfo, data)=>{
            const selection = document.selection;
            if (selection.isFake && this.isEnabled) {
                this._handleSelectionMove(data.keyCode);
            }
        }, {
            priority: 'lowest'
        });
    }
    /**
     * @inheritDoc
     */ stopObserving() {}
    /**
     * @inheritDoc
     */ destroy() {
        super.destroy();
        this._fireSelectionChangeDoneDebounced.cancel();
    }
    /**
     * Handles collapsing view selection according to given key code. If left or up key is provided - new selection will be
     * collapsed to left. If right or down key is pressed - new selection will be collapsed to right.
     *
     * This method fires {@link module:engine/view/document~Document#event:selectionChange} and
     * {@link module:engine/view/document~Document#event:selectionChangeDone} events imitating behaviour of
     * {@link module:engine/view/observer/selectionobserver~SelectionObserver}.
     */ _handleSelectionMove(keyCode) {
        const selection = this.document.selection;
        const newSelection = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](selection.getRanges(), {
            backward: selection.isBackward,
            fake: false
        });
        // Left or up arrow pressed - move selection to start.
        if (keyCode == __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["keyCodes"].arrowleft || keyCode == __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["keyCodes"].arrowup) {
            newSelection.setTo(newSelection.getFirstPosition());
        }
        // Right or down arrow pressed - move selection to end.
        if (keyCode == __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["keyCodes"].arrowright || keyCode == __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["keyCodes"].arrowdown) {
            newSelection.setTo(newSelection.getLastPosition());
        }
        const data = {
            oldSelection: selection,
            newSelection,
            domSelection: null
        };
        // Fire dummy selection change event.
        this.document.fire('selectionChange', data);
        // Call` #_fireSelectionChangeDoneDebounced` every time when `selectionChange` event is fired.
        // This function is debounced what means that `selectionChangeDone` event will be fired only when
        // defined int the function time will elapse since the last time the function was called.
        // So `selectionChangeDone` will be fired when selection will stop changing.
        this._fireSelectionChangeDoneDebounced(data);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/mutationobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/mutationobserver
 */ /* globals window */ __turbopack_context__.s([
    "default",
    ()=>MutationObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/filler.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isEqualWith$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqualWith$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/isEqualWith.js [app-ssr] (ecmascript) <export default as isEqualWith>");
;
;
;
class MutationObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * @inheritDoc
     */ constructor(view){
        super(view);
        this._config = {
            childList: true,
            characterData: true,
            subtree: true
        };
        this.domConverter = view.domConverter;
        this.renderer = view._renderer;
        this._domElements = new Set();
        this._mutationObserver = new window.MutationObserver(this._onMutations.bind(this));
    }
    /**
     * Synchronously handles mutations and empties the queue.
     */ flush() {
        this._onMutations(this._mutationObserver.takeRecords());
    }
    /**
     * @inheritDoc
     */ observe(domElement) {
        this._domElements.add(domElement);
        if (this.isEnabled) {
            this._mutationObserver.observe(domElement, this._config);
        }
    }
    /**
     * @inheritDoc
     */ stopObserving(domElement) {
        this._domElements.delete(domElement);
        if (this.isEnabled) {
            // Unfortunately, it is not possible to stop observing particular DOM element.
            // In order to stop observing one of multiple DOM elements, we need to re-connect the mutation observer.
            this._mutationObserver.disconnect();
            for (const domElement of this._domElements){
                this._mutationObserver.observe(domElement, this._config);
            }
        }
    }
    /**
     * @inheritDoc
     */ enable() {
        super.enable();
        for (const domElement of this._domElements){
            this._mutationObserver.observe(domElement, this._config);
        }
    }
    /**
     * @inheritDoc
     */ disable() {
        super.disable();
        this._mutationObserver.disconnect();
    }
    /**
     * @inheritDoc
     */ destroy() {
        super.destroy();
        this._mutationObserver.disconnect();
    }
    /**
     * Handles mutations. Mark view elements to sync and call render.
     *
     * @param domMutations Array of native mutations.
     */ _onMutations(domMutations) {
        // As a result of this.flush() we can have an empty collection.
        if (domMutations.length === 0) {
            return;
        }
        const domConverter = this.domConverter;
        // Use map and set for deduplication.
        const mutatedTextNodes = new Set();
        const elementsWithMutatedChildren = new Set();
        // Handle `childList` mutations first, so we will be able to check if the `characterData` mutation is in the
        // element with changed structure anyway.
        for (const mutation of domMutations){
            const element = domConverter.mapDomToView(mutation.target);
            if (!element) {
                continue;
            }
            // Do not collect mutations from UIElements and RawElements.
            if (element.is('uiElement') || element.is('rawElement')) {
                continue;
            }
            if (mutation.type === 'childList' && !this._isBogusBrMutation(mutation)) {
                elementsWithMutatedChildren.add(element);
            }
        }
        // Handle `characterData` mutations later, when we have the full list of nodes which changed structure.
        for (const mutation of domMutations){
            const element = domConverter.mapDomToView(mutation.target);
            // Do not collect mutations from UIElements and RawElements.
            if (element && (element.is('uiElement') || element.is('rawElement'))) {
                continue;
            }
            if (mutation.type === 'characterData') {
                const text = domConverter.findCorrespondingViewText(mutation.target);
                if (text && !elementsWithMutatedChildren.has(text.parent)) {
                    mutatedTextNodes.add(text);
                } else if (!text && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["startsWithFiller"])(mutation.target)) {
                    elementsWithMutatedChildren.add(domConverter.mapDomToView(mutation.target.parentNode));
                }
            }
        }
        // Now we build the list of mutations to mark elements. We did not do it earlier to avoid marking the
        // same node multiple times in case of duplication.
        let hasMutations = false;
        for (const textNode of mutatedTextNodes){
            hasMutations = true;
            this.renderer.markToSync('text', textNode);
        }
        for (const viewElement of elementsWithMutatedChildren){
            const domElement = domConverter.mapViewToDom(viewElement);
            const viewChildren = Array.from(viewElement.getChildren());
            const newViewChildren = Array.from(domConverter.domChildrenToView(domElement, {
                withChildren: false
            }));
            // It may happen that as a result of many changes (sth was inserted and then removed),
            // both elements haven't really changed. #1031
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isEqualWith$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isEqualWith$3e$__["isEqualWith"])(viewChildren, newViewChildren, sameNodes)) {
                hasMutations = true;
                this.renderer.markToSync('children', viewElement);
            }
        }
        // In case only non-relevant mutations were recorded it skips the event and force render (#5600).
        if (hasMutations) {
            // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
            // @if CK_DEBUG_TYPING // 	console.group( '%c[MutationObserver]%c Mutations detected',
            // @if CK_DEBUG_TYPING // 		'font-weight:bold;color:green', ''
            // @if CK_DEBUG_TYPING // 	);
            // @if CK_DEBUG_TYPING // }
            // At this point we have "dirty DOM" (changed) and de-synched view (which has not been changed).
            // In order to "reset DOM" we render the view again.
            this.view.forceRender();
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.groupEnd();
        // @if CK_DEBUG_TYPING // }
        }
    }
    /**
     * Checks if mutation was generated by the browser inserting bogus br on the end of the block element.
     * Such mutations are generated while pressing space or performing native spellchecker correction
     * on the end of the block element in Firefox browser.
     *
     * @param mutation Native mutation object.
     */ _isBogusBrMutation(mutation) {
        let addedNode = null;
        // Check if mutation added only one node on the end of its parent.
        if (mutation.nextSibling === null && mutation.removedNodes.length === 0 && mutation.addedNodes.length == 1) {
            addedNode = this.domConverter.domToView(mutation.addedNodes[0], {
                withChildren: false
            });
        }
        return addedNode && addedNode.is('element', 'br');
    }
}
function sameNodes(child1, child2) {
    // First level of comparison (array of children vs array of children) – use the Lodash's default behavior.
    if (Array.isArray(child1)) {
        return;
    }
    // Elements.
    if (child1 === child2) {
        return true;
    } else if (child1.is('$text') && child2.is('$text')) {
        return child1.data === child2.data;
    }
    // Not matching types.
    return false;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/focusobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/focusobserver
 */ /* globals setTimeout, clearTimeout */ __turbopack_context__.s([
    "default",
    ()=>FocusObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript)");
;
class FocusObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * @inheritDoc
     */ constructor(view){
        super(view);
        /**
         * Set to `true` if the document is in the process of setting the focus.
         *
         * The flag is used to indicate that setting the focus is in progress.
         */ this._isFocusChanging = false;
        /**
         * @inheritDoc
         */ this.domEventType = [
            'focus',
            'blur'
        ];
        this.useCapture = true;
        const document = this.document;
        document.on('focus', ()=>{
            this._isFocusChanging = true;
            // Unfortunately native `selectionchange` event is fired asynchronously.
            // We need to wait until `SelectionObserver` handle the event and then render. Otherwise rendering will
            // overwrite new DOM selection with selection from the view.
            // See https://github.com/ckeditor/ckeditor5-engine/issues/795 for more details.
            // Long timeout is needed to solve #676 and https://github.com/ckeditor/ckeditor5-engine/issues/1157 issues.
            //
            // Using `view.change()` instead of `view.forceRender()` to prevent double rendering
            // in a situation where `selectionchange` already caused selection change.
            this._renderTimeoutId = setTimeout(()=>{
                this.flush();
                view.change(()=>{});
            }, 50);
        });
        document.on('blur', (evt, data)=>{
            const selectedEditable = document.selection.editableElement;
            if (selectedEditable === null || selectedEditable === data.target) {
                document.isFocused = false;
                this._isFocusChanging = false;
                // Re-render the document to update view elements
                // (changing document.isFocused already marked view as changed since last rendering).
                view.change(()=>{});
            }
        });
    }
    /**
     * Finishes setting the document focus state.
     */ flush() {
        if (this._isFocusChanging) {
            this._isFocusChanging = false;
            this.document.isFocused = true;
        }
    }
    /**
     * @inheritDoc
     */ onDomEvent(domEvent) {
        this.fire(domEvent.type, domEvent);
    }
    /**
     * @inheritDoc
     */ destroy() {
        if (this._renderTimeoutId) {
            clearTimeout(this._renderTimeoutId);
        }
        super.destroy();
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/selectionobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/selectionobserver
 */ /* global setInterval, clearInterval */ __turbopack_context__.s([
    "default",
    ()=>SelectionObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$mutationobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/mutationobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/env.js [app-ssr] (ecmascript) <export default as env>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$debounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__debounce$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/debounce.js [app-ssr] (ecmascript) <export default as debounce>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$focusobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/focusobserver.js [app-ssr] (ecmascript)");
;
;
;
;
;
class SelectionObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    constructor(view){
        super(view);
        this.mutationObserver = view.getObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$mutationobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        this.focusObserver = view.getObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$focusobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        this.selection = this.document.selection;
        this.domConverter = view.domConverter;
        this._documents = new WeakSet();
        this._fireSelectionChangeDoneDebounced = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$debounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__debounce$3e$__["debounce"])((data)=>{
            this.document.fire('selectionChangeDone', data);
        }, 200);
        this._clearInfiniteLoopInterval = setInterval(()=>this._clearInfiniteLoop(), 1000);
        this._documentIsSelectingInactivityTimeoutDebounced = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$debounce$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__debounce$3e$__["debounce"])(()=>this.document.isSelecting = false, 5000);
        this._loopbackCounter = 0;
    }
    /**
     * @inheritDoc
     */ observe(domElement) {
        const domDocument = domElement.ownerDocument;
        const startDocumentIsSelecting = ()=>{
            this.document.isSelecting = true;
            // Let's activate the safety timeout each time the document enters the "is selecting" state.
            this._documentIsSelectingInactivityTimeoutDebounced();
        };
        const endDocumentIsSelecting = ()=>{
            if (!this.document.isSelecting) {
                return;
            }
            // Make sure that model selection is up-to-date at the end of selecting process.
            // Sometimes `selectionchange` events could arrive after the `mouseup` event and that selection could be already outdated.
            this._handleSelectionChange(null, domDocument);
            this.document.isSelecting = false;
            // The safety timeout can be canceled when the document leaves the "is selecting" state.
            this._documentIsSelectingInactivityTimeoutDebounced.cancel();
        };
        // The document has the "is selecting" state while the user keeps making (extending) the selection
        // (e.g. by holding the mouse button and moving the cursor). The state resets when they either released
        // the mouse button or interrupted the process by pressing or releasing any key.
        this.listenTo(domElement, 'selectstart', startDocumentIsSelecting, {
            priority: 'highest'
        });
        this.listenTo(domElement, 'keydown', endDocumentIsSelecting, {
            priority: 'highest',
            useCapture: true
        });
        this.listenTo(domElement, 'keyup', endDocumentIsSelecting, {
            priority: 'highest',
            useCapture: true
        });
        // Add document-wide listeners only once. This method could be called for multiple editing roots.
        if (this._documents.has(domDocument)) {
            return;
        }
        // This listener is using capture mode to make sure that selection is upcasted before any other
        // handler would like to check it and update (for example table multi cell selection).
        this.listenTo(domDocument, 'mouseup', endDocumentIsSelecting, {
            priority: 'highest',
            useCapture: true
        });
        this.listenTo(domDocument, 'selectionchange', (evt, domEvent)=>{
            // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
            // @if CK_DEBUG_TYPING // 	const domSelection = domDocument.defaultView!.getSelection();
            // @if CK_DEBUG_TYPING // 	console.group( '%c[SelectionObserver]%c selectionchange', 'color:green', ''
            // @if CK_DEBUG_TYPING // 	);
            // @if CK_DEBUG_TYPING // 	console.info( '%c[SelectionObserver]%c DOM Selection:', 'font-weight:bold;color:green', '',
            // @if CK_DEBUG_TYPING // 		{ node: domSelection!.anchorNode, offset: domSelection!.anchorOffset },
            // @if CK_DEBUG_TYPING // 		{ node: domSelection!.focusNode, offset: domSelection!.focusOffset }
            // @if CK_DEBUG_TYPING // 	);
            // @if CK_DEBUG_TYPING // }
            // The Renderer is disabled while composing on non-android browsers, so we can't update the view selection
            // because the DOM and view tree drifted apart. Position mapping could fail because of it.
            if (this.document.isComposing && !__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid) {
                // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
                // @if CK_DEBUG_TYPING // 	console.info( '%c[SelectionObserver]%c Selection change ignored (isComposing)',
                // @if CK_DEBUG_TYPING // 		'font-weight:bold;color:green', ''
                // @if CK_DEBUG_TYPING // 	);
                // @if CK_DEBUG_TYPING // 	console.groupEnd();
                // @if CK_DEBUG_TYPING // }
                return;
            }
            this._handleSelectionChange(domEvent, domDocument);
            // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
            // @if CK_DEBUG_TYPING // 	console.groupEnd();
            // @if CK_DEBUG_TYPING // }
            // Defer the safety timeout when the selection changes (e.g. the user keeps extending the selection
            // using their mouse).
            this._documentIsSelectingInactivityTimeoutDebounced();
        });
        this._documents.add(domDocument);
    }
    /**
     * @inheritDoc
     */ stopObserving(domElement) {
        this.stopListening(domElement);
    }
    /**
     * @inheritDoc
     */ destroy() {
        super.destroy();
        clearInterval(this._clearInfiniteLoopInterval);
        this._fireSelectionChangeDoneDebounced.cancel();
        this._documentIsSelectingInactivityTimeoutDebounced.cancel();
    }
    /* istanbul ignore next -- @preserve */ _reportInfiniteLoop() {
    // @if CK_DEBUG //		throw new Error(
    // @if CK_DEBUG //			'Selection change observer detected an infinite rendering loop.\n\n' +
    // @if CK_DEBUG //	 		'⚠️⚠️ Report this error on https://github.com/ckeditor/ckeditor5/issues/11658.'
    // @if CK_DEBUG //		);
    }
    /**
     * Selection change listener. {@link module:engine/view/observer/mutationobserver~MutationObserver#flush Flush} mutations, check if
     * a selection changes and fires {@link module:engine/view/document~Document#event:selectionChange} event on every change
     * and {@link module:engine/view/document~Document#event:selectionChangeDone} when a selection stop changing.
     *
     * @param domEvent DOM event.
     * @param domDocument DOM document.
     */ _handleSelectionChange(domEvent, domDocument) {
        if (!this.isEnabled) {
            return;
        }
        const domSelection = domDocument.defaultView.getSelection();
        if (this.checkShouldIgnoreEventFromTarget(domSelection.anchorNode)) {
            return;
        }
        // Ensure the mutation event will be before selection event on all browsers.
        this.mutationObserver.flush();
        const newViewSelection = this.domConverter.domSelectionToView(domSelection);
        // Do not convert selection change if the new view selection has no ranges in it.
        //
        // It means that the DOM selection is in some way incorrect. Ranges that were in the DOM selection could not be
        // converted to the view. This happens when the DOM selection was moved outside of the editable element.
        if (newViewSelection.rangeCount == 0) {
            this.view.hasDomSelection = false;
            return;
        }
        this.view.hasDomSelection = true;
        // Mark the latest focus change as complete (we got new selection after the focus so the selection is in the focused element).
        this.focusObserver.flush();
        if (this.selection.isEqual(newViewSelection) && this.domConverter.isDomSelectionCorrect(domSelection)) {
            return;
        }
        // Ensure we are not in the infinite loop (#400).
        // This counter is reset each second. 60 selection changes in 1 second is enough high number
        // to be very difficult (impossible) to achieve using just keyboard keys (during normal editor use).
        if (++this._loopbackCounter > 60) {
            // Selection change observer detected an infinite rendering loop.
            // Most probably you try to put the selection in the position which is not allowed
            // by the browser and browser fixes it automatically what causes `selectionchange` event on
            // which a loopback through a model tries to re-render the wrong selection and again.
            this._reportInfiniteLoop();
            return;
        }
        if (this.selection.isSimilar(newViewSelection)) {
            // If selection was equal and we are at this point of algorithm, it means that it was incorrect.
            // Just re-render it, no need to fire any events, etc.
            this.view.forceRender();
        } else {
            const data = {
                oldSelection: this.selection,
                newSelection: newViewSelection,
                domSelection
            };
            // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
            // @if CK_DEBUG_TYPING // 	console.info( '%c[SelectionObserver]%c Fire selection change:',
            // @if CK_DEBUG_TYPING // 		'font-weight:bold;color:green', '',
            // @if CK_DEBUG_TYPING // 		newViewSelection.getFirstRange()
            // @if CK_DEBUG_TYPING // 	);
            // @if CK_DEBUG_TYPING // }
            // Prepare data for new selection and fire appropriate events.
            this.document.fire('selectionChange', data);
            // Call `#_fireSelectionChangeDoneDebounced` every time when `selectionChange` event is fired.
            // This function is debounced what means that `selectionChangeDone` event will be fired only when
            // defined int the function time will elapse since the last time the function was called.
            // So `selectionChangeDone` will be fired when selection will stop changing.
            this._fireSelectionChangeDoneDebounced(data);
        }
    }
    /**
     * Clears `SelectionObserver` internal properties connected with preventing infinite loop.
     */ _clearInfiniteLoop() {
        this._loopbackCounter = 0;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/compositionobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/compositionobserver
 */ __turbopack_context__.s([
    "default",
    ()=>CompositionObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript)");
;
class CompositionObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * @inheritDoc
     */ constructor(view){
        super(view);
        /**
         * @inheritDoc
         */ this.domEventType = [
            'compositionstart',
            'compositionupdate',
            'compositionend'
        ];
        const document = this.document;
        document.on('compositionstart', ()=>{
            // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
            // @if CK_DEBUG_TYPING // 	console.log( '%c[CompositionObserver] ' +
            // @if CK_DEBUG_TYPING // 		'┌───────────────────────────── isComposing = true ─────────────────────────────┐',
            // @if CK_DEBUG_TYPING // 		'font-weight: bold; color: green'
            // @if CK_DEBUG_TYPING // 	);
            // @if CK_DEBUG_TYPING // }
            document.isComposing = true;
        }, {
            priority: 'low'
        });
        document.on('compositionend', ()=>{
            // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
            // @if CK_DEBUG_TYPING // 	console.log( '%c[CompositionObserver] ' +
            // @if CK_DEBUG_TYPING // 		'└───────────────────────────── isComposing = false ─────────────────────────────┘',
            // @if CK_DEBUG_TYPING // 		'font-weight: bold; color: green'
            // @if CK_DEBUG_TYPING // 	);
            // @if CK_DEBUG_TYPING // }
            document.isComposing = false;
        }, {
            priority: 'low'
        });
    }
    /**
     * @inheritDoc
     */ onDomEvent(domEvent) {
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.group( `%c[CompositionObserver]%c ${ domEvent.type }`, 'color: green', '' );
        // @if CK_DEBUG_TYPING // }
        this.fire(domEvent.type, domEvent, {
            data: domEvent.data
        });
    // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
    // @if CK_DEBUG_TYPING // 	console.groupEnd();
    // @if CK_DEBUG_TYPING // }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/datatransfer.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * A facade over the native [`DataTransfer`](https://developer.mozilla.org/en-US/docs/Web/API/DataTransfer) object.
 */ __turbopack_context__.s([
    "default",
    ()=>DataTransfer
]);
class DataTransfer {
    /**
     * @param nativeDataTransfer The native [`DataTransfer`](https://developer.mozilla.org/en-US/docs/Web/API/DataTransfer) object.
     * @param options.cacheFiles Whether `files` list should be initialized in the constructor.
     */ constructor(nativeDataTransfer, options = {}){
        // We should store references to the File instances in case someone would like to process this files
        // outside the event handler. Files are stored only for `drop` and `paste` events because they are not usable
        // in other events and are generating a huge delay on Firefox while dragging.
        // See https://github.com/ckeditor/ckeditor5/issues/13366.
        this._files = options.cacheFiles ? getFiles(nativeDataTransfer) : null;
        this._native = nativeDataTransfer;
    }
    /**
     * The array of files created from the native `DataTransfer#files` or `DataTransfer#items`.
     */ get files() {
        if (!this._files) {
            this._files = getFiles(this._native);
        }
        return this._files;
    }
    /**
     * Returns an array of available native content types.
     */ get types() {
        return this._native.types;
    }
    /**
     * Gets the data from the data transfer by its MIME type.
     *
     * ```ts
     * dataTransfer.getData( 'text/plain' );
     * ```
     *
     * @param type The MIME type. E.g. `text/html` or `text/plain`.
     */ getData(type) {
        return this._native.getData(type);
    }
    /**
     * Sets the data in the data transfer.
     *
     * @param type The MIME type. E.g. `text/html` or `text/plain`.
     */ setData(type, data) {
        this._native.setData(type, data);
    }
    /**
     * The effect that is allowed for a drag operation.
     */ set effectAllowed(value) {
        this._native.effectAllowed = value;
    }
    get effectAllowed() {
        return this._native.effectAllowed;
    }
    /**
     * The actual drop effect.
     */ set dropEffect(value) {
        this._native.dropEffect = value;
    }
    get dropEffect() {
        return this._native.dropEffect;
    }
    /**
     * Set a preview image of the dragged content.
     */ setDragImage(image, x, y) {
        this._native.setDragImage(image, x, y);
    }
    /**
     * Whether the dragging operation was canceled.
     */ get isCanceled() {
        return this._native.dropEffect == 'none' || !!this._native.mozUserCancelled;
    }
}
function getFiles(nativeDataTransfer) {
    // DataTransfer.files and items are array-like and might not have an iterable interface.
    const files = Array.from(nativeDataTransfer.files || []);
    const items = Array.from(nativeDataTransfer.items || []);
    if (files.length) {
        return files;
    }
    // Chrome has empty DataTransfer.files, but allows getting files through the items interface.
    return items.filter((item)=>item.kind === 'file').map((item)=>item.getAsFile());
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/inputobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/inputobserver
 */ __turbopack_context__.s([
    "default",
    ()=>InputObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$datatransfer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/datatransfer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/env.js [app-ssr] (ecmascript) <export default as env>");
;
;
;
class InputObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    constructor(){
        super(...arguments);
        /**
         * @inheritDoc
         */ this.domEventType = 'beforeinput';
    }
    /**
     * @inheritDoc
     */ onDomEvent(domEvent) {
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.group( `%c[InputObserver]%c ${ domEvent.type }: ${ domEvent.inputType }`,
        // @if CK_DEBUG_TYPING // 		'color: green', 'color: default'
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        const domTargetRanges = domEvent.getTargetRanges();
        const view = this.view;
        const viewDocument = view.document;
        let dataTransfer = null;
        let data = null;
        let targetRanges = [];
        if (domEvent.dataTransfer) {
            dataTransfer = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$datatransfer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](domEvent.dataTransfer);
        }
        if (domEvent.data !== null) {
            data = domEvent.data;
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.info( `%c[InputObserver]%c event data: %c${ JSON.stringify( data ) }`,
        // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', 'font-weight:bold', 'color: blue;'
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        } else if (dataTransfer) {
            data = dataTransfer.getData('text/plain');
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.info( `%c[InputObserver]%c event data transfer: %c${ JSON.stringify( data ) }`,
        // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', 'font-weight:bold', 'color: blue;'
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        }
        // If the editor selection is fake (an object is selected), the DOM range does not make sense because it is anchored
        // in the fake selection container.
        if (viewDocument.selection.isFake) {
            // Future-proof: in case of multi-range fake selections being possible.
            targetRanges = Array.from(viewDocument.selection.getRanges());
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.info( '%c[InputObserver]%c using fake selection:',
        // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', 'font-weight:bold', targetRanges,
        // @if CK_DEBUG_TYPING // 		viewDocument.selection.isFake ? 'fake view selection' : 'fake DOM parent'
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        } else if (domTargetRanges.length) {
            targetRanges = domTargetRanges.map((domRange)=>{
                // Sometimes browser provides range that starts before editable node.
                // We try to fall back to collapsed range at the valid end position.
                // See https://github.com/ckeditor/ckeditor5/issues/14411.
                // See https://github.com/ckeditor/ckeditor5/issues/14050.
                const viewStart = view.domConverter.domPositionToView(domRange.startContainer, domRange.startOffset);
                const viewEnd = view.domConverter.domPositionToView(domRange.endContainer, domRange.endOffset);
                if (viewStart) {
                    return view.createRange(viewStart, viewEnd);
                } else if (viewEnd) {
                    return view.createRange(viewEnd);
                }
            }).filter((range)=>!!range);
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.info( '%c[InputObserver]%c using target ranges:',
        // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', 'font-weight:bold', targetRanges
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        } else if (__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid) {
            const domSelection = domEvent.target.ownerDocument.defaultView.getSelection();
            targetRanges = Array.from(view.domConverter.domSelectionToView(domSelection).getRanges());
        // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
        // @if CK_DEBUG_TYPING // 	console.info( '%c[InputObserver]%c using selection ranges:',
        // @if CK_DEBUG_TYPING // 		'color: green;font-weight: bold', 'font-weight:bold', targetRanges
        // @if CK_DEBUG_TYPING // 	);
        // @if CK_DEBUG_TYPING // }
        }
        // Android sometimes fires insertCompositionText with a new-line character at the end of the data
        // instead of firing insertParagraph beforeInput event.
        // Fire the correct type of beforeInput event and ignore the replaced fragment of text because
        // it wants to replace "test" with "test\n".
        // https://github.com/ckeditor/ckeditor5/issues/12368.
        if (__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isAndroid && domEvent.inputType == 'insertCompositionText' && data && data.endsWith('\n')) {
            this.fire(domEvent.type, domEvent, {
                inputType: 'insertParagraph',
                targetRanges: [
                    view.createRange(targetRanges[0].end)
                ]
            });
            // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
            // @if CK_DEBUG_TYPING // 	console.groupEnd();
            // @if CK_DEBUG_TYPING // }
            return;
        }
        // Normalize the insertText data that includes new-line characters.
        // https://github.com/ckeditor/ckeditor5/issues/2045.
        if (domEvent.inputType == 'insertText' && data && data.includes('\n')) {
            // There might be a single new-line or double for new paragraph, but we translate
            // it to paragraphs as it is our default action for enter handling.
            const parts = data.split(/\n{1,2}/g);
            let partTargetRanges = targetRanges;
            for(let i = 0; i < parts.length; i++){
                const dataPart = parts[i];
                if (dataPart != '') {
                    this.fire(domEvent.type, domEvent, {
                        data: dataPart,
                        dataTransfer,
                        targetRanges: partTargetRanges,
                        inputType: domEvent.inputType,
                        isComposing: domEvent.isComposing
                    });
                    // Use the result view selection so following events will be added one after another.
                    partTargetRanges = [
                        viewDocument.selection.getFirstRange()
                    ];
                }
                if (i + 1 < parts.length) {
                    this.fire(domEvent.type, domEvent, {
                        inputType: 'insertParagraph',
                        targetRanges: partTargetRanges
                    });
                    // Use the result view selection so following events will be added one after another.
                    partTargetRanges = [
                        viewDocument.selection.getFirstRange()
                    ];
                }
            }
            // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
            // @if CK_DEBUG_TYPING // 	console.groupEnd();
            // @if CK_DEBUG_TYPING // }
            return;
        }
        // Fire the normalized beforeInput event.
        this.fire(domEvent.type, domEvent, {
            data,
            dataTransfer,
            targetRanges,
            inputType: domEvent.inputType,
            isComposing: domEvent.isComposing
        });
    // @if CK_DEBUG_TYPING // if ( ( window as any ).logCKETyping ) {
    // @if CK_DEBUG_TYPING // 	console.groupEnd();
    // @if CK_DEBUG_TYPING // }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/arrowkeysobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/arrowkeysobserver
 */ __turbopack_context__.s([
    "default",
    ()=>ArrowKeysObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingeventinfo.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/keyboard.js [app-ssr] (ecmascript)");
;
;
;
class ArrowKeysObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * @inheritDoc
     */ constructor(view){
        super(view);
        this.document.on('keydown', (event, data)=>{
            if (this.isEnabled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isArrowKeyCode"])(data.keyCode)) {
                const eventInfo = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, 'arrowKey', this.document.selection.getFirstRange());
                this.document.fire(eventInfo, data);
                if (eventInfo.stop.called) {
                    event.stop();
                }
            }
        });
    }
    /**
     * @inheritDoc
     */ observe() {}
    /**
     * @inheritDoc
     */ stopObserving() {}
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/tabobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "default",
    ()=>TabObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingeventinfo.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/keyboard.js [app-ssr] (ecmascript)");
;
;
;
class TabObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * @inheritDoc
     */ constructor(view){
        super(view);
        const doc = this.document;
        doc.on('keydown', (evt, data)=>{
            if (!this.isEnabled || data.keyCode != __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["keyCodes"].tab || data.ctrlKey) {
                return;
            }
            const event = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](doc, 'tab', doc.selection.getFirstRange());
            doc.fire(event, data);
            if (event.stop.called) {
                evt.stop();
            }
        });
    }
    /**
     * @inheritDoc
     */ observe() {}
    /**
     * @inheritDoc
     */ stopObserving() {}
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/view.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/view
 */ __turbopack_context__.s([
    "default",
    ()=>View
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/document.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$downcastwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/downcastwriter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$renderer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/renderer.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$domconverter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/domconverter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/selection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$keyobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/keyobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$fakeselectionobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/fakeselectionobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$mutationobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/mutationobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$selectionobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/selectionobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$focusobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/focusobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$compositionobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/compositionobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$inputobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/inputobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$arrowkeysobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/arrowkeysobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$tabobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/tabobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/env.js [app-ssr] (ecmascript) <export default as env>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/observablemixin.js [app-ssr] (ecmascript) <export default as ObservableMixin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$scroll$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/dom/scroll.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/uielement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/filler.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/cloneDeep.js [app-ssr] (ecmascript) <export default as cloneDeep>");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
class View extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$observablemixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ObservableMixin$3e$__["ObservableMixin"])() {
    /**
     * @param stylesProcessor The styles processor instance.
     */ constructor(stylesProcessor){
        super();
        /**
         * Roots of the DOM tree. Map on the `HTMLElement`s with roots names as keys.
         */ this.domRoots = new Map();
        /**
         * A DOM root attributes cache. It saves the initial values of DOM root attributes before the DOM element
         * is {@link module:engine/view/view~View#attachDomRoot attached} to the view so later on, when
         * the view is destroyed ({@link module:engine/view/view~View#detachDomRoot}), they can be easily restored.
         * This way, the DOM element can go back to the (clean) state as if the editing view never used it.
         */ this._initialDomRootAttributes = new WeakMap();
        /**
         * Map of registered {@link module:engine/view/observer/observer~Observer observers}.
         */ this._observers = new Map();
        /**
         * Is set to `true` when {@link #change view changes} are currently in progress.
         */ this._ongoingChange = false;
        /**
         * Used to prevent calling {@link #forceRender} and {@link #change} during rendering view to the DOM.
         */ this._postFixersInProgress = false;
        /**
         * Internal flag to temporary disable rendering. See the usage in the {@link #_disableRendering}.
         */ this._renderingDisabled = false;
        /**
         * Internal flag that disables rendering when there are no changes since the last rendering.
         * It stores information about changed selection and changed elements from attached document roots.
         */ this._hasChangedSinceTheLastRendering = false;
        this.document = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$document$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](stylesProcessor);
        this.domConverter = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$domconverter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document);
        this.set('isRenderingInProgress', false);
        this.set('hasDomSelection', false);
        this._renderer = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$renderer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.domConverter, this.document.selection);
        this._renderer.bind('isFocused', 'isSelecting', 'isComposing').to(this.document, 'isFocused', 'isSelecting', 'isComposing');
        this._writer = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$downcastwriter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document);
        // Add default observers.
        // Make sure that this list matches AlwaysRegisteredObservers type.
        this.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$mutationobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        this.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$focusobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        this.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$selectionobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        this.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$keyobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        this.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$fakeselectionobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        this.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$compositionobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        this.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$arrowkeysobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        this.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$inputobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        this.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$tabobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        // Inject quirks handlers.
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$filler$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["injectQuirksHandling"])(this);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$uielement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["injectUiElementHandling"])(this);
        // Use 'normal' priority so that rendering is performed as first when using that priority.
        this.on('render', ()=>{
            this._render();
            // Informs that layout has changed after render.
            this.document.fire('layoutChanged');
            // Reset the `_hasChangedSinceTheLastRendering` flag after rendering.
            this._hasChangedSinceTheLastRendering = false;
        });
        // Listen to the document selection changes directly.
        this.listenTo(this.document.selection, 'change', ()=>{
            this._hasChangedSinceTheLastRendering = true;
        });
        // Trigger re-render if only the focus changed.
        this.listenTo(this.document, 'change:isFocused', ()=>{
            this._hasChangedSinceTheLastRendering = true;
        });
        // Remove ranges from DOM selection if editor is blurred.
        // See https://github.com/ckeditor/ckeditor5/issues/5753.
        if (__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isiOS) {
            this.listenTo(this.document, 'blur', (evt, data)=>{
                const relatedViewElement = this.domConverter.mapDomToView(data.domEvent.relatedTarget);
                // Do not modify DOM selection if focus is moved to other editable of the same editor.
                if (!relatedViewElement) {
                    this.domConverter._clearDomSelection();
                }
            });
        }
    }
    /**
     * Attaches a DOM root element to the view element and enable all observers on that element.
     * Also {@link module:engine/view/renderer~Renderer#markToSync mark element} to be synchronized
     * with the view what means that all child nodes will be removed and replaced with content of the view root.
     *
     * This method also will change view element name as the same as tag name of given dom root.
     * Name is always transformed to lower case.
     *
     * **Note:** Use {@link #detachDomRoot `detachDomRoot()`} to revert this action.
     *
     * @param domRoot DOM root element.
     * @param name Name of the root.
     */ attachDomRoot(domRoot, name = 'main') {
        const viewRoot = this.document.getRoot(name);
        // Set view root name the same as DOM root tag name.
        viewRoot._name = domRoot.tagName.toLowerCase();
        const initialDomRootAttributes = {};
        // 1. Copy and cache the attributes to remember the state of the element before attaching.
        //    The cached attributes will be restored in detachDomRoot() so the element goes to the
        //    clean state as if the editing view never used it.
        // 2. Apply the attributes using the view writer, so they all go under the control of the engine.
        //    The editing view takes over the attribute management completely because various
        //    features (e.g. addPlaceholder()) require dynamic changes of those attributes and they
        //    cannot be managed by the engine and the UI library at the same time.
        for (const { name, value } of Array.from(domRoot.attributes)){
            initialDomRootAttributes[name] = value;
            // Do not use writer.setAttribute() for the class attribute. The EditableUIView class
            // and its descendants could have already set some using the writer.addClass() on the view
            // document root. They haven't been rendered yet so they are not present in the DOM root.
            // Using writer.setAttribute( 'class', ... ) would override them completely.
            if (name === 'class') {
                this._writer.addClass(value.split(' '), viewRoot);
            } else {
                this._writer.setAttribute(name, value, viewRoot);
            }
        }
        this._initialDomRootAttributes.set(domRoot, initialDomRootAttributes);
        const updateContenteditableAttribute = ()=>{
            this._writer.setAttribute('contenteditable', (!viewRoot.isReadOnly).toString(), viewRoot);
            if (viewRoot.isReadOnly) {
                this._writer.addClass('ck-read-only', viewRoot);
            } else {
                this._writer.removeClass('ck-read-only', viewRoot);
            }
        };
        // Set initial value.
        updateContenteditableAttribute();
        this.domRoots.set(name, domRoot);
        this.domConverter.bindElements(domRoot, viewRoot);
        this._renderer.markToSync('children', viewRoot);
        this._renderer.markToSync('attributes', viewRoot);
        this._renderer.domDocuments.add(domRoot.ownerDocument);
        viewRoot.on('change:children', (evt, node)=>this._renderer.markToSync('children', node));
        viewRoot.on('change:attributes', (evt, node)=>this._renderer.markToSync('attributes', node));
        viewRoot.on('change:text', (evt, node)=>this._renderer.markToSync('text', node));
        viewRoot.on('change:isReadOnly', ()=>this.change(updateContenteditableAttribute));
        viewRoot.on('change', ()=>{
            this._hasChangedSinceTheLastRendering = true;
        });
        for (const observer of this._observers.values()){
            observer.observe(domRoot, name);
        }
    }
    /**
     * Detaches a DOM root element from the view element and restores its attributes to the state before
     * {@link #attachDomRoot `attachDomRoot()`}.
     *
     * @param name Name of the root to detach.
     */ detachDomRoot(name) {
        const domRoot = this.domRoots.get(name);
        // Remove all root attributes so the DOM element is "bare".
        Array.from(domRoot.attributes).forEach(({ name })=>domRoot.removeAttribute(name));
        const initialDomRootAttributes = this._initialDomRootAttributes.get(domRoot);
        // Revert all view root attributes back to the state before attachDomRoot was called.
        for(const attribute in initialDomRootAttributes){
            domRoot.setAttribute(attribute, initialDomRootAttributes[attribute]);
        }
        this.domRoots.delete(name);
        this.domConverter.unbindDomElement(domRoot);
        for (const observer of this._observers.values()){
            observer.stopObserving(domRoot);
        }
    }
    /**
     * Gets DOM root element.
     *
     * @param name  Name of the root.
     * @returns DOM root element instance.
     */ getDomRoot(name = 'main') {
        return this.domRoots.get(name);
    }
    /**
     * Creates observer of the given type if not yet created, {@link module:engine/view/observer/observer~Observer#enable enables} it
     * and {@link module:engine/view/observer/observer~Observer#observe attaches} to all existing and future
     * {@link #domRoots DOM roots}.
     *
     * Note: Observers are recognized by their constructor (classes). A single observer will be instantiated and used only
     * when registered for the first time. This means that features and other components can register a single observer
     * multiple times without caring whether it has been already added or not.
     *
     * @param ObserverConstructor The constructor of an observer to add.
     * Should create an instance inheriting from {@link module:engine/view/observer/observer~Observer}.
     * @returns Added observer instance.
     */ addObserver(ObserverConstructor) {
        let observer = this._observers.get(ObserverConstructor);
        if (observer) {
            return observer;
        }
        observer = new ObserverConstructor(this);
        this._observers.set(ObserverConstructor, observer);
        for (const [name, domElement] of this.domRoots){
            observer.observe(domElement, name);
        }
        observer.enable();
        return observer;
    }
    /**
     * Returns observer of the given type or `undefined` if such observer has not been added yet.
     *
     * @param ObserverConstructor The constructor of an observer to get.
     * @returns Observer instance or undefined.
     */ getObserver(ObserverConstructor) {
        return this._observers.get(ObserverConstructor);
    }
    /**
     * Disables all added observers.
     */ disableObservers() {
        for (const observer of this._observers.values()){
            observer.disable();
        }
    }
    /**
     * Enables all added observers.
     */ enableObservers() {
        for (const observer of this._observers.values()){
            observer.enable();
        }
    }
    /**
     * Scrolls the page viewport and {@link #domRoots} with their ancestors to reveal the
     * caret, **if not already visible to the user**.
     *
     * **Note**: Calling this method fires the {@link module:engine/view/view~ViewScrollToTheSelectionEvent} event that
     * allows custom behaviors.
     *
     * @param options Additional configuration of the scrolling behavior.
     * @param options.viewportOffset A distance between the DOM selection and the viewport boundary to be maintained
     * while scrolling to the selection (default is 20px). Setting this value to `0` will reveal the selection precisely at
     * the viewport boundary.
     * @param options.ancestorOffset A distance between the DOM selection and scrollable DOM root ancestor(s) to be maintained
     * while scrolling to the selection (default is 20px). Setting this value to `0` will reveal the selection precisely at
     * the scrollable ancestor(s) boundary.
     * @param options.alignToTop When set `true`, the DOM selection will be aligned to the top of the viewport if not already visible
     * (see `forceScroll` to learn more).
     * @param options.forceScroll When set `true`, the DOM selection will be aligned to the top of the viewport and scrollable ancestors
     * whether it is already visible or not. This option will only work when `alignToTop` is `true`.
     */ scrollToTheSelection({ alignToTop, forceScroll, viewportOffset = 20, ancestorOffset = 20 } = {}) {
        const range = this.document.selection.getFirstRange();
        if (!range) {
            return;
        }
        // Clone to make sure properties like `viewportOffset` are not mutated in the event listeners.
        const originalArgs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__["cloneDeep"])({
            alignToTop,
            forceScroll,
            viewportOffset,
            ancestorOffset
        });
        if (typeof viewportOffset === 'number') {
            viewportOffset = {
                top: viewportOffset,
                bottom: viewportOffset,
                left: viewportOffset,
                right: viewportOffset
            };
        }
        const options = {
            target: this.domConverter.viewRangeToDom(range),
            viewportOffset,
            ancestorOffset,
            alignToTop,
            forceScroll
        };
        this.fire('scrollToTheSelection', options, originalArgs);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$dom$2f$scroll$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["scrollViewportToShowTarget"])(options);
    }
    /**
     * It will focus DOM element representing {@link module:engine/view/editableelement~EditableElement EditableElement}
     * that is currently having selection inside.
     */ focus() {
        if (!this.document.isFocused) {
            const editable = this.document.selection.editableElement;
            if (editable) {
                this.domConverter.focus(editable);
                this.forceRender();
            } else {
            // Before focusing view document, selection should be placed inside one of the view's editables.
            // Normally its selection will be converted from model document (which have default selection), but
            // when using view document on its own, we need to manually place selection before focusing it.
            //
            // @if CK_DEBUG // console.warn( 'There is no selection in any editable to focus.' );
            }
        }
    }
    /**
     * The `change()` method is the primary way of changing the view. You should use it to modify any node in the view tree.
     * It makes sure that after all changes are made the view is rendered to the DOM (assuming that the view will be changed
     * inside the callback). It prevents situations when the DOM is updated when the view state is not yet correct. It allows
     * to nest calls one inside another and still performs a single rendering after all those changes are made.
     * It also returns the return value of its callback.
     *
     * ```ts
     * const text = view.change( writer => {
     * 	const newText = writer.createText( 'foo' );
     * 	writer.insert( position1, newText );
     *
     * 	view.change( writer => {
     * 		writer.insert( position2, writer.createText( 'bar' ) );
     * 	} );
     *
     * 	writer.remove( range );
     *
     * 	return newText;
     * } );
     * ```
     *
     * When the outermost change block is done and rendering to the DOM is over the
     * {@link module:engine/view/view~View#event:render `View#render`} event is fired.
     *
     * This method throws a `applying-view-changes-on-rendering` error when
     * the change block is used after rendering to the DOM has started.
     *
     * @param callback Callback function which may modify the view.
     * @returns Value returned by the callback.
     */ change(callback) {
        if (this.isRenderingInProgress || this._postFixersInProgress) {
            /**
             * Thrown when there is an attempt to make changes to the view tree when it is in incorrect state. This may
             * cause some unexpected behaviour and inconsistency between the DOM and the view.
             * This may be caused by:
             *
             * * calling {@link module:engine/view/view~View#change} or {@link module:engine/view/view~View#forceRender} during rendering
             * process,
             * * calling {@link module:engine/view/view~View#change} or {@link module:engine/view/view~View#forceRender} inside of
             *   {@link module:engine/view/document~Document#registerPostFixer post-fixer function}.
             *
             * @error cannot-change-view-tree
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('cannot-change-view-tree', this);
        }
        try {
            // Recursive call to view.change() method - execute listener immediately.
            if (this._ongoingChange) {
                return callback(this._writer);
            }
            // This lock will assure that all recursive calls to view.change() will end up in same block - one "render"
            // event for all nested calls.
            this._ongoingChange = true;
            const callbackResult = callback(this._writer);
            this._ongoingChange = false;
            // This lock is used by editing controller to render changes from outer most model.change() once. As plugins might call
            // view.change() inside model.change() block - this will ensures that postfixers and rendering are called once after all
            // changes. Also, we don't need to render anything if there're no changes since last rendering.
            if (!this._renderingDisabled && this._hasChangedSinceTheLastRendering) {
                this._postFixersInProgress = true;
                this.document._callPostFixers(this._writer);
                this._postFixersInProgress = false;
                this.fire('render');
            }
            return callbackResult;
        } catch (err) {
            // @if CK_DEBUG // throw err;
            /* istanbul ignore next -- @preserve */ __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"].rethrowUnexpectedError(err, this);
        }
    }
    /**
     * Forces rendering {@link module:engine/view/document~Document view document} to DOM. If any view changes are
     * currently in progress, rendering will start after all {@link #change change blocks} are processed.
     *
     * Note that this method is dedicated for special cases. All view changes should be wrapped in the {@link #change}
     * block and the view will automatically check whether it needs to render DOM or not.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `applying-view-changes-on-rendering` when
     * trying to re-render when rendering to DOM has already started.
     */ forceRender() {
        this._hasChangedSinceTheLastRendering = true;
        this.getObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$focusobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]).flush();
        this.change(()=>{});
    }
    /**
     * Destroys this instance. Makes sure that all observers are destroyed and listeners removed.
     */ destroy() {
        for (const observer of this._observers.values()){
            observer.destroy();
        }
        this.document.destroy();
        this.stopListening();
    }
    /**
     * Creates position at the given location. The location can be specified as:
     *
     * * a {@link module:engine/view/position~Position position},
     * * parent element and offset (offset defaults to `0`),
     * * parent element and `'end'` (sets position at the end of that element),
     * * {@link module:engine/view/item~Item view item} and `'before'` or `'after'` (sets position before or after given view item).
     *
     * This method is a shortcut to other constructors such as:
     *
     * * {@link #createPositionBefore},
     * * {@link #createPositionAfter},
     *
     * @param offset Offset or one of the flags. Used only when first parameter is a {@link module:engine/view/item~Item view item}.
     */ createPositionAt(itemOrPosition, offset) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(itemOrPosition, offset);
    }
    /**
     * Creates a new position after given view item.
     *
     * @param item View item after which the position should be located.
     */ createPositionAfter(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(item);
    }
    /**
     * Creates a new position before given view item.
     *
     * @param item View item before which the position should be located.
     */ createPositionBefore(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item);
    }
    /**
     * Creates a range spanning from `start` position to `end` position.
     *
     * **Note:** This factory method creates it's own {@link module:engine/view/position~Position} instances basing on passed values.
     *
     * @param start Start position.
     * @param end End position. If not set, range will be collapsed at `start` position.
     */ createRange(start, end) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end);
    }
    /**
     * Creates a range that starts before given {@link module:engine/view/item~Item view item} and ends after it.
     */ createRangeOn(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(item);
    }
    /**
     * Creates a range inside an {@link module:engine/view/element~Element element} which starts before the first child of
     * that element and ends after the last child of that element.
     *
     * @param element Element which is a parent for the range.
     */ createRangeIn(element) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(element);
    }
    createSelection(...args) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](...args);
    }
    /**
     * Disables or enables rendering. If the flag is set to `true` then the rendering will be disabled.
     * If the flag is set to `false` and if there was some change in the meantime, then the rendering action will be performed.
     *
     * @internal
     * @param flag A flag indicates whether the rendering should be disabled.
     */ _disableRendering(flag) {
        this._renderingDisabled = flag;
        if (flag == false) {
            // Render when you stop blocking rendering.
            this.change(()=>{});
        }
    }
    /**
     * Renders all changes. In order to avoid triggering the observers (e.g. selection) all observers are disabled
     * before rendering and re-enabled after that.
     */ _render() {
        this.isRenderingInProgress = true;
        this.disableObservers();
        this._renderer.render();
        this.enableObservers();
        this.isRenderingInProgress = false;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/clickobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/clickobserver
 */ __turbopack_context__.s([
    "default",
    ()=>ClickObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript)");
;
class ClickObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    constructor(){
        super(...arguments);
        /**
         * @inheritDoc
         */ this.domEventType = 'click';
    }
    /**
     * @inheritDoc
     */ onDomEvent(domEvent) {
        this.fire(domEvent.type, domEvent);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/mouseobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/observer/mouseobserver
 */ __turbopack_context__.s([
    "default",
    ()=>MouseObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript)");
;
class MouseObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    constructor(){
        super(...arguments);
        /**
         * @inheritDoc
         */ this.domEventType = [
            'mousedown',
            'mouseup',
            'mouseover',
            'mouseout'
        ];
    }
    /**
     * @inheritDoc
     */ onDomEvent(domEvent) {
        this.fire(domEvent.type, domEvent);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/upcastwriter.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/view/upcastwriter
 */ __turbopack_context__.s([
    "default",
    ()=>UpcastWriter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/documentfragment.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/isPlainObject.js [app-ssr] (ecmascript) <export default as isPlainObject>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/selection.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
class UpcastWriter {
    /**
     * @param document The view document instance in which this upcast writer operates.
     */ constructor(document){
        this.document = document;
    }
    /**
     * Creates a new {@link module:engine/view/documentfragment~DocumentFragment} instance.
     *
     * @param children A list of nodes to be inserted into the created document fragment.
     * @returns The created document fragment.
     */ createDocumentFragment(children) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$documentfragment$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, children);
    }
    /**
     * Creates a new {@link module:engine/view/element~Element} instance.
     *
     * Attributes can be passed in various formats:
     *
     * ```ts
     * upcastWriter.createElement( 'div', { class: 'editor', contentEditable: 'true' } ); // object
     * upcastWriter.createElement( 'div', [ [ 'class', 'editor' ], [ 'contentEditable', 'true' ] ] ); // map-like iterator
     * upcastWriter.createElement( 'div', mapOfAttributes ); // map
     * ```
     *
     * @param name Node name.
     * @param attrs Collection of attributes.
     * @param children A list of nodes to be inserted into created element.
     * @returns Created element.
     */ createElement(name, attrs, children) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, name, attrs, children);
    }
    /**
     * Creates a new {@link module:engine/view/text~Text} instance.
     *
     * @param data The text's data.
     * @returns The created text node.
     */ createText(data) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, data);
    }
    /**
     * Clones the provided element.
     *
     * @see module:engine/view/element~Element#_clone
     * @param element Element to be cloned.
     * @param deep If set to `true` clones element and all its children recursively. When set to `false`,
     * element will be cloned without any children.
     * @returns Clone of this element.
     */ clone(element, deep = false) {
        return element._clone(deep);
    }
    /**
     * Appends a child node or a list of child nodes at the end of this node
     * and sets the parent of these nodes to this element.
     *
     * @see module:engine/view/element~Element#_appendChild
     * @param items Items to be inserted.
     * @param element Element to which items will be appended.
     * @returns Number of appended nodes.
     */ appendChild(items, element) {
        return element._appendChild(items);
    }
    /**
     * Inserts a child node or a list of child nodes on the given index and sets the parent of these nodes to
     * this element.
     *
     * @see module:engine/view/element~Element#_insertChild
     * @param index Offset at which nodes should be inserted.
     * @param items Items to be inserted.
     * @param element Element to which items will be inserted.
     * @returns Number of inserted nodes.
     */ insertChild(index, items, element) {
        return element._insertChild(index, items);
    }
    /**
     * Removes the given number of child nodes starting at the given index and set the parent of these nodes to `null`.
     *
     * @see module:engine/view/element~Element#_removeChildren
     * @param index Offset from which nodes will be removed.
     * @param howMany Number of nodes to remove.
     * @param element Element which children will be removed.
     * @returns The array containing removed nodes.
     */ removeChildren(index, howMany, element) {
        return element._removeChildren(index, howMany);
    }
    /**
     * Removes given element from the view structure. Will not have effect on detached elements.
     *
     * @param element Element which will be removed.
     * @returns The array containing removed nodes.
     */ remove(element) {
        const parent = element.parent;
        if (parent) {
            return this.removeChildren(parent.getChildIndex(element), 1, parent);
        }
        return [];
    }
    /**
     * Replaces given element with the new one in the view structure. Will not have effect on detached elements.
     *
     * @param oldElement Element which will be replaced.
     * @param newElement Element which will be inserted in the place of the old element.
     * @returns Whether old element was successfully replaced.
     */ replace(oldElement, newElement) {
        const parent = oldElement.parent;
        if (parent) {
            const index = parent.getChildIndex(oldElement);
            this.removeChildren(index, 1, parent);
            this.insertChild(index, newElement, parent);
            return true;
        }
        return false;
    }
    /**
     * Removes given element from view structure and places its children in its position.
     * It does nothing if element has no parent.
     *
     * @param element Element to unwrap.
     */ unwrapElement(element) {
        const parent = element.parent;
        if (parent) {
            const index = parent.getChildIndex(element);
            this.remove(element);
            this.insertChild(index, element.getChildren(), parent);
        }
    }
    /**
     * Renames element by creating a copy of a given element but with its name changed and then moving contents of the
     * old element to the new one.
     *
     * Since this function creates a new element and removes the given one, the new element is returned to keep reference.
     *
     * @param newName New element name.
     * @param  element Element to be renamed.
     * @returns New element or null if the old element was not replaced (happens for detached elements).
     */ rename(newName, element) {
        const newElement = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.document, newName, element.getAttributes(), element.getChildren());
        return this.replace(element, newElement) ? newElement : null;
    }
    /**
     * Adds or overwrites element's attribute with a specified key and value.
     *
     * ```ts
     * writer.setAttribute( 'href', 'http://ckeditor.com', linkElement );
     * ```
     *
     * @see module:engine/view/element~Element#_setAttribute
     * @param key Attribute key.
     * @param value Attribute value.
     * @param element Element for which attribute will be set.
     */ setAttribute(key, value, element) {
        element._setAttribute(key, value);
    }
    /**
     * Removes attribute from the element.
     *
     * ```ts
     * writer.removeAttribute( 'href', linkElement );
     * ```
     *
     * @see module:engine/view/element~Element#_removeAttribute
     * @param key Attribute key.
     * @param element Element from which attribute will be removed.
     */ removeAttribute(key, element) {
        element._removeAttribute(key);
    }
    /**
     * Adds specified class to the element.
     *
     * ```ts
     * writer.addClass( 'foo', linkElement );
     * writer.addClass( [ 'foo', 'bar' ], linkElement );
     * ```
     *
     * @see module:engine/view/element~Element#_addClass
     * @param className Single class name or array of class names which will be added.
     * @param element Element for which class will be added.
     */ addClass(className, element) {
        element._addClass(className);
    }
    /**
     * Removes specified class from the element.
     *
     * ```ts
     * writer.removeClass( 'foo', linkElement );
     * writer.removeClass( [ 'foo', 'bar' ], linkElement );
     * ```
     *
     * @see module:engine/view/element~Element#_removeClass
     * @param className Single class name or array of class names which will be removed.
     * @param element Element from which class will be removed.
     */ removeClass(className, element) {
        element._removeClass(className);
    }
    setStyle(property, valueOrElement, element) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isPlainObject$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isPlainObject$3e$__["isPlainObject"])(property) && element === undefined) {
            valueOrElement._setStyle(property);
        } else {
            element._setStyle(property, valueOrElement);
        }
    }
    /**
     * Removes specified style from the element.
     *
     * ```ts
     * writer.removeStyle( 'color', element );  // Removes 'color' style.
     * writer.removeStyle( [ 'color', 'border-top' ], element ); // Removes both 'color' and 'border-top' styles.
     * ```
     *
     * **Note**: This method can work with normalized style names if
     * {@link module:engine/controller/datacontroller~DataController#addStyleProcessorRules a particular style processor rule is enabled}.
     * See {@link module:engine/view/stylesmap~StylesMap#remove `StylesMap#remove()`} for details.
     *
     * @see module:engine/view/element~Element#_removeStyle
     * @param property Style property name or names to be removed.
     * @param element Element from which style will be removed.
     */ removeStyle(property, element) {
        element._removeStyle(property);
    }
    /**
     * Sets a custom property on element. Unlike attributes, custom properties are not rendered to the DOM,
     * so they can be used to add special data to elements.
     *
     * @see module:engine/view/element~Element#_setCustomProperty
     * @param key Custom property name/key.
     * @param value Custom property value to be stored.
     * @param element Element for which custom property will be set.
     */ setCustomProperty(key, value, element) {
        element._setCustomProperty(key, value);
    }
    /**
     * Removes a custom property stored under the given key.
     *
     * @see module:engine/view/element~Element#_removeCustomProperty
     * @param key Name/key of the custom property to be removed.
     * @param element Element from which the custom property will be removed.
     * @returns Returns true if property was removed.
     */ removeCustomProperty(key, element) {
        return element._removeCustomProperty(key);
    }
    /**
     * Creates position at the given location. The location can be specified as:
     *
     * * a {@link module:engine/view/position~Position position},
     * * parent element and offset (offset defaults to `0`),
     * * parent element and `'end'` (sets position at the end of that element),
     * * {@link module:engine/view/item~Item view item} and `'before'` or `'after'` (sets position before or after given view item).
     *
     * This method is a shortcut to other constructors such as:
     *
     * * {@link #createPositionBefore},
     * * {@link #createPositionAfter},
     *
     * @param offset Offset or one of the flags. Used only when first parameter is a {@link module:engine/view/item~Item view item}.
     */ createPositionAt(itemOrPosition, offset) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(itemOrPosition, offset);
    }
    /**
     * Creates a new position after given view item.
     *
     * @param item View item after which the position should be located.
     */ createPositionAfter(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAfter(item);
    }
    /**
     * Creates a new position before given view item.
     *
     * @param item View item before which the position should be located.
     */ createPositionBefore(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(item);
    }
    /**
     * Creates a range spanning from `start` position to `end` position.
     *
     * **Note:** This factory method creates it's own {@link module:engine/view/position~Position} instances basing on passed values.
     *
     * @param start Start position.
     * @param end End position. If not set, range will be collapsed at `start` position.
     */ createRange(start, end) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](start, end);
    }
    /**
     * Creates a range that starts before given {@link module:engine/view/item~Item view item} and ends after it.
     */ createRangeOn(item) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(item);
    }
    /**
     * Creates a range inside an {@link module:engine/view/element~Element element} which starts before the first child of
     * that element and ends after the last child of that element.
     *
     * @param element Element which is a parent for the range.
     */ createRangeIn(element) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(element);
    }
    createSelection(...args) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](...args);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "getBoxSidesShorthandValue",
    ()=>getBoxSidesShorthandValue,
    "getBoxSidesValueReducer",
    ()=>getBoxSidesValueReducer,
    "getBoxSidesValues",
    ()=>getBoxSidesValues,
    "getPositionShorthandNormalizer",
    ()=>getPositionShorthandNormalizer,
    "getShorthandValues",
    ()=>getShorthandValues,
    "isAttachment",
    ()=>isAttachment,
    "isColor",
    ()=>isColor,
    "isLength",
    ()=>isLength,
    "isLineStyle",
    ()=>isLineStyle,
    "isPercentage",
    ()=>isPercentage,
    "isPosition",
    ()=>isPosition,
    "isRepeat",
    ()=>isRepeat,
    "isURL",
    ()=>isURL
]);
const HEX_COLOR_REGEXP = /^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/i;
const RGB_COLOR_REGEXP = /^rgb\([ ]?([0-9]{1,3}[ %]?,[ ]?){2,3}[0-9]{1,3}[ %]?\)$/i;
const RGBA_COLOR_REGEXP = /^rgba\([ ]?([0-9]{1,3}[ %]?,[ ]?){3}(1|[0-9]+%|[0]?\.?[0-9]+)\)$/i;
const HSL_COLOR_REGEXP = /^hsl\([ ]?([0-9]{1,3}[ %]?[,]?[ ]*){3}(1|[0-9]+%|[0]?\.?[0-9]+)?\)$/i;
const HSLA_COLOR_REGEXP = /^hsla\([ ]?([0-9]{1,3}[ %]?,[ ]?){2,3}(1|[0-9]+%|[0]?\.?[0-9]+)\)$/i;
// Note: This regexp hardcodes a single level of nested () for values such as `calc( var( ...) + ...)`.
// If this gets more complex, a proper parser should be used instead.
const CSS_SHORTHAND_VALUE_REGEXP = /\w+\((?:[^()]|\([^()]*\))*\)|\S+/gi;
const COLOR_NAMES = new Set([
    // CSS Level 1
    'black',
    'silver',
    'gray',
    'white',
    'maroon',
    'red',
    'purple',
    'fuchsia',
    'green',
    'lime',
    'olive',
    'yellow',
    'navy',
    'blue',
    'teal',
    'aqua',
    // CSS Level 2 (Revision 1)
    'orange',
    // CSS Color Module Level 3
    'aliceblue',
    'antiquewhite',
    'aquamarine',
    'azure',
    'beige',
    'bisque',
    'blanchedalmond',
    'blueviolet',
    'brown',
    'burlywood',
    'cadetblue',
    'chartreuse',
    'chocolate',
    'coral',
    'cornflowerblue',
    'cornsilk',
    'crimson',
    'cyan',
    'darkblue',
    'darkcyan',
    'darkgoldenrod',
    'darkgray',
    'darkgreen',
    'darkgrey',
    'darkkhaki',
    'darkmagenta',
    'darkolivegreen',
    'darkorange',
    'darkorchid',
    'darkred',
    'darksalmon',
    'darkseagreen',
    'darkslateblue',
    'darkslategray',
    'darkslategrey',
    'darkturquoise',
    'darkviolet',
    'deeppink',
    'deepskyblue',
    'dimgray',
    'dimgrey',
    'dodgerblue',
    'firebrick',
    'floralwhite',
    'forestgreen',
    'gainsboro',
    'ghostwhite',
    'gold',
    'goldenrod',
    'greenyellow',
    'grey',
    'honeydew',
    'hotpink',
    'indianred',
    'indigo',
    'ivory',
    'khaki',
    'lavender',
    'lavenderblush',
    'lawngreen',
    'lemonchiffon',
    'lightblue',
    'lightcoral',
    'lightcyan',
    'lightgoldenrodyellow',
    'lightgray',
    'lightgreen',
    'lightgrey',
    'lightpink',
    'lightsalmon',
    'lightseagreen',
    'lightskyblue',
    'lightslategray',
    'lightslategrey',
    'lightsteelblue',
    'lightyellow',
    'limegreen',
    'linen',
    'magenta',
    'mediumaquamarine',
    'mediumblue',
    'mediumorchid',
    'mediumpurple',
    'mediumseagreen',
    'mediumslateblue',
    'mediumspringgreen',
    'mediumturquoise',
    'mediumvioletred',
    'midnightblue',
    'mintcream',
    'mistyrose',
    'moccasin',
    'navajowhite',
    'oldlace',
    'olivedrab',
    'orangered',
    'orchid',
    'palegoldenrod',
    'palegreen',
    'paleturquoise',
    'palevioletred',
    'papayawhip',
    'peachpuff',
    'peru',
    'pink',
    'plum',
    'powderblue',
    'rosybrown',
    'royalblue',
    'saddlebrown',
    'salmon',
    'sandybrown',
    'seagreen',
    'seashell',
    'sienna',
    'skyblue',
    'slateblue',
    'slategray',
    'slategrey',
    'snow',
    'springgreen',
    'steelblue',
    'tan',
    'thistle',
    'tomato',
    'turquoise',
    'violet',
    'wheat',
    'whitesmoke',
    'yellowgreen',
    // CSS Color Module Level 3 (System Colors)
    'activeborder',
    'activecaption',
    'appworkspace',
    'background',
    'buttonface',
    'buttonhighlight',
    'buttonshadow',
    'buttontext',
    'captiontext',
    'graytext',
    'highlight',
    'highlighttext',
    'inactiveborder',
    'inactivecaption',
    'inactivecaptiontext',
    'infobackground',
    'infotext',
    'menu',
    'menutext',
    'scrollbar',
    'threeddarkshadow',
    'threedface',
    'threedhighlight',
    'threedlightshadow',
    'threedshadow',
    'window',
    'windowframe',
    'windowtext',
    // CSS Color Module Level 4
    'rebeccapurple',
    // Keywords
    'currentcolor',
    'transparent'
]);
function isColor(string) {
    // As far as I was able to test checking some pre-conditions is faster than joining each test with ||.
    if (string.startsWith('#')) {
        return HEX_COLOR_REGEXP.test(string);
    }
    if (string.startsWith('rgb')) {
        return RGB_COLOR_REGEXP.test(string) || RGBA_COLOR_REGEXP.test(string);
    }
    if (string.startsWith('hsl')) {
        return HSL_COLOR_REGEXP.test(string) || HSLA_COLOR_REGEXP.test(string);
    }
    // Array check > RegExp test.
    return COLOR_NAMES.has(string.toLowerCase());
}
const lineStyleValues = [
    'none',
    'hidden',
    'dotted',
    'dashed',
    'solid',
    'double',
    'groove',
    'ridge',
    'inset',
    'outset'
];
function isLineStyle(string) {
    return lineStyleValues.includes(string);
}
const lengthRegExp = /^([+-]?[0-9]*([.][0-9]+)?(px|cm|mm|in|pc|pt|ch|em|ex|rem|vh|vw|vmin|vmax)|0)$/;
function isLength(string) {
    return lengthRegExp.test(string);
}
const PERCENTAGE_VALUE_REGEXP = /^[+-]?[0-9]*([.][0-9]+)?%$/;
function isPercentage(string) {
    return PERCENTAGE_VALUE_REGEXP.test(string);
}
const repeatValues = [
    'repeat-x',
    'repeat-y',
    'repeat',
    'space',
    'round',
    'no-repeat'
];
function isRepeat(string) {
    return repeatValues.includes(string);
}
const positionValues = [
    'center',
    'top',
    'bottom',
    'left',
    'right'
];
function isPosition(string) {
    return positionValues.includes(string);
}
const attachmentValues = [
    'fixed',
    'scroll',
    'local'
];
function isAttachment(string) {
    return attachmentValues.includes(string);
}
const urlRegExp = /^url\(/;
function isURL(string) {
    return urlRegExp.test(string);
}
function getBoxSidesValues(value = '') {
    if (value === '') {
        return {
            top: undefined,
            right: undefined,
            bottom: undefined,
            left: undefined
        };
    }
    const values = getShorthandValues(value);
    const top = values[0];
    const bottom = values[2] || top;
    const right = values[1] || top;
    const left = values[3] || right;
    return {
        top,
        bottom,
        right,
        left
    };
}
function getBoxSidesValueReducer(styleShorthand) {
    return (value)=>{
        const { top, right, bottom, left } = value;
        const reduced = [];
        if (![
            top,
            right,
            left,
            bottom
        ].every((value)=>!!value)) {
            if (top) {
                reduced.push([
                    styleShorthand + '-top',
                    top
                ]);
            }
            if (right) {
                reduced.push([
                    styleShorthand + '-right',
                    right
                ]);
            }
            if (bottom) {
                reduced.push([
                    styleShorthand + '-bottom',
                    bottom
                ]);
            }
            if (left) {
                reduced.push([
                    styleShorthand + '-left',
                    left
                ]);
            }
        } else {
            reduced.push([
                styleShorthand,
                getBoxSidesShorthandValue(value)
            ]);
        }
        return reduced;
    };
}
function getBoxSidesShorthandValue({ top, right, bottom, left }) {
    const out = [];
    if (left !== right) {
        out.push(top, right, bottom, left);
    } else if (bottom !== top) {
        out.push(top, right, bottom);
    } else if (right !== top) {
        out.push(top, right);
    } else {
        out.push(top);
    }
    return out.join(' ');
}
function getPositionShorthandNormalizer(shorthand) {
    return (value)=>{
        return {
            path: shorthand,
            value: getBoxSidesValues(value)
        };
    };
}
function getShorthandValues(string) {
    const matches = string.matchAll(CSS_SHORTHAND_VALUE_REGEXP);
    return Array.from(matches).map((i)=>i[0]);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/background.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "addBackgroundRules",
    ()=>addBackgroundRules
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/utils.js [app-ssr] (ecmascript)");
;
function addBackgroundRules(stylesProcessor) {
    stylesProcessor.setNormalizer('background', getBackgroundNormalizer());
    stylesProcessor.setNormalizer('background-color', getBackgroundColorNormalizer());
    stylesProcessor.setReducer('background', getBackgroundReducer());
    stylesProcessor.setStyleRelation('background', [
        'background-color'
    ]);
}
function getBackgroundNormalizer() {
    return (value)=>{
        const background = {};
        const parts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getShorthandValues"])(value);
        for (const part of parts){
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isRepeat"])(part)) {
                background.repeat = background.repeat || [];
                background.repeat.push(part);
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isPosition"])(part)) {
                background.position = background.position || [];
                background.position.push(part);
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isAttachment"])(part)) {
                background.attachment = part;
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isColor"])(part)) {
                background.color = part;
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isURL"])(part)) {
                background.image = part;
            }
        }
        return {
            path: 'background',
            value: background
        };
    };
}
function getBackgroundColorNormalizer() {
    return (value)=>({
            path: 'background.color',
            value
        });
}
function getBackgroundReducer() {
    return (value)=>{
        const ret = [];
        ret.push([
            'background-color',
            value.color
        ]);
        return ret;
    };
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/border.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "addBorderRules",
    ()=>addBorderRules
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/utils.js [app-ssr] (ecmascript)");
;
function addBorderRules(stylesProcessor) {
    stylesProcessor.setNormalizer('border', getBorderNormalizer());
    // Border-position shorthands.
    stylesProcessor.setNormalizer('border-top', getBorderPositionNormalizer('top'));
    stylesProcessor.setNormalizer('border-right', getBorderPositionNormalizer('right'));
    stylesProcessor.setNormalizer('border-bottom', getBorderPositionNormalizer('bottom'));
    stylesProcessor.setNormalizer('border-left', getBorderPositionNormalizer('left'));
    // Border-property shorthands.
    stylesProcessor.setNormalizer('border-color', getBorderPropertyNormalizer('color'));
    stylesProcessor.setNormalizer('border-width', getBorderPropertyNormalizer('width'));
    stylesProcessor.setNormalizer('border-style', getBorderPropertyNormalizer('style'));
    // Border longhands.
    stylesProcessor.setNormalizer('border-top-color', getBorderPropertyPositionNormalizer('color', 'top'));
    stylesProcessor.setNormalizer('border-top-style', getBorderPropertyPositionNormalizer('style', 'top'));
    stylesProcessor.setNormalizer('border-top-width', getBorderPropertyPositionNormalizer('width', 'top'));
    stylesProcessor.setNormalizer('border-right-color', getBorderPropertyPositionNormalizer('color', 'right'));
    stylesProcessor.setNormalizer('border-right-style', getBorderPropertyPositionNormalizer('style', 'right'));
    stylesProcessor.setNormalizer('border-right-width', getBorderPropertyPositionNormalizer('width', 'right'));
    stylesProcessor.setNormalizer('border-bottom-color', getBorderPropertyPositionNormalizer('color', 'bottom'));
    stylesProcessor.setNormalizer('border-bottom-style', getBorderPropertyPositionNormalizer('style', 'bottom'));
    stylesProcessor.setNormalizer('border-bottom-width', getBorderPropertyPositionNormalizer('width', 'bottom'));
    stylesProcessor.setNormalizer('border-left-color', getBorderPropertyPositionNormalizer('color', 'left'));
    stylesProcessor.setNormalizer('border-left-style', getBorderPropertyPositionNormalizer('style', 'left'));
    stylesProcessor.setNormalizer('border-left-width', getBorderPropertyPositionNormalizer('width', 'left'));
    stylesProcessor.setExtractor('border-top', getBorderPositionExtractor('top'));
    stylesProcessor.setExtractor('border-right', getBorderPositionExtractor('right'));
    stylesProcessor.setExtractor('border-bottom', getBorderPositionExtractor('bottom'));
    stylesProcessor.setExtractor('border-left', getBorderPositionExtractor('left'));
    stylesProcessor.setExtractor('border-top-color', 'border.color.top');
    stylesProcessor.setExtractor('border-right-color', 'border.color.right');
    stylesProcessor.setExtractor('border-bottom-color', 'border.color.bottom');
    stylesProcessor.setExtractor('border-left-color', 'border.color.left');
    stylesProcessor.setExtractor('border-top-width', 'border.width.top');
    stylesProcessor.setExtractor('border-right-width', 'border.width.right');
    stylesProcessor.setExtractor('border-bottom-width', 'border.width.bottom');
    stylesProcessor.setExtractor('border-left-width', 'border.width.left');
    stylesProcessor.setExtractor('border-top-style', 'border.style.top');
    stylesProcessor.setExtractor('border-right-style', 'border.style.right');
    stylesProcessor.setExtractor('border-bottom-style', 'border.style.bottom');
    stylesProcessor.setExtractor('border-left-style', 'border.style.left');
    stylesProcessor.setReducer('border-color', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValueReducer"])('border-color'));
    stylesProcessor.setReducer('border-style', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValueReducer"])('border-style'));
    stylesProcessor.setReducer('border-width', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValueReducer"])('border-width'));
    stylesProcessor.setReducer('border-top', getBorderPositionReducer('top'));
    stylesProcessor.setReducer('border-right', getBorderPositionReducer('right'));
    stylesProcessor.setReducer('border-bottom', getBorderPositionReducer('bottom'));
    stylesProcessor.setReducer('border-left', getBorderPositionReducer('left'));
    stylesProcessor.setReducer('border', getBorderReducer());
    stylesProcessor.setStyleRelation('border', [
        'border-color',
        'border-style',
        'border-width',
        'border-top',
        'border-right',
        'border-bottom',
        'border-left',
        'border-top-color',
        'border-right-color',
        'border-bottom-color',
        'border-left-color',
        'border-top-style',
        'border-right-style',
        'border-bottom-style',
        'border-left-style',
        'border-top-width',
        'border-right-width',
        'border-bottom-width',
        'border-left-width'
    ]);
    stylesProcessor.setStyleRelation('border-color', [
        'border-top-color',
        'border-right-color',
        'border-bottom-color',
        'border-left-color'
    ]);
    stylesProcessor.setStyleRelation('border-style', [
        'border-top-style',
        'border-right-style',
        'border-bottom-style',
        'border-left-style'
    ]);
    stylesProcessor.setStyleRelation('border-width', [
        'border-top-width',
        'border-right-width',
        'border-bottom-width',
        'border-left-width'
    ]);
    stylesProcessor.setStyleRelation('border-top', [
        'border-top-color',
        'border-top-style',
        'border-top-width'
    ]);
    stylesProcessor.setStyleRelation('border-right', [
        'border-right-color',
        'border-right-style',
        'border-right-width'
    ]);
    stylesProcessor.setStyleRelation('border-bottom', [
        'border-bottom-color',
        'border-bottom-style',
        'border-bottom-width'
    ]);
    stylesProcessor.setStyleRelation('border-left', [
        'border-left-color',
        'border-left-style',
        'border-left-width'
    ]);
}
function getBorderNormalizer() {
    return (value)=>{
        const { color, style, width } = normalizeBorderShorthand(value);
        return {
            path: 'border',
            value: {
                color: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValues"])(color),
                style: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValues"])(style),
                width: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValues"])(width)
            }
        };
    };
}
function getBorderPositionNormalizer(side) {
    return (value)=>{
        const { color, style, width } = normalizeBorderShorthand(value);
        const border = {};
        if (color !== undefined) {
            border.color = {
                [side]: color
            };
        }
        if (style !== undefined) {
            border.style = {
                [side]: style
            };
        }
        if (width !== undefined) {
            border.width = {
                [side]: width
            };
        }
        return {
            path: 'border',
            value: border
        };
    };
}
function getBorderPropertyNormalizer(propertyName) {
    return (value)=>{
        return {
            path: 'border',
            value: toBorderPropertyShorthand(value, propertyName)
        };
    };
}
function toBorderPropertyShorthand(value, property) {
    return {
        [property]: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValues"])(value)
    };
}
function getBorderPropertyPositionNormalizer(property, side) {
    return (value)=>{
        return {
            path: 'border',
            value: {
                [property]: {
                    [side]: value
                }
            }
        };
    };
}
function getBorderPositionExtractor(which) {
    return (name, styles)=>{
        if (styles.border) {
            return extractBorderPosition(styles.border, which);
        }
    };
}
function extractBorderPosition(border, which) {
    const value = {};
    if (border.width && border.width[which]) {
        value.width = border.width[which];
    }
    if (border.style && border.style[which]) {
        value.style = border.style[which];
    }
    if (border.color && border.color[which]) {
        value.color = border.color[which];
    }
    return value;
}
function normalizeBorderShorthand(string) {
    const result = {};
    const parts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getShorthandValues"])(string);
    for (const part of parts){
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isLength"])(part) || /thin|medium|thick/.test(part)) {
            result.width = part;
        } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isLineStyle"])(part)) {
            result.style = part;
        } else {
            result.color = part;
        }
    }
    return result;
}
/**
 * The border reducer factory.
 *
 * It tries to produce the most optimal output for the specified styles.
 *
 * For a border style:
 *
 * ```css
 * style: {top: "solid", bottom: "solid", right: "solid", left: "solid"}
 * ```
 *
 * It will produce: `border-style: solid`.
 * For a border style and color:
 *
 * ```css
 * color: {top: "#ff0", bottom: "#ff0", right: "#ff0", left: "#ff0"}
 * style: {top: "solid", bottom: "solid", right: "solid", left: "solid"}
 * ```
 *
 * It will produce: `border-color: #ff0; border-style: solid`.
 * If all border parameters are specified:
 *
 * ```css
 * color: {top: "#ff0", bottom: "#ff0", right: "#ff0", left: "#ff0"}
 * style: {top: "solid", bottom: "solid", right: "solid", left: "solid"}
 * width: {top: "2px", bottom: "2px", right: "2px", left: "2px"}
 * ```
 *
 * It will combine everything into a single property: `border: 2px solid #ff0`.
 *
 * The definitions are merged only if all border selectors have the same values.
 */ function getBorderReducer() {
    return (value)=>{
        const topStyles = extractBorderPosition(value, 'top');
        const rightStyles = extractBorderPosition(value, 'right');
        const bottomStyles = extractBorderPosition(value, 'bottom');
        const leftStyles = extractBorderPosition(value, 'left');
        const borderStyles = [
            topStyles,
            rightStyles,
            bottomStyles,
            leftStyles
        ];
        const borderStylesByType = {
            width: getReducedStyleValueForType(borderStyles, 'width'),
            style: getReducedStyleValueForType(borderStyles, 'style'),
            color: getReducedStyleValueForType(borderStyles, 'color')
        };
        // Try reducing to a single `border:` property.
        const reducedBorderStyle = reduceBorderPosition(borderStylesByType, 'all');
        if (reducedBorderStyle.length) {
            return reducedBorderStyle;
        }
        // Try reducing to `border-style:`, `border-width:`, `border-color:` properties.
        const reducedStyleTypes = Object.entries(borderStylesByType).reduce((reducedStyleTypes, [type, value])=>{
            if (value) {
                reducedStyleTypes.push([
                    `border-${type}`,
                    value
                ]);
                // Remove it from the full set to not include it in the most specific properties later.
                borderStyles.forEach((style)=>delete style[type]);
            }
            return reducedStyleTypes;
        }, []);
        // The reduced properties (by type) and all that remains that could not be reduced.
        return [
            ...reducedStyleTypes,
            ...reduceBorderPosition(topStyles, 'top'),
            ...reduceBorderPosition(rightStyles, 'right'),
            ...reduceBorderPosition(bottomStyles, 'bottom'),
            ...reduceBorderPosition(leftStyles, 'left')
        ];
    };
    //TURBOPACK unreachable
    ;
    /**
     * @param styles The array of objects with `style`, `color`, `width` properties.
     */ function getReducedStyleValueForType(styles, type) {
        return styles.map((style)=>style[type]).reduce((result, style)=>result == style ? result : null);
    }
}
function getBorderPositionReducer(which) {
    return (value)=>reduceBorderPosition(value, which);
}
/**
 * Returns an array with reduced border styles depending on the specified values.
 *
 * If all border properties (width, style, color) are specified, the returned selector will be
 * merged into a group: `border-*: [width] [style] [color]`.
 *
 * Otherwise, the specific definitions will be returned: `border-(width|style|color)-*: [value]`.
 *
 * @param value Styles if defined.
 * @param which The border position.
 */ function reduceBorderPosition(value, which) {
    const borderTypes = [];
    if (value && value.width) {
        borderTypes.push('width');
    }
    if (value && value.style) {
        borderTypes.push('style');
    }
    if (value && value.color) {
        borderTypes.push('color');
    }
    if (borderTypes.length == 3) {
        const borderValue = borderTypes.map((item)=>value[item]).join(' ');
        return [
            which == 'all' ? [
                'border',
                borderValue
            ] : [
                `border-${which}`,
                borderValue
            ]
        ];
    }
    // We are unable to reduce to a single `border:` property.
    if (which == 'all') {
        return [];
    }
    return borderTypes.map((type)=>{
        return [
            `border-${which}-${type}`,
            value[type]
        ];
    });
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/margin.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "addMarginRules",
    ()=>addMarginRules
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/utils.js [app-ssr] (ecmascript)");
;
function addMarginRules(stylesProcessor) {
    stylesProcessor.setNormalizer('margin', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getPositionShorthandNormalizer"])('margin'));
    stylesProcessor.setNormalizer('margin-top', (value)=>({
            path: 'margin.top',
            value
        }));
    stylesProcessor.setNormalizer('margin-right', (value)=>({
            path: 'margin.right',
            value
        }));
    stylesProcessor.setNormalizer('margin-bottom', (value)=>({
            path: 'margin.bottom',
            value
        }));
    stylesProcessor.setNormalizer('margin-left', (value)=>({
            path: 'margin.left',
            value
        }));
    stylesProcessor.setReducer('margin', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValueReducer"])('margin'));
    stylesProcessor.setStyleRelation('margin', [
        'margin-top',
        'margin-right',
        'margin-bottom',
        'margin-left'
    ]);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/padding.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "addPaddingRules",
    ()=>addPaddingRules
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/styles/utils.js [app-ssr] (ecmascript)");
;
function addPaddingRules(stylesProcessor) {
    stylesProcessor.setNormalizer('padding', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getPositionShorthandNormalizer"])('padding'));
    stylesProcessor.setNormalizer('padding-top', (value)=>({
            path: 'padding.top',
            value
        }));
    stylesProcessor.setNormalizer('padding-right', (value)=>({
            path: 'padding.right',
            value
        }));
    stylesProcessor.setNormalizer('padding-bottom', (value)=>({
            path: 'padding.bottom',
            value
        }));
    stylesProcessor.setNormalizer('padding-left', (value)=>({
            path: 'padding.left',
            value
        }));
    stylesProcessor.setReducer('padding', (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$styles$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBoxSidesValueReducer"])('padding'));
    stylesProcessor.setStyleRelation('padding', [
        'padding-top',
        'padding-right',
        'padding-bottom',
        'padding-left'
    ]);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/mouseobserver.js [app-ssr] (ecmascript) <export default as MouseObserver>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MouseObserver",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$mouseobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$mouseobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/mouseobserver.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventdata.js [app-ssr] (ecmascript) <export default as DomEventData>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DomEventData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventdata$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventdata$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventdata.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript) <export default as Observer>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Observer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/focusobserver.js [app-ssr] (ecmascript) <export default as FocusObserver>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FocusObserver",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$focusobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$focusobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/focusobserver.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingeventinfo.js [app-ssr] (ecmascript) <export default as BubblingEventInfo>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BubblingEventInfo",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingeventinfo.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/datatransfer.js [app-ssr] (ecmascript) <export default as DataTransfer>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DataTransfer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$datatransfer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$datatransfer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/datatransfer.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript) <export default as DomEventObserver>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DomEventObserver",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventobserver.js [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=e9609_%40ckeditor_ckeditor5-engine_src_view_f02a1211._.js.map