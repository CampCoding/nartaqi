module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(admin)/badge/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_nartaqi__next-internal_server_app_%28admin%29_badge_page_actions_bf62203e.js.map