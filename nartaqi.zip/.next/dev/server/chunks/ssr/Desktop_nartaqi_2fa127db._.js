module.exports = [
"[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// "use client";
// import {
//   Col,
//   DatePicker,
//   Form,
//   Input,
//   InputNumber,
//   Row,
//   Select,
//   Upload,
//   Button,
//   TimePicker,
//   Switch,
// } from "antd";
// import React, { useEffect, useState } from "react";
// import {
//   BookOutlined,
//   FileTextOutlined,
//   InboxOutlined,
//   CalendarOutlined,
//   UserOutlined,
//   DollarOutlined,
//   TeamOutlined,
//   FolderOutlined,
//   SettingOutlined,
//   ClockCircleOutlined,
// } from "@ant-design/icons";
// import dayjs from "dayjs";
// import { useDispatch, useSelector } from "react-redux";
// import {
//   handleGetAllCoursesCategories,
//   handleGetCategoryParts,
// } from "../../lib/features/categoriesSlice";
// import {
//   handleAddBaiskRound,
//   handleGetSourceRound,
//   handleEditBaiskRound,
//   add_round_data,
//   handleGetAllRounds,
// } from "../../lib/features/roundsSlice";
// import { handleGetAllTeachers } from "../../lib/features/teacherSlice";
// import { toast } from "react-toastify";
// import { useRouter } from "next/navigation";
// import dynamic from "next/dynamic";
// import "react-quill-new/dist/quill.snow.css";
// const ReactQuill = dynamic(() => import("react-quill-new"), { ssr: false });
// const { Dragger } = Upload;
// const { TextArea } = Input;
// const { RangePicker } = DatePicker;
// const normFile = (e) => {
//   if (Array.isArray(e)) return e;
//   return e?.fileList || [];
// };
// const customBeforeUpload = () => false;
// const isDayjsValid = (value) => {
//   if (!value) return false;
//   if (dayjs.isDayjs(value)) return value.isValid();
//   return false;
// };
// export default function AddCourseSourceBasicInfo({
//   isSource,
//   fileList,
//   setFileList,
//   setSource,
//   availableSections,
//   selectedCategory,
//   setSelectedCategory,
//   all_categories,
//   beforeUpload = customBeforeUpload,
//   setImagePreview,
//   rowData,
//   setRowData,
//   goToNextStep,
//   setRoundId,
//   goToPrevStep,
//   currentStep,
//   id,
//   page,
//   pageSize,
//   Cat_id
// }) {
//   const [form] = Form.useForm();
//   const dispatch = useDispatch();
//   const { all_courses_categories_list, get_categories_parts_list, get_categories_parts_loading } =
//     useSelector((state) => state?.categories);
//   const { store_round, add_round_loading, edit_round_loading } = useSelector(
//     (state) => state?.rounds
//   );
//   const { teachers_list } = useSelector((state) => state?.teachers);
//   const [categoriesOptions, setCategoriesOptions] = useState([]);
//   const [categoriesPartOptions, setCategoriesPartOptions] = useState([]);
//   const [selectedOption, setSelectedOption] = useState(null);
//   const [isSubmitting, setIsSubmitting] = useState(false);
//   const [teacherOptions, setTeacherOptions] = useState([]);
//   const [validationErrors, setValidationErrors] = useState([]);
//   const [touchedFields, setTouchedFields] = useState({});
//   const [courseBookFileList, setCourseBookFileList] = useState([]);
//   const [extraPdfFileList, setExtraPdfFileList] = useState([]);
//   const [oldFilesToDelete, setOldFilesToDelete] = useState({
//     image: false,
//     round_book: false,
//     round_road_map_book: false,
//   });
//   const [isInitialized, setIsInitialized] = useState(false);
//   const router = useRouter();
//   const isEditMode = Boolean(id);
//   const getFieldLabel = (fieldName) => {
//     const labels = {
//       name: "اسم الدورة",
//       price: "السعر",
//       category: "الفئة",
//       section: "القسم",
//       description: "وصف الدورة",
//       genderPolicy: "سياسة النوع",
//       capacity: "السعة القصوى",
//       instructor: "المدربين",
//       availableRange: "فترة إتاحة الدورة",
//       goal: "الهدف",
//       image: "صورة الدورة",
//       time: "وقت الدورة",
//       terms_condition :"الشروط والأحكام",
//     };
//     return labels[fieldName] || fieldName;
//   };
//   /* ====================== Load teachers / categories ====================== */
//   useEffect(() => {
//     dispatch(handleGetAllTeachers());
//   }, [dispatch]);
//   useEffect(() => {
//     console.log(teachers_list?.data?.message)
//     if (teachers_list?.data?.message) {
//       setTeacherOptions(
//         teachers_list.data.message.map((item) => ({
//           label: item?.name,
//           value: item?.id,
//         }))
//       );
//     }
//   }, [teachers_list]);
//   useEffect(() => {
//     dispatch(handleGetAllCoursesCategories({}));
//   }, [dispatch]);
//   useEffect(() => {
//     if (all_courses_categories_list?.data?.message?.data) {
//       setCategoriesOptions(
//         all_courses_categories_list.data.message.data.map((item) => ({
//           label: item?.name,
//           value: item?.id,
//         }))
//       );
//     }
//   }, [all_courses_categories_list]);
//   useEffect(() => {
//     if (selectedCategory) {
//       const data_send = {
//         course_category_id: selectedCategory,
//       };
//       dispatch(handleGetCategoryParts({ body: data_send }));
//     }
//   }, [selectedCategory, dispatch]);
//   const quillModules = {
//     toolbar: [
//       [{ header: [1, 2, 3, false] }],
//       ["bold", "italic", "underline"],
//       [{ list: "ordered" }, { list: "bullet" }],
//       [{ align: [] }],
//       ["link"],
//       ["clean"],
//     ],
//   };
//   const quillFormats = [
//     "header",
//     "bold",
//     "italic",
//     "underline",
//     "list",
//     "bullet",
//     "align",
//     "link",
//   ];
//   const isQuillEmpty = (value) => {
//     if (!value) return true;
//     const plain = value
//       .replace(/<[^>]+>/g, "")
//       .replace(/&nbsp;/g, " ")
//       .trim();
//     return plain.length === 0;
//   };
//   useEffect(() => {
//     if (get_categories_parts_list?.data?.message) {
//       const options = get_categories_parts_list.data.message
//         .filter((item) => Number(item?.course_category_id) === Number(selectedCategory))
//         .map((part) => ({
//           label: part?.name,
//           value: part?.id,
//         }));
//       setCategoriesPartOptions(options || []);
//     } else {
//       setCategoriesPartOptions([]);
//     }
//   }, [get_categories_parts_list, selectedCategory]);
//   /* ====================== Handle file changes ====================== */
//   const handleFileChange = ({ fileList: newFileList }) => {
//     setFileList(newFileList);
//     if (newFileList.length > 0) {
//       const file = newFileList[0];
//       if (file.originFileObj) {
//         const previewUrl = URL.createObjectURL(file.originFileObj);
//         setImagePreview(previewUrl);
//         if (isEditMode && rowData?.image_url) {
//           setOldFilesToDelete(prev => ({ ...prev, image: true }));
//         }
//       } else if (file.url) {
//         setImagePreview(file.url);
//       }
//     } else {
//       setImagePreview(null);
//       if (isEditMode && rowData?.image_url) {
//         setOldFilesToDelete(prev => ({ ...prev, image: true }));
//       }
//     }
//     validateImageField(newFileList);
//   };
//   const handleRemoveFile = () => {
//     setFileList([]);
//     setImagePreview(null);
//     if (isEditMode && rowData?.image_url) {
//       setOldFilesToDelete(prev => ({ ...prev, image: true }));
//     }
//     validateImageField([]);
//   };
//   const handleCourseBookChange = ({ fileList: newFileList }) => {
//     setCourseBookFileList(newFileList);
//     form.setFieldsValue({ courseBook: newFileList });
//     // If user removes the file (empty array), mark old file for deletion
//     // if (newFileList.length === 0 && isEditMode && rowData?.round_book_url) {
//     //   setOldFilesToDelete(prev => ({ ...prev, round_book: true }));
//     // } else if (newFileList.length > 0 && newFileList[0].originFileObj && isEditMode && rowData?.round_book_url) {
//     //   // User uploaded a new file, mark old one for deletion
//     //   setOldFilesToDelete(prev => ({ ...prev, round_book: true }));
//     // }
//   };
//   const handleExtraPdfChange = ({ fileList: newFileList }) => {
//     setExtraPdfFileList(newFileList);
//     form.setFieldsValue({ extraPdf: newFileList });
//     // If user removes the file (empty array), mark old file for deletion
//     // if (newFileList.length === 0 && isEditMode && rowData?.round_road_map_book_url) {
//     //   setOldFilesToDelete(prev => ({ ...prev, round_road_map_book: true }));
//     // } else if (newFileList.length > 0 && newFileList[0].originFileObj && isEditMode && rowData?.round_road_map_book_url) {
//     //   // User uploaded a new file, mark old one for deletion
//     //   setOldFilesToDelete(prev => ({ ...prev, round_road_map_book: true }));
//     // }
//   };
//   const validateImageField = (files) => {
//     if (!files || files.length === 0) {
//       if (!isEditMode || !rowData?.image_url) {
//         if (!touchedFields.image) {
//           setTouchedFields((prev) => ({ ...prev, image: true }));
//         }
//         return false;
//       }
//     }
//     return true;
//   };
//   /* ====================== Field change handlers ====================== */
//   const handleFieldChange = (fieldName, value) => {
//     setTouchedFields((prev) => ({ ...prev, [fieldName]: true }));
//     if (fieldName === "goal") {
//       validateQuillField(value);
//     }
//   };
//   const validateQuillField = (value) => {
//     if (isQuillEmpty(value)) {
//       if (!validationErrors.includes("goal") && touchedFields.goal) {
//         setValidationErrors((prev) => [...prev, "goal"]);
//       }
//     } else {
//       setValidationErrors((prev) => prev.filter((err) => err !== "goal"));
//     }
//   };
//   /* ====================== Prefill when editing ====================== */
//   useEffect(() => {
//     console.log(rowData);
//     if (id && rowData) {
//       const formValues = {
//         name: rowData.name || "",
//         price: rowData.price || 0,
//         category: rowData.course_category_id || rowData.category_id || "",
//         section: rowData.category_part_id || "",
//         description: rowData.description || "",
//         genderPolicy: rowData.gender || "both",
//         capacity: rowData.capacity || 20,
//         instructor: rowData?.teachers?.map(item => item?.id) || [],
//         free: Boolean(rowData.free),
//         active: Boolean(rowData.active ?? true),
//         goal: rowData.goal || "",
//         certificate: Boolean(
//           rowData?.certificate ?? rowData?.has_certificate ?? rowData?.hasCertificate ?? false
//         ),
//       };
//       if (rowData.start_date && rowData.end_date) {
//         formValues.availableRange = [
//           dayjs(rowData.start_date),
//           dayjs(rowData.end_date),
//         ];
//       }
//       if (rowData.time || rowData.duration_time || rowData.time_show) {
//         const timeValue = rowData.time || rowData.duration_time || rowData.time_show;
//         const parsedTime = dayjs(timeValue, "HH:mm:ss");
//         if (parsedTime.isValid()) {
//           formValues.time = parsedTime;
//         }
//       }
//       form.setFieldsValue(formValues);
//       if (formValues.category) {
//         setSelectedCategory(formValues.category);
//       }
//       if (formValues.section) {
//         setSelectedOption(formValues.section);
//       }
//       if (rowData?.image_url && fileList.length === 0) {
//         const fakeFile = {
//           uid: `image-${rowData.id}`,
//           name: "course-cover",
//           status: "done",
//           url: rowData.image_url,
//         };
//         setFileList([fakeFile]);
//         setImagePreview(rowData.image_url);
//       }
//       // Initialize course book file list with existing file
//       // if (rowData?.round_book_url && courseBookFileList.length === 0) {
//       //   const fakeCourseBookFile = {
//       //     uid: `course-book-${rowData.id}`,
//       //     name: rowData?.round_book_name || "round-book.pdf",
//       //     status: "done",
//       //     url: rowData?.round_book_url,
//       //   };
//       //   setCourseBookFileList([fakeCourseBookFile]);
//       //   form.setFieldsValue({ courseBook: [fakeCourseBookFile] });
//       // }
//       // Initialize extra PDF file list with existing file
//       // if (rowData?.round_road_map_book_url && extraPdfFileList.length === 0) {
//       //   const fakeRoadMapBookFile = {
//       //     uid: `road-map-${rowData.id}`,
//       //     name: rowData?.round_road_map_book_name || "road-map-book.pdf",
//       //     status: "done",
//       //     url: rowData.round_road_map_book_url,
//       //   };
//       //   setExtraPdfFileList([fakeRoadMapBookFile]);
//       //   form.setFieldsValue({ extraPdf: [fakeRoadMapBookFile] });
//       // }
//       setIsInitialized(true);
//     }
//   }, [rowData, id, form, fileList, setFileList, setImagePreview, setSelectedCategory,
//     courseBookFileList, extraPdfFileList, isInitialized, isEditMode]);
//   useEffect(() => {
//     if (store_round && !rowData) {
//       const formValues = {
//         name: store_round.name || "",
//         price: store_round.price || 0,
//         category: store_round.course_category_id || store_round.category_id || "",
//         section: store_round.category_part_id || "",
//         description: store_round.description || "",
//         genderPolicy: store_round.gender || "both",
//         capacity: store_round.capacity || 20,
//         instructor: store_round?.instructor || [],
//         free: Boolean(store_round?.free),
//         active: Boolean(store_round?.active ?? true),
//         goal: store_round?.goal || "",
//         certificate: Boolean(
//           store_round?.certificate ?? store_round?.has_certificate ?? store_round?.hasCertificate ?? false
//         ),
//       };
//       if (store_round.start_date && store_round.end_date) {
//         formValues.availableRange = [
//           dayjs(store_round.start_date),
//           dayjs(store_round.end_date),
//         ];
//       }
//       if (store_round.time_show || store_round.time) {
//         const timeValue = store_round.time_show || store_round.time;
//         const parsedTime = dayjs(timeValue, "HH:mm:ss");
//         if (parsedTime.isValid()) {
//           formValues.time = parsedTime;
//         }
//       }
//       form.setFieldsValue(formValues);
//       if (formValues.category) {
//         setSelectedCategory(formValues.category);
//       }
//       if (formValues.section) {
//         setSelectedOption(formValues.section);
//       }
//       if (store_round?.round_book && courseBookFileList.length === 0) {
//         if (typeof store_round.round_book === 'string' && store_round.round_book.startsWith('http')) {
//           const fakeCourseBookFile = {
//             uid: `${Date.now()}-round-book`,
//             name: store_round?.round_book_name || "round-book.pdf",
//             status: "done",
//             url: store_round.round_book,
//           };
//           setCourseBookFileList([fakeCourseBookFile]);
//           form.setFieldsValue({ courseBook: [fakeCourseBookFile] });
//         }
//       }
//       if (store_round?.round_road_map_book && extraPdfFileList.length === 0) {
//         if (typeof store_round.round_road_map_book === 'string' && store_round.round_road_map_book.startsWith('http')) {
//           const fakeRoadMapBookFile = {
//             uid: `${Date.now()}-road-map-book`,
//             name: store_round?.round_road_map_book || "road-map-book.pdf",
//             status: "done",
//             url: store_round.round_road_map_book,
//           };
//           setExtraPdfFileList([fakeRoadMapBookFile]);
//           form.setFieldsValue({ extraPdf: [fakeRoadMapBookFile] });
//         }
//       }
//       setIsInitialized(true);
//     }
//   }, [store_round, courseBookFileList, extraPdfFileList, form, setSelectedCategory,
//     rowData, isInitialized, setCourseBookFileList, setExtraPdfFileList]);
//   /* ====================== Validation ====================== */
//   const validateFormBeforeSubmit = (values) => {
//     const errors = [];
//     if (!values.name?.trim()) errors.push("name");
//     if (values.price === undefined || values.price === null || values.price === "") errors.push("price");
//     if (!values.category) errors.push("category");
//     if (!values.section) errors.push("section");
//     // if (!values.description?.trim()) errors.push("description");
//     if (!values.genderPolicy) errors.push("genderPolicy");
//     if (!values.capacity) errors.push("capacity");
//     if (!values.instructor || values.instructor.length === 0) errors.push("instructor");
//     // if (!values.availableRange || values.availableRange.length !== 2) {
//     //   errors.push("availableRange");
//     // } else {
//     //   const [start, end] = values.availableRange;
//     //   if (!isDayjsValid(start) || !isDayjsValid(end)) {
//     //     errors.push("availableRange");
//     //   } else if (end.isBefore(start)) {
//     //     errors.push("availableRange");
//     //     toast.error("تاريخ النهاية يجب أن يكون بعد تاريخ البداية");
//     //   }
//     // }
//     if (isQuillEmpty(values.goal)) {
//       errors.push("goal");
//     }
//     if (!isEditMode && (!fileList || fileList.length === 0)) {
//       errors.push("image");
//     }
//     return errors;
//   };
//   const showValidationToast = (errors) => {
//     if (errors.length === 0) return;
//     const errorMessages = errors.map((err) => getFieldLabel(err));
//     const errorText = `الحقول التالية مطلوبة: ${errorMessages.join("، ")}`;
//     toast.error(errorText, {
//       position: "top-center",
//       autoClose: 5000,
//       hideProgressBar: false,
//       closeOnClick: true,
//       pauseOnHover: true,
//       draggable: true,
//       progress: undefined,
//     });
//   };
//   const getFileObject = (fileItem) => {
//     if (fileItem.originFileObj) {
//       return fileItem.originFileObj;
//     }
//     if (fileItem.response) {
//       return fileItem.response;
//     }
//     return null;
//   };
//   /* ====================== Submit ====================== */
//   async function handleSubmit(values) {
//     try {
//       setIsSubmitting(true);
//       const allFields = [
//         "name",
//         "price",
//         "category",
//         "section",
//         // "description",
//         "genderPolicy",
//         "capacity",
//         "instructor",
//         "goal",
//         "image",
//       ];
//       const touchedAll = {};
//       allFields.forEach((field) => (touchedAll[field] = true));
//       setTouchedFields(touchedAll);
//       const validationErrors = validateFormBeforeSubmit(values);
//       if (validationErrors.length > 0) {
//         setValidationErrors(validationErrors);
//         showValidationToast(validationErrors);
//         setIsSubmitting(false);
//         const firstError = validationErrors[0];
//         const element = document.querySelector(`[data-field="${firstError}"]`);
//         if (element) {
//           element.scrollIntoView({ behavior: "smooth", block: "center" });
//         }
//         return;
//       }
//       setValidationErrors([]);
//       // const [start, end] = values.availableRange;
//       const range = Array.isArray(values?.availableRange) ? values.availableRange : [];
//       const start = range[0] || null;
//       const end = range[1] || null;
//       const hasStart = isDayjsValid(start);
//       const hasEnd = isDayjsValid(end);
//       const timeString =
//         values.time && isDayjsValid(values.time)
//           ? values.time.format("HH:mm:ss")
//           : null;
//       let courseBookFile = null;
//       if (courseBookFileList.length > 0) {
//         const fileItem = courseBookFileList[0];
//         courseBookFile = getFileObject(fileItem);
//       }
//       let extraPdfFile = null;
//       if (extraPdfFileList.length > 0) {
//         const fileItem = extraPdfFileList[0];
//         extraPdfFile = getFileObject(fileItem);
//       }
//       let imageFile = null;
//       if (fileList && fileList.length > 0) {
//         const file = fileList[0];
//         imageFile = getFileObject(file);
//       }
//       if (!isEditMode && !imageFile) {
//         toast.error("يجب رفع صورة صالحة للدورة");
//         setIsSubmitting(false);
//         return;
//       }
//       const formData = new FormData();
//       formData.append("name", values?.name?.trim());
//       // formData.append("description", values?.description?.trim());
//       formData.append("price", values?.price?.toString() || "0");
//       formData.append("certificate", values?.certificate ? "1" : "0");
//       // if (start && isDayjsValid(start)) {
//       //   formData.append("start_date", dayjs(start).format("YYYY-MM-DD"));
//       // }
//       // if (end && isDayjsValid(end)) {
//       //   formData.append("end_date", dayjs(end).format("YYYY-MM-DD"));
//       // }
//       if (hasStart) {
//         formData.append("start_date", dayjs(start).format("YYYY-MM-DD"));
//       } else if (isEditMode && touchedFields.availableRange) {
//         formData.append("start_date", "");
//       }
//       if (hasEnd) {
//         formData.append("end_date", dayjs(end).format("YYYY-MM-DD"));
//       } else if (isEditMode && touchedFields.availableRange) {
//         formData.append("end_date", "");
//       }
//       formData.append("gender", values.genderPolicy || "both");
//       formData.append("for", "Beginners");
//       formData.append("goal", values?.goal || "");
//       formData.append("course_category_id", selectedCategory?.toString());
//       formData.append("category_part_id", selectedOption?.toString());
//       formData.append("source", isSource ? "0" : "1");
//       formData.append("capacity", values?.capacity?.toString() || "20");
//       if (timeString) {
//         formData.append("time_show", timeString);
//       } else if (isEditMode && touchedFields.time) {
//         formData.append("time_show", "");
//       }
//       formData.append("teacher_id", values?.instructor?.join(",") || "");
//       formData.append("free", values?.free ? "1" : "0");
//       formData.append("active", values?.active ? "1" : "0");
//       if (isEditMode) {
//         formData.append("id", rowData?.id?.toString());
//         if (imageFile) {
//           formData.append("image", imageFile);
//         } else if (oldFilesToDelete.image) {
//           // If image was removed, send empty string to delete it
//           formData.append("image", "");
//         }
//         // Handle course book
//         if (courseBookFile) {
//           // User uploaded a new file
//           formData.append("round_book", courseBookFile);
//         } else if (oldFilesToDelete.round_book) {
//           // User removed the existing file (via trash icon)
//           formData.append("round_book", "");
//         } else if (rowData?.round_book_url && !oldFilesToDelete.round_book) {
//           // Keep the existing file - send the URL
//           formData.append("round_book", rowData.round_book_url);
//         } else {
//           // No file was provided - send empty
//           formData.append("round_book", "");
//         }
//         // Handle extra PDF
//         if (extraPdfFile) {
//           // User uploaded a new file
//           formData.append("round_road_map_book", extraPdfFile);
//         } else if (oldFilesToDelete.round_road_map_book) {
//           // User removed the existing file (via trash icon)
//           formData.append("round_road_map_book", "");
//         } else if (rowData?.round_road_map_book_url && !oldFilesToDelete.round_road_map_book) {
//           // Keep the existing file - send the URL
//           formData.append("round_road_map_book", rowData.round_road_map_book_url);
//         } else {
//           // No file was provided - send empty
//           formData.append("round_road_map_book", "");
//         }
//       } else {
//         // For new course
//         if (imageFile) {
//           formData.append("image", imageFile);
//         }
//         if (courseBookFile) {
//           formData.append("round_book", courseBookFile);
//         } else {
//           formData.append("round_book", "");
//         }
//         if (extraPdfFile) {
//           formData.append("round_road_map_book", extraPdfFile);
//         } else {
//           formData.append("round_road_map_book", "");
//         }
//         const startStr = hasStart ? dayjs(start).format("YYYY-MM-DD") : null;
// const endStr = hasEnd ? dayjs(end).format("YYYY-MM-DD") : null;
// dispatch(add_round_data({
//   ...values,
//   course_category_id: selectedCategory,
//   category_part_id: selectedOption,
//   teacher_id: values?.instructor?.join(','),
//   start_date: startStr,
//   end_date: endStr,
//   time_show: timeString || null,
//   certificate: values?.certificate ? 1 : 0,
//   round_road_map_book: extraPdfFile,
//   round_book: courseBookFile
// }));
//       }
//       const result = await dispatch(
//         isEditMode
//           ? handleEditBaiskRound({ body: formData })
//           : handleAddBaiskRound({ body: formData })
//       ).unwrap();
//       if (result?.data?.status == "success") {
//         const roundIdValue = result?.data?.message?.round_id || rowData?.id || id;
//         setRoundId(roundIdValue);
//         dispatch(handleGetSourceRound({ page, per_page: 6 }));
//         dispatch(handleGetAllRounds({
//           course_category_id: Cat_id,
//           page,
//           per_page: 6
//         }))
//         if (isEditMode) {
//           toast.success(
//             result?.data?.message?.message || "تم تحديث الدورة بنجاح"
//           );
//           // Reset deletion flags
//           setOldFilesToDelete({
//             image: false,
//             round_book: false,
//             round_road_map_book: false,
//           });
//         } else {
//           toast.success(result?.data?.message || "تم إضافة الدورة بنجاح");
//         }
//         goToNextStep();
//       } else {
//         console.log("errorrrr", result);
//         toast.error(
//           result?.error?.response?.data?.message || "حدث خطأ أثناء حفظ البيانات"
//         );
//       }
//     } catch (error) {
//       console.error("Submission error:", error);
//       toast.error("حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى");
//     } finally {
//       setIsSubmitting(false);
//     }
//   }
//   const disabledDate = (current) => {
//     return current && current < dayjs().startOf("day");
//   };
//   function handleSubmitFailed(errorInfo) {
//     console.log("Form submission failed:", errorInfo);
//     const errorFields = errorInfo.errorFields
//       .map((field) => field.name[0])
//       .flat();
//     const uniqueErrors = [...new Set(errorFields)];
//     const errorMessages = uniqueErrors.map((field) => getFieldLabel(field));
//     const errorText = `يرجى مراجعة الحقول التالية: ${errorMessages.join("، ")}`;
//     toast.error(errorText, {
//       position: "top-center",
//       autoClose: 5000,
//     });
//     const touched = {};
//     uniqueErrors.forEach((field) => (touched[field] = true));
//     setTouchedFields((prev) => ({ ...prev, ...touched }));
//   }
//   const hasError = (fieldName) => {
//     return validationErrors.includes(fieldName) && touchedFields[fieldName];
//   };
//   /* ====================== Render ====================== */
//   return (
//     <div className="space-y-8">
//       <Form
//         form={form}
//         layout="vertical"
//         onFinish={handleSubmit}
//         onFinishFailed={handleSubmitFailed}
//         className="space-y-8"
//         initialValues={{
//           genderPolicy: "both",
//           capacity: 20,
//           free: false,
//           active: true,
//           certificate: false,
//           price: 0,
//         }}
//         validateMessages={{
//           required: "${label} مطلوب",
//           types: {
//             number: "${label} يجب أن يكون رقماً",
//           },
//           number: {
//             min: "${label} لا يمكن أن يكون أقل من ${min}",
//             max: "${label} لا يمكن أن يكون أكثر من ${max}",
//           },
//           string: {
//             min: "${label} يجب أن يكون على الأقل ${min} أحرف",
//             max: "${label} لا يمكن أن يتجاوز ${max} أحرف",
//           },
//         }}
//       >
//         <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
//           {/* Image Upload */}
//           <div className="lg:col-span-1" data-field="image">
//             <Form.Item
//               label={
//                 <span className="font-semibold text-gray-700 flex items-center gap-2">
//                   <InboxOutlined className="text-blue-600" />
//                   صورة الدورة {!isEditMode && "*"}
//                 </span>
//               }
//               required={!isEditMode}
//               validateStatus={hasError("image") ? "error" : ""}
//               help={hasError("image") ? "صورة الدورة مطلوبة" : null}
//             >
//               <Dragger
//                 accept=".jpg,.jpeg,.png,.gif,.webp"
//                 multiple={false}
//                 maxCount={1}
//                 beforeUpload={beforeUpload}
//                 fileList={fileList}
//                 onChange={handleFileChange}
//                 onRemove={handleRemoveFile}
//                 listType="picture"
//                 className={`border-2 border-dashed rounded-xl ${hasError("image")
//                   ? "border-red-400 bg-red-50/50"
//                   : "border-blue-300 hover:border-blue-400 bg-blue-50/50"
//                   }`}
//               >
//                 <p className="ant-upload-drag-icon">
//                   <InboxOutlined
//                     className={`text-4xl ${hasError("image") ? "text-red-500" : "text-blue-500"
//                       }`}
//                   />
//                 </p>
//                 <p className="ant-upload-text font-medium text-gray-700">
//                   {isEditMode && rowData?.image_url ? "تغيير الصورة" : "اسحب الصورة هنا أو اضغط للاختيار"}
//                 </p>
//                 <p className="ant-upload-hint text-gray-500">
//                   الحجم الأقصى 5MB - صيغ مدعومة: JPG, PNG, WebP
//                 </p>
//               </Dragger>
//             </Form.Item>
//           </div>
//           {/* Basic Details */}
//           <div className="lg:col-span-2 space-y-6">
//             <Row gutter={16}>
//               <Col span={12} data-field="name">
//                 <Form.Item
//                   label={
//                     <span className="font-semibold text-gray-700 flex items-center gap-2">
//                       <BookOutlined className="text-green-600" />
//                       اسم الدورة *
//                     </span>
//                   }
//                   name="name"
//                   rules={[
//                     { required: true, message: "أدخل اسم الدورة" },
//                     { min: 3, message: "الاسم لا يقل عن 3 أحرف" },
//                   ]}
//                   validateStatus={hasError("name") ? "error" : ""}
//                 >
//                   <Input
//                     placeholder="مثال: دورة البرمجة المتقدمة"
//                     className={`rounded-xl ${hasError("name")
//                       ? "border-red-400"
//                       : "border-gray-300 hover:border-blue-400 focus:border-blue-500"
//                       }`}
//                     onChange={(e) => handleFieldChange("name", e.target.value)}
//                   />
//                 </Form.Item>
//               </Col>
//               <Col span={12} data-field="price">
//                 <Form.Item
//                   label={
//                     <span className="font-semibold text-gray-700 flex items-center gap-2">
//                       <DollarOutlined className="text-orange-600" />
//                       السعر (ج.م) *
//                     </span>
//                   }
//                   name="price"
//                   rules={[
//                     { required: true, message: "أدخل السعر" },
//                     { type: "number", min: 0, message: "السعر لا يقل عن 0" },
//                   ]}
//                   validateStatus={hasError("price") ? "error" : ""}
//                 >
//                   <InputNumber
//                     className={`w-full rounded-xl ${hasError("price") ? "border-red-400" : ""
//                       }`}
//                     placeholder="499"
//                     min={0}
//                     step={1}
//                     formatter={(value) =>
//                       `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
//                     }
//                     parser={(value) => value.replace(/\$\s?|(,*)/g, "")}
//                     onChange={(value) => handleFieldChange("price", value)}
//                   />
//                 </Form.Item>
//               </Col>
//             </Row>
//             <Row gutter={16}>
//               <Col span={12} data-field="category">
//                 <Form.Item
//                   label={
//                     <span className="font-semibold text-gray-700 flex items-center gap-2">
//                       <FolderOutlined className="text-purple-600" />
//                       الفئة *
//                     </span>
//                   }
//                   name="category"
//                   rules={[{ required: true, message: "اختر الفئة" }]}
//                   validateStatus={hasError("category") ? "error" : ""}
//                 >
//                   <Select
//                     placeholder="اختر فئة الدورة"
//                     className={`rounded-xl ${hasError("category") ? "border-red-400" : ""
//                       }`}
//                     onChange={(value) => {
//                       setSelectedCategory(value);
//                       handleFieldChange("category", value);
//                       form.setFieldsValue({ section: undefined });
//                       setSelectedOption(null);
//                       setValidationErrors((prev) =>
//                         prev.filter((err) => err !== "section")
//                       );
//                     }}
//                     options={categoriesOptions}
//                   />
//                 </Form.Item>
//               </Col>
//               <Col span={12} data-field="section">
//                 <Form.Item
//                   label={
//                     <span className="font-semibold text-gray-700 flex items-center gap-2">
//                       <BookOutlined className="text-indigo-600" />
//                       القسم *
//                     </span>
//                   }
//                   name="section"
//                   rules={[{ required: true, message: "اختر القسم" }]}
//                   validateStatus={hasError("section") ? "error" : ""}
//                 >
//                   <Select
//                     loading={get_categories_parts_loading}
//                     placeholder="اختر قسم من الفئة"
//                     className={`rounded-xl ${hasError("section") ? "border-red-400" : ""
//                       }`}
//                     disabled={!selectedCategory || get_categories_parts_loading}
//                     value={selectedOption}
//                     onChange={(value) => {
//                       setSelectedOption(value);
//                       handleFieldChange("section", value);
//                     }}
//                     options={categoriesPartOptions}
//                     notFoundContent={
//                       !selectedCategory
//                         ? "يرجى اختيار الفئة أولاً"
//                         : "لا توجد أقسام لهذه الفئة"
//                     }
//                   />
//                 </Form.Item>
//               </Col>
//             </Row>
//             <Form.Item
//               label={
//                 <span className="font-semibold text-gray-700">
//                   وصف الدورة *
//                 </span>
//               }
//               name="description"
//               // rules={[
//               //   { required: true, message: "أدخل وصفًا للدورة" },
//               // ]}
//               validateStatus={hasError("description") ? "error" : ""}
//               data-field="description"
//             >
//               <TextArea
//                 rows={4}
//                 placeholder="اكتب وصفاً شاملاً للدورة وأهدافها التعليمية..."
//                 className={`rounded-xl ${hasError("description")
//                   ? "border-red-400"
//                   : "border-gray-300 hover:border-blue-400 focus:border-blue-500"
//                   }`}
//                 showCount
//                 onChange={(e) =>
//                   handleFieldChange("description", e.target.value)
//                 }
//               />
//             </Form.Item>
//           </div>
//         </div>
//         {/* Configuration Section */}
//         <div className="bg-gradient-to-r from-gray-50 to-blue-50/30 rounded-2xl p-6 border border-gray-200">
//           <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-3">
//             <SettingOutlined className="text-blue-600" />
//             إعدادات الدورة
//           </h3>
//           <Row gutter={24}>
//             <Col span={8} data-field="genderPolicy">
//               <Form.Item
//                 label={
//                   <span className="font-semibold text-gray-700 flex items-center gap-2">
//                     <UserOutlined className="text-pink-600" />
//                     سياسة النوع *
//                   </span>
//                 }
//                 name="genderPolicy"
//                 rules={[{ required: true, message: "اختر السياسة" }]}
//                 validateStatus={hasError("genderPolicy") ? "error" : ""}
//               >
//                 <Select
//                   className={`rounded-xl ${hasError("genderPolicy") ? "border-red-400" : ""
//                     }`}
//                   options={[
//                     { label: "👨 للذكور فقط", value: "male" },
//                     { label: "👩 للإناث فقط", value: "female" },
//                     { label: "👥 للجميع", value: "both" },
//                   ]}
//                   onChange={(value) => handleFieldChange("genderPolicy", value)}
//                 />
//               </Form.Item>
//             </Col>
//             <Col span={8} data-field="capacity">
//               <Form.Item
//                 label={
//                   <span className="font-semibold text-gray-700 flex items-center gap-2">
//                     <TeamOutlined className="text-red-600" />
//                     السعة القصوى *
//                   </span>
//                 }
//                 name="capacity"
//                 rules={[{ required: true, message: "أدخل السعة القصوى" }]}
//                 validateStatus={hasError("capacity") ? "error" : ""}
//               >
//                 <InputNumber
//                   className={`w-full rounded-xl ${hasError("capacity") ? "border-red-400" : ""
//                     }`}
//                   placeholder="50"
//                   min={1}
//                   onChange={(value) => handleFieldChange("capacity", value)}
//                 />
//               </Form.Item>
//             </Col>
//             <Col span={8} data-field="instructor">
//               <Form.Item
//                 label={
//                   <span className="font-semibold text-gray-700 flex items-center gap-2">
//                     <UserOutlined className="text-cyan-600" />
//                     المدربين *
//                   </span>
//                 }
//                 name="instructor"
//                 rules={[{ required: true, message: "اختر المدربين" }]}
//                 validateStatus={hasError("instructor") ? "error" : ""}
//               >
//                 <Select
//                   mode="multiple"
//                   className={`rounded-xl ${hasError("instructor") ? "border-red-400" : ""
//                     }`}
//                   placeholder="اختر المدربين"
//                   options={teacherOptions}
//                   onChange={(value) => handleFieldChange("instructor", value)}
//                 />
//               </Form.Item>
//             </Col>
//           </Row>
//           <Form.Item
//             label={
//               <span className="font-semibold text-gray-700 flex items-center gap-2">
//                 <CalendarOutlined className="text-green-600" />
//                 فترة إتاحة الدورة *
//               </span>
//             }
//             name="availableRange"
//             // rules={[{ required: true, message: "حدد فترة الإتاحة" }]}
//             validateStatus={hasError("availableRange") ? "error" : ""}
//             data-field="availableRange"
//           >
//             <RangePicker
//               className={`w-full rounded-xl ${hasError("availableRange") ? "border-red-400" : ""
//                 }`}
//               placeholder={["تاريخ البداية", "تاريخ النهاية"]}
//               format="DD/MM/YYYY"
//               disabledDate={disabledDate}
//               onChange={(dates) => handleFieldChange("availableRange", dates)}
//             />
//           </Form.Item>
//           <Row gutter={24}>
//             <Col span={8}>
//               <Form.Item
//                 label={<span className="font-semibold text-gray-700 flex items-center gap-2">مجاني</span>}
//                 name="free"
//                 valuePropName="checked"
//               >
//                 <Switch onChange={(v) => handleFieldChange("free", v)} />
//               </Form.Item>
//             </Col>
//             <Col span={8}>
//               <Form.Item
//                 label={<span className="font-semibold text-gray-700 flex items-center gap-2">نشط</span>}
//                 name="active"
//                 valuePropName="checked"
//               >
//                 <Switch onChange={(v) => handleFieldChange("active", v)} />
//               </Form.Item>
//             </Col>
//             <Col span={8}>
//               <Form.Item
//                 label={<span className="font-semibold text-gray-700 flex items-center gap-2">شهادة</span>}
//                 name="certificate"
//                 valuePropName="checked"
//               >
//                 <Switch onChange={(v) => handleFieldChange("certificate", v)} />
//               </Form.Item>
//             </Col>
//           </Row>
//           <Row gutter={24}>
//             <Col span={12} data-field="goal">
//               <Form.Item
//                 label={
//                   <span className="font-semibold text-gray-700 flex items-center gap-2">
//                     الهدف *
//                   </span>
//                 }
//                 name="goal"
//                 validateStatus={hasError("goal") ? "error" : ""}
//                 help={hasError("goal") ? "أدخل الهدف" : null}
//               >
//                 <div
//                   className={`bg-white border rounded-xl ${hasError("goal") ? "border-red-400" : "border-gray-200"
//                     }`}
//                 >
//                   <ReactQuill
//                     theme="snow"
//                     modules={quillModules}
//                     formats={quillFormats}
//                     placeholder="اكتب الهدف من الدورة بالتفصيل (مثلاً: ماذا يتعلم الطالب، النتائج المتوقعة، الجمهور المستهدف)..."
//                     className="h-full"
//                     value={form.getFieldValue("goal")}
//                     onChange={(value) => {
//                       form.setFieldsValue({ goal: value });
//                       handleFieldChange("goal", value);
//                       validateQuillField(value);
//                     }}
//                   />
//                 </div>
//               </Form.Item>
//             </Col>
//              <Col span={12} data-field="terms_condition">
//               <Form.Item
//                 label={
//                   <span className="font-semibold text-gray-700 flex items-center gap-2">
//                      *
//                   </span>
//                 }
//                 name="terms_condition"
//                 validateStatus={hasError("terms_condition") ? "error" : ""}
//                 help={hasError("terms_condition") ? "أدخل الشروط والأحكام" : null}
//               >
//                 <div
//                   className={`bg-white border rounded-xl ${hasError("terms_condition") ? "border-red-400" : "border-gray-200"
//                     }`}
//                 >
//                   <ReactQuill
//                     theme="snow"
//                     modules={quillModules}
//                     formats={quillFormats}
//                     placeholder="اكتب الهدف من الدورة بالتفصيل (مثلاً: ماذا يتعلم الطالب، النتائج المتوقعة، الجمهور المستهدف)..."
//                     className="h-full"
//                     value={form.getFieldValue("terms_condition")}
//                     onChange={(value) => {
//                       form.setFieldsValue({ terms_condition: value });
//                       handleFieldChange("terms_condition", value);
//                       validateQuillField(value);
//                     }}
//                   />
//                 </div>
//               </Form.Item>
//             </Col>
//           </Row>
//           <Row gutter={24}>
//             <Col span={12} data-field="time">
//               <Form.Item
//                 label={
//                   <span className="font-semibold text-gray-700 flex items-center gap-2">
//                     <ClockCircleOutlined className="text-blue-600" />
//                     وقت الدورة
//                   </span>
//                 }
//                 name="time"
//               >
//                 <TimePicker
//                   className="w-full rounded-xl"
//                   format="HH:mm:ss"
//                   placeholder="اختر وقت الدورة"
//                   onChange={(value) => handleFieldChange("time", value)}
//                 />
//               </Form.Item>
//             </Col>
//           </Row>
//           {/* كتاب الدورة */}
//           <div className="flex flex-col gap-2">
//             <Form.Item
//               label={
//                 <span className="font-semibold text-gray-700 flex items-center gap-2">
//                   <FileTextOutlined className="text-cyan-600" />
//                   كتاب الدورة
//                 </span>
//               }
//               name="courseBook"
//               valuePropName="fileList"
//               getValueFromEvent={normFile}
//             >
//               <Dragger
//                 multiple={false}
//                 accept=".pdf,.doc,.docx,.txt"
//                 beforeUpload={customBeforeUpload}
//                 fileList={courseBookFileList}
//                 onChange={handleCourseBookChange}
//                 onRemove={(file) => {
//                   console.log(file);
//                   // setCourseBookFileList([])
//                   // When user clicks trash icon, file will be removed from UI
//                   // The handleCourseBookChange will handle marking for deletion
//                   return true;
//                 }}
//               >
//                 <p className="ant-upload-drag-icon">
//                   <InboxOutlined />
//                 </p>
//                 <p className="ant-upload-text">
//                   {isEditMode && rowData?.round_book_url ? "تغيير كتاب الدورة" : "اسحب ملف كتاب الدورة هنا أو اضغط للاختيار"}
//                 </p>
//                 {courseBookFileList.length === 0 && rowData?.round_book_url && (
//                   <p className="text-sm text-gray-500 mt-2">
//                     الملف الحالي: {rowData?.round_book_name || "round-book.pdf"}
//                   </p>
//                 )}
//               </Dragger>
//             </Form.Item>
//             {courseBookFileList.length === 0 && rowData?.round_book_url && !oldFilesToDelete.round_book && (
//               <div className="flex items-center gap-2">
//                 <a
//                   href={rowData.round_book_url}
//                   target="_blank"
//                   rel="noopener noreferrer"
//                   className="text-blue-600 hover:text-blue-800"
//                 >
//                   عرض الملف الحالي
//                 </a>
//                 <Button
//                   type="text"
//                   danger
//                   size="small"
//                   onClick={() => {
//                     // Remove file from UI
//                     setCourseBookFileList([]);
//                     // Mark for deletion
//                     setOldFilesToDelete(prev => ({ ...prev, round_book: true }));
//                     // toast.info("تم إزالة ملف كتاب الدورة. سيتم حذفه عند الحفظ.");
//                   }}
//                 >
//                   حذف الملف
//                 </Button>
//               </div>
//             )}
//           </div>
//           {/* ملف PDF إضافي */}
//           <div className="flex flex-col gap-2">
//             <Form.Item
//               label={
//                 <span className="font-semibold text-gray-700 flex items-center gap-2">
//                   <FileTextOutlined className="text-purple-600" />
//                   جدول الدورة
//                 </span>
//               }
//               name="extraPdf"
//               valuePropName="fileList"
//               getValueFromEvent={normFile}
//             >
//               <Dragger
//                 multiple={false}
//                 accept=".pdf,.doc,.docx,.txt"
//                 beforeUpload={customBeforeUpload}
//                 fileList={extraPdfFileList}
//                 onChange={handleExtraPdfChange}
//                 onRemove={(file) => {
//                   // When user clicks trash icon, file will be removed from UI
//                   // The handleExtraPdfChange will handle marking for deletion
//                   return true;
//                 }}
//               >
//                 <p className="ant-upload-drag-icon">
//                   <InboxOutlined />
//                 </p>
//                 <p className="ant-upload-text">
//                   {isEditMode && rowData?.round_road_map_book_url ? "تغيير جدول الدورة" : "اسحب ملف PDF هنا أو اضغط للاختيار"}
//                 </p>
//                 {extraPdfFileList.length === 0 && rowData?.round_road_map_book_url && (
//                   <p className="text-sm text-gray-500 mt-2">
//                     الملف الحالي: {rowData?.round_road_map_book_name || "road-map-book.pdf"}
//                   </p>
//                 )}
//               </Dragger>
//             </Form.Item>
//             {extraPdfFileList?.length === 0 && rowData?.round_road_map_book_url && !oldFilesToDelete?.round_road_map_book && (
//               <div className="flex items-center gap-2">
//                 <a
//                   href={rowData.round_road_map_book_url}
//                   target="_blank"
//                   rel="noopener noreferrer"
//                   className="text-blue-600 hover:text-blue-800"
//                 >
//                   عرض الملف الحالي
//                 </a>
//                 <Button
//                   type="text"
//                   danger
//                   size="small"
//                   onClick={() => {
//                     // Remove file from UI
//                     setExtraPdfFileList([]);
//                     // Mark for deletion
//                     setOldFilesToDelete(prev => ({ ...prev, round_road_map_book: true }));
//                     // toast.info("تم إزالة ملف كتاب الدورة. سيتم حذفه عند الحفظ.");
//                   }}
//                 >
//                   حذف الملف
//                 </Button>
//               </div>
//             )}
//           </div>
//         </div>
//         <div className="mt-8 flex justify-between space-x-4 space-x-reverse">
//           <div className="mt-8 flex justify-between !ms-auto space-x-4 space-x-reverse">
//             <Button
//               size="large"
//               onClick={goToPrevStep}
//               disabled={currentStep === 1}
//               className={`rounded-lg border border-gray-300 bg-white px-6 py-2 text-gray-700 transition duration-150 hover:bg-gray-50 ${currentStep === 1 ? "cursor-not-allowed opacity-50" : ""
//                 }`}
//             >
//               السابق
//             </Button>
//             <Button
//               type="primary"
//               htmlType="submit"
//               size="large"
//               loading={add_round_loading || edit_round_loading || isSubmitting}
//               className="rounded-lg bg-blue-600 px-6 py-2 text-white shadow-md hover:bg-blue-700"
//             >
//               {add_round_loading || edit_round_loading || isSubmitting
//                 ? "جاري الحفظ..."
//                 : isEditMode
//                   ? "حفظ التعديلات"
//                   : "التالي"}
//             </Button>
//           </div>
//         </div>
//       </Form>
//     </div>
//   );
// }
__turbopack_context__.s([
    "default",
    ()=>AddCourseSourceBasicInfo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/col/index.js [app-ssr] (ecmascript) <export default as Col>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$date$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/date-picker/index.js [app-ssr] (ecmascript) <export default as DatePicker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/form/index.js [app-ssr] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input/index.js [app-ssr] (ecmascript) <export default as Input>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2d$number$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__InputNumber$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input-number/index.js [app-ssr] (ecmascript) <export default as InputNumber>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/row/index.js [app-ssr] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/select/index.js [app-ssr] (ecmascript) <export default as Select>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/upload/index.js [app-ssr] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$time$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TimePicker$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/time-picker/index.js [app-ssr] (ecmascript) <export default as TimePicker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$switch$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/switch/index.js [app-ssr] (ecmascript) <export default as Switch>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$BookOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/BookOutlined.js [app-ssr] (ecmascript) <export default as BookOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FileTextOutlined.js [app-ssr] (ecmascript) <export default as FileTextOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$InboxOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__InboxOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/InboxOutlined.js [app-ssr] (ecmascript) <export default as InboxOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$CalendarOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/CalendarOutlined.js [app-ssr] (ecmascript) <export default as CalendarOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UserOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UserOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/UserOutlined.js [app-ssr] (ecmascript) <export default as UserOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DollarOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DollarOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/DollarOutlined.js [app-ssr] (ecmascript) <export default as DollarOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$TeamOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TeamOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/TeamOutlined.js [app-ssr] (ecmascript) <export default as TeamOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FolderOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FolderOutlined.js [app-ssr] (ecmascript) <export default as FolderOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$SettingOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__SettingOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/SettingOutlined.js [app-ssr] (ecmascript) <export default as SettingOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$ClockCircleOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ClockCircleOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/ClockCircleOutlined.js [app-ssr] (ecmascript) <export default as ClockCircleOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/dayjs/dayjs.min.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$categoriesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/categoriesSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundsSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$teacherSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/teacherSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/shared/lib/app-dynamic.js [app-ssr] (ecmascript)");
;
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
const ReactQuill = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(async ()=>{}, {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/nartaqi/node_modules/react-quill-new/lib/index.js [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
const { Dragger } = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"];
const { TextArea } = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"];
const { RangePicker } = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$date$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__["DatePicker"];
const normFile = (e)=>{
    if (Array.isArray(e)) return e;
    return e?.fileList || [];
};
const customBeforeUpload = ()=>false;
const isDayjsValid = (value)=>{
    if (!value) return false;
    if (__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].isDayjs(value)) return value.isValid();
    return false;
};
function AddCourseSourceBasicInfo({ isSource, fileList, setFileList, setSource, availableSections, selectedCategory, setSelectedCategory, all_categories, beforeUpload = customBeforeUpload, setImagePreview, rowData, setRowData, goToNextStep, setRoundId, goToPrevStep, currentStep, id, page, pageSize, Cat_id }) {
    const [form] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].useForm();
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const { all_courses_categories_list, get_categories_parts_list, get_categories_parts_loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.categories);
    const { store_round, add_round_loading, edit_round_loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.rounds);
    const { teachers_list } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.teachers);
    // const searchParams = new URLSearchParams(typeof window != undefined && typeof window != "undefined" && window.location.search);
    const [categoriesOptions, setCategoriesOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [categoriesPartOptions, setCategoriesPartOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedOption, setSelectedOption] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isSubmitting, setIsSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [teacherOptions, setTeacherOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [validationErrors, setValidationErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [touchedFields, setTouchedFields] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [courseBookFileList, setCourseBookFileList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [extraPdfFileList, setExtraPdfFileList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [oldFilesToDelete, setOldFilesToDelete] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        image: false,
        round_book: false,
        round_road_map_book: false
    });
    const [isInitialized, setIsInitialized] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const isEditMode = Boolean(id);
    const getFieldLabel = (fieldName)=>{
        const labels = {
            name: "اسم الدورة",
            price: "السعر",
            category: "الفئة",
            section: "القسم",
            description: "وصف الدورة",
            genderPolicy: "سياسة النوع",
            capacity: "السعة القصوى",
            instructor: "المدربين",
            availableRange: "فترة إتاحة الدورة",
            goal: "الهدف",
            terms_condition: "الشروط والأحكام",
            image: "صورة الدورة",
            time: "وقت الدورة"
        };
        return labels[fieldName] || fieldName;
    };
    /* ====================== Load teachers / categories ====================== */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$teacherSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllTeachers"])());
    }, [
        dispatch
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log(teachers_list?.data?.message);
        if (teachers_list?.data?.message) {
            setTeacherOptions(teachers_list.data.message.map((item)=>({
                    label: item?.name,
                    value: item?.id
                })));
        }
    }, [
        teachers_list
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$categoriesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllCoursesCategories"])({}));
    }, [
        dispatch
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (all_courses_categories_list?.data?.message?.data) {
            setCategoriesOptions(all_courses_categories_list.data.message.data.map((item)=>({
                    label: item?.name,
                    value: item?.id
                })));
        }
    }, [
        all_courses_categories_list
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (selectedCategory) {
            const data_send = {
                course_category_id: selectedCategory
            };
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$categoriesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetCategoryParts"])({
                body: data_send
            }));
        }
    }, [
        selectedCategory,
        dispatch
    ]);
    const quillModules = {
        toolbar: [
            [
                {
                    header: [
                        1,
                        2,
                        3,
                        false
                    ]
                }
            ],
            [
                "bold",
                "italic",
                "underline"
            ],
            [
                {
                    list: "ordered"
                },
                {
                    list: "bullet"
                }
            ],
            [
                {
                    align: []
                }
            ],
            [
                "link"
            ],
            [
                "clean"
            ]
        ]
    };
    const quillFormats = [
        "header",
        "bold",
        "italic",
        "underline",
        "list",
        "bullet",
        "align",
        "link"
    ];
    const isQuillEmpty = (value)=>{
        if (!value) return true;
        const plain = value.replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ").trim();
        return plain.length === 0;
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (get_categories_parts_list?.data?.message) {
            const options = get_categories_parts_list.data.message.filter((item)=>Number(item?.course_category_id) === Number(selectedCategory)).map((part)=>({
                    label: part?.name,
                    value: part?.id
                }));
            setCategoriesPartOptions(options || []);
        } else {
            setCategoriesPartOptions([]);
        }
    }, [
        get_categories_parts_list,
        selectedCategory
    ]);
    /* ====================== Handle file changes ====================== */ const handleFileChange = ({ fileList: newFileList })=>{
        setFileList(newFileList);
        if (newFileList.length > 0) {
            const file = newFileList[0];
            if (file.originFileObj) {
                const previewUrl = URL.createObjectURL(file.originFileObj);
                setImagePreview(previewUrl);
                if (isEditMode && rowData?.image_url) {
                    setOldFilesToDelete((prev)=>({
                            ...prev,
                            image: true
                        }));
                }
            } else if (file.url) {
                setImagePreview(file.url);
            }
        } else {
            setImagePreview(null);
            if (isEditMode && rowData?.image_url) {
                setOldFilesToDelete((prev)=>({
                        ...prev,
                        image: true
                    }));
            }
        }
        validateImageField(newFileList);
    };
    const handleRemoveFile = ()=>{
        setFileList([]);
        setImagePreview(null);
        if (isEditMode && rowData?.image_url) {
            setOldFilesToDelete((prev)=>({
                    ...prev,
                    image: true
                }));
        }
        validateImageField([]);
    };
    const handleCourseBookChange = ({ fileList: newFileList })=>{
        setCourseBookFileList(newFileList);
        form.setFieldsValue({
            courseBook: newFileList
        });
    };
    const handleExtraPdfChange = ({ fileList: newFileList })=>{
        setExtraPdfFileList(newFileList);
        form.setFieldsValue({
            extraPdf: newFileList
        });
    };
    const validateImageField = (files)=>{
        if (!files || files.length === 0) {
            if (!isEditMode || !rowData?.image_url) {
                if (!touchedFields.image) {
                    setTouchedFields((prev)=>({
                            ...prev,
                            image: true
                        }));
                }
                return false;
            }
        }
        return true;
    };
    /* ====================== Field change handlers ====================== */ const handleFieldChange = (fieldName, value)=>{
        setTouchedFields((prev)=>({
                ...prev,
                [fieldName]: true
            }));
        if (fieldName === "goal" || fieldName === "terms_condition") {
            validateQuillField(value, fieldName);
        }
    };
    const validateQuillField = (value, fieldName)=>{
        if (isQuillEmpty(value)) {
            if (!validationErrors.includes(fieldName) && touchedFields[fieldName]) {
                setValidationErrors((prev)=>[
                        ...prev,
                        fieldName
                    ]);
            }
        } else {
            setValidationErrors((prev)=>prev.filter((err)=>err !== fieldName));
        }
    };
    /* ====================== Prefill when editing ====================== */ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log(rowData);
        if (id && rowData) {
            const formValues = {
                name: rowData.name || "",
                price: rowData.price || 0,
                category: rowData.course_category_id || rowData.category_id || "",
                section: rowData.category_part_id || "",
                description: rowData.description || "",
                genderPolicy: rowData.gender || "both",
                capacity: rowData.capacity || 20,
                instructor: rowData?.teachers?.map((item)=>item?.id) || [],
                free: Boolean(rowData.free),
                active: Boolean(rowData.active ?? true),
                goal: rowData.goal || "",
                // terms_condition: rowData.terms_condition || "",
                certificate: Boolean(rowData?.certificate ?? rowData?.has_certificate ?? rowData?.hasCertificate ?? false)
            };
            if (rowData.start_date && rowData.end_date) {
                formValues.availableRange = [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(rowData.start_date),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(rowData.end_date)
                ];
            }
            if (rowData.time || rowData.duration_time || rowData.time_show) {
                const timeValue = rowData.time || rowData.duration_time || rowData.time_show;
                const parsedTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(timeValue, "HH:mm:ss");
                if (parsedTime.isValid()) {
                    formValues.time = parsedTime;
                }
            }
            form.setFieldsValue(formValues);
            if (formValues.category) {
                setSelectedCategory(formValues.category);
            }
            if (formValues.section) {
                setSelectedOption(formValues.section);
            }
            if (rowData?.image_url && fileList.length === 0) {
                const fakeFile = {
                    uid: `image-${rowData.id}`,
                    name: "course-cover",
                    status: "done",
                    url: rowData.image_url
                };
                setFileList([
                    fakeFile
                ]);
                setImagePreview(rowData.image_url);
            }
            setIsInitialized(true);
        }
    }, [
        rowData,
        id,
        form,
        fileList,
        setFileList,
        setImagePreview,
        setSelectedCategory,
        courseBookFileList,
        extraPdfFileList,
        isInitialized,
        isEditMode
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (store_round && !rowData) {
            const formValues = {
                name: store_round.name || "",
                price: store_round.price || 0,
                category: store_round.course_category_id || store_round.category_id || "",
                section: store_round.category_part_id || "",
                description: store_round.description || "",
                genderPolicy: store_round.gender || "both",
                capacity: store_round.capacity || 20,
                instructor: store_round?.instructor || [],
                free: Boolean(store_round?.free),
                active: Boolean(store_round?.active ?? true),
                goal: store_round?.goal || "",
                // terms_condition: store_round?.terms_condition || "",
                certificate: Boolean(store_round?.certificate ?? store_round?.has_certificate ?? store_round?.hasCertificate ?? false)
            };
            if (store_round.start_date && store_round.end_date) {
                formValues.availableRange = [
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(store_round.start_date),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(store_round.end_date)
                ];
            }
            if (store_round.time_show || store_round.time) {
                const timeValue = store_round.time_show || store_round.time;
                const parsedTime = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(timeValue, "HH:mm:ss");
                if (parsedTime.isValid()) {
                    formValues.time = parsedTime;
                }
            }
            form.setFieldsValue(formValues);
            if (formValues.category) {
                setSelectedCategory(formValues.category);
            }
            if (formValues.section) {
                setSelectedOption(formValues.section);
            }
            setIsInitialized(true);
        }
    }, [
        store_round,
        form,
        setSelectedCategory,
        rowData,
        isInitialized,
        setCourseBookFileList,
        setExtraPdfFileList
    ]);
    /* ====================== Validation ====================== */ const validateFormBeforeSubmit = (values)=>{
        const errors = [];
        // Always required fields
        if (!values.name?.trim()) errors.push("name");
        if (values.price === undefined || values.price === null || values.price === "") errors.push("price");
        if (!values.category) errors.push("category");
        if (!values.section) errors.push("section");
        if (!values.genderPolicy) errors.push("genderPolicy");
        if (!values.capacity) errors.push("capacity");
        if (!values.instructor || values.instructor.length === 0) errors.push("instructor");
        // Conditionally required based on isSource
        if (isSource) {
            // if (!values.description?.trim()) errors.push("description");
            // If isSource is true, make these fields required
            if (!values.availableRange || values.availableRange.length !== 2) {
                errors.push("availableRange");
            } else {
                const [start, end] = values.availableRange;
                if (!isDayjsValid(start) || !isDayjsValid(end)) {
                    errors.push("availableRange");
                } else if (end.isBefore(start)) {
                    errors.push("availableRange");
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("تاريخ النهاية يجب أن يكون بعد تاريخ البداية");
                }
            }
            if (!values.time || !isDayjsValid(values.time)) {
                errors.push("time");
            }
        }
        // If isSource is false, these fields remain optional (no validation)
        if (isQuillEmpty(values.goal)) {
            errors.push("goal");
        }
        if (!isEditMode && (!fileList || fileList.length === 0)) {
            errors.push("image");
        }
        return errors;
    };
    const showValidationToast = (errors)=>{
        if (errors.length === 0) return;
        const errorMessages = errors.map((err)=>getFieldLabel(err));
        const errorText = `الحقول التالية مطلوبة: ${errorMessages.join("، ")}`;
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(errorText, {
            position: "top-center",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined
        });
    };
    const getFileObject = (fileItem)=>{
        if (fileItem.originFileObj) {
            return fileItem.originFileObj;
        }
        if (fileItem.response) {
            return fileItem.response;
        }
        return null;
    };
    /* ====================== Submit ====================== */ async function handleSubmit(values) {
        try {
            setIsSubmitting(true);
            const allFields = [
                "name",
                "price",
                "category",
                "section",
                "genderPolicy",
                "capacity",
                "instructor",
                "goal",
                "image"
            ];
            // Add conditional fields based on isSource
            if (isSource) {
                allFields.push("availableRange", "time");
            }
            const touchedAll = {};
            allFields.forEach((field)=>touchedAll[field] = true);
            setTouchedFields(touchedAll);
            const validationErrors = validateFormBeforeSubmit(values);
            if (validationErrors.length > 0) {
                setValidationErrors(validationErrors);
                showValidationToast(validationErrors);
                setIsSubmitting(false);
                const firstError = validationErrors[0];
                const element = document.querySelector(`[data-field="${firstError}"]`);
                if (element) {
                    element.scrollIntoView({
                        behavior: "smooth",
                        block: "center"
                    });
                }
                return;
            }
            setValidationErrors([]);
            const range = Array.isArray(values?.availableRange) ? values.availableRange : [];
            const start = range[0] || null;
            const end = range[1] || null;
            const hasStart = isDayjsValid(start);
            const hasEnd = isDayjsValid(end);
            const timeString = values.time && isDayjsValid(values.time) ? values.time.format("HH:mm:ss") : null;
            let courseBookFile = null;
            if (courseBookFileList.length > 0) {
                const fileItem = courseBookFileList[0];
                courseBookFile = getFileObject(fileItem);
            }
            let extraPdfFile = null;
            if (extraPdfFileList.length > 0) {
                const fileItem = extraPdfFileList[0];
                extraPdfFile = getFileObject(fileItem);
            }
            let imageFile = null;
            if (fileList && fileList.length > 0) {
                const file = fileList[0];
                imageFile = getFileObject(file);
            }
            if (!isEditMode && !imageFile) {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("يجب رفع صورة صالحة للدورة");
                setIsSubmitting(false);
                return;
            }
            const formData = new FormData();
            formData.append("name", values?.name?.trim());
            formData.append("description", values?.description?.trim() || "");
            formData.append("price", values?.price?.toString() || "0");
            formData.append("have_certificate", values?.certificate ? "1" : "0");
            if (hasStart) {
                formData.append("start_date", (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(start).format("YYYY-MM-DD"));
            } else if (isEditMode && touchedFields.availableRange) {
                formData.append("start_date", "");
            }
            if (hasEnd) {
                formData.append("end_date", (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(end).format("YYYY-MM-DD"));
            } else if (isEditMode && touchedFields.availableRange) {
                formData.append("end_date", "");
            }
            formData.append("gender", values.genderPolicy || "both");
            formData.append("for", "Beginners");
            formData.append("goal", values?.goal || "");
            // formData.append("terms_condition", values?.terms_condition || "");
            formData.append("course_category_id", selectedCategory?.toString());
            formData.append("category_part_id", selectedOption?.toString());
            formData.append("source", isSource ? "0" : "1");
            formData.append("capacity", values?.capacity?.toString() || "20");
            if (timeString) {
                formData.append("time_show", timeString);
            } else if (isEditMode && touchedFields.time) {
                formData.append("time_show", "");
            }
            formData.append("teacher_id", values?.instructor?.join(",") || "");
            formData.append("free", values?.free ? "1" : "0");
            formData.append("active", values?.active ? "1" : "0");
            if (isEditMode) {
                formData.append("id", rowData?.id?.toString());
                if (imageFile) {
                    formData.append("image", imageFile);
                } else if (oldFilesToDelete.image) {
                    formData.append("image", "");
                }
                if (courseBookFile) {
                    formData.append("round_book", courseBookFile);
                } else if (oldFilesToDelete.round_book) {
                    formData.append("round_book", "");
                } else if (rowData?.round_book_url && !oldFilesToDelete.round_book) {
                    formData.append("round_book", rowData.round_book_url);
                } else {
                    formData.append("round_book", "");
                }
                if (extraPdfFile) {
                    formData.append("round_road_map_book", extraPdfFile);
                } else if (oldFilesToDelete.round_road_map_book) {
                    formData.append("round_road_map_book", "");
                } else if (rowData?.round_road_map_book_url && !oldFilesToDelete.round_road_map_book) {
                    formData.append("round_road_map_book", rowData.round_road_map_book_url);
                } else {
                    formData.append("round_road_map_book", "");
                }
            } else {
                if (imageFile) {
                    formData.append("image", imageFile);
                }
                if (courseBookFile) {
                    formData.append("round_book", courseBookFile);
                } else {
                    formData.append("round_book", "");
                }
                if (extraPdfFile) {
                    formData.append("round_road_map_book", extraPdfFile);
                } else {
                    formData.append("round_road_map_book", "");
                }
                const startStr = hasStart ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(start).format("YYYY-MM-DD") : "";
                const endStr = hasEnd ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(end).format("YYYY-MM-DD") : "";
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["add_round_data"])({
                    ...values,
                    course_category_id: selectedCategory,
                    category_part_id: selectedOption,
                    teacher_id: values?.instructor?.join(','),
                    start_date: startStr,
                    end_date: endStr,
                    time_show: timeString || "",
                    description: values?.description || "",
                    certificate: values?.certificate ? 1 : 0,
                    round_road_map_book: extraPdfFile,
                    round_book: courseBookFile,
                    goal: values?.goal || ""
                }));
            }
            const result = await dispatch(isEditMode ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleEditBaiskRound"])({
                body: formData
            }) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleAddBaiskRound"])({
                body: formData
            })).unwrap();
            if (result?.data?.status == "success") {
                const url = new URL(window.location);
                url.searchParams.set("round_id", result?.data?.message?.round_id || rowData?.id || id);
                window.history.replaceState({}, "", url);
                const roundIdValue = result?.data?.message?.round_id || rowData?.id || id;
                setRoundId(roundIdValue);
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetSourceRound"])({
                    page,
                    per_page: 100000
                }));
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRounds"])({
                    course_category_id: Cat_id,
                    page,
                    per_page: 6
                }));
                if (isEditMode) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(result?.data?.message?.message || "تم تحديث الدورة بنجاح");
                    setOldFilesToDelete({
                        image: false,
                        round_book: false,
                        round_road_map_book: false
                    });
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(result?.data?.message || "تم إضافة الدورة بنجاح");
                }
                goToNextStep();
            } else {
                console.log("errorrrr", result);
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(result?.error?.response?.data?.message || "حدث خطأ أثناء حفظ البيانات");
            }
        } catch (error) {
            console.error("Submission error:", error);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى");
        } finally{
            setIsSubmitting(false);
        }
    }
    const disabledDate = (current)=>{
        return current && current < (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])().startOf("day");
    };
    function handleSubmitFailed(errorInfo) {
        console.log("Form submission failed:", errorInfo);
        const errorFields = errorInfo.errorFields.map((field)=>field.name[0]).flat();
        const uniqueErrors = [
            ...new Set(errorFields)
        ];
        const errorMessages = uniqueErrors.map((field)=>getFieldLabel(field));
        const errorText = `يرجى مراجعة الحقول التالية: ${errorMessages.join("، ")}`;
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(errorText, {
            position: "top-center",
            autoClose: 5000
        });
        const touched = {};
        uniqueErrors.forEach((field)=>touched[field] = true);
        setTouchedFields((prev)=>({
                ...prev,
                ...touched
            }));
    }
    const hasError = (fieldName)=>{
        return validationErrors.includes(fieldName) && touchedFields[fieldName];
    };
    // Helper function to get label based on isSource
    const getFieldLabelWithOptional = (fieldName)=>{
        const baseLabel = getFieldLabel(fieldName);
        if (isSource) {
            return `${baseLabel} *`;
        }
        return `${baseLabel} ${fieldName === 'description' || fieldName === 'availableRange' || fieldName === 'time' ? '(اختياري)' : '*'}`;
    };
    /* ====================== Render ====================== */ return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
            form: form,
            layout: "vertical",
            onFinish: handleSubmit,
            onFinishFailed: handleSubmitFailed,
            className: "space-y-8",
            initialValues: {
                genderPolicy: "both",
                capacity: 20,
                free: false,
                active: true,
                certificate: false,
                price: 0
            },
            validateMessages: {
                required: "${label} مطلوب",
                types: {
                    number: "${label} يجب أن يكون رقماً"
                },
                number: {
                    min: "${label} لا يمكن أن يكون أقل من ${min}",
                    max: "${label} لا يمكن أن يكون أكثر من ${max}"
                },
                string: {
                    min: "${label} يجب أن يكون على الأقل ${min} أحرف",
                    max: "${label} لا يمكن أن يتجاوز ${max} أحرف"
                }
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 lg:grid-cols-3 gap-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "lg:col-span-1",
                            "data-field": "image",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "font-semibold text-gray-700 flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$InboxOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__InboxOutlined$3e$__["InboxOutlined"], {
                                            className: "text-blue-600"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2203,
                                            columnNumber: 19
                                        }, void 0),
                                        getFieldLabelWithOptional("image")
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2202,
                                    columnNumber: 17
                                }, void 0),
                                required: !isEditMode,
                                validateStatus: hasError("image") ? "error" : "",
                                help: hasError("image") ? "صورة الدورة مطلوبة" : null,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Dragger, {
                                    accept: ".jpg,.jpeg,.png",
                                    multiple: false,
                                    maxCount: 1,
                                    beforeUpload: beforeUpload,
                                    fileList: fileList,
                                    onChange: handleFileChange,
                                    onRemove: handleRemoveFile,
                                    listType: "picture",
                                    className: `border-2 border-dashed rounded-xl ${hasError("image") ? "border-red-400 bg-red-50/50" : "border-blue-300 hover:border-blue-400 bg-blue-50/50"}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "ant-upload-drag-icon",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$InboxOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__InboxOutlined$3e$__["InboxOutlined"], {
                                                className: `text-4xl ${hasError("image") ? "text-red-500" : "text-blue-500"}`
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2226,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2225,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "ant-upload-text font-medium text-gray-700",
                                            children: isEditMode && rowData?.image_url ? "تغيير الصورة" : "اسحب الصورة هنا أو اضغط للاختيار"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2231,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "ant-upload-hint text-gray-500",
                                            children: "الحجم الأقصى 5MB - صيغ مدعومة: JPG, PNG"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2234,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2211,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                lineNumber: 2200,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                            lineNumber: 2199,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "lg:col-span-2 space-y-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                                    gutter: 16,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                            span: 12,
                                            "data-field": "name",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                                label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-semibold text-gray-700 flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$BookOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOutlined$3e$__["BookOutlined"], {
                                                            className: "text-green-600"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                            lineNumber: 2248,
                                                            columnNumber: 23
                                                        }, void 0),
                                                        getFieldLabelWithOptional("name")
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2247,
                                                    columnNumber: 21
                                                }, void 0),
                                                name: "name",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "أدخل اسم الدورة"
                                                    },
                                                    {
                                                        min: 3,
                                                        message: "الاسم لا يقل عن 3 أحرف"
                                                    }
                                                ],
                                                validateStatus: hasError("name") ? "error" : "",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                                                    placeholder: "مثال: دورة البرمجة المتقدمة",
                                                    className: `rounded-xl ${hasError("name") ? "border-red-400" : "border-gray-300 hover:border-blue-400 focus:border-blue-500"}`,
                                                    onChange: (e)=>handleFieldChange("name", e.target.value)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2259,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2245,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2244,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                            span: 12,
                                            "data-field": "price",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                                label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-semibold text-gray-700 flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DollarOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DollarOutlined$3e$__["DollarOutlined"], {
                                                            className: "text-orange-600"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                            lineNumber: 2273,
                                                            columnNumber: 23
                                                        }, void 0),
                                                        getFieldLabelWithOptional("price")
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2272,
                                                    columnNumber: 21
                                                }, void 0),
                                                name: "price",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "أدخل السعر"
                                                    },
                                                    {
                                                        type: "number",
                                                        min: 0,
                                                        message: "السعر لا يقل عن 0"
                                                    }
                                                ],
                                                validateStatus: hasError("price") ? "error" : "",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2d$number$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__InputNumber$3e$__["InputNumber"], {
                                                    className: `w-full rounded-xl ${hasError("price") ? "border-red-400" : ""}`,
                                                    placeholder: "499",
                                                    min: 0,
                                                    step: 1,
                                                    formatter: (value)=>`${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                                                    parser: (value)=>value.replace(/\$\s?|(,*)/g, ""),
                                                    onChange: (value)=>handleFieldChange("price", value)
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2284,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2270,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2269,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2243,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                                    gutter: 16,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                            span: 12,
                                            "data-field": "category",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                                label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-semibold text-gray-700 flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FolderOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderOutlined$3e$__["FolderOutlined"], {
                                                            className: "text-purple-600"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                            lineNumber: 2305,
                                                            columnNumber: 23
                                                        }, void 0),
                                                        getFieldLabelWithOptional("category")
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2304,
                                                    columnNumber: 21
                                                }, void 0),
                                                name: "category",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "اختر الفئة"
                                                    }
                                                ],
                                                validateStatus: hasError("category") ? "error" : "",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                                                    placeholder: "اختر فئة الدورة",
                                                    className: `rounded-xl ${hasError("category") ? "border-red-400" : ""}`,
                                                    onChange: (value)=>{
                                                        setSelectedCategory(value);
                                                        handleFieldChange("category", value);
                                                        form.setFieldsValue({
                                                            section: undefined
                                                        });
                                                        setSelectedOption(null);
                                                        setValidationErrors((prev)=>prev.filter((err)=>err !== "section"));
                                                    },
                                                    options: categoriesOptions
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2313,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2302,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2301,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                            span: 12,
                                            "data-field": "section",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                                label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-semibold text-gray-700 flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$BookOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOutlined$3e$__["BookOutlined"], {
                                                            className: "text-indigo-600"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                            lineNumber: 2334,
                                                            columnNumber: 23
                                                        }, void 0),
                                                        getFieldLabelWithOptional("section")
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2333,
                                                    columnNumber: 21
                                                }, void 0),
                                                name: "section",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "اختر القسم"
                                                    }
                                                ],
                                                validateStatus: hasError("section") ? "error" : "",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                                                    loading: get_categories_parts_loading,
                                                    placeholder: "اختر قسم من الفئة",
                                                    className: `rounded-xl ${hasError("section") ? "border-red-400" : ""}`,
                                                    disabled: !selectedCategory || get_categories_parts_loading,
                                                    value: selectedOption,
                                                    onChange: (value)=>{
                                                        setSelectedOption(value);
                                                        handleFieldChange("section", value);
                                                    },
                                                    options: categoriesPartOptions,
                                                    notFoundContent: !selectedCategory ? "يرجى اختيار الفئة أولاً" : "لا توجد أقسام لهذه الفئة"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2342,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2331,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2330,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2300,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                    label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-semibold text-gray-700 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__["FileTextOutlined"], {
                                                className: "text-gray-600"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2367,
                                                columnNumber: 19
                                            }, void 0),
                                            getFieldLabelWithOptional("description")
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2366,
                                        columnNumber: 17
                                    }, void 0),
                                    name: "description",
                                    validateStatus: hasError("description") ? "error" : "",
                                    "data-field": "description",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(TextArea, {
                                        rows: 4,
                                        placeholder: isSource ? "اكتب وصفاً شاملاً للدورة وأهدافها التعليمية..." : "اكتب وصفاً شاملاً للدورة وأهدافها التعليمية... (اختياري)",
                                        className: `rounded-xl ${hasError("description") ? "border-red-400" : "border-gray-300 hover:border-blue-400 focus:border-blue-500"}`,
                                        showCount: true,
                                        onChange: (e)=>handleFieldChange("description", e.target.value)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2376,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2364,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                            lineNumber: 2242,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                    lineNumber: 2197,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-gradient-to-r from-gray-50 to-blue-50/30 rounded-2xl p-6 border border-gray-200",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-xl font-bold text-gray-800 mb-6 flex items-center gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$SettingOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__SettingOutlined$3e$__["SettingOutlined"], {
                                    className: "text-blue-600"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2395,
                                    columnNumber: 13
                                }, this),
                                "إعدادات الدورة"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                            lineNumber: 2394,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                            gutter: 24,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    span: 8,
                                    "data-field": "genderPolicy",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700 flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UserOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UserOutlined$3e$__["UserOutlined"], {
                                                    className: "text-pink-600"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2404,
                                                    columnNumber: 21
                                                }, void 0),
                                                getFieldLabelWithOptional("genderPolicy")
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2403,
                                            columnNumber: 19
                                        }, void 0),
                                        name: "genderPolicy",
                                        rules: [
                                            {
                                                required: true,
                                                message: "اختر السياسة"
                                            }
                                        ],
                                        validateStatus: hasError("genderPolicy") ? "error" : "",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                                            className: `rounded-xl ${hasError("genderPolicy") ? "border-red-400" : ""}`,
                                            options: [
                                                {
                                                    label: "👨 للذكور فقط",
                                                    value: "male"
                                                },
                                                {
                                                    label: "👩 للإناث فقط",
                                                    value: "female"
                                                },
                                                {
                                                    label: "👥 للجميع",
                                                    value: "both"
                                                }
                                            ],
                                            onChange: (value)=>handleFieldChange("genderPolicy", value)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2412,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2401,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2400,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    span: 8,
                                    "data-field": "capacity",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700 flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$TeamOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TeamOutlined$3e$__["TeamOutlined"], {
                                                    className: "text-red-600"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2428,
                                                    columnNumber: 21
                                                }, void 0),
                                                getFieldLabelWithOptional("capacity")
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2427,
                                            columnNumber: 19
                                        }, void 0),
                                        name: "capacity",
                                        rules: [
                                            {
                                                required: true,
                                                message: "أدخل السعة القصوى"
                                            }
                                        ],
                                        validateStatus: hasError("capacity") ? "error" : "",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2d$number$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__InputNumber$3e$__["InputNumber"], {
                                            className: `w-full rounded-xl ${hasError("capacity") ? "border-red-400" : ""}`,
                                            placeholder: "50",
                                            min: 1,
                                            onChange: (value)=>handleFieldChange("capacity", value)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2436,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2425,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2424,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    span: 8,
                                    "data-field": "instructor",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700 flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UserOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UserOutlined$3e$__["UserOutlined"], {
                                                    className: "text-cyan-600"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2449,
                                                    columnNumber: 21
                                                }, void 0),
                                                getFieldLabelWithOptional("instructor")
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2448,
                                            columnNumber: 19
                                        }, void 0),
                                        name: "instructor",
                                        rules: [
                                            {
                                                required: true,
                                                message: "اختر المدربين"
                                            }
                                        ],
                                        validateStatus: hasError("instructor") ? "error" : "",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$select$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Select$3e$__["Select"], {
                                            mode: "multiple",
                                            className: `rounded-xl ${hasError("instructor") ? "border-red-400" : ""}`,
                                            placeholder: "اختر المدربين",
                                            options: teacherOptions,
                                            onChange: (value)=>handleFieldChange("instructor", value)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2457,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2446,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2445,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                            lineNumber: 2399,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                            gutter: 24,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    span: 12,
                                    "data-field": "availableRange",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-semibold text-gray-700 flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$CalendarOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarOutlined$3e$__["CalendarOutlined"], {
                                                            className: "text-green-600"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                            lineNumber: 2475,
                                                            columnNumber: 23
                                                        }, void 0),
                                                        getFieldLabelWithOptional("availableRange")
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2474,
                                                    columnNumber: 21
                                                }, void 0),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mt-1 mb-2",
                                                    children: "تاريخ بداية الدورة - تاريخ نهاية الدورة"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2478,
                                                    columnNumber: 21
                                                }, void 0)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2473,
                                            columnNumber: 19
                                        }, void 0),
                                        name: "availableRange",
                                        rules: isSource ? [
                                            {
                                                required: true,
                                                message: "حدد فترة إتاحة الدورة"
                                            }
                                        ] : [],
                                        validateStatus: hasError("availableRange") ? "error" : "",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(RangePicker, {
                                            className: `w-full rounded-xl ${hasError("availableRange") ? "border-red-400" : ""}`,
                                            placeholder: [
                                                "تاريخ البداية",
                                                "تاريخ النهاية"
                                            ],
                                            format: "DD/MM/YYYY",
                                            disabledDate: disabledDate,
                                            onChange: (dates)=>handleFieldChange("availableRange", dates)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2489,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2471,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2470,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    span: 12,
                                    "data-field": "time",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "font-semibold text-gray-700 flex items-center gap-2",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$ClockCircleOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ClockCircleOutlined$3e$__["ClockCircleOutlined"], {
                                                            className: "text-blue-600"
                                                        }, void 0, false, {
                                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                            lineNumber: 2504,
                                                            columnNumber: 23
                                                        }, void 0),
                                                        getFieldLabelWithOptional("time")
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2503,
                                                    columnNumber: 21
                                                }, void 0),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mt-1 mb-2",
                                                    children: "وقت عرض الدورة (مثلا : 14:00:00)"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2507,
                                                    columnNumber: 21
                                                }, void 0)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2502,
                                            columnNumber: 19
                                        }, void 0),
                                        name: "time",
                                        rules: isSource ? [
                                            {
                                                required: true,
                                                message: "حدد وقت الدورة"
                                            }
                                        ] : [],
                                        validateStatus: hasError("time") ? "error" : "",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$time$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TimePicker$3e$__["TimePicker"], {
                                            className: `w-full rounded-xl ${hasError("time") ? "border-red-400" : ""}`,
                                            format: "HH:mm:ss",
                                            placeholder: isSource ? "اختر وقت الدورة" : "اختر وقت الدورة (اختياري)",
                                            onChange: (value)=>handleFieldChange("time", value)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2518,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2500,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2499,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                            lineNumber: 2469,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                            gutter: 24,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    span: 8,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700 flex items-center gap-2",
                                            children: "مجاني"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2532,
                                            columnNumber: 24
                                        }, void 0),
                                        name: "free",
                                        valuePropName: "checked",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$switch$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
                                            onChange: (v)=>handleFieldChange("free", v)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2536,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2531,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2530,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    span: 8,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700 flex items-center gap-2",
                                            children: "نشط"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2542,
                                            columnNumber: 24
                                        }, void 0),
                                        name: "active",
                                        valuePropName: "checked",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$switch$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
                                            onChange: (v)=>handleFieldChange("active", v)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2546,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2541,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2540,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    span: 8,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700 flex items-center gap-2",
                                            children: "شهادة"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2552,
                                            columnNumber: 24
                                        }, void 0),
                                        name: "certificate",
                                        valuePropName: "checked",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$switch$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Switch$3e$__["Switch"], {
                                            onChange: (v)=>handleFieldChange("certificate", v)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2556,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2551,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2550,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                            lineNumber: 2529,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                            gutter: 24,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                span: 24,
                                "data-field": "goal",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                    label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-semibold text-gray-700 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__["FileTextOutlined"], {
                                                className: "text-green-600"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2566,
                                                columnNumber: 21
                                            }, void 0),
                                            getFieldLabelWithOptional("goal")
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2565,
                                        columnNumber: 19
                                    }, void 0),
                                    className: "min-h-44",
                                    name: "goal",
                                    validateStatus: hasError("goal") ? "error" : "",
                                    help: hasError("goal") ? "أدخل الهدف" : null,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `bg-white  rounded-xl ${hasError("goal") ? "border border-red-400" : ""}`,
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(ReactQuill, {
                                            theme: "snow",
                                            modules: quillModules,
                                            formats: quillFormats,
                                            placeholder: "اكتب الهدف من الدورة بالتفصيل (مثلاً: ماذا يتعلم الطالب، النتائج المتوقعة، الجمهور المستهدف)...",
                                            className: "!min-h-44",
                                            value: form.getFieldValue("goal"),
                                            onChange: (value)=>{
                                                form.setFieldsValue({
                                                    goal: value
                                                });
                                                handleFieldChange("goal", value);
                                                validateQuillField(value, "goal");
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2579,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2575,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2563,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                lineNumber: 2562,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                            lineNumber: 2561,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                    label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-semibold text-gray-700 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__["FileTextOutlined"], {
                                                className: "text-cyan-600"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2604,
                                                columnNumber: 19
                                            }, void 0),
                                            "كتاب الدورة (اختياري)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2603,
                                        columnNumber: 17
                                    }, void 0),
                                    name: "courseBook",
                                    valuePropName: "fileList",
                                    getValueFromEvent: normFile,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Dragger, {
                                        multiple: false,
                                        accept: ".pdf,.doc,.docx,.txt",
                                        beforeUpload: customBeforeUpload,
                                        fileList: courseBookFileList,
                                        onChange: handleCourseBookChange,
                                        onRemove: (file)=>{
                                            return true;
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "ant-upload-drag-icon",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$InboxOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__InboxOutlined$3e$__["InboxOutlined"], {}, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2624,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2623,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "ant-upload-text",
                                                children: isEditMode && rowData?.round_book_url ? "تغيير كتاب الدورة" : "اسحب ملف كتاب الدورة هنا أو اضغط للاختيار (اختياري)"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2626,
                                                columnNumber: 17
                                            }, this),
                                            courseBookFileList.length === 0 && rowData?.round_book_url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-gray-500 mt-2",
                                                children: [
                                                    "الملف الحالي: ",
                                                    rowData?.round_book_name || "round-book.pdf"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2630,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2613,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2601,
                                    columnNumber: 13
                                }, this),
                                courseBookFileList.length === 0 && rowData?.round_book_url && !oldFilesToDelete.round_book && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: rowData.round_book_url,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "text-blue-600 hover:text-blue-800",
                                            children: "عرض الملف الحالي"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2638,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                            type: "text",
                                            danger: true,
                                            size: "small",
                                            onClick: ()=>{
                                                setCourseBookFileList([]);
                                                setOldFilesToDelete((prev)=>({
                                                        ...prev,
                                                        round_book: true
                                                    }));
                                            },
                                            children: "حذف الملف"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2646,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2637,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                            lineNumber: 2600,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                    label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "font-semibold text-gray-700 flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__["FileTextOutlined"], {
                                                className: "text-purple-600"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2666,
                                                columnNumber: 19
                                            }, void 0),
                                            "جدول الدورة (اختياري)"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2665,
                                        columnNumber: 17
                                    }, void 0),
                                    name: "extraPdf",
                                    valuePropName: "fileList",
                                    getValueFromEvent: normFile,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Dragger, {
                                        multiple: false,
                                        accept: ".pdf,.doc,.docx,.txt",
                                        beforeUpload: customBeforeUpload,
                                        fileList: extraPdfFileList,
                                        onChange: handleExtraPdfChange,
                                        onRemove: (file)=>{
                                            return true;
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "ant-upload-drag-icon",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$InboxOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__InboxOutlined$3e$__["InboxOutlined"], {}, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                    lineNumber: 2685,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2684,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "ant-upload-text",
                                                children: isEditMode && rowData?.round_road_map_book_url ? "تغيير جدول الدورة" : "اسحب ملف PDF هنا أو اضغط للاختيار (اختياري)"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2687,
                                                columnNumber: 17
                                            }, this),
                                            extraPdfFileList.length === 0 && rowData?.round_road_map_book_url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-sm text-gray-500 mt-2",
                                                children: [
                                                    "الملف الحالي: ",
                                                    rowData?.round_road_map_book_name || "road-map-book.pdf"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                                lineNumber: 2691,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                        lineNumber: 2674,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2663,
                                    columnNumber: 13
                                }, this),
                                extraPdfFileList?.length === 0 && rowData?.round_road_map_book_url && !oldFilesToDelete?.round_road_map_book && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: rowData.round_road_map_book_url,
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "text-blue-600 hover:text-blue-800",
                                            children: "عرض الملف الحالي"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2699,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                            type: "text",
                                            danger: true,
                                            size: "small",
                                            onClick: ()=>{
                                                setExtraPdfFileList([]);
                                                setOldFilesToDelete((prev)=>({
                                                        ...prev,
                                                        round_road_map_book: true
                                                    }));
                                            },
                                            children: "حذف الملف"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                            lineNumber: 2707,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                    lineNumber: 2698,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                            lineNumber: 2662,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                    lineNumber: 2393,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-8 flex justify-between space-x-4 space-x-reverse",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-8 flex justify-between !ms-auto space-x-4 space-x-reverse",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                size: "large",
                                onClick: goToPrevStep,
                                disabled: currentStep === 1,
                                className: `rounded-lg border border-gray-300 bg-white px-6 py-2 text-gray-700 transition duration-150 hover:bg-gray-50 ${currentStep === 1 ? "cursor-not-allowed opacity-50" : ""}`,
                                children: "السابق"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                lineNumber: 2725,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                type: "primary",
                                htmlType: "submit",
                                size: "large",
                                loading: add_round_loading || edit_round_loading || isSubmitting,
                                className: "rounded-lg bg-blue-600 px-6 py-2 text-white shadow-md hover:bg-blue-700",
                                children: add_round_loading || edit_round_loading || isSubmitting ? "جاري الحفظ..." : isEditMode ? "حفظ التعديلات" : "التالي"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                                lineNumber: 2735,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                        lineNumber: 2724,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
                    lineNumber: 2723,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
            lineNumber: 2168,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx",
        lineNumber: 2167,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
;
;
const PagesHeader = ({ title, subtitle, extra })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center justify-between mb-6",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "text-4xl font-bold text-[#202938] mb-2",
                        children: title ?? "Subjects Management"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx",
                        lineNumber: 7,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-[#202938]/60 text-lg",
                        children: subtitle ?? "Organize and manage your teaching subjects"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx",
                        lineNumber: 10,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx",
                lineNumber: 6,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            extra
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx",
        lineNumber: 5,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = PagesHeader;
}),
"[project]/Desktop/nartaqi/components/atoms/Button.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const Button = ({ children, type = "default", size = "default", className = "", onClick, disabled = false, loading = false, icon, ...props })=>{
    const baseClasses = "inline-flex items-center justify-center font-medium rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";
    const sizeClasses = {
        small: "px-3 py-1.5 text-sm",
        default: "px-4 py-2 text-sm",
        large: "px-6 py-3 text-base"
    };
    const typeClasses = {
        primary: "bg-[#0F7490] hover:bg-[#0F7490]/90 text-white focus:ring-[#0F7490]/50 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5",
        secondary: "bg-[#C9AE6C] hover:bg-[#C9AE6C]/90 text-white focus:ring-[#C9AE6C]/50",
        accent: "bg-[#8B5CF6] hover:bg-[#8B5CF6]/90 text-white focus:ring-[#8B5CF6]/50",
        default: "bg-white hover:bg-gray-50 text-[#202938] border border-gray-200 focus:ring-gray-200",
        text: "bg-transparent hover:bg-gray-100 text-[#202938] focus:ring-gray-200",
        danger: "bg-red-500 hover:bg-red-600 text-white focus:ring-red-200"
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: `${baseClasses} ${sizeClasses[size]} ${typeClasses[type]} ${className}`,
        onClick: onClick,
        disabled: disabled,
        ...props,
        children: [
            icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: children && "ml-2",
                children: icon
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/atoms/Button.jsx",
                lineNumber: 39,
                columnNumber: 16
            }, ("TURBOPACK compile-time value", void 0)),
            children
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/atoms/Button.jsx",
        lineNumber: 33,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Button;
}),
"[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AddFeatureModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/form/index.js [app-ssr] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input/index.js [app-ssr] (ecmascript) <export default as Input>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/upload/index.js [app-ssr] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/UploadOutlined.js [app-ssr] (ecmascript) <export default as UploadOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/featuresSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
function AddFeatureModal({ open, setOpen, id }) {
    console.log(open);
    // Use Antd Form instance for form submission and validation
    const [form] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].useForm();
    const [featureData, setFeatureData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        title: "",
        description: "",
        image: null
    });
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const { add_feature_loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.features);
    // --- Utility Functions ---
    const handleClose = ()=>{
        setOpen(false);
        form.resetFields(); // Clear form fields on close
        setFeatureData({
            title: "",
            description: "",
            image: null
        });
    };
    const handleImageChange = (info)=>{
        // Only proceed if a file is present and not an array
        const file = info.fileList?.[0]?.originFileObj || null;
        if (file) {
            setFeatureData((prev)=>({
                    ...prev,
                    image: file
                }));
        } else {
            setFeatureData((prev)=>({
                    ...prev,
                    image: null
                }));
        }
        // Prevents Antd from auto-uploading
        return false;
    };
    // --- Submission Handler ---
    async function handleSubmit() {
        try {
            // Validate all form fields first
            const values = await form.validateFields();
            const formData = new FormData();
            formData.append("round_id", id);
            formData.append("title", featureData.title);
            formData.append("description", featureData.description);
            // Conditionally append image only if it exists
            if (featureData.image) {
                formData.append("image", featureData.image);
            }
            // Show loading state and dispatch action
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleAddRoundFeatures"])({
                body: formData
            })).unwrap().then((res)=>{
                if (res?.data?.status === "success") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(res?.data?.message || "تم إضافة الميزة بنجاح");
                    // Refetch all features after successful addition
                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundFeatures"])({
                        body: {
                            round_id: id
                        }
                    }));
                    handleClose(); // Close and reset modal on success
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.data?.message || res?.data || "هناك خطأ أثناء إضافة الميزة");
                }
            }).catch((e)=>{
                console.error("Feature submission error:", e);
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.");
            });
        } catch (errorInfo) {
            // This catches validation errors (e.g., required fields not filled)
            console.log('Validation Failed:', errorInfo);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("يرجى ملء جميع الحقول المطلوبة بشكل صحيح.");
        }
    }
    // --- Component Render ---
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        open: open,
        title: "إضافة مميزات الدورة",
        onCancel: handleClose,
        confirmLoading: add_feature_loading,
        okText: "إضافة",
        okButtonProps: {
            className: "bg-blue-500"
        },
        cancelText: "إلغاء",
        // Use the footer to handle submission via Antd's Form methods
        onOk: handleSubmit,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
            form: form,
            layout: "vertical",
            onValuesChange: (changedValues, allValues)=>{
                // Update local state when form values change
                setFeatureData((prev)=>({
                        ...prev,
                        ...changedValues
                    }));
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "title",
                    label: "عنوان الميزة",
                    rules: [
                        {
                            required: true,
                            message: 'الرجاء إدخال عنوان الميزة!'
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                        placeholder: "مثال: شهادة معتمدة"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx",
                        lineNumber: 124,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx",
                    lineNumber: 119,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "description",
                    label: "وصف الميزة",
                    rules: [
                        {
                            required: true,
                            message: 'الرجاء إدخال وصف الميزة!'
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"].TextArea, {
                        rows: 4,
                        placeholder: "مثال: يحصل المتدرب على شهادة معتمدة من الجهة الفلانية بعد إتمام الدورة."
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx",
                        lineNumber: 133,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx",
                    lineNumber: 128,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "image",
                    label: "صورة الميزة ",
                    rules: [
                        {
                            required: true
                        }
                    ],
                    // No 'required' rule, but a custom validation to ensure file type if one is uploaded
                    valuePropName: "fileList",
                    getValueFromEvent: (e)=>{
                        if (Array.isArray(e)) {
                            return e;
                        }
                        return e && e.fileList;
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"], {
                        name: "image",
                        listType: "picture",
                        maxCount: 1,
                        beforeUpload: ()=>false,
                        onChange: handleImageChange,
                        accept: ".png,.jpg,.jpeg",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__["UploadOutlined"], {}, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx",
                                lineNumber: 158,
                                columnNumber: 27
                            }, void 0),
                            children: "اختر صورة"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx",
                            lineNumber: 158,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx",
                        lineNumber: 150,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx",
                    lineNumber: 137,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx",
            lineNumber: 107,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx",
        lineNumber: 96,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EditFeatureModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/form/index.js [app-ssr] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input/index.js [app-ssr] (ecmascript) <export default as Input>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/upload/index.js [app-ssr] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/UploadOutlined.js [app-ssr] (ecmascript) <export default as UploadOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/featuresSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
function EditFeatureModal({ open, setOpen, id, rowData, setRowData }) {
    const [form] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].useForm();
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const { edit_feature_loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.features);
    // --- Effect to Populate Form Fields ---
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (open && rowData) {
            // 1. Set fields for title and description directly
            form.setFieldsValue({
                title: rowData.title,
                description: rowData.description
            });
            // 2. Handle Image URL for preview
            if (typeof rowData.image === 'string' && rowData.image.startsWith('http')) {
                form.setFieldsValue({
                    image: [
                        {
                            uid: '-1',
                            name: 'Existing Image',
                            status: 'done',
                            url: rowData.image,
                            isExisting: true
                        }
                    ]
                });
            } else if (rowData.image instanceof File) {
                // If rowData already holds a File (e.g., if selected before modal closed)
                form.setFieldsValue({
                    image: [
                        {
                            uid: '-1',
                            name: rowData.image.name,
                            status: 'done'
                        }
                    ]
                });
            } else {
                form.setFieldsValue({
                    image: []
                });
            }
        }
    }, [
        open,
        rowData,
        form
    ]);
    const handleClose = ()=>{
        setOpen(false);
        form.resetFields();
        setRowData({}); // Reset rowData to an empty object
    };
    // --- FIX: Corrected handleImageChange ---
    const handleImageChange = (info)=>{
        const fileList = info.fileList;
        // Check if a file was selected/kept
        if (fileList.length > 0) {
            const file = fileList[0];
            if (file.originFileObj) {
                // A new file was selected (originFileObj exists)
                setRowData((prev)=>({
                        ...prev,
                        image: file.originFileObj
                    }));
            } else if (file.isExisting || file.url) {
                // The existing file URL is still present
                setRowData((prev)=>({
                        ...prev,
                        image: prev.image
                    }));
            }
        } else {
            // Image was removed or list is empty
            setRowData((prev)=>({
                    ...prev,
                    image: null
                }));
        }
        // CRITICAL: Must return the fileList so the Form.Item can update the visual component
        return info.fileList;
    };
    const handleSubmit = async ()=>{
        try {
            // Validate all fields
            const values = await form.validateFields();
            const formData = new FormData();
            // Feature ID (must be sent for editing)
            if (rowData.feature_id) {
                formData.append("id", rowData.feature_id);
            }
            formData.append("round_id", id);
            // Append current title and description from state
            formData.append("title", rowData.title);
            formData.append("description", rowData.description);
            // Handle image payload
            if (rowData.image instanceof File) {
                // Case 1: New file selected by the user
                formData.append("image", rowData.image);
            } else if (typeof rowData.image === 'string' && rowData.image.startsWith('http')) {
                // Case 2: Existing URL (User didn't change the image, send the URL back)
                formData.append("image", rowData.image);
            } else if (rowData.image === null) {
            // Case 3: Image explicitly removed (Send a signal to delete if needed)
            // Check your API documentation for how to handle image removal. 
            // Example: formData.append("delete_image", "true"); 
            // If your API ignores "image" when null, you can skip this.
            }
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleEditRoundFeatures"])({
                body: formData
            })).unwrap().then((res)=>{
                console.log(res);
                if (res?.data?.status == "success") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(res?.data?.message || "تم تعديل الميزة بنجاح");
                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundFeatures"])({
                        body: {
                            round_id: id
                        }
                    }));
                    handleClose();
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.data?.message || "هناك خطأ أثناء تعديل الميزة");
                }
            }).catch((e)=>{
                console.error("Feature submission error:", e);
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.");
            });
        } catch (errorInfo) {
            console.log('Validation Failed:', errorInfo);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("يرجى ملء جميع الحقول المطلوبة بشكل صحيح.");
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        open: open,
        title: "تعديل مميزات الدورة",
        onCancel: handleClose,
        confirmLoading: edit_feature_loading,
        okText: "تعديل",
        cancelText: "إلغاء",
        onOk: handleSubmit,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
            form: form,
            layout: "vertical",
            // onValuesChange handles title/description state update
            onValuesChange: (changedValues)=>{
                if (changedValues.title !== undefined || changedValues.description !== undefined) {
                    setRowData((prev)=>({
                            ...prev,
                            ...changedValues
                        }));
                }
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "title",
                    label: "عنوان الميزة",
                    rules: [
                        {
                            required: true,
                            message: 'الرجاء إدخال عنوان الميزة!'
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                        placeholder: "مثال: شهادة معتمدة"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx",
                        lineNumber: 166,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx",
                    lineNumber: 161,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "description",
                    label: "وصف الميزة",
                    rules: [
                        {
                            required: true,
                            message: 'الرجاء إدخال وصف الميزة!'
                        }
                    ],
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"].TextArea, {
                        rows: 4,
                        placeholder: "مثال: يحصل المتدرب على شهادة معتمدة من الجهة الفلانية بعد إتمام الدورة."
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx",
                        lineNumber: 175,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx",
                    lineNumber: 170,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                    name: "image",
                    label: "صورة الميزة",
                    valuePropName: "fileList",
                    // CRITICAL: getValueFromEvent must pass the fileList through
                    getValueFromEvent: (e)=>{
                        if (Array.isArray(e)) {
                            return e;
                        }
                        return e && e.fileList;
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"], {
                        name: "image",
                        listType: "picture",
                        maxCount: 1,
                        beforeUpload: ()=>false,
                        onChange: handleImageChange,
                        accept: ".png,.jpg,.jpeg",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__["UploadOutlined"], {}, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx",
                                lineNumber: 199,
                                columnNumber: 27
                            }, void 0),
                            children: "اختر صورة"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx",
                            lineNumber: 199,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx",
                        lineNumber: 191,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx",
                    lineNumber: 179,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx",
            lineNumber: 147,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx",
        lineNumber: 138,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DeleteFeatureModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$typography$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/typography/index.js [app-ssr] (ecmascript) <export default as Typography>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DeleteOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DeleteOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/DeleteOutlined.js [app-ssr] (ecmascript) <export default as DeleteOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$ExclamationCircleOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ExclamationCircleOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/ExclamationCircleOutlined.js [app-ssr] (ecmascript) <export default as ExclamationCircleOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/featuresSlice.jsx [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const { Text } = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$typography$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Typography$3e$__["Typography"];
function DeleteFeatureModal({ open, setOpen, rowData, id }) {
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    // Ensure the state path and variable name are correct (e.g., state?.content?.delete_content_loading)
    const { delete_feature_loading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.features);
    function handleDelete() {
        // Check if rowData is valid before dispatching
        if (!rowData || !rowData.id) {
            console.error("rowData or rowData.id is missing.");
            setOpen(false); // Close modal if data is invalid
            return;
        }
        const data_send = {
            id: rowData?.id
        };
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleDeleteRoundFeatures"])({
            body: data_send
        })).unwrap().then((res)=>{
            if (res?.data?.status == "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم حذف المحتوي بنجاح");
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundFeatures"])({
                    body: {
                        round_id: id
                    }
                }));
            }
            setOpen(false);
        }).catch((err)=>{
            console.error("Failed to delete content:", err);
        });
    }
    // Determine the title of the item being deleted for clarity
    const contentTitle = rowData?.title || 'هذا الميزه';
    // Custom footer for better control over button design and loading state
    const modalFooter = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex justify-start space-x-2 space-x-reverse pt-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                type: "primary",
                danger: true,
                onClick: handleDelete,
                loading: delete_feature_loading,
                className: "rounded-md px-6",
                icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DeleteOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DeleteOutlined$3e$__["DeleteOutlined"], {}, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
                    lineNumber: 57,
                    columnNumber: 15
                }, void 0),
                children: "حذف نهائي"
            }, "submit", false, {
                fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                onClick: ()=>setOpen(false),
                disabled: delete_feature_loading,
                className: "rounded-md px-6",
                children: "إلغاء"
            }, "back", false, {
                fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
                lineNumber: 61,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
        lineNumber: 49,
        columnNumber: 5
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
        open: open,
        onCancel: ()=>setOpen(false),
        footer: modalFooter,
        title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            style: {
                color: '#faad14'
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$ExclamationCircleOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ExclamationCircleOutlined$3e$__["ExclamationCircleOutlined"], {
                    style: {
                        marginLeft: 8
                    }
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
                    lineNumber: 79,
                    columnNumber: 11
                }, void 0),
                " تأكيد الحذف"
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
            lineNumber: 78,
            columnNumber: 9
        }, void 0),
        // Set modal direction to RTL for proper Arabic display
        wrapClassName: "rtl-modal-wrap",
        style: {
            direction: 'rtl'
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-4 mt-4 text-right",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Text, {
                    strong: true,
                    style: {
                        fontSize: '1.1rem'
                    },
                    className: "text-gray-800",
                    children: [
                        "هل أنت متأكد من حذف محتوى الدورة: ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Text, {
                            mark: true,
                            children: contentTitle
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
                            lineNumber: 88,
                            columnNumber: 45
                        }, this),
                        "؟"
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
                    lineNumber: 87,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Text, {
                    type: "danger",
                    style: {
                        fontSize: '0.95rem'
                    },
                    children: "**تحذير:** لا يمكن التراجع عن هذا الإجراء. سيتم فقدان جميع الدروس والفيديوهات المتعلقة بهذا المحتوى."
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
                    lineNumber: 90,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
            lineNumber: 86,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx",
        lineNumber: 73,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Features
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/featuresSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$spin$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Spin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/spin/index.js [app-ssr] (ecmascript) <export default as Spin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tooltip$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/tooltip/index.js [app-ssr] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$PagesHeader$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/ui/PagesHeader.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/atoms/Button.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Features$2f$AddFeatureModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/RoundContent/Features/AddFeatureModal.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/square-pen.js [app-ssr] (ecmascript) <export default as Edit>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/trash.js [app-ssr] (ecmascript) <export default as Trash>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Features$2f$EditFeatureModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/RoundContent/Features/EditFeatureModal.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Features$2f$DeleteFeatureModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/RoundContent/Features/DeleteFeatureModal.jsx [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
function Features({ roundId, currentStep, goToNextStep, goToPrevStep, STEPS }) {
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const { all_features_loading, all_features_list } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.features);
    const [openAddModal, setOpenAddModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [openEditModal, setOpenEditModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [openDeleteModal, setOpenDeleteModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [rowData, setRowData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$featuresSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundFeatures"])({
            body: {
                round_id: roundId
            }
        }));
    }, [
        roundId,
        dispatch
    ]);
    // Handle Loading State
    if (all_features_loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "h-screen flex justify-center items-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$spin$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Spin$3e$__["Spin"], {
                size: "large",
                spinning: true
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                lineNumber: 42,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
            lineNumber: 41,
            columnNumber: 7
        }, this);
    }
    const features = all_features_list?.data?.message || [];
    // Handle Empty State
    // if (features.length === 0) {
    //   return (
    //     <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 py-16 px-4">
    //       <p className="text-gray-500 text-lg mb-4">
    //         لا تتوفر مميزات حالياً لهذه الدورة.
    //       </p>
    //       <Button onClick={() => {
    //         console.log("jello")
    //         setOpenAddModal(true)
    //       }}>إضافة مميزة جديدة</Button>
    //     </div>
    //   );
    // }
    // --- Card Render Logic ---
    const renderFeatureCard = (feature)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white rounded-xl border border-gray-200 shadow-lg overflow-hidden    hover:shadow-2xl hover:scale-[1.05] transition-all duration-300",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative w-full h-[250px]",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: feature.image_url,
                        alt: feature.title,
                        className: "w-full h-full object-cover rounded-t-xl",
                        onError: (e)=>{
                            e.target.src = "https://via.placeholder.com/400x300?text=صورة+غير+متوفرة";
                            e.target.className = "w-full h-full object-contain bg-gray-100 p-8 opacity-80"; // Adjust styling for placeholder
                        }
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                        lineNumber: 73,
                        columnNumber: 5
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                    lineNumber: 72,
                    columnNumber: 3
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "px-6 py-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-xl font-semibold text-gray-900 mb-2 truncate",
                            children: feature.title
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                            lineNumber: 88,
                            columnNumber: 5
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-gray-600 text-sm overflow-hidden mb-4 line-clamp-3",
                            children: feature.description
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                            lineNumber: 92,
                            columnNumber: 5
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                    lineNumber: 87,
                    columnNumber: 3
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-end px-6 py-4 border-t border-gray-100 bg-gray-50",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-4 text-gray-500",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tooltip$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: "Edit",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$square$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Edit$3e$__["Edit"], {
                                    size: 20,
                                    className: "cursor-pointer hover:text-blue-600 transition-colors",
                                    onClick: ()=>{
                                        setRowData({
                                            ...feature,
                                            feature_id: feature.id,
                                            image: feature.image_url
                                        });
                                        setOpenEditModal(true);
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                                    lineNumber: 101,
                                    columnNumber: 9
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                                lineNumber: 100,
                                columnNumber: 7
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tooltip$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                title: "Delete",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash$3e$__["Trash"], {
                                    size: 20,
                                    className: "cursor-pointer hover:text-red-600 transition-colors",
                                    onClick: ()=>{
                                        setRowData({
                                            ...feature,
                                            feature_id: feature.id
                                        });
                                        setOpenDeleteModal(true);
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                                    lineNumber: 116,
                                    columnNumber: 9
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                                lineNumber: 115,
                                columnNumber: 7
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                        lineNumber: 99,
                        columnNumber: 5
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                    lineNumber: 98,
                    columnNumber: 3
                }, this)
            ]
        }, feature.id, true, {
            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
            lineNumber: 66,
            columnNumber: 4
        }, this);
    // --- Main Component Render ---
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gray-50 py-10 px-4 sm:px-6 lg:px-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl mx-auto",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$ui$2f$PagesHeader$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        title: "مميزات الدورة",
                        subtitle: "قم بإدارة وتنظيم مميزات الدورة وإمكانياتها",
                        extra: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            className: "!bg-indigo-600 hover:!bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg shadow-md transition-colors",
                            onClick: ()=>{
                                console.log("setOpenAddModal(true)");
                                setOpenAddModal(true);
                            },
                            children: "إضافة مميزة جديدة"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                            lineNumber: 143,
                            columnNumber: 13
                        }, void 0)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                        lineNumber: 139,
                        columnNumber: 9
                    }, this),
                    features?.length == 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "min-h-screen flex flex-col items-center justify-center bg-gray-50 py-16 px-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-gray-500 text-lg mb-4",
                                children: "لا تتوفر مميزات حالياً لهذه الدورة."
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                                lineNumber: 156,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$atoms$2f$Button$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                className: "!bg-indigo-600 hover:!bg-indigo-700 text-white font-medium py-2 px-4 rounded-lg shadow-md transition-colors",
                                onClick: ()=>{
                                    console.log("jello");
                                    setOpenAddModal(true);
                                },
                                children: "إضافة مميزة جديدة"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                                lineNumber: 159,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                        lineNumber: 155,
                        columnNumber: 38
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8",
                        children: features.map(renderFeatureCard)
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                        lineNumber: 167,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                lineNumber: 137,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Features$2f$AddFeatureModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: roundId,
                open: openAddModal,
                setOpen: setOpenAddModal
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                lineNumber: 174,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Features$2f$EditFeatureModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: roundId,
                open: openEditModal,
                setOpen: setOpenEditModal,
                rowData: rowData,
                setRowData: setRowData
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                lineNumber: 179,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$RoundContent$2f$Features$2f$DeleteFeatureModal$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: roundId,
                open: openDeleteModal,
                setOpen: setOpenDeleteModal,
                rowData: rowData
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                lineNumber: 186,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-8 flex justify-between space-x-4 space-x-reverse",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: goToPrevStep,
                        disabled: currentStep === 1,
                        className: `rounded-lg border border-gray-300 bg-white px-6 py-2 text-gray-700 transition duration-150 hover:bg-gray-50 ${currentStep === 1 ? "cursor-not-allowed opacity-50" : ""}`,
                        children: "السابق"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                        lineNumber: 194,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: goToNextStep,
                        disabled: currentStep === STEPS.length,
                        className: `rounded-lg bg-blue-600 px-6 py-2 text-white shadow-md transition duration-150 hover:bg-blue-700 ${currentStep === STEPS.length ? "cursor-not-allowed opacity-50" : ""}`,
                        children: currentStep === STEPS.length ? "إنهاء ونشر" : "التالي"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                        lineNumber: 203,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
                lineNumber: 193,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx",
        lineNumber: 136,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/components/AddCourseSourceResource.jsx
__turbopack_context__.s([
    "default",
    ()=>AddCourseSourceResource
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/button/index.js [app-ssr] (ecmascript) <locals> <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/col/index.js [app-ssr] (ecmascript) <export default as Col>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/form/index.js [app-ssr] (ecmascript) <export default as Form>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/input/index.js [app-ssr] (ecmascript) <export default as Input>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/modal/index.js [app-ssr] (ecmascript) <export default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/row/index.js [app-ssr] (ecmascript) <export default as Row>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$date$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/date-picker/index.js [app-ssr] (ecmascript) <export default as DatePicker>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/message/index.js [app-ssr] (ecmascript) <export default as message>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/upload/index.js [app-ssr] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$popconfirm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Popconfirm$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/popconfirm/index.js [app-ssr] (ecmascript) <export default as Popconfirm>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tooltip$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/tooltip/index.js [app-ssr] (ecmascript) <export default as Tooltip>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FolderOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FolderOutlined.js [app-ssr] (ecmascript) <export default as FolderOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$LinkOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LinkOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/LinkOutlined.js [app-ssr] (ecmascript) <export default as LinkOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$CopyOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CopyOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/CopyOutlined.js [app-ssr] (ecmascript) <export default as CopyOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DeleteOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DeleteOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/DeleteOutlined.js [app-ssr] (ecmascript) <export default as DeleteOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/UploadOutlined.js [app-ssr] (ecmascript) <export default as UploadOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FileTextOutlined.js [app-ssr] (ecmascript) <export default as FileTextOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$CalendarOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/CalendarOutlined.js [app-ssr] (ecmascript) <export default as CalendarOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$EditOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EditOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/EditOutlined.js [app-ssr] (ecmascript) <export default as EditOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$EyeOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/EyeOutlined.js [app-ssr] (ecmascript) <export default as EyeOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DownloadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DownloadOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/DownloadOutlined.js [app-ssr] (ecmascript) <export default as DownloadOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$PaperClipOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PaperClipOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/PaperClipOutlined.js [app-ssr] (ecmascript) <export default as PaperClipOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FilePdfOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FilePdfOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FilePdfOutlined.js [app-ssr] (ecmascript) <export default as FilePdfOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileWordOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileWordOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FileWordOutlined.js [app-ssr] (ecmascript) <export default as FileWordOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileExcelOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileExcelOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FileExcelOutlined.js [app-ssr] (ecmascript) <export default as FileExcelOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileImageOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileImageOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FileImageOutlined.js [app-ssr] (ecmascript) <export default as FileImageOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileZipOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileZipOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FileZipOutlined.js [app-ssr] (ecmascript) <export default as FileZipOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileUnknownOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileUnknownOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/FileUnknownOutlined.js [app-ssr] (ecmascript) <export default as FileUnknownOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$resourcesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/resourcesSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/dayjs/dayjs.min.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-toastify/dist/index.mjs [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
;
;
function AddCourseSourceResource({ videos, setVideos, duplicateTargets = [], onDuplicateResources, goToNextStep, goToPrevStep, currentStep, id, STEPS, source }) {
    const [form] = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].useForm(); // Add form instance
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const { add_resource_loading, edit_resource_loading, delete_resource_loading, all_resources_loading, all_resources_list } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSelector"])((state)=>state?.resource);
    // Duplicate Modal States
    const [dupOpen, setDupOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [dupLoading, setDupLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [dupError, setDupError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [targetsSearch, setTargetsSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [selectedTargets, setSelectedTargets] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    // File Modal States
    const [addFileModal, setAddFileModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [editFileModal, setEditFileModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedResource, setSelectedResource] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [newFileData, setNewFileData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({
        name: "",
        description: "",
        file: null,
        show_date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])()
    });
    // Initial form values from existing data
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (all_resources_list?.data?.message) {
            const resources = all_resources_list.data.message;
            form.setFieldsValue({
                resources: {
                    telegram: resources?.group_links?.telegram_link || "",
                    whatsapp: resources?.group_links?.whatsapp_link || ""
                }
            });
        }
    }, [
        all_resources_list,
        form
    ]);
    // Load existing resources
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$resourcesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundResources"])({
            body: {
                round_id: id
            }
        }));
    }, [
        dispatch,
        id
    ]);
    const filteredTargets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const term = (targetsSearch || "").toLowerCase();
        if (!term) return duplicateTargets;
        return duplicateTargets.filter((t)=>(t.title || "").toLowerCase().includes(term));
    }, [
        duplicateTargets,
        targetsSearch
    ]);
    const toggleTarget = (id)=>{
        setSelectedTargets((prev)=>prev.includes(id) ? prev.filter((x)=>x !== id) : [
                ...prev,
                id
            ]);
    };
    const toggleAllTargets = ()=>{
        if (selectedTargets.length === filteredTargets.length) {
            setSelectedTargets([]);
        } else {
            setSelectedTargets(filteredTargets.map((t)=>t.id));
        }
    };
    const openDuplicateModal = ()=>{
        setDupError("");
        setTargetsSearch("");
        setSelectedTargets([]);
        setDupOpen(true);
    };
    const confirmDuplicate = async ()=>{
        if (selectedTargets.length === 0) {
            setDupError("برجاء اختيار دورة/دورات الهدف أولاً.");
            return;
        }
        try {
            setDupLoading(true);
            const telegram = form?.getFieldValue?.([
                "resources",
                "telegram"
            ]) ?? "";
            const whatsapp = form?.getFieldValue?.([
                "resources",
                "whatsapp"
            ]) ?? "";
            const files = (videos || []).map((v)=>({
                    id: v.id,
                    name: v.name || "",
                    description: v.description || "",
                    source: "upload",
                    file: v.file,
                    show_date: v.show_date
                }));
            if (onDuplicateResources) {
                await onDuplicateResources({
                    links: {
                        telegram,
                        whatsapp
                    },
                    files
                }, selectedTargets);
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].success("تم نسخ المصادر بنجاح!");
            setDupOpen(false);
        } catch (e) {
            setDupError(e?.message || "تعذّر النسخ، جرّب مرة أخرى.");
        } finally{
            setDupLoading(false);
        }
    };
    // Get file icon based on type
    const getFileIcon = (filename)=>{
        const ext = filename?.split('.').pop()?.toLowerCase();
        switch(ext){
            case 'pdf':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FilePdfOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FilePdfOutlined$3e$__["FilePdfOutlined"], {
                    className: "text-red-600 text-xl"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 173,
                    columnNumber: 16
                }, this);
            case 'doc':
            case 'docx':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileWordOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileWordOutlined$3e$__["FileWordOutlined"], {
                    className: "text-blue-600 text-xl"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 176,
                    columnNumber: 16
                }, this);
            case 'xls':
            case 'xlsx':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileExcelOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileExcelOutlined$3e$__["FileExcelOutlined"], {
                    className: "text-green-600 text-xl"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 179,
                    columnNumber: 16
                }, this);
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileImageOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileImageOutlined$3e$__["FileImageOutlined"], {
                    className: "text-purple-600 text-xl"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 184,
                    columnNumber: 16
                }, this);
            case 'zip':
            case 'rar':
            case '7z':
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileZipOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileZipOutlined$3e$__["FileZipOutlined"], {
                    className: "text-yellow-600 text-xl"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 188,
                    columnNumber: 16
                }, this);
            default:
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileUnknownOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileUnknownOutlined$3e$__["FileUnknownOutlined"], {
                    className: "text-gray-600 text-xl"
                }, void 0, false, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 190,
                    columnNumber: 16
                }, this);
        }
    };
    // Format file size
    const formatFileSize = (bytes)=>{
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = [
            'Bytes',
            'KB',
            'MB',
            'GB'
        ];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    };
    // Save Telegram & WhatsApp links
    const saveResourceLinks = async ()=>{
        try {
            await form.validateFields([
                [
                    'resources',
                    'telegram'
                ],
                [
                    'resources',
                    'whatsapp'
                ]
            ]);
            const values = form.getFieldsValue();
            const telegram_link = values?.resources?.telegram || "";
            const whatsapp_link = values?.resources?.whatsapp || "";
            // Create a function to update links in your Redux slice
            // For now, we'll send them with each file operation
            return {
                telegram_link,
                whatsapp_link
            };
        } catch (error) {
            console.error("Validation error:", error);
            return {
                telegram_link: "",
                whatsapp_link: ""
            };
        }
    };
    // Add File Functions
    const openAddFileModal = async ()=>{
        const links = await saveResourceLinks();
        setNewFileData({
            name: "",
            description: "",
            file: null,
            show_date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(),
            ...links // Store links in newFileData
        });
        setAddFileModal(true);
    };
    const confirmAddFile = async ()=>{
        if (!newFileData.name.trim()) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("عنوان الملف مطلوب");
            return;
        }
        if (!newFileData.file) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("يرجى رفع ملف");
            return;
        }
        try {
            // Get current form values for links
            const values = form.getFieldsValue();
            const telegram = values?.resources?.telegram || "";
            const whatsapp = values?.resources?.whatsapp || "";
            const formData = new FormData();
            formData.append("telegram_link", telegram);
            formData.append("whatsapp_link", whatsapp);
            formData.append("round_id", id);
            formData.append("title", newFileData.name.trim());
            formData.append("description", newFileData.description.trim());
            formData.append("file", newFileData.file);
            formData.append("show_date", newFileData.show_date.format("YYYY-MM-DD"));
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$resourcesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleAddRoundResource"])({
                body: formData
            })).unwrap().then((res)=>{
                if (res?.data?.status === "success") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم إضافة الملف بنجاح");
                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$resourcesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundResources"])({
                        body: {
                            round_id: id || 1
                        }
                    }));
                    setAddFileModal(false);
                    setNewFileData({
                        name: "",
                        description: "",
                        file: null,
                        show_date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])()
                    });
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.data?.message || "فشل في إضافة الملف");
                }
            }).catch((error)=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء إضافة الملف");
            });
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء التحقق من البيانات");
        }
    };
    // Edit File Functions
    const openEditFileModal = (resource)=>{
        setSelectedResource(resource);
        setNewFileData({
            name: resource.title || "",
            description: resource.description || "",
            file: null,
            show_date: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(resource.show_date || resource.created_at)
        });
        setEditFileModal(true);
    };
    const confirmEditFile = async ()=>{
        if (!newFileData.name.trim()) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("عنوان الملف مطلوب");
            return;
        }
        try {
            // Get current form values for links
            const values = form.getFieldsValue();
            const telegram = values?.resources?.telegram || "";
            const whatsapp = values?.resources?.whatsapp || "";
            const formData = new FormData();
            formData.append("id", selectedResource.id);
            formData.append("telegram_link", telegram);
            formData.append("whatsapp_link", whatsapp);
            formData.append("round_id", id);
            formData.append("title", newFileData.name.trim());
            formData.append("description", newFileData.description.trim());
            formData.append("show_date", newFileData.show_date.format("YYYY-MM-DD"));
            // Only append file if a new one was selected
            if (newFileData.file) {
                formData.append("file", newFileData.file);
            }
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$resourcesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleEditRoundResource"])({
                body: formData
            })).unwrap().then((res)=>{
                if (res?.data?.status === "success") {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم تعديل الملف بنجاح");
                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$resourcesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundResources"])({
                        body: {
                            round_id: id || 1
                        }
                    }));
                    setEditFileModal(false);
                    setSelectedResource(null);
                } else {
                    __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.data?.message || "فشل في تعديل الملف");
                }
            }).catch((error)=>{
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء تعديل الملف");
            });
        } catch (error) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء التحقق من البيانات");
        }
    };
    // Delete File Functions
    const handleDeleteFile = (resourceId)=>{
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$resourcesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleDeleteRoundResource"])({
            body: {
                id: resourceId
            }
        })).unwrap().then((res)=>{
            if (res?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم حذف الملف بنجاح");
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$resourcesSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRoundResources"])({
                    body: {
                        round_id: id || 1
                    }
                }));
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error(res?.data?.message || "فشل في حذف الملف");
            }
        }).catch((error)=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("حدث خطأ أثناء حذف الملف");
        });
    };
    // View File Details
    const viewFileDetails = (resource)=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"].info({
            title: resource.title,
            width: 600,
            content: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4",
                        children: [
                            getFileIcon(resource.url || resource.title),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        className: "font-bold text-lg",
                                        children: resource.title
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 369,
                                        columnNumber: 15
                                    }, this),
                                    resource.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-600",
                                        children: resource.description
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 371,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                lineNumber: 368,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                        lineNumber: 366,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-gray-50 p-3 rounded-lg",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm text-gray-500",
                                        children: "تاريخ الإضافة"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 378,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "font-medium",
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(resource.created_at).format("YYYY/MM/DD HH:mm")
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 379,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                lineNumber: 377,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-gray-50 p-3 rounded-lg",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-sm text-gray-500",
                                        children: "تاريخ العرض"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 385,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "font-medium",
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(resource.show_date || resource.created_at).format("YYYY/MM/DD")
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 386,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                lineNumber: 384,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                        lineNumber: 376,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-blue-50 p-3 rounded-lg",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "text-sm text-blue-500",
                                children: "رابط الملف"
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                lineNumber: 393,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: resource.url,
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "text-blue-600 hover:text-blue-800 break-all",
                                children: resource.url
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                lineNumber: 394,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                        lineNumber: 392,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                lineNumber: 365,
                columnNumber: 9
            }, this),
            okText: "تم"
        });
    };
    // Save & Continue
    const handleSaveAndContinue = async ()=>{
        try {
            await form.validateFields();
            const values = form.getFieldsValue();
            const telegram_link = values?.resources?.telegram || "";
            const whatsapp_link = values?.resources?.whatsapp || "";
            // Save links to the backend
            // You need to create a Redux action for this
            const saveLinksResult = await dispatch(handleUpdateResourceLinks({
                body: {
                    round_id: id || 1,
                    telegram_link,
                    whatsapp_link
                }
            })).unwrap();
            if (saveLinksResult?.data?.status === "success") {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success("تم حفظ الروابط بنجاح");
                localStorage.removeItem("courseBasicInfo");
            } else {
                __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$toastify$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].error("فشل في حفظ الروابط");
            }
        } catch (err) {
            console.error("Error saving resources:", err);
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("حدث خطأ أثناء حفظ المصادر");
        } finally{
            if (currentStep == STEPS.length) {
                if (!source) {
                    router.push(`/round_content?id=${id}&source=${1}`);
                } else {
                    router.push(`/round_content?id=${id}`);
                }
            } else {
                goToNextStep();
            }
        }
    };
    // You need to add this function to your resourcesSlice
    const handleUpdateResourceLinks = async ({ body })=>{
    // API call to update Telegram and WhatsApp links for the round
    // Example endpoint: PUT /api/rounds/{id}/resource-links
    // const response = await api.post(apiRoutes.update_resource_links, { body });
    // return response;
    };
    const resources = all_resources_list?.data?.message?.resource || [];
    const resourceLinks = all_resources_list?.data?.message || {};
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        console.log(resourceLinks?.group_links);
    }, [
        resourceLinks
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-8",
        dir: "rtl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"], {
                form: form,
                layout: "vertical",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-gradient-to-r from-purple-50 to-indigo-50 rounded-2xl p-6 border border-purple-200",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center justify-between gap-3 flex-wrap",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-xl font-bold text-gray-800 mb-4 sm:mb-0 flex items-center gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FolderOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderOutlined$3e$__["FolderOutlined"], {
                                            className: "text-purple-600"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 478,
                                            columnNumber: 15
                                        }, this),
                                        "المصادر والملفات"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 477,
                                    columnNumber: 13
                                }, this),
                                duplicateTargets.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                    type: "primary",
                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$CopyOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CopyOutlined$3e$__["CopyOutlined"], {}, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 484,
                                        columnNumber: 23
                                    }, void 0),
                                    className: "bg-emerald-600 hover:bg-emerald-700",
                                    onClick: openDuplicateModal,
                                    children: "نسخ إلى دورات أخرى"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 482,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 476,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$row$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Row$3e$__["Row"], {
                            gutter: 24,
                            className: "mt-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    span: 12,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700 flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$LinkOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LinkOutlined$3e$__["LinkOutlined"], {
                                                    className: "text-blue-500"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                    lineNumber: 499,
                                                    columnNumber: 21
                                                }, void 0),
                                                "رابط مجموعة التليجرام"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 498,
                                            columnNumber: 19
                                        }, void 0),
                                        name: [
                                            "resources",
                                            "telegram"
                                        ],
                                        initialValue: resourceLinks?.group_links?.telegram_link || "",
                                        rules: [
                                            {
                                                type: 'url',
                                                message: 'يرجى إدخال رابط صحيح'
                                            }
                                        ],
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                                            placeholder: "https://t.me/groupname",
                                            className: "rounded-xl",
                                            prefix: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$LinkOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LinkOutlined$3e$__["LinkOutlined"], {
                                                className: "text-gray-400"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                lineNumber: 515,
                                                columnNumber: 27
                                            }, void 0)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 512,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 496,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 495,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$col$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Col$3e$__["Col"], {
                                    span: 12,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$form$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Form$3e$__["Form"].Item, {
                                        label: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "font-semibold text-gray-700 flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$LinkOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LinkOutlined$3e$__["LinkOutlined"], {
                                                    className: "text-green-500"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                    lineNumber: 523,
                                                    columnNumber: 21
                                                }, void 0),
                                                "رابط مجموعة الواتساب"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 522,
                                            columnNumber: 19
                                        }, void 0),
                                        name: [
                                            "resources",
                                            "whatsapp"
                                        ],
                                        initialValue: resourceLinks?.group_links?.whatsapp_link || "",
                                        rules: [
                                            {
                                                type: 'url',
                                                message: 'يرجى إدخال رابط صحيح'
                                            }
                                        ],
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                                            placeholder: "https://chat.whatsapp.com/...",
                                            className: "rounded-xl",
                                            prefix: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$LinkOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LinkOutlined$3e$__["LinkOutlined"], {
                                                className: "text-gray-400"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                lineNumber: 539,
                                                columnNumber: 27
                                            }, void 0)
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 536,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 520,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 519,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 494,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between mb-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                            className: "text-lg font-semibold text-gray-800 flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FolderOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderOutlined$3e$__["FolderOutlined"], {
                                                    className: "text-blue-600"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                    lineNumber: 549,
                                                    columnNumber: 17
                                                }, this),
                                                "ملفات إضافية (",
                                                resources.length,
                                                ")"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 548,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                            type: "primary",
                                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__["UploadOutlined"], {}, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                lineNumber: 554,
                                                columnNumber: 23
                                            }, void 0),
                                            onClick: openAddFileModal,
                                            className: "bg-blue-600 hover:bg-blue-700",
                                            children: "إضافة ملف جديد"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 552,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 547,
                                    columnNumber: 13
                                }, this),
                                all_resources_loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center py-12",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 564,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-gray-500 mt-4",
                                            children: "جاري تحميل الملفات..."
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 565,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 563,
                                    columnNumber: 15
                                }, this) : resources.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center py-12 text-gray-500 border-2 border-dashed border-gray-300 rounded-xl bg-white",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__["FileTextOutlined"], {
                                            className: "text-4xl text-gray-300 mb-4"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 569,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-lg",
                                            children: "لا توجد ملفات مضافة بعد"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 570,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-gray-400 mt-2",
                                            children: "قم بإضافة أول ملف للموارد"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 571,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 568,
                                    columnNumber: 15
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "space-y-4",
                                    children: resources.map((resource, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "bg-white rounded-xl border border-gray-200 p-5 shadow-sm hover:shadow-md transition group",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-start justify-between gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex-1 min-w-0",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-3 mb-2",
                                                                children: [
                                                                    getFileIcon(resource.url || resource.title),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "min-w-0",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                                className: "font-bold text-gray-900 truncate",
                                                                                children: resource.title
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                                lineNumber: 585,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            resource.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                                className: "text-gray-600 text-sm leading-relaxed mt-1 line-clamp-2",
                                                                                children: resource.description
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                                lineNumber: 589,
                                                                                columnNumber: 31
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                        lineNumber: 584,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                lineNumber: 582,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex flex-wrap gap-4 text-sm text-gray-500 mt-3",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tooltip$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                                                        title: "عرض الملف",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                            href: resource.url,
                                                                            target: "_blank",
                                                                            rel: "noopener noreferrer",
                                                                            className: "flex items-center gap-1 hover:text-blue-600",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$EyeOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeOutlined$3e$__["EyeOutlined"], {}, void 0, false, {
                                                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                                    lineNumber: 604,
                                                                                    columnNumber: 31
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: "truncate max-w-xs",
                                                                                    children: resource.url
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                                    lineNumber: 605,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                            lineNumber: 598,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                        lineNumber: 597,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "flex items-center gap-1",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$CalendarOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CalendarOutlined$3e$__["CalendarOutlined"], {}, void 0, false, {
                                                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                                lineNumber: 610,
                                                                                columnNumber: 29
                                                                            }, this),
                                                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$dayjs$2f$dayjs$2e$min$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(resource.show_date || resource.created_at).format("YYYY/MM/DD")
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                        lineNumber: 609,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    resource.file_size && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "flex items-center gap-1",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$PaperClipOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PaperClipOutlined$3e$__["PaperClipOutlined"], {}, void 0, false, {
                                                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                                lineNumber: 616,
                                                                                columnNumber: 31
                                                                            }, this),
                                                                            formatFileSize(resource.file_size)
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                        lineNumber: 615,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                lineNumber: 596,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                        lineNumber: 581,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tooltip$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                                                title: "تحميل الملف",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                    href: resource.url,
                                                                    download: true,
                                                                    target: "_blank",
                                                                    rel: "noopener noreferrer",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                        type: "text",
                                                                        size: "small",
                                                                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DownloadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DownloadOutlined$3e$__["DownloadOutlined"], {}, void 0, false, {
                                                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                            lineNumber: 644,
                                                                            columnNumber: 37
                                                                        }, void 0),
                                                                        className: "text-green-500 hover:text-green-700"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                        lineNumber: 641,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                    lineNumber: 635,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                lineNumber: 634,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tooltip$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                                                title: "تعديل",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                    type: "text",
                                                                    size: "small",
                                                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$EditOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EditOutlined$3e$__["EditOutlined"], {}, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                        lineNumber: 654,
                                                                        columnNumber: 35
                                                                    }, void 0),
                                                                    onClick: ()=>openEditFileModal(resource),
                                                                    className: "text-yellow-500 hover:text-yellow-700",
                                                                    disabled: edit_resource_loading
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                    lineNumber: 651,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                lineNumber: 650,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$popconfirm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Popconfirm$3e$__["Popconfirm"], {
                                                                title: "حذف الملف",
                                                                description: "هل أنت متأكد من حذف هذا الملف؟",
                                                                onConfirm: ()=>handleDeleteFile(resource.id),
                                                                okText: "نعم",
                                                                cancelText: "لا",
                                                                okButtonProps: {
                                                                    danger: true
                                                                },
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$tooltip$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Tooltip$3e$__["Tooltip"], {
                                                                    title: "حذف",
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                        type: "text",
                                                                        size: "small",
                                                                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DeleteOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DeleteOutlined$3e$__["DeleteOutlined"], {}, void 0, false, {
                                                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                            lineNumber: 673,
                                                                            columnNumber: 37
                                                                        }, void 0),
                                                                        className: "text-red-500 hover:text-red-700",
                                                                        disabled: delete_resource_loading
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                        lineNumber: 670,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                    lineNumber: 669,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                                lineNumber: 661,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                        lineNumber: 623,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                lineNumber: 580,
                                                columnNumber: 21
                                            }, this)
                                        }, resource.id || idx, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 576,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 574,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 546,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 475,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                lineNumber: 474,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: goToPrevStep,
                        disabled: currentStep === 1,
                        className: `px-8 py-3 rounded-lg border text-gray-700 bg-white hover:bg-gray-50 transition ${currentStep === 1 ? "opacity-50 cursor-not-allowed" : ""}`,
                        children: "السابق"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                        lineNumber: 691,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleSaveAndContinue,
                        disabled: add_resource_loading || all_resources_loading,
                        className: "px-8 py-3 rounded-lg bg-blue-600 text-white font-medium shadow-md hover:bg-blue-700 disabled:opacity-60 transition",
                        children: currentStep === STEPS.length ? "إنهاء ونشر" : "التالي"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                        lineNumber: 699,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                lineNumber: 690,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3 text-xl font-bold",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__["UploadOutlined"], {
                            className: "text-blue-600"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 712,
                            columnNumber: 13
                        }, void 0),
                        "إضافة ملف جديد"
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 711,
                    columnNumber: 11
                }, void 0),
                open: addFileModal,
                onCancel: ()=>setAddFileModal(false),
                onOk: confirmAddFile,
                okText: add_resource_loading ? "جاري الإضافة..." : "إضافة الملف",
                cancelText: "إلغاء",
                width: 640,
                okButtonProps: {
                    size: "large",
                    loading: add_resource_loading,
                    disabled: add_resource_loading || !newFileData.name.trim() || !newFileData.file
                },
                cancelButtonProps: {
                    size: "large",
                    disabled: add_resource_loading
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-6 py-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-semibold text-gray-700 mb-2",
                                    children: [
                                        "عنوان الملف ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-red-500",
                                            children: "*"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 732,
                                            columnNumber: 27
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 731,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                                    size: "large",
                                    placeholder: "مثال: ملزمة الرياضيات - الوحدة الثانية",
                                    value: newFileData.name,
                                    onChange: (e)=>setNewFileData({
                                            ...newFileData,
                                            name: e.target.value
                                        }),
                                    disabled: add_resource_loading
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 734,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 730,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-semibold text-gray-700 mb-2",
                                    children: "الوصف"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 744,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"].TextArea, {
                                    rows: 3,
                                    required: true,
                                    placeholder: "وصف مختصر عن محتوى الملف...",
                                    value: newFileData.description,
                                    onChange: (e)=>setNewFileData({
                                            ...newFileData,
                                            description: e.target.value
                                        }),
                                    disabled: add_resource_loading
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 747,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 743,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-semibold text-gray-700 mb-2",
                                    children: [
                                        "رفع الملف ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-red-500",
                                            children: "*"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 759,
                                            columnNumber: 25
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 758,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"], {
                                    beforeUpload: (file)=>{
                                        setNewFileData({
                                            ...newFileData,
                                            file
                                        });
                                        return false; // Prevent auto upload
                                    },
                                    showUploadList: false,
                                    disabled: add_resource_loading,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__["UploadOutlined"], {}, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 770,
                                            columnNumber: 23
                                        }, void 0),
                                        size: "large",
                                        block: true,
                                        className: "h-16 border-dashed",
                                        children: "اختر ملف"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 769,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 761,
                                    columnNumber: 13
                                }, this),
                                newFileData.file && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-3 p-3 bg-green-50 border border-green-200 rounded-lg text-green-700 flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__["FileTextOutlined"], {}, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                    lineNumber: 781,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "truncate max-w-xs",
                                                    children: newFileData.file.name
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                    lineNumber: 782,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 780,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                            type: "text",
                                            size: "small",
                                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DeleteOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DeleteOutlined$3e$__["DeleteOutlined"], {}, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                lineNumber: 787,
                                                columnNumber: 25
                                            }, void 0),
                                            onClick: ()=>setNewFileData({
                                                    ...newFileData,
                                                    file: null
                                                }),
                                            disabled: add_resource_loading
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 784,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 779,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-500 mt-2",
                                    children: "يمكنك رفع أي نوع من الملفات (PDF، Word، Excel، صور، إلخ)"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 793,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 757,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-semibold text-gray-700 mb-2",
                                    children: "تاريخ العرض"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 799,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$date$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__["DatePicker"], {
                                    className: "w-full",
                                    size: "large",
                                    value: newFileData.show_date,
                                    onChange: (date)=>setNewFileData({
                                            ...newFileData,
                                            show_date: date
                                        }),
                                    format: "YYYY-MM-DD",
                                    disabled: add_resource_loading
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 802,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-500 mt-2",
                                    children: "سيظهر الملف للطلاب بدءًا من هذا التاريخ"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 810,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 798,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 729,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                lineNumber: 709,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3 text-xl font-bold",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$EditOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EditOutlined$3e$__["EditOutlined"], {
                            className: "text-yellow-600"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 821,
                            columnNumber: 13
                        }, void 0),
                        "تعديل الملف"
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 820,
                    columnNumber: 11
                }, void 0),
                open: editFileModal,
                onCancel: ()=>setEditFileModal(false),
                onOk: confirmEditFile,
                okText: edit_resource_loading ? "جاري التعديل..." : "حفظ التعديلات",
                cancelText: "إلغاء",
                width: 640,
                okButtonProps: {
                    size: "large",
                    loading: edit_resource_loading,
                    disabled: edit_resource_loading || !newFileData.name.trim()
                },
                cancelButtonProps: {
                    size: "large",
                    disabled: edit_resource_loading
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-6 py-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-semibold text-gray-700 mb-2",
                                    children: [
                                        "عنوان الملف ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-red-500",
                                            children: "*"
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 841,
                                            columnNumber: 27
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 840,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"], {
                                    size: "large",
                                    placeholder: "عنوان الملف",
                                    value: newFileData.name,
                                    onChange: (e)=>setNewFileData({
                                            ...newFileData,
                                            name: e.target.value
                                        }),
                                    disabled: edit_resource_loading
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 843,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 839,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-semibold text-gray-700 mb-2",
                                    children: "الوصف (اختياري)"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 853,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"].TextArea, {
                                    rows: 3,
                                    placeholder: "وصف الملف",
                                    value: newFileData.description,
                                    onChange: (e)=>setNewFileData({
                                            ...newFileData,
                                            description: e.target.value
                                        }),
                                    disabled: edit_resource_loading
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 856,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 852,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-semibold text-gray-700 mb-2",
                                    children: "تغيير الملف (اختياري)"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 866,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"], {
                                    beforeUpload: (file)=>{
                                        setNewFileData({
                                            ...newFileData,
                                            file
                                        });
                                        return false; // Prevent auto upload
                                    },
                                    showUploadList: false,
                                    disabled: edit_resource_loading,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$UploadOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UploadOutlined$3e$__["UploadOutlined"], {}, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 878,
                                            columnNumber: 23
                                        }, void 0),
                                        size: "large",
                                        block: true,
                                        className: "h-16 border-dashed",
                                        children: "اختر ملف جديد"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 877,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 869,
                                    columnNumber: 13
                                }, this),
                                newFileData.file ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-3 p-3 bg-green-50 border border-green-200 rounded-lg text-green-700 flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__["FileTextOutlined"], {}, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                    lineNumber: 889,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "truncate max-w-xs",
                                                    children: newFileData.file.name
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                    lineNumber: 890,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 888,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$button$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__$3c$export__default__as__Button$3e$__["Button"], {
                                            type: "text",
                                            size: "small",
                                            icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$DeleteOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DeleteOutlined$3e$__["DeleteOutlined"], {}, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                lineNumber: 895,
                                                columnNumber: 25
                                            }, void 0),
                                            onClick: ()=>setNewFileData({
                                                    ...newFileData,
                                                    file: null
                                                }),
                                            disabled: edit_resource_loading
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                            lineNumber: 892,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 887,
                                    columnNumber: 15
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-3 p-3 bg-gray-50 border border-gray-200 rounded-lg text-gray-600",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$FileTextOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FileTextOutlined$3e$__["FileTextOutlined"], {}, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                lineNumber: 903,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "سيتم الاحتفاظ بالملف الحالي"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                lineNumber: 904,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 902,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 901,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-500 mt-2",
                                    children: "اتركه فارغاً للحفاظ على الملف الحالي"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 908,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 865,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block text-sm font-semibold text-gray-700 mb-2",
                                    children: "تاريخ العرض"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 914,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$date$2d$picker$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DatePicker$3e$__["DatePicker"], {
                                    className: "w-full",
                                    size: "large",
                                    value: newFileData.show_date,
                                    onChange: (date)=>setNewFileData({
                                            ...newFileData,
                                            show_date: date
                                        }),
                                    format: "YYYY-MM-DD",
                                    disabled: edit_resource_loading
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 917,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 913,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 838,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                lineNumber: 818,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$modal$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Modal$3e$__["Modal"], {
                open: dupOpen,
                onCancel: ()=>setDupOpen(false),
                onOk: confirmDuplicate,
                okText: dupLoading ? "جارٍ النسخ..." : "نسخ",
                cancelText: "إلغاء",
                confirmLoading: dupLoading,
                width: 600,
                title: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$CopyOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CopyOutlined$3e$__["CopyOutlined"], {
                            className: "text-emerald-600"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 940,
                            columnNumber: 13
                        }, void 0),
                        "نسخ الموارد إلى دورات أخرى"
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 939,
                    columnNumber: 11
                }, void 0),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$input$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Input$3e$__["Input"].Search, {
                            placeholder: "ابحث عن دورة...",
                            allowClear: true,
                            onChange: (e)=>setTargetsSearch(e.target.value),
                            disabled: dupLoading
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 946,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: "px-3 py-1 border rounded hover:bg-gray-50",
                                    onClick: toggleAllTargets,
                                    disabled: dupLoading,
                                    children: selectedTargets.length === filteredTargets.length ? "إلغاء تحديد الكل" : "تحديد الكل"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 953,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-500",
                                    children: [
                                        "المختار: ",
                                        selectedTargets.length,
                                        " من ",
                                        filteredTargets.length
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 963,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 952,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-h-64 overflow-auto space-y-2",
                            children: filteredTargets.map((t)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: `flex items-center justify-between p-3 border rounded-lg cursor-pointer transition ${selectedTargets.includes(t.id) ? "border-emerald-500 bg-emerald-50" : "border-gray-200 hover:bg-gray-50"} ${dupLoading ? "opacity-60 cursor-not-allowed" : ""}`,
                                    onClick: ()=>!dupLoading && toggleTarget(t.id),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "checkbox",
                                                checked: selectedTargets.includes(t.id),
                                                onChange: ()=>{},
                                                onClick: (e)=>e.stopPropagation(),
                                                disabled: dupLoading
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                lineNumber: 979,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "font-medium",
                                                        children: t.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                        lineNumber: 987,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-xs text-gray-500",
                                                        children: [
                                                            "ID: ",
                                                            t.id
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                        lineNumber: 988,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                                lineNumber: 986,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                        lineNumber: 978,
                                        columnNumber: 17
                                    }, this)
                                }, t.id, false, {
                                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                                    lineNumber: 970,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 968,
                            columnNumber: 11
                        }, this),
                        dupError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-red-600 text-sm bg-red-50 p-2 rounded",
                            children: dupError
                        }, void 0, false, {
                            fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                            lineNumber: 995,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                    lineNumber: 945,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
                lineNumber: 930,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx",
        lineNumber: 473,
        columnNumber: 5
    }, this);
}
}),
"[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// "use client";
// import React, { useEffect, useState } from "react";
// import {
//   PlusOutlined,
//   BookOutlined,
//   FileTextOutlined,
//   DeleteOutlined,
//   PlayCircleOutlined,
//   CalendarOutlined,
//   FolderOutlined,
//   SettingOutlined,
// } from "@ant-design/icons";
// import {
//   Form,
//   Button,
//   message,
//   Upload,
//   Divider,
// } from "antd";
// import dayjs from "dayjs";
// import "react-quill-new/dist/quill.snow.css";
// import dynamic from "next/dynamic";
// import AddCourseSourceContent from "../../../../components/SaudiCourseSource/AddCourseSourceContent";
// import AddCourseSourceBasicInfo from "../../../../components/SaudiCourseSource/AddCourseSourceBasicInfo";
// import AddCourseSourceShedule from "../../../../components/SaudiCourseSource/AddCourseSourceShedule";
// import AddCourseSourceResource from "../../../../components/SaudiCourseSource/AddCourseSourceResource";
// import { useDispatch, useSelector } from "react-redux";
// const ReactQuill = dynamic(() => import("react-quill-new"), { ssr: false });
// // Mock data for categories with sections
// export const all_categories = [
//   {
//     id: 1,
//     title: "دورات عامة",
//     sections: [
//       { id: 1, name: "تطوير الويب", isVisible: true },
//       { id: 2, name: "تطوير التطبيقات", isVisible: true },
//       { id: 3, name: "الذكاء الاصطناعي", isVisible: true },
//     ],
//   },
//   {
//     id: 2,
//     title: "الرخصة المهنية",
//     sections: [
//       { id: 4, name: "تصميم UI/UX", isVisible: true },
//       { id: 5, name: "الجرافيك ديزاين", isVisible: true },
//       { id: 6, name: "الرسم الرقمي", isVisible: false },
//     ],
//   },
//   {
//     id: 3,
//     title: "دورات اخري",
//     sections: [
//       { id: 7, name: "الرياضيات المتقدمة", isVisible: true },
//       { id: 8, name: "الفيزياء", isVisible: true },
//       { id: 9, name: "الكيمياء", isVisible: true },
//     ],
//   },
// ];
// const quillModules = {
//   toolbar: [
//     [{ header: [1, 2, 3, false] }],
//     ["bold", "italic", "underline", "strike"],
//     [{ list: "ordered" }, { list: "bullet" }],
//     [{ align: ["", "center", "right", "justify"] }],
//     [{ direction: "rtl" }],
//     [{ color: [] }, { background: [] }],
//     ["link", "blockquote", "code-block"],
//     ["clean"],
//   ],
// };
// const quillFormats = [
//   "header", "bold", "italic", "underline", "strike", "list",
//   "align", "direction", "color", "background", "link", "blockquote", "code-block",
// ];
// const RichTextField = ({ value, onChange, placeholder }) => (
//   <div dir="rtl" className="rich-text-field">
//     <ReactQuill
//       className="ql-rtl"
//       theme="snow"
//       value={value}
//       onChange={(html) => onChange?.(html)}
//       modules={quillModules}
//       formats={quillFormats}
//       placeholder={placeholder}
//       style={{ minHeight: "120px" }}
//     />
//   </div>
// );
// // Helper: convert file -> base64
// const getBase64 = (file) =>
//   new Promise((resolve, reject) => {
//     const reader = new FileReader();
//     reader.readAsDataURL(file);
//     reader.onload = () => resolve(reader.result);
//     reader.onerror = reject;
//   });
// const EnhancedCourseForm = ({ open, setOpen }) => {
//   const [form] = Form.useForm();
//   const [loading, setLoading] = useState(false);
//   const [activeTab, setActiveTab] = useState(1);
//   const [fileList, setFileList] = useState([]);
//   const [fileNames, setFileNames] = useState({}); // uid -> custom name
//   const [videos, setVideos] = useState([{ id: 1, name: "", url: "" }]);
//   const [imagePreview, setImagePreview] = useState(null);
//   const [selectedCategory, setSelectedCategory] = useState(null);
//   const [availableSections, setAvailableSections] = useState([]);
//   const [schedules, setSchedules] = useState([]);
//   const [newSchedule, setNewSchedule] = useState({
//     day: "",
//     date:"",
//     startTime: null,
//     endTime: null,
//     maxStudents: 30,
//     isActive: true,
//   });
//   const dispatch = useDispatch();
//   const {add_round_loading} = useSelector(state => state?.rounds)
//   // Update sections when category changes
//   useEffect(() => {
//     if (selectedCategory) {
//       const category = all_categories.find(cat => cat.id === selectedCategory);
//       if (category) {
//         setAvailableSections(category.sections.filter(section => section.isVisible));
//       }
//     } else {
//       setAvailableSections([]);
//     }
//   }, [selectedCategory]);
//   const beforeUpload = async (file) => {
//     const isImage = file.type?.startsWith("image/");
//     if (!isImage) {
//       message.error("من فضلك ارفع ملف صورة فقط.");
//       return Upload.LIST_IGNORE;
//     }
//     const isLt5M = file.size / 1024 / 1024 < 5;
//     if (!isLt5M) {
//       message.error("حجم الصورة يجب أن يكون أقل من 5MB.");
//       return Upload.LIST_IGNORE;
//     }
//     const preview = await getBase64(file);
//     setImagePreview(preview);
//     setFileList([
//       {
//         uid: file.uid || file.name,
//         name: file.name,
//         status: "done",
//         originFileObj: file,
//       },
//     ]);
//     return false;
//   };
//   const onFilesChange = ({ fileList }) => {
//     setFileList(fileList);
//     setFileNames((prev) => {
//       const next = { ...prev };
//       fileList.forEach((f) => {
//         if (f.uid && !next[f.uid]) next[f.uid] = f.name?.replace(/\.[^.]+$/, "") || "";
//       });
//       // remove stale uids
//       Object.keys(next).forEach((uid) => {
//         if (!fileList.find((f) => f.uid === uid)) delete next[uid];
//       });
//       return next;
//     });
//   };
//   const handleAddSchedule = () => {
//     if (newSchedule.date && newSchedule.startTime && newSchedule.endTime) {
//       const schedule = {
//         ...newSchedule,
//         startTime: newSchedule.startTime.format("HH:mm"),
//         endTime: newSchedule.endTime.format("HH:mm"),
//       };
//       setSchedules([...schedules, schedule]);
//       setNewSchedule({
//         day: "",
//         startTime: null,
//         endTime: null,
//         maxStudents: 30,
//         isActive: true,
//       });
//       message.success("تم إضافة الجدولة بنجاح!");
//     } else {
//       message.error("يجب إدخال جميع البيانات المطلوبة.");
//     }
//   };
//   const handleUpdateSchedule = (index, updatedSchedule) => {
//     const newSchedules = [...schedules];
//     newSchedules[index] = {
//       ...updatedSchedule,
//       startTime: updatedSchedule.startTime?.format ?
//         updatedSchedule.startTime.format("HH:mm") : updatedSchedule.startTime,
//       endTime: updatedSchedule.endTime?.format ?
//         updatedSchedule.endTime.format("HH:mm") : updatedSchedule.endTime,
//     };
//     setSchedules(newSchedules);
//     message.success("تم تحديث الجدولة بنجاح!");
//   };
//   const handleRemoveSchedule = (index) => {
//     const newSchedules = [...schedules];
//     newSchedules.splice(index, 1);
//     setSchedules(newSchedules);
//     message.success("تم حذف الجدولة بنجاح!");
//   };
//   const handleFinish = async () => {
//     setLoading(true);
//     try {
//       const raw = form.getFieldsValue(true);
//       const payload = {
//         code: raw.code?.toUpperCase(),
//         imageUrl: imagePreview,
//         name: raw.name?.trim(),
//         category: raw.category,
//         section: raw.section,
//         price: Number(raw.price ?? 0),
//         duration: raw.duration?.trim(),
//         description: raw.description?.trim(),
//         status: raw.status,
//         genderPolicy: raw.genderPolicy,
//         capacity: Number(raw.capacity ?? 0),
//         instructor: raw.instructor,
//         availableFrom: raw.availableRange?.[0] ?
//           dayjs(raw.availableRange[0]).format("YYYY-MM-DD") : undefined,
//         availableTo: raw.availableRange?.[1] ?
//           dayjs(raw.availableRange[1]).format("YYYY-MM-DD") : undefined,
//         summary: raw.summary || "",
//         schedules: schedules,
//         resources: {
//           files: (raw.resources?.files || []).map((f) => ({
//             // preserve original file object where possible
//             uid: f.uid,
//             name: fileNames[f.uid] ?? f.name,
//             originName: f.name,
//             type: f.type,
//           })),
//           telegram: raw.resources?.telegram || "",
//           whatsapp: raw.resources?.whatsapp || "",
//           videos: videos.filter((v) => v.url?.trim()).map((v) => ({ name: v.name?.trim() || "", url: v.url.trim() })),
//         },
//       };
//       await new Promise((r) => setTimeout(r, 1500));
//       console.log("Enhanced Form Data:", payload);
//       message.success("تمت إضافة الدورة بنجاح!");
//       handleReset();
//       setOpen(false);
//     } catch (e) {
//       message.error("فشل إضافة الدورة. حاول مرة أخرى.");
//     } finally {
//       setLoading(false);
//     }
//   };
//   const handleReset = () => {
//     form.resetFields();
//     setFileList([]);
//     setImagePreview(null);
//     setSelectedCategory(null);
//     setAvailableSections([]);
//     setSchedules([]);
//     setNewSchedule({
//       day: "",
//       startTime: null,
//       endTime: null,
//       maxStudents: 30,
//       isActive: true,
//     });
//   };
//   const tabItems = [
//     { key: 1, label: "المعلومات الأساسية", icon: <BookOutlined /> },
//     // { key: 2, label: "الجدولة والمواعيد", icon: <CalendarOutlined /> },
//     // { key: 3, label: "المحتوى التفصيلي", icon: <FileTextOutlined /> },
//     // { key: 4, label: "المصادر والملفات", icon: <FolderOutlined /> },
//   ];
//   return (
//     <div className="bg-gradient-to-br from-gray-50 to-blue-50/30 min-h-[80vh]" dir="rtl">
//           {/* Enhanced Header */}
//           <div className="relative mb-8 p-6 bg-white rounded-2xl shadow-sm border-b-4 border-b-blue-500">
//             <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-400/10 to-purple-400/10 rounded-full -translate-y-16 translate-x-16"></div>
//             <div className="relative flex items-center gap-4 mb-3">
//               <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center shadow-lg">
//                 <PlusOutlined className="text-white text-xl" />
//               </div>
//               <div>
//                 <h1 className="text-3xl font-bold bg-gradient-to-r from-gray-800 to-blue-800 bg-clip-text text-transparent">
//                   إضافة دورة جديدة
//                 </h1>
//                 <p className="text-gray-600 mt-1">إنشاء وتكوين دورة تعليمية شاملة مع الجدولة والمحتوى</p>
//               </div>
//             </div>
//             {/* Progress Indicator */}
//             <div className="flex items-center gap-2 mt-4">
//               {tabItems.map((tab, index) => (
//                 <div
//                   key={tab.key}
//                   className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-all cursor-pointer
//                     ${activeTab === tab.key
//                       ? 'bg-blue-100 text-blue-700 border border-blue-200'
//                       : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
//                     }`}
//                   onClick={() => setActiveTab(tab.key)}
//                 >
//                   {tab.icon}
//                   <span className="hidden sm:inline">{tab.label}</span>
//                 </div>
//               ))}
//             </div>
//           </div>
//           <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
//             <div
//               // form={form}
//               // layout="vertical"
//               // onFinish={handleFinish}
//               initialValues={{
//                 code: "COURSE_" + Math.random().toString(36).substr(2, 6).toUpperCase(),
//                 name: "",
//                 category: null,
//                 section: null,
//                 price: 499,
//                 duration: "3 شهور",
//                 description: "",
//                 status: "نشط",
//                 genderPolicy: "both",
//                 capacity: 50,
//                 instructor: [],
//                 availableRange: [dayjs().add(1, 'week'), dayjs().add(3, 'month')],
//                 summary: "",
//               }}
//               className="p-8"
//             >
//               {/* Basic Information Tab */}
//               {activeTab === 1 && (
//                 <AddCourseSourceBasicInfo
//                 all_categories={all_categories}
//                 availableSections={availableSections}
//                 beforeUpload={beforeUpload}
//                 fileList={fileList}
//                 selectedCategory={selectedCategory}
//                 setFileList={setFileList}
//                 setImagePreview={setImagePreview}
//                 setSelectedCategory={setSelectedCategory}
//                 />
//               )}
//               {/* Schedule Tab */}
//               {activeTab === 2 && (
//                 <AddCourseSourceShedule
//                 handleAddSchedule={handleAddSchedule}
//                 handleRemoveSchedule={handleRemoveSchedule}
//                 handleUpdateSchedule={handleUpdateSchedule}
//                 newSchedule={newSchedule}
//                 schedules={schedules}
//                 setNewSchedule={setNewSchedule}
//                 />
//               )}
//               {/* Content Tab */}
//               {activeTab === 3 && (
//                 <div className="space-y-8">
//                   <div className="rounded-2xl p-6">
//                     <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-3">
//                       <FileTextOutlined className="text-green-600" />
//                       المحتوى التفصيلي للدورة
//                     </h3>
//                     <Form.Item
//                       label={<span className="font-semibold text-gray-700">ملخص الدورة</span>}
//                       name="summary"
//                     >
//                       <RichTextField
//                         placeholder="اكتب ملخصاً شاملاً للدورة يتضمن الأهداف التعليمية والمخرجات المتوقعة..."
//                       />
//                     </Form.Item>
//                     <Form.Item
//                       label={<span className="font-semibold text-gray-700">الشروط والأحكام</span>}
//                       name="privacy"
//                     >
//                       <RichTextField
//                         placeholder="اكتب ملخصاً شاملاً للدورة يتضمن الأهداف التعليمية والمخرجات المتوقعة..."
//                       />
//                     </Form.Item>
//                       <Form.Item
//                       label={<span className="font-semibold text-gray-700">مميزات الدورة</span>}
//                       name="benefits"
//                     >
//                       <RichTextField
//                         placeholder={"اكتب مميزات الدورة ...."}
//                       />
//                     </Form.Item>
//                     <Divider />
//                     <div>
//                       <h4 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
//                         <PlayCircleOutlined className="text-blue-600" />
//                         المحتوى التعليمي
//                       </h4>
//                       <p className="text-gray-600 mb-4">
//                         يمكنك إضافة المحتوى التعليمي التفصيلي (الدروس، الفيديوهات، الاختبارات) بعد إنشاء الدورة
//                       </p>
//                       <AddCourseSourceContent
//                         courseId={null}
//                         onContentAdded={(content) => console.log('Content added:', content)}
//                       />
//                     </div>
//                   </div>
//                 </div>
//               )}
//               {/* Resources Tab */}
//               {activeTab === 4 && (
//                 <AddCourseSourceResource
//                 setVideos={setVideos}
//                 videos={videos}
//                 />
//               )}
//               {/* Navigation and Actions */}
//               <div className="flex items-center justify-between pt-8 border-t border-gray-200">
//                 <div className="flex items-center gap-3">
//                   {activeTab > 1 && (
//                     <Button
//                       size="large"
//                       onClick={() => setActiveTab(activeTab - 1)}
//                       className="rounded-xl"
//                       icon={<span>←</span>}
//                     >
//                       السابق
//                     </Button>
//                   )}
//                 </div>
//                 {/* <div className="flex items-center gap-3">
//                   {activeTab < 4 ? (
//                     <Button
//                       type="primary"
//                       size="large"
//                       onClick={() => setActiveTab(activeTab + 1)}
//                       className="rounded-xl"
//                       icon={<span>→</span>}
//                     >
//                       التالي
//                     </Button>
//                   ) : (
//                     <Button
//                       type="primary"
//                       size="large"
//                       htmltype="submit"
//                       loading={loading}
//                       className="rounded-xl bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
//                       icon={<PlusOutlined />}
//                     >
//                       إنشاء الدورة
//                     </Button>
//                   )}
//                 </div> */}
//               </div>
//             </div>
//           </div>
//         </div>
//   );
// };
// export default EnhancedCourseForm;
// "use client";
// import { useParams, useSearchParams } from "next/navigation";
// import React, { useEffect, useState } from "react";
// import { PlusOutlined } from "@ant-design/icons";
// import { Check } from "lucide-react";
// import AddCourseSourceBasicInfo from "../../../../../components/SaudiCourseSource/AddCourseSourceBasicInfo";
// import Features from "../../../../../components/SaudiCourseSource/Features";
// import AddCourseSourceResource from "../../../../../components/SaudiCourseSource/AddCourseSourceResource";
// import { handleGetSourceRound } from "../../../../../lib/features/roundsSlice";
// import { useDispatch } from "react-redux";
// // Define the steps data
// const STEPS = [
//   {
//     id: 1,
//     title: "بيانات الدورة",
//     description: "إضافة أقسام، دروس، ومواد تعليمية.",
//   },
//   {
//     id: 2,
//     title: "مميزات الدورة",
//     description: "إضافة أقسام، دروس، ومواد تعليمية.",
//   },
//   {
//     id: 3,
//     title: "المصادر والملفات",
//     description: "رفع الملفات والروابط المساندة ومراجعة الدورة.",
//   },
// ];
// export default function Page() {
//   const {id} = useParams();
//   const params = useSearchParams();
//   const [currentStep, setCurrentStep] = useState(1);
//   const [roundId, setRoundId] = useState(null);
//   const [fileList, setFileList] = useState([]);
//   const [fileNames, setFileNames] = useState({});
//   const [videos, setVideos] = useState([{ id: 1, name: "", url: "" }]);
//   const [imagePreview, setImagePreview] = useState(null);
//   const [selectedCategory, setSelectedCategory] = useState(null);
//   const [rowData , setRowData] = useState({});
//   const dispatch = useDispatch();
//     useEffect(() => {
//        dispatch(handleGetSourceRound())
//        .unwrap()
//        .then(res => {
//          if(res?.data?.status == "success") {
//           setRowData(res?.data?.message?.data?.find(item => item?.id == id));
//          }
//        })
//      } , [id])
//   // --- Navigation Logic ---
//   const goToNextStep = () => {
//     setCurrentStep((prev) => Math.min(prev + 1, STEPS.length));
//   };
//   const goToPrevStep = () => {
//     setCurrentStep((prev) => Math.max(prev - 1, 1));
//   };
//   // -------------------------
//   const getStepStatus = (stepId) => {
//     if (stepId < currentStep) return "complete";
//     if (stepId === currentStep) return "current";
//     return "upcoming";
//   };
//   const beforeUpload = async (file) => {
//     const isImage = file.type?.startsWith("image/");
//     if (!isImage) {
//       message.error("من فضلك ارفع ملف صورة فقط.");
//       return Upload.LIST_IGNORE;
//     }
//     const isLt5M = file.size / 1024 / 1024 < 5;
//     if (!isLt5M) {
//       message.error("حجم الصورة يجب أن يكون أقل من 5MB.");
//       return Upload.LIST_IGNORE;
//     }
//     const preview = await getBase64(file);
//     setImagePreview(preview);
//     setFileList([
//       {
//         uid: file.uid || file.name,
//         name: file.name,
//         status: "done",
//         originFileObj: file,
//       },
//     ]);
//     return false;
//   };
//   const onFilesChange = ({ fileList }) => {
//     setFileList(fileList);
//     setFileNames((prev) => {
//       const next = { ...prev };
//       fileList.forEach((f) => {
//         if (f.uid && !next[f.uid])
//           next[f.uid] = f.name?.replace(/\.[^.]+$/, "") || "";
//       });
//       // remove stale uids
//       Object.keys(next).forEach((uid) => {
//         if (!fileList.find((f) => f.uid === uid)) delete next[uid];
//       });
//       return next;
//     });
//   };
//   const getStatusClasses = (status) => {
//     switch (status) {
//       case "complete":
//         return {
//           dot: "bg-blue-600 text-white border-blue-600",
//           text: "text-blue-800 font-semibold",
//           line: "bg-blue-600",
//         };
//       case "current":
//         return {
//           dot: "bg-white text-blue-600 border-2 border-blue-600 shadow-md",
//           text: "text-gray-900 font-bold",
//           line: "bg-gray-300",
//         };
//       case "upcoming":
//       default:
//         return {
//           dot: "bg-gray-200 text-gray-500 border-gray-300",
//           text: "text-gray-500",
//           line: "bg-gray-300",
//         };
//     }
//   };
//   // ------- Step content -------
//   const renderStepContent = () => {
//     if (currentStep === 1) {
//       // مرحلة التأسيس
//       return (
//         <AddCourseSourceBasicInfo
//           id={id}
//           beforeUpload={beforeUpload}
//           fileList={fileList}
//           selectedCategory={selectedCategory}
//           setSelectedCategory={setSelectedCategory}
//           setFileList={setFileList}
//           setImagePreview={setImagePreview}
//           currentStep={currentStep}
//           goToNextStep={goToNextStep}
//           goToPrevStep={goToPrevStep}
//           setRoundId={setRoundId}
//           rowData={rowData}
//           setRowData={setRowData}
//         />
//       );
//     }
//     if (currentStep === 2) {
//       // المحاضرات
//       return (
//         <Features
//           roundId={roundId}
//           currentStep={currentStep}
//           goToNextStep={goToNextStep}
//           goToPrevStep={goToPrevStep}
//           STEPS={STEPS}
//         />
//         //  <CourseSourceLecturesContent id={id}/>
//       );
//     }
//     // المصادر والملفات
//     return (
//       <AddCourseSourceResource
//         currentStep={currentStep}
//         goToPrevStep={goToPrevStep}
//         id={roundId}
//         STEPS={STEPS}
//       />
//     );
//   };
//   // ---------------------------
//   return (
//     <div
//       className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50/30 p-4 sm:p-8"
//       dir="rtl"
//     >
//       {/* Header */}
//       <div className="relative mx-auto mb-8 max-w-6xl rounded-2xl border-b-4 border-blue-500 bg-white p-6 shadow-xl">
//         <div className="absolute top-0 right-0 h-32 w-32 -translate-y-16 translate-x-16 rounded-full bg-gradient-to-br from-blue-400/10 to-purple-400/10 opacity-50" />
//         <div className="relative mb-3 flex items-center gap-4">
//           <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 shadow-2xl">
//             <PlusOutlined className="text-xl text-white" />
//           </div>
//           <div>
//             <h1 className="bg-gradient-to-r from-gray-800 to-blue-800 bg-clip-text text-3xl font-extrabold text-transparent">
//               إضافة دورة جديدة
//             </h1>
//             <p className="mt-1 text-gray-600">
//               إنشاء وتكوين دورة تعليمية شاملة مع الجدولة والمحتوى.
//             </p>
//           </div>
//         </div>
//       </div>
//       {/* Main */}
//       <div className="mx-auto max-w-6xl">
//         {/* Stepper */}
//         <div className="mb-10 flex items-start justify-between rounded-xl border border-gray-100 bg-white p-6 shadow-lg">
//           {STEPS.map((step, index) => {
//             const status = getStepStatus(step.id);
//             const { dot, text, line } = getStatusClasses(status);
//             const isLast = index === STEPS.length - 1;
//             return (
//               <React.Fragment key={step.id}>
//                 <div className="flex w-1/4 min-w-0 flex-shrink-0 flex-col items-center">
//                   <div
//                     className={`relative flex h-10 w-10 items-center justify-center rounded-full transition duration-300 ${dot}`}
//                   >
//                     {status === "complete" ? (
//                       <Check className="h-4 w-4" />
//                     ) : (
//                       <span className="text-lg">{step.id}</span>
//                     )}
//                   </div>
//                   <div className="mt-3 min-w-0 text-center">
//                     <h3
//                       className={`overflow-hidden text-ellipsis whitespace-nowrap text-sm md:text-base leading-tight transition duration-300 ${text}`}
//                     >
//                       {step.title}
//                     </h3>
//                     <p className="mt-0.5 hidden text-xs text-gray-500 md:block">
//                       {status === "current"
//                         ? "الخطوة الحالية"
//                         : step.description.split(",")[0]}
//                     </p>
//                   </div>
//                 </div>
//                 {!isLast && (
//                   <div className="mx-2 flex flex-grow items-center">
//                     <div
//                       className={`h-0.5 w-full transition duration-300 ${
//                         status === "complete" ? "bg-blue-600" : line
//                       }`}
//                     />
//                   </div>
//                 )}
//               </React.Fragment>
//             );
//           })}
//         </div>
//         {/* Content */}
//         <div className="mt-8 rounded-xl border border-gray-100 bg-white p-8 shadow-lg">
//           <h2 className="mb-4 border-b pb-2 text-2xl font-bold text-gray-800">
//             الخطوة {currentStep}: {STEPS[currentStep - 1].title}
//           </h2>
//           {renderStepContent()}
//           {/* Navigation buttons */}
//           {/* <div className="mt-8 flex justify-between space-x-4 space-x-reverse">
//             <button
//               onClick={goToPrevStep}
//               disabled={currentStep === 1}
//               className={`rounded-lg border border-gray-300 bg-white px-6 py-2 text-gray-700 transition duration-150 hover:bg-gray-50 ${
//                 currentStep === 1 ? "cursor-not-allowed opacity-50" : ""
//               }`}
//             >
//               السابق
//             </button>
//             <button
//               onClick={goToNextStep}
//               disabled={currentStep === STEPS.length}
//               className={`rounded-lg bg-blue-600 px-6 py-2 text-white shadow-md transition duration-150 hover:bg-blue-700 ${
//                 currentStep === STEPS.length ? "cursor-not-allowed opacity-50" : ""
//               }`}
//             >
//               {currentStep === STEPS.length ? "إنهاء ونشر" : "التالي"}
//             </button>
//           </div> */}
//         </div>
//       </div>
//     </div>
//   );
// }
__turbopack_context__.s([
    "default",
    ()=>Page
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$PlusOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusOutlined$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ant-design/icons/es/icons/PlusOutlined.js [app-ssr] (ecmascript) <export default as PlusOutlined>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lucide-react/dist/esm/icons/check.js [app-ssr] (ecmascript) <export default as Check>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/upload/index.js [app-ssr] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/antd/es/message/index.js [app-ssr] (ecmascript) <export default as message>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$SaudiCourseSource$2f$AddCourseSourceBasicInfo$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceBasicInfo.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$SaudiCourseSource$2f$Features$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/SaudiCourseSource/Features.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$SaudiCourseSource$2f$AddCourseSourceResource$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/components/SaudiCourseSource/AddCourseSourceResource.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/lib/features/roundsSlice.jsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/react-redux/dist/react-redux.mjs [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
// Helper لتحويل الصورة لـ base64 (للمعاينة)
const getBase64 = (file)=>new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = ()=>resolve(reader.result);
        reader.onerror = (error)=>reject(error);
    });
// Define the steps data
const STEPS = [
    {
        id: 1,
        title: "بيانات الدورة",
        description: "إضافة أقسام، دروس، ومواد تعليمية."
    },
    {
        id: 2,
        title: "مميزات الدورة",
        description: "إضافة أقسام، دروس، ومواد تعليمية."
    },
    {
        id: 3,
        title: "المصادر والملفات",
        description: "رفع الملفات والروابط المساندة ومراجعة الدورة."
    }
];
function Page() {
    const { id } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useParams"])();
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const [currentStep, setCurrentStep] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1);
    const [roundId, setRoundId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [fileList, setFileList] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [fileNames, setFileNames] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [videos, setVideos] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([
        {
            id: 1,
            name: "",
            url: ""
        }
    ]);
    const [imagePreview, setImagePreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedCategory, setSelectedCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [rowData, setRowData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useDispatch"])();
    const page = params.get("page");
    const pageSize = params.get("pageSize");
    const isSource = params.get("isSource");
    const Cat_id = params.get("category_id");
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!isSource) {
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetSourceRound"])({
                page,
                per_page: 10000000
            })).unwrap().then((res)=>{
                if (res?.data?.status === "success") {
                    const found = res?.data?.message?.data?.find((item)=>String(item?.id) === String(id));
                    setRowData(found || null);
                    if (found?.id) {
                        setRoundId(found.id);
                    }
                }
            });
        } else {
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$lib$2f$features$2f$roundsSlice$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["handleGetAllRounds"])({
                course_category_id: Cat_id,
                page,
                per_page: 6
            })).unwrap().then((res)=>{
                if (res?.data?.status === "success") {
                    const found = res?.data?.message?.data?.find((item)=>String(item?.id) === String(id));
                    setRowData(found || null);
                    if (found?.id) {
                        setRoundId(found.id);
                    }
                }
            });
        }
    }, [
        id,
        dispatch,
        page,
        pageSize
    ]);
    // --- Navigation Logic ---
    const goToNextStep = ()=>{
        setCurrentStep((prev)=>Math.min(prev + 1, STEPS.length));
    };
    const goToPrevStep = ()=>{
        setCurrentStep((prev)=>Math.max(prev - 1, 1));
    };
    // -------------------------
    const getStepStatus = (stepId)=>{
        if (stepId < currentStep) return "complete";
        if (stepId === currentStep) return "current";
        return "upcoming";
    };
    const beforeUpload = async (file)=>{
        const isImage = file.type?.startsWith("image/");
        if (!isImage) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("من فضلك ارفع ملف صورة فقط.");
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"].LIST_IGNORE;
        }
        const isLt5M = file.size / 1024 / 1024 < 5;
        if (!isLt5M) {
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$message$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__message$3e$__["message"].error("حجم الصورة يجب أن يكون أقل من 5MB.");
            return __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$antd$2f$es$2f$upload$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"].LIST_IGNORE;
        }
        const preview = await getBase64(file);
        setImagePreview(preview);
        setFileList([
            {
                uid: file.uid || file.name,
                name: file.name,
                status: "done",
                originFileObj: file
            }
        ]);
        return false; // منع الرفع التلقائي
    };
    const onFilesChange = ({ fileList })=>{
        setFileList(fileList);
        setFileNames((prev)=>{
            const next = {
                ...prev
            };
            fileList.forEach((f)=>{
                if (f.uid && !next[f.uid]) next[f.uid] = f.name?.replace(/\.[^.]+$/, "") || "";
            });
            Object.keys(next).forEach((uid)=>{
                if (!fileList.find((f)=>f.uid === uid)) delete next[uid];
            });
            return next;
        });
    };
    const getStatusClasses = (status)=>{
        switch(status){
            case "complete":
                return {
                    dot: "bg-blue-600 text-white border-blue-600",
                    text: "text-blue-800 font-semibold",
                    line: "bg-blue-600"
                };
            case "current":
                return {
                    dot: "bg-white text-blue-600 border-2 border-blue-600 shadow-md",
                    text: "text-gray-900 font-bold",
                    line: "bg-gray-300"
                };
            case "upcoming":
            default:
                return {
                    dot: "bg-gray-200 text-gray-500 border-gray-300",
                    text: "text-gray-500",
                    line: "bg-gray-300"
                };
        }
    };
    // ------- Step content -------
    const renderStepContent = ()=>{
        if (currentStep === 1) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$SaudiCourseSource$2f$AddCourseSourceBasicInfo$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: id,
                beforeUpload: beforeUpload,
                fileList: fileList,
                selectedCategory: selectedCategory,
                setSelectedCategory: setSelectedCategory,
                setFileList: setFileList,
                setImagePreview: setImagePreview,
                currentStep: currentStep,
                goToNextStep: goToNextStep,
                goToPrevStep: goToPrevStep,
                setRoundId: setRoundId,
                rowData: rowData,
                page: page,
                pageSize: pageSize,
                setRowData: setRowData,
                isSource: isSource,
                Cat_id: Cat_id
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                lineNumber: 963,
                columnNumber: 9
            }, this);
        }
        if (currentStep === 2) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$SaudiCourseSource$2f$Features$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                roundId: roundId,
                currentStep: currentStep,
                goToNextStep: goToNextStep,
                goToPrevStep: goToPrevStep,
                STEPS: STEPS
            }, void 0, false, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                lineNumber: 987,
                columnNumber: 9
            }, this);
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$components$2f$SaudiCourseSource$2f$AddCourseSourceResource$2e$jsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
            currentStep: currentStep,
            goToPrevStep: goToPrevStep,
            id: roundId,
            STEPS: STEPS
        }, void 0, false, {
            fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
            lineNumber: 998,
            columnNumber: 7
        }, this);
    };
    // ---------------------------
    const isEditMode = Boolean(id);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gradient-to-br from-gray-50 to-blue-50/30 p-4 sm:p-8",
        dir: "rtl",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative mx-auto mb-8 max-w-6xl rounded-2xl border-b-4 border-blue-500 bg-white p-6 shadow-xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute top-0 right-0 h-32 w-32 -translate-y-16 translate-x-16 rounded-full bg-gradient-to-br from-blue-400/10 to-purple-400/10 opacity-50"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                        lineNumber: 1017,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative mb-3 flex items-center gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 shadow-2xl",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ant$2d$design$2f$icons$2f$es$2f$icons$2f$PlusOutlined$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusOutlined$3e$__["PlusOutlined"], {
                                    className: "text-xl text-white"
                                }, void 0, false, {
                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                    lineNumber: 1021,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                lineNumber: 1020,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "bg-gradient-to-r from-gray-800 to-blue-800 bg-clip-text text-3xl font-extrabold text-transparent",
                                        children: isEditMode ? "تعديل بيانات الدورة" : "إضافة دورة جديدة"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                        lineNumber: 1024,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-1 text-gray-600",
                                        children: "إنشاء وتكوين دورة تعليمية شاملة مع الجدولة والمحتوى."
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                        lineNumber: 1027,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                lineNumber: 1023,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                        lineNumber: 1019,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                lineNumber: 1016,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto max-w-6xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-10 flex items-start justify-between rounded-xl border border-gray-100 bg-white p-6 shadow-lg",
                        children: STEPS.map((step, index)=>{
                            const status = getStepStatus(step.id);
                            const { dot, text, line } = getStatusClasses(status);
                            const isLast = index === STEPS.length - 1;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].Fragment, {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex w-1/4 min-w-0 flex-shrink-0 flex-col items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `relative flex h-10 w-10 items-center justify-center rounded-full transition duration-300 ${dot}`,
                                                children: status === "complete" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Check$3e$__["Check"], {
                                                    className: "h-4 w-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                                    lineNumber: 1050,
                                                    columnNumber: 23
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-lg",
                                                    children: step.id
                                                }, void 0, false, {
                                                    fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                                    lineNumber: 1052,
                                                    columnNumber: 23
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                                lineNumber: 1046,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-3 min-w-0 text-center",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: `overflow-hidden text-ellipsis whitespace-nowrap text-sm md:text-base leading-tight transition duration-300 ${text}`,
                                                        children: step.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                                        lineNumber: 1057,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-0.5 hidden text-xs text-gray-500 md:block",
                                                        children: status === "current" ? "الخطوة الحالية" : step.description.split(",")[0]
                                                    }, void 0, false, {
                                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                                        lineNumber: 1062,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                                lineNumber: 1056,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                        lineNumber: 1045,
                                        columnNumber: 17
                                    }, this),
                                    !isLast && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mx-2 flex flex-grow items-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: `h-0.5 w-full transition duration-300 ${status === "complete" ? "bg-blue-600" : line}`
                                        }, void 0, false, {
                                            fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                            lineNumber: 1072,
                                            columnNumber: 21
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                        lineNumber: 1071,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, step.id, true, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                lineNumber: 1044,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                        lineNumber: 1037,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-8 rounded-xl border border-gray-100 bg-white p-8 shadow-lg",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "mb-4 border-b pb-2 text-2xl font-bold text-gray-800",
                                children: [
                                    "الخطوة ",
                                    currentStep,
                                    ": ",
                                    STEPS[currentStep - 1].title
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                                lineNumber: 1086,
                                columnNumber: 11
                            }, this),
                            renderStepContent()
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                        lineNumber: 1085,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
                lineNumber: 1035,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/nartaqi/app/(admin)/saudi_source_course/edit/[id]/page.jsx",
        lineNumber: 1011,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=Desktop_nartaqi_2fa127db._.js.map