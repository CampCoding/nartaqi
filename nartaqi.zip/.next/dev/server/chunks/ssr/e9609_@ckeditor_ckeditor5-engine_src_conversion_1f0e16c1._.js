module.exports = [
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/mapper.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/conversion/mapper
 */ __turbopack_context__.s([
    "default",
    ()=>Mapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/text.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
;
;
;
;
;
;
class Mapper extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])() {
    /**
     * Creates an instance of the mapper.
     */ constructor(){
        super();
        /**
         * Model element to view element mapping.
         */ this._modelToViewMapping = new WeakMap();
        /**
         * View element to model element mapping.
         */ this._viewToModelMapping = new WeakMap();
        /**
         * A map containing callbacks between view element names and functions evaluating length of view elements
         * in model.
         */ this._viewToModelLengthCallbacks = new Map();
        /**
         * Model marker name to view elements mapping.
         *
         * Keys are `String`s while values are `Set`s with {@link module:engine/view/element~Element view elements}.
         * One marker (name) can be mapped to multiple elements.
         */ this._markerNameToElements = new Map();
        /**
         * View element to model marker names mapping.
         *
         * This is reverse to {@link ~Mapper#_markerNameToElements} map.
         */ this._elementToMarkerNames = new Map();
        /**
         * The map of removed view elements with their current root (used for deferred unbinding).
         */ this._deferredBindingRemovals = new Map();
        /**
         * Stores marker names of markers which have changed due to unbinding a view element (so it is assumed that the view element
         * has been removed, moved or renamed).
         */ this._unboundMarkerNames = new Set();
        // Default mapper algorithm for mapping model position to view position.
        this.on('modelToViewPosition', (evt, data)=>{
            if (data.viewPosition) {
                return;
            }
            const viewContainer = this._modelToViewMapping.get(data.modelPosition.parent);
            if (!viewContainer) {
                /**
                 * A model position could not be mapped to the view because the parent of the model position
                 * does not have a mapped view element (might have not been converted yet or it has no converter).
                 *
                 * Make sure that the model element is correctly converted to the view.
                 *
                 * @error mapping-model-position-view-parent-not-found
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('mapping-model-position-view-parent-not-found', this, {
                    modelPosition: data.modelPosition
                });
            }
            data.viewPosition = this.findPositionIn(viewContainer, data.modelPosition.offset);
        }, {
            priority: 'low'
        });
        // Default mapper algorithm for mapping view position to model position.
        this.on('viewToModelPosition', (evt, data)=>{
            if (data.modelPosition) {
                return;
            }
            const viewBlock = this.findMappedViewAncestor(data.viewPosition);
            const modelParent = this._viewToModelMapping.get(viewBlock);
            const modelOffset = this._toModelOffset(data.viewPosition.parent, data.viewPosition.offset, viewBlock);
            data.modelPosition = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(modelParent, modelOffset);
        }, {
            priority: 'low'
        });
    }
    /**
     * Marks model and view elements as corresponding. Corresponding elements can be retrieved by using
     * the {@link module:engine/conversion/mapper~Mapper#toModelElement toModelElement} and
     * {@link module:engine/conversion/mapper~Mapper#toViewElement toViewElement} methods.
     * The information that elements are bound is also used to translate positions.
     *
     * @param modelElement Model element.
     * @param viewElement View element.
     */ bindElements(modelElement, viewElement) {
        this._modelToViewMapping.set(modelElement, viewElement);
        this._viewToModelMapping.set(viewElement, modelElement);
    }
    /**
     * Unbinds the given {@link module:engine/view/element~Element view element} from the map.
     *
     * **Note:** view-to-model binding will be removed, if it existed. However, corresponding model-to-view binding
     * will be removed only if model element is still bound to the passed `viewElement`.
     *
     * This behavior allows for re-binding model element to another view element without fear of losing the new binding
     * when the previously bound view element is unbound.
     *
     * @param viewElement View element to unbind.
     * @param options The options object.
     * @param options.defer Controls whether the binding should be removed immediately or deferred until a
     * {@link #flushDeferredBindings `flushDeferredBindings()`} call.
     */ unbindViewElement(viewElement, options = {}) {
        const modelElement = this.toModelElement(viewElement);
        if (this._elementToMarkerNames.has(viewElement)) {
            for (const markerName of this._elementToMarkerNames.get(viewElement)){
                this._unboundMarkerNames.add(markerName);
            }
        }
        if (options.defer) {
            this._deferredBindingRemovals.set(viewElement, viewElement.root);
        } else {
            this._viewToModelMapping.delete(viewElement);
            if (this._modelToViewMapping.get(modelElement) == viewElement) {
                this._modelToViewMapping.delete(modelElement);
            }
        }
    }
    /**
     * Unbinds the given {@link module:engine/model/element~Element model element} from the map.
     *
     * **Note:** the model-to-view binding will be removed, if it existed. However, the corresponding view-to-model binding
     * will be removed only if the view element is still bound to the passed `modelElement`.
     *
     * This behavior lets for re-binding view element to another model element without fear of losing the new binding
     * when the previously bound model element is unbound.
     *
     * @param modelElement Model element to unbind.
     */ unbindModelElement(modelElement) {
        const viewElement = this.toViewElement(modelElement);
        this._modelToViewMapping.delete(modelElement);
        if (this._viewToModelMapping.get(viewElement) == modelElement) {
            this._viewToModelMapping.delete(viewElement);
        }
    }
    /**
     * Binds the given marker name with the given {@link module:engine/view/element~Element view element}. The element
     * will be added to the current set of elements bound with the given marker name.
     *
     * @param element Element to bind.
     * @param name Marker name.
     */ bindElementToMarker(element, name) {
        const elements = this._markerNameToElements.get(name) || new Set();
        elements.add(element);
        const names = this._elementToMarkerNames.get(element) || new Set();
        names.add(name);
        this._markerNameToElements.set(name, elements);
        this._elementToMarkerNames.set(element, names);
    }
    /**
     * Unbinds an element from given marker name.
     *
     * @param element Element to unbind.
     * @param name Marker name.
     */ unbindElementFromMarkerName(element, name) {
        const nameToElements = this._markerNameToElements.get(name);
        if (nameToElements) {
            nameToElements.delete(element);
            if (nameToElements.size == 0) {
                this._markerNameToElements.delete(name);
            }
        }
        const elementToNames = this._elementToMarkerNames.get(element);
        if (elementToNames) {
            elementToNames.delete(name);
            if (elementToNames.size == 0) {
                this._elementToMarkerNames.delete(element);
            }
        }
    }
    /**
     * Returns all marker names of markers which have changed due to unbinding a view element (so it is assumed that the view element
     * has been removed, moved or renamed) since the last flush. After returning, the marker names list is cleared.
     */ flushUnboundMarkerNames() {
        const markerNames = Array.from(this._unboundMarkerNames);
        this._unboundMarkerNames.clear();
        return markerNames;
    }
    /**
     * Unbinds all deferred binding removals of view elements that in the meantime were not re-attached to some root or document fragment.
     *
     * See: {@link #unbindViewElement `unbindViewElement()`}.
     */ flushDeferredBindings() {
        for (const [viewElement, root] of this._deferredBindingRemovals){
            // Unbind it only if it wasn't re-attached to some root or document fragment.
            if (viewElement.root == root) {
                this.unbindViewElement(viewElement);
            }
        }
        this._deferredBindingRemovals = new Map();
    }
    /**
     * Removes all model to view and view to model bindings.
     */ clearBindings() {
        this._modelToViewMapping = new WeakMap();
        this._viewToModelMapping = new WeakMap();
        this._markerNameToElements = new Map();
        this._elementToMarkerNames = new Map();
        this._unboundMarkerNames = new Set();
        this._deferredBindingRemovals = new Map();
    }
    toModelElement(viewElement) {
        return this._viewToModelMapping.get(viewElement);
    }
    toViewElement(modelElement) {
        return this._modelToViewMapping.get(modelElement);
    }
    /**
     * Gets the corresponding model range.
     *
     * @param viewRange View range.
     * @returns Corresponding model range.
     */ toModelRange(viewRange) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.toModelPosition(viewRange.start), this.toModelPosition(viewRange.end));
    }
    /**
     * Gets the corresponding view range.
     *
     * @param modelRange Model range.
     * @returns Corresponding view range.
     */ toViewRange(modelRange) {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.toViewPosition(modelRange.start), this.toViewPosition(modelRange.end));
    }
    /**
     * Gets the corresponding model position.
     *
     * @fires viewToModelPosition
     * @param viewPosition View position.
     * @returns Corresponding model position.
     */ toModelPosition(viewPosition) {
        const data = {
            viewPosition,
            mapper: this
        };
        this.fire('viewToModelPosition', data);
        return data.modelPosition;
    }
    /**
     * Gets the corresponding view position.
     *
     * @fires modelToViewPosition
     * @param modelPosition Model position.
     * @param options Additional options for position mapping process.
     * @param options.isPhantom Should be set to `true` if the model position to map is pointing to a place
     * in model tree which no longer exists. For example, it could be an end of a removed model range.
     * @returns Corresponding view position.
     */ toViewPosition(modelPosition, options = {}) {
        const data = {
            modelPosition,
            mapper: this,
            isPhantom: options.isPhantom
        };
        this.fire('modelToViewPosition', data);
        return data.viewPosition;
    }
    /**
     * Gets all view elements bound to the given marker name.
     *
     * @param name Marker name.
     * @returns View elements bound with the given marker name or `null`
     * if no elements are bound to the given marker name.
     */ markerNameToElements(name) {
        const boundElements = this._markerNameToElements.get(name);
        if (!boundElements) {
            return null;
        }
        const elements = new Set();
        for (const element of boundElements){
            if (element.is('attributeElement')) {
                for (const clone of element.getElementsWithSameId()){
                    elements.add(clone);
                }
            } else {
                elements.add(element);
            }
        }
        return elements;
    }
    /**
     * Registers a callback that evaluates the length in the model of a view element with the given name.
     *
     * The callback is fired with one argument, which is a view element instance. The callback is expected to return
     * a number representing the length of the view element in the model.
     *
     * ```ts
     * // List item in view may contain nested list, which have other list items. In model though,
     * // the lists are represented by flat structure. Because of those differences, length of list view element
     * // may be greater than one. In the callback it's checked how many nested list items are in evaluated list item.
     *
     * function getViewListItemLength( element ) {
     * 	let length = 1;
     *
     * 	for ( let child of element.getChildren() ) {
     * 		if ( child.name == 'ul' || child.name == 'ol' ) {
     * 			for ( let item of child.getChildren() ) {
     * 				length += getViewListItemLength( item );
     * 			}
     * 		}
     * 	}
     *
     * 	return length;
     * }
     *
     * mapper.registerViewToModelLength( 'li', getViewListItemLength );
     * ```
     *
     * @param viewElementName Name of view element for which callback is registered.
     * @param lengthCallback Function return a length of view element instance in model.
     */ registerViewToModelLength(viewElementName, lengthCallback) {
        this._viewToModelLengthCallbacks.set(viewElementName, lengthCallback);
    }
    /**
     * For the given `viewPosition`, finds and returns the closest ancestor of this position that has a mapping to
     * the model.
     *
     * @param viewPosition Position for which a mapped ancestor should be found.
     */ findMappedViewAncestor(viewPosition) {
        let parent = viewPosition.parent;
        while(!this._viewToModelMapping.has(parent)){
            parent = parent.parent;
        }
        return parent;
    }
    /**
     * Calculates model offset based on the view position and the block element.
     *
     * Example:
     *
     * ```html
     * <p>foo<b>ba|r</b></p> // _toModelOffset( b, 2, p ) -> 5
     * ```
     *
     * Is a sum of:
     *
     * ```html
     * <p>foo|<b>bar</b></p> // _toModelOffset( p, 3, p ) -> 3
     * <p>foo<b>ba|r</b></p> // _toModelOffset( b, 2, b ) -> 2
     * ```
     *
     * @param viewParent Position parent.
     * @param viewOffset Position offset.
     * @param viewBlock Block used as a base to calculate offset.
     * @returns Offset in the model.
     */ _toModelOffset(viewParent, viewOffset, viewBlock) {
        if (viewBlock != viewParent) {
            // See example.
            const offsetToParentStart = this._toModelOffset(viewParent.parent, viewParent.index, viewBlock);
            const offsetInParent = this._toModelOffset(viewParent, viewOffset, viewParent);
            return offsetToParentStart + offsetInParent;
        }
        // viewBlock == viewParent, so we need to calculate the offset in the parent element.
        // If the position is a text it is simple ("ba|r" -> 2).
        if (viewParent.is('$text')) {
            return viewOffset;
        }
        // If the position is in an element we need to sum lengths of siblings ( <b> bar </b> foo | -> 3 + 3 = 6 ).
        let modelOffset = 0;
        for(let i = 0; i < viewOffset; i++){
            modelOffset += this.getModelLength(viewParent.getChild(i));
        }
        return modelOffset;
    }
    /**
     * Gets the length of the view element in the model.
     *
     * The length is calculated as follows:
     * * if a {@link #registerViewToModelLength length mapping callback} is provided for the given `viewNode`, it is used to
     * evaluate the model length (`viewNode` is used as first and only parameter passed to the callback),
     * * length of a {@link module:engine/view/text~Text text node} is equal to the length of its
     * {@link module:engine/view/text~Text#data data},
     * * length of a {@link module:engine/view/uielement~UIElement ui element} is equal to 0,
     * * length of a mapped {@link module:engine/view/element~Element element} is equal to 1,
     * * length of a non-mapped {@link module:engine/view/element~Element element} is equal to the length of its children.
     *
     * Examples:
     *
     * ```
     * foo                          -> 3 // Text length is equal to its data length.
     * <p>foo</p>                   -> 1 // Length of an element which is mapped is by default equal to 1.
     * <b>foo</b>                   -> 3 // Length of an element which is not mapped is a length of its children.
     * <div><p>x</p><p>y</p></div>  -> 2 // Assuming that <div> is not mapped and <p> are mapped.
     * ```
     *
     * @param viewNode View node.
     * @returns Length of the node in the tree model.
     */ getModelLength(viewNode) {
        if (this._viewToModelLengthCallbacks.get(viewNode.name)) {
            const callback = this._viewToModelLengthCallbacks.get(viewNode.name);
            return callback(viewNode);
        } else if (this._viewToModelMapping.has(viewNode)) {
            return 1;
        } else if (viewNode.is('$text')) {
            return viewNode.data.length;
        } else if (viewNode.is('uiElement')) {
            return 0;
        } else {
            let len = 0;
            for (const child of viewNode.getChildren()){
                len += this.getModelLength(child);
            }
            return len;
        }
    }
    /**
     * Finds the position in the view node (or in its children) with the expected model offset.
     *
     * Example:
     *
     * ```
     * <p>fo<b>bar</b>bom</p> -> expected offset: 4
     *
     * findPositionIn( p, 4 ):
     * <p>|fo<b>bar</b>bom</p> -> expected offset: 4, actual offset: 0
     * <p>fo|<b>bar</b>bom</p> -> expected offset: 4, actual offset: 2
     * <p>fo<b>bar</b>|bom</p> -> expected offset: 4, actual offset: 5 -> we are too far
     *
     * findPositionIn( b, 4 - ( 5 - 3 ) ):
     * <p>fo<b>|bar</b>bom</p> -> expected offset: 2, actual offset: 0
     * <p>fo<b>bar|</b>bom</p> -> expected offset: 2, actual offset: 3 -> we are too far
     *
     * findPositionIn( bar, 2 - ( 3 - 3 ) ):
     * We are in the text node so we can simple find the offset.
     * <p>fo<b>ba|r</b>bom</p> -> expected offset: 2, actual offset: 2 -> position found
     * ```
     *
     * @param viewParent Tree view element in which we are looking for the position.
     * @param expectedOffset Expected offset.
     * @returns Found position.
     */ findPositionIn(viewParent, expectedOffset) {
        // Last scanned view node.
        let viewNode;
        // Length of the last scanned view node.
        let lastLength = 0;
        let modelOffset = 0;
        let viewOffset = 0;
        // In the text node it is simple: the offset in the model equals the offset in the text.
        if (viewParent.is('$text')) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewParent, expectedOffset);
        }
        // In other cases we add lengths of child nodes to find the proper offset.
        // If it is smaller we add the length.
        while(modelOffset < expectedOffset){
            viewNode = viewParent.getChild(viewOffset);
            lastLength = this.getModelLength(viewNode);
            modelOffset += lastLength;
            viewOffset++;
        }
        // If it equals we found the position.
        if (modelOffset == expectedOffset) {
            return this._moveViewPositionToTextNode(new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewParent, viewOffset));
        } else {
            // ( modelOffset - lastLength ) is the offset to the child we enter,
            // so we subtract it from the expected offset to fine the offset in the child.
            return this.findPositionIn(viewNode, expectedOffset - (modelOffset - lastLength));
        }
    }
    /**
     * Because we prefer positions in the text nodes over positions next to text nodes, if the view position was next to a text node,
     * it moves it into the text node instead.
     *
     * ```
     * <p>[]<b>foo</b></p> -> <p>[]<b>foo</b></p> // do not touch if position is not directly next to text
     * <p>foo[]<b>foo</b></p> -> <p>foo{}<b>foo</b></p> // move to text node
     * <p><b>[]foo</b></p> -> <p><b>{}foo</b></p> // move to text node
     * ```
     *
     * @param viewPosition Position potentially next to the text node.
     * @returns Position in the text node if possible.
     */ _moveViewPositionToTextNode(viewPosition) {
        // If the position is just after a text node, put it at the end of that text node.
        // If the position is just before a text node, put it at the beginning of that text node.
        const nodeBefore = viewPosition.nodeBefore;
        const nodeAfter = viewPosition.nodeAfter;
        if (nodeBefore instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodeBefore, nodeBefore.data.length);
        } else if (nodeAfter instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$text$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            return new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nodeAfter, 0);
        }
        // Otherwise, just return the given position.
        return viewPosition;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/modelconsumable.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/conversion/modelconsumable
 */ __turbopack_context__.s([
    "default",
    ()=>ModelConsumable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/textproxy.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
;
;
class ModelConsumable {
    constructor(){
        /**
         * Contains list of consumable values.
         */ this._consumable = new Map();
        /**
         * For each {@link module:engine/model/textproxy~TextProxy} added to `ModelConsumable`, this registry holds a parent
         * of that `TextProxy` and the start and end indices of that `TextProxy`. This allows identification of the `TextProxy`
         * instances that point to the same part of the model but are different instances. Each distinct `TextProxy`
         * is given a unique `Symbol` which is then registered as consumable. This process is transparent for the `ModelConsumable`
         * API user because whenever `TextProxy` is added, tested, consumed or reverted, the internal mechanisms of
         * `ModelConsumable` translate `TextProxy` to that unique `Symbol`.
         */ this._textProxyRegistry = new Map();
    }
    /**
     * Adds a consumable value to the consumables list and links it with a given model item.
     *
     * ```ts
     * modelConsumable.add( modelElement, 'insert' ); // Add `modelElement` insertion change to consumable values.
     * modelConsumable.add( modelElement, 'addAttribute:bold' ); // Add `bold` attribute insertion on `modelElement` change.
     * modelConsumable.add( modelElement, 'removeAttribute:bold' ); // Add `bold` attribute removal on `modelElement` change.
     * modelConsumable.add( modelSelection, 'selection' ); // Add `modelSelection` to consumable values.
     * modelConsumable.add( modelRange, 'range' ); // Add `modelRange` to consumable values.
     * ```
     *
     * @param item Model item, range or selection that has the consumable.
     * @param type Consumable type. Will be normalized to a proper form, that is either `<word>` or `<part>:<part>`.
     * Second colon and everything after will be cut. Passing event name is a safe and good practice.
     */ add(item, type) {
        type = _normalizeConsumableType(type);
        if (item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            item = this._getSymbolForTextProxy(item);
        }
        if (!this._consumable.has(item)) {
            this._consumable.set(item, new Map());
        }
        this._consumable.get(item).set(type, true);
    }
    /**
     * Removes a given consumable value from a given model item.
     *
     * ```ts
     * modelConsumable.consume( modelElement, 'insert' ); // Remove `modelElement` insertion change from consumable values.
     * modelConsumable.consume( modelElement, 'addAttribute:bold' ); // Remove `bold` attribute insertion on `modelElement` change.
     * modelConsumable.consume( modelElement, 'removeAttribute:bold' ); // Remove `bold` attribute removal on `modelElement` change.
     * modelConsumable.consume( modelSelection, 'selection' ); // Remove `modelSelection` from consumable values.
     * modelConsumable.consume( modelRange, 'range' ); // Remove 'modelRange' from consumable values.
     * ```
     *
     * @param item Model item, range or selection from which consumable will be consumed.
     * @param type Consumable type. Will be normalized to a proper form, that is either `<word>` or `<part>:<part>`.
     * Second colon and everything after will be cut. Passing event name is a safe and good practice.
     * @returns `true` if consumable value was available and was consumed, `false` otherwise.
     */ consume(item, type) {
        type = _normalizeConsumableType(type);
        if (item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            item = this._getSymbolForTextProxy(item);
        }
        if (this.test(item, type)) {
            this._consumable.get(item).set(type, false);
            return true;
        } else {
            return false;
        }
    }
    /**
     * Tests whether there is a consumable value of a given type connected with a given model item.
     *
     * ```ts
     * modelConsumable.test( modelElement, 'insert' ); // Check for `modelElement` insertion change.
     * modelConsumable.test( modelElement, 'addAttribute:bold' ); // Check for `bold` attribute insertion on `modelElement` change.
     * modelConsumable.test( modelElement, 'removeAttribute:bold' ); // Check for `bold` attribute removal on `modelElement` change.
     * modelConsumable.test( modelSelection, 'selection' ); // Check if `modelSelection` is consumable.
     * modelConsumable.test( modelRange, 'range' ); // Check if `modelRange` is consumable.
     * ```
     *
     * @param item Model item, range or selection to be tested.
     * @param type Consumable type. Will be normalized to a proper form, that is either `<word>` or `<part>:<part>`.
     * Second colon and everything after will be cut. Passing event name is a safe and good practice.
     * @returns `null` if such consumable was never added, `false` if the consumable values was
     * already consumed or `true` if it was added and not consumed yet.
     */ test(item, type) {
        type = _normalizeConsumableType(type);
        if (item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            item = this._getSymbolForTextProxy(item);
        }
        const itemConsumables = this._consumable.get(item);
        if (itemConsumables === undefined) {
            return null;
        }
        const value = itemConsumables.get(type);
        if (value === undefined) {
            return null;
        }
        return value;
    }
    /**
     * Reverts consuming of a consumable value.
     *
     * ```ts
     * modelConsumable.revert( modelElement, 'insert' ); // Revert consuming `modelElement` insertion change.
     * modelConsumable.revert( modelElement, 'addAttribute:bold' ); // Revert consuming `bold` attribute insert from `modelElement`.
     * modelConsumable.revert( modelElement, 'removeAttribute:bold' ); // Revert consuming `bold` attribute remove from `modelElement`.
     * modelConsumable.revert( modelSelection, 'selection' ); // Revert consuming `modelSelection`.
     * modelConsumable.revert( modelRange, 'range' ); // Revert consuming `modelRange`.
     * ```
     *
     * @param item Model item, range or selection to be reverted.
     * @param type Consumable type.
     * @returns `true` if consumable has been reversed, `false` otherwise. `null` if the consumable has
     * never been added.
     */ revert(item, type) {
        type = _normalizeConsumableType(type);
        if (item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$textproxy$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            item = this._getSymbolForTextProxy(item);
        }
        const test = this.test(item, type);
        if (test === false) {
            this._consumable.get(item).set(type, true);
            return true;
        } else if (test === true) {
            return false;
        }
        return null;
    }
    /**
     * Verifies if all events from the specified group were consumed.
     *
     * @param eventGroup The events group to verify.
     */ verifyAllConsumed(eventGroup) {
        const items = [];
        for (const [item, consumables] of this._consumable){
            for (const [event, canConsume] of consumables){
                const eventPrefix = event.split(':')[0];
                if (canConsume && eventGroup == eventPrefix) {
                    items.push({
                        event,
                        item: item.name || item.description
                    });
                }
            }
        }
        if (items.length) {
            /**
             * Some of the {@link module:engine/model/item~Item model items} were not consumed while downcasting the model to view.
             *
             * This might be the effect of:
             *
             * * A missing converter for some model elements. Make sure that you registered downcast converters for all model elements.
             * * A custom converter that does not consume converted items. Make sure that you
             * {@link module:engine/conversion/modelconsumable~ModelConsumable#consume consumed} all model elements that you converted
             * from the model to the view.
             * * A custom converter that called `event.stop()`. When providing a custom converter, keep in mind that you should not stop
             * the event. If you stop it then the default converter at the `lowest` priority will not trigger the conversion of this node's
             * attributes and child nodes.
             *
             * @error conversion-model-consumable-not-consumed
             * @param {Array.<module:engine/model/item~Item>} items Items that were not consumed.
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('conversion-model-consumable-not-consumed', null, {
                items
            });
        }
    }
    /**
     * Gets a unique symbol for the passed {@link module:engine/model/textproxy~TextProxy} instance. All `TextProxy` instances that
     * have same parent, same start index and same end index will get the same symbol.
     *
     * Used internally to correctly consume `TextProxy` instances.
     *
     * @internal
     * @param textProxy `TextProxy` instance to get a symbol for.
     * @returns Symbol representing all equal instances of `TextProxy`.
     */ _getSymbolForTextProxy(textProxy) {
        let symbol = null;
        const startMap = this._textProxyRegistry.get(textProxy.startOffset);
        if (startMap) {
            const endMap = startMap.get(textProxy.endOffset);
            if (endMap) {
                symbol = endMap.get(textProxy.parent);
            }
        }
        if (!symbol) {
            symbol = this._addSymbolForTextProxy(textProxy);
        }
        return symbol;
    }
    /**
     * Adds a symbol for the given {@link module:engine/model/textproxy~TextProxy} instance.
     *
     * Used internally to correctly consume `TextProxy` instances.
     *
     * @param textProxy Text proxy instance.
     * @returns Symbol generated for given `TextProxy`.
     */ _addSymbolForTextProxy(textProxy) {
        const start = textProxy.startOffset;
        const end = textProxy.endOffset;
        const parent = textProxy.parent;
        const symbol = Symbol('$textProxy:' + textProxy.data);
        let startMap;
        let endMap;
        startMap = this._textProxyRegistry.get(start);
        if (!startMap) {
            startMap = new Map();
            this._textProxyRegistry.set(start, startMap);
        }
        endMap = startMap.get(end);
        if (!endMap) {
            endMap = new Map();
            startMap.set(end, endMap);
        }
        endMap.set(parent, symbol);
        return symbol;
    }
}
/**
 * Returns a normalized consumable type name from the given string. A normalized consumable type name is a string that has
 * at most one colon, for example: `insert` or `addMarker:highlight`. If a string to normalize has more "parts" (more colons),
 * the further parts are dropped, for example: `addattribute:bold:$text` -> `addattributes:bold`.
 *
 * @param type Consumable type.
 * @returns Normalized consumable type.
 */ function _normalizeConsumableType(type) {
    const parts = type.split(':');
    // For inserts allow passing event name, it's stored in the context of a specified element so the element name is not needed.
    if (parts[0] == 'insert') {
        return parts[0];
    }
    // Markers are identified by the whole name (otherwise we would consume the whole markers group).
    if (parts[0] == 'addMarker' || parts[0] == 'removeMarker') {
        return type;
    }
    return parts.length > 1 ? parts[0] + ':' + parts[1] : parts[0];
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/downcastdispatcher.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/conversion/downcastdispatcher
 */ __turbopack_context__.s([
    "default",
    ()=>DowncastDispatcher
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$modelconsumable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/modelconsumable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
;
;
;
class DowncastDispatcher extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])() {
    /**
     * Creates a downcast dispatcher instance.
     *
     * @see module:engine/conversion/downcastdispatcher~DowncastConversionApi
     *
     * @param conversionApi Additional properties for an interface that will be passed to events fired
     * by the downcast dispatcher.
     */ constructor(conversionApi){
        super();
        this._conversionApi = {
            dispatcher: this,
            ...conversionApi
        };
        this._firedEventsMap = new WeakMap();
    }
    /**
     * Converts changes buffered in the given {@link module:engine/model/differ~Differ model differ}
     * and fires conversion events based on it.
     *
     * @fires insert
     * @fires remove
     * @fires attribute
     * @fires addMarker
     * @fires removeMarker
     * @fires reduceChanges
     * @param differ The differ object with buffered changes.
     * @param markers Markers related to the model fragment to convert.
     * @param writer The view writer that should be used to modify the view document.
     */ convertChanges(differ, markers, writer) {
        const conversionApi = this._createConversionApi(writer, differ.getRefreshedItems());
        // Before the view is updated, remove markers which have changed.
        for (const change of differ.getMarkersToRemove()){
            this._convertMarkerRemove(change.name, change.range, conversionApi);
        }
        // Let features modify the change list (for example to allow reconversion).
        const changes = this._reduceChanges(differ.getChanges());
        // Convert changes that happened on model tree.
        for (const entry of changes){
            if (entry.type === 'insert') {
                this._convertInsert(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(entry.position, entry.length), conversionApi);
            } else if (entry.type === 'reinsert') {
                this._convertReinsert(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(entry.position, entry.length), conversionApi);
            } else if (entry.type === 'remove') {
                this._convertRemove(entry.position, entry.length, entry.name, conversionApi);
            } else {
                // Defaults to 'attribute' change.
                this._convertAttribute(entry.range, entry.attributeKey, entry.attributeOldValue, entry.attributeNewValue, conversionApi);
            }
        }
        // Remove mappings for all removed view elements.
        // Remove these mappings as soon as they are not needed (https://github.com/ckeditor/ckeditor5/issues/15411).
        conversionApi.mapper.flushDeferredBindings();
        for (const markerName of conversionApi.mapper.flushUnboundMarkerNames()){
            const markerRange = markers.get(markerName).getRange();
            this._convertMarkerRemove(markerName, markerRange, conversionApi);
            this._convertMarkerAdd(markerName, markerRange, conversionApi);
        }
        // After the view is updated, convert markers which have changed.
        for (const change of differ.getMarkersToAdd()){
            this._convertMarkerAdd(change.name, change.range, conversionApi);
        }
        // Verify if all insert consumables were consumed.
        conversionApi.consumable.verifyAllConsumed('insert');
    }
    /**
     * Starts a conversion of a model range and the provided markers.
     *
     * @fires insert
     * @fires attribute
     * @fires addMarker
     * @param range The inserted range.
     * @param markers The map of markers that should be down-casted.
     * @param writer The view writer that should be used to modify the view document.
     * @param options Optional options object passed to `convertionApi.options`.
     */ convert(range, markers, writer, options = {}) {
        const conversionApi = this._createConversionApi(writer, undefined, options);
        this._convertInsert(range, conversionApi);
        for (const [name, range] of markers){
            this._convertMarkerAdd(name, range, conversionApi);
        }
        // Verify if all insert consumables were consumed.
        conversionApi.consumable.verifyAllConsumed('insert');
    }
    /**
     * Starts the model selection conversion.
     *
     * Fires events for a given {@link module:engine/model/selection~Selection selection} to start the selection conversion.
     *
     * @fires selection
     * @fires addMarker
     * @fires attribute
     * @param selection The selection to convert.
     * @param markers Markers connected with the converted model.
     * @param writer View writer that should be used to modify the view document.
     */ convertSelection(selection, markers, writer) {
        const conversionApi = this._createConversionApi(writer);
        // First perform a clean-up at the current position of the selection.
        this.fire('cleanSelection', {
            selection
        }, conversionApi);
        // Don't convert selection if it is in a model root that does not have a view root (for now this is only the graveyard root).
        const modelRoot = selection.getFirstPosition().root;
        if (!conversionApi.mapper.toViewElement(modelRoot)) {
            return;
        }
        // Now, perform actual selection conversion.
        const markersAtSelection = Array.from(markers.getMarkersAtPosition(selection.getFirstPosition()));
        this._addConsumablesForSelection(conversionApi.consumable, selection, markersAtSelection);
        this.fire('selection', {
            selection
        }, conversionApi);
        if (!selection.isCollapsed) {
            return;
        }
        for (const marker of markersAtSelection){
            // Do not fire event if the marker has been consumed.
            if (conversionApi.consumable.test(selection, 'addMarker:' + marker.name)) {
                const markerRange = marker.getRange();
                if (!shouldMarkerChangeBeConverted(selection.getFirstPosition(), marker, conversionApi.mapper)) {
                    continue;
                }
                const data = {
                    item: selection,
                    markerName: marker.name,
                    markerRange
                };
                this.fire(`addMarker:${marker.name}`, data, conversionApi);
            }
        }
        for (const key of selection.getAttributeKeys()){
            // Do not fire event if the attribute has been consumed.
            if (conversionApi.consumable.test(selection, 'attribute:' + key)) {
                const data = {
                    item: selection,
                    range: selection.getFirstRange(),
                    attributeKey: key,
                    attributeOldValue: null,
                    attributeNewValue: selection.getAttribute(key)
                };
                this.fire(`attribute:${key}:$text`, data, conversionApi);
            }
        }
    }
    /**
     * Fires insertion conversion of a range of nodes.
     *
     * For each node in the range, {@link #event:insert `insert` event is fired}. For each attribute on each node,
     * {@link #event:attribute `attribute` event is fired}.
     *
     * @fires insert
     * @fires attribute
     * @param range The inserted range.
     * @param conversionApi The conversion API object.
     * @param options.doNotAddConsumables Whether the ModelConsumable should not get populated
     * for items in the provided range.
     */ _convertInsert(range, conversionApi, options = {}) {
        if (!options.doNotAddConsumables) {
            // Collect a list of things that can be consumed, consisting of nodes and their attributes.
            this._addConsumablesForInsert(conversionApi.consumable, range);
        }
        // Fire a separate insert event for each node and text fragment contained in the range.
        for (const data of Array.from(range.getWalker({
            shallow: true
        })).map(walkerValueToEventData)){
            this._testAndFire('insert', data, conversionApi);
        }
    }
    /**
     * Fires conversion of a single node removal. Fires {@link #event:remove remove event} with provided data.
     *
     * @param position Position from which node was removed.
     * @param length Offset size of removed node.
     * @param name Name of removed node.
     * @param conversionApi The conversion API object.
     */ _convertRemove(position, length, name, conversionApi) {
        this.fire(`remove:${name}`, {
            position,
            length
        }, conversionApi);
    }
    /**
     * Starts a conversion of an attribute change on a given `range`.
     *
     * For each node in the given `range`, {@link #event:attribute attribute event} is fired with the passed data.
     *
     * @fires attribute
     * @param range Changed range.
     * @param key Key of the attribute that has changed.
     * @param oldValue Attribute value before the change or `null` if the attribute has not been set before.
     * @param newValue New attribute value or `null` if the attribute has been removed.
     * @param conversionApi The conversion API object.
     */ _convertAttribute(range, key, oldValue, newValue, conversionApi) {
        // Create a list with attributes to consume.
        this._addConsumablesForRange(conversionApi.consumable, range, `attribute:${key}`);
        // Create a separate attribute event for each node in the range.
        for (const value of range){
            const data = {
                item: value.item,
                range: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(value.previousPosition, value.length),
                attributeKey: key,
                attributeOldValue: oldValue,
                attributeNewValue: newValue
            };
            this._testAndFire(`attribute:${key}`, data, conversionApi);
        }
    }
    /**
     * Fires re-insertion conversion (with a `reconversion` flag passed to `insert` events)
     * of a range of elements (only elements on the range depth, without children).
     *
     * For each node in the range on its depth (without children), {@link #event:insert `insert` event} is fired.
     * For each attribute on each node, {@link #event:attribute `attribute` event} is fired.
     *
     * @fires insert
     * @fires attribute
     * @param range The range to reinsert.
     * @param conversionApi The conversion API object.
     */ _convertReinsert(range, conversionApi) {
        // Convert the elements - without converting children.
        const walkerValues = Array.from(range.getWalker({
            shallow: true
        }));
        // Collect a list of things that can be consumed, consisting of nodes and their attributes.
        this._addConsumablesForInsert(conversionApi.consumable, walkerValues);
        // Fire a separate insert event for each node and text fragment contained shallowly in the range.
        for (const data of walkerValues.map(walkerValueToEventData)){
            this._testAndFire('insert', {
                ...data,
                reconversion: true
            }, conversionApi);
        }
    }
    /**
     * Converts the added marker. Fires the {@link #event:addMarker `addMarker`} event for each item
     * in the marker's range. If the range is collapsed, a single event is dispatched. See the event description for more details.
     *
     * @fires addMarker
     * @param markerName Marker name.
     * @param markerRange The marker range.
     * @param conversionApi The conversion API object.
     */ _convertMarkerAdd(markerName, markerRange, conversionApi) {
        // Do not convert if range is in graveyard.
        if (markerRange.root.rootName == '$graveyard') {
            return;
        }
        // In markers' case, event name == consumable name.
        const eventName = `addMarker:${markerName}`;
        //
        // First, fire an event for the whole marker.
        //
        conversionApi.consumable.add(markerRange, eventName);
        this.fire(eventName, {
            markerName,
            markerRange
        }, conversionApi);
        //
        // Do not fire events for each item inside the range if the range got consumed.
        // Also consume the whole marker consumable if it wasn't consumed.
        //
        if (!conversionApi.consumable.consume(markerRange, eventName)) {
            return;
        }
        //
        // Then, fire an event for each item inside the marker range.
        //
        this._addConsumablesForRange(conversionApi.consumable, markerRange, eventName);
        for (const item of markerRange.getItems()){
            // Do not fire event for already consumed items.
            if (!conversionApi.consumable.test(item, eventName)) {
                continue;
            }
            const data = {
                item,
                range: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(item),
                markerName,
                markerRange
            };
            this.fire(eventName, data, conversionApi);
        }
    }
    /**
     * Fires the conversion of the marker removal. Fires the {@link #event:removeMarker `removeMarker`} event with the provided data.
     *
     * @fires removeMarker
     * @param markerName Marker name.
     * @param markerRange The marker range.
     * @param conversionApi The conversion API object.
     */ _convertMarkerRemove(markerName, markerRange, conversionApi) {
        // Do not convert if range is in graveyard.
        if (markerRange.root.rootName == '$graveyard') {
            return;
        }
        this.fire(`removeMarker:${markerName}`, {
            markerName,
            markerRange
        }, conversionApi);
    }
    /**
     * Fires the reduction of changes buffered in the {@link module:engine/model/differ~Differ `Differ`}.
     *
     * Features can replace selected {@link module:engine/model/differ~DiffItem `DiffItem`}s with `reinsert` entries to trigger
     * reconversion. The {@link module:engine/conversion/downcasthelpers~DowncastHelpers#elementToStructure
     * `DowncastHelpers.elementToStructure()`} is using this event to trigger reconversion.
     *
     * @fires reduceChanges
     */ _reduceChanges(changes) {
        const data = {
            changes
        };
        this.fire('reduceChanges', data);
        return data.changes;
    }
    /**
     * Populates provided {@link module:engine/conversion/modelconsumable~ModelConsumable} with values to consume from a given range,
     * assuming that the range has just been inserted to the model.
     *
     * @param consumable The consumable.
     * @param walkerValues The walker values for the inserted range.
     * @returns The values to consume.
     */ _addConsumablesForInsert(consumable, walkerValues) {
        for (const value of walkerValues){
            const item = value.item;
            // Add consumable if it wasn't there yet.
            if (consumable.test(item, 'insert') === null) {
                consumable.add(item, 'insert');
                for (const key of item.getAttributeKeys()){
                    consumable.add(item, 'attribute:' + key);
                }
            }
        }
        return consumable;
    }
    /**
     * Populates provided {@link module:engine/conversion/modelconsumable~ModelConsumable} with values to consume for a given range.
     *
     * @param consumable The consumable.
     * @param range The affected range.
     * @param type Consumable type.
     * @returns The values to consume.
     */ _addConsumablesForRange(consumable, range, type) {
        for (const item of range.getItems()){
            consumable.add(item, type);
        }
        return consumable;
    }
    /**
     * Populates provided {@link module:engine/conversion/modelconsumable~ModelConsumable} with selection consumable values.
     *
     * @param consumable The consumable.
     * @param selection The selection to create the consumable from.
     * @param markers Markers that contain the selection.
     * @returns The values to consume.
     */ _addConsumablesForSelection(consumable, selection, markers) {
        consumable.add(selection, 'selection');
        for (const marker of markers){
            consumable.add(selection, 'addMarker:' + marker.name);
        }
        for (const key of selection.getAttributeKeys()){
            consumable.add(selection, 'attribute:' + key);
        }
        return consumable;
    }
    /**
     * Tests whether given event wasn't already fired and if so, fires it.
     *
     * @fires insert
     * @fires attribute
     * @param type Event type.
     * @param data Event data.
     * @param conversionApi The conversion API object.
     */ _testAndFire(type, data, conversionApi) {
        const eventName = getEventName(type, data);
        const itemKey = data.item.is('$textProxy') ? conversionApi.consumable._getSymbolForTextProxy(data.item) : data.item;
        const eventsFiredForConversion = this._firedEventsMap.get(conversionApi);
        const eventsFiredForItem = eventsFiredForConversion.get(itemKey);
        if (!eventsFiredForItem) {
            eventsFiredForConversion.set(itemKey, new Set([
                eventName
            ]));
        } else if (!eventsFiredForItem.has(eventName)) {
            eventsFiredForItem.add(eventName);
        } else {
            return;
        }
        this.fire(eventName, data, conversionApi);
    }
    /**
     * Fires not already fired events for setting attributes on just inserted item.
     *
     * @param item The model item to convert attributes for.
     * @param conversionApi The conversion API object.
     */ _testAndFireAddAttributes(item, conversionApi) {
        const data = {
            item,
            range: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(item)
        };
        for (const key of data.item.getAttributeKeys()){
            data.attributeKey = key;
            data.attributeOldValue = null;
            data.attributeNewValue = data.item.getAttribute(key);
            this._testAndFire(`attribute:${key}`, data, conversionApi);
        }
    }
    /**
     * Builds an instance of the {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi} from a template and a given
     * {@link module:engine/view/downcastwriter~DowncastWriter `DowncastWriter`} and options object.
     *
     * @param writer View writer that should be used to modify the view document.
     * @param refreshedItems A set of model elements that should not reuse their
     * previous view representations.
     * @param options Optional options passed to `convertionApi.options`.
     * @return The conversion API object.
     */ _createConversionApi(writer, refreshedItems = new Set(), options = {}) {
        const conversionApi = {
            ...this._conversionApi,
            consumable: new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$modelconsumable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](),
            writer,
            options,
            convertItem: (item)=>this._convertInsert(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createOn(item), conversionApi),
            convertChildren: (element)=>this._convertInsert(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(element), conversionApi, {
                    doNotAddConsumables: true
                }),
            convertAttributes: (item)=>this._testAndFireAddAttributes(item, conversionApi),
            canReuseView: (viewElement)=>!refreshedItems.has(conversionApi.mapper.toModelElement(viewElement))
        };
        this._firedEventsMap.set(conversionApi, new Map());
        return conversionApi;
    }
}
/**
 * Helper function, checks whether change of `marker` at `modelPosition` should be converted. Marker changes are not
 * converted if they happen inside an element with custom conversion method.
 */ function shouldMarkerChangeBeConverted(modelPosition, marker, mapper) {
    const range = marker.getRange();
    const ancestors = Array.from(modelPosition.getAncestors());
    ancestors.shift(); // Remove root element. It cannot be passed to `model.Range#containsItem`.
    ancestors.reverse();
    const hasCustomHandling = ancestors.some((element)=>{
        if (range.containsItem(element)) {
            const viewElement = mapper.toViewElement(element);
            return !!viewElement.getCustomProperty('addHighlight');
        }
    });
    return !hasCustomHandling;
}
function getEventName(type, data) {
    const name = data.item.is('element') ? data.item.name : '$text';
    return `${type}:${name}`;
}
function walkerValueToEventData(value) {
    const item = value.item;
    const itemRange = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createFromPositionAndShift(value.previousPosition, value.length);
    return {
        item,
        range: itemRange
    };
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/conversionhelpers.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/conversion/conversionhelpers
 */ /**
 * Base class for conversion helpers.
 */ __turbopack_context__.s([
    "default",
    ()=>ConversionHelpers
]);
class ConversionHelpers {
    /**
     * Creates a conversion helpers instance.
     */ constructor(dispatchers){
        this._dispatchers = dispatchers;
    }
    /**
     * Registers a conversion helper.
     *
     * **Note**: See full usage example in the `{@link module:engine/conversion/conversion~Conversion#for conversion.for()}`
     * method description.
     *
     * @param conversionHelper The function to be called on event.
     */ add(conversionHelper) {
        for (const dispatcher of this._dispatchers){
            conversionHelper(dispatcher);
        }
        return this;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/downcasthelpers.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * Contains downcast (model-to-view) converters for {@link module:engine/conversion/downcastdispatcher~DowncastDispatcher}.
 *
 * @module engine/conversion/downcasthelpers
 */ __turbopack_context__.s([
    "cleanSelection",
    ()=>cleanSelection,
    "convertCollapsedSelection",
    ()=>convertCollapsedSelection,
    "convertRangeSelection",
    ()=>convertRangeSelection,
    "createViewElementFromHighlightDescriptor",
    ()=>createViewElementFromHighlightDescriptor,
    "default",
    ()=>DowncastHelpers,
    "insertAttributesAndChildren",
    ()=>insertAttributesAndChildren,
    "insertElement",
    ()=>insertElement,
    "insertStructure",
    ()=>insertStructure,
    "insertText",
    ()=>insertText,
    "insertUIElement",
    ()=>insertUIElement,
    "remove",
    ()=>remove,
    "wrap",
    ()=>wrap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/selection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/documentselection.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/element.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/attributeelement.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$conversionhelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/conversionhelpers.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/stylesmap.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/toarray.js [app-ssr] (ecmascript) <export default as toArray>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/cloneDeep.js [app-ssr] (ecmascript) <export default as cloneDeep>");
;
;
;
;
;
;
;
;
;
;
class DowncastHelpers extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$conversionhelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Model element to view element conversion helper.
     *
     * This conversion results in creating a view element. For example, model `<paragraph>Foo</paragraph>` becomes `<p>Foo</p>` in the view.
     *
     * ```ts
     * editor.conversion.for( 'downcast' ).elementToElement( {
     * 	model: 'paragraph',
     * 	view: 'p'
     * } );
     *
     * editor.conversion.for( 'downcast' ).elementToElement( {
     * 	model: 'paragraph',
     * 	view: 'div',
     * 	converterPriority: 'high'
     * } );
     *
     * editor.conversion.for( 'downcast' ).elementToElement( {
     * 	model: 'fancyParagraph',
     * 	view: {
     * 		name: 'p',
     * 		classes: 'fancy'
     * 	}
     * } );
     *
     * editor.conversion.for( 'downcast' ).elementToElement( {
     * 	model: 'heading',
     * 	view: ( modelElement, conversionApi ) => {
     * 		const { writer } = conversionApi;
     *
     * 		return writer.createContainerElement( 'h' + modelElement.getAttribute( 'level' ) );
     * 	}
     * } );
     * ```
     *
     * The element-to-element conversion supports the reconversion mechanism. It can be enabled by using either the `attributes` or
     * the `children` props on a model description. You will find a couple examples below.
     *
     * In order to reconvert an element if any of its direct children have been added or removed, use the `children` property on a `model`
     * description. For example, this model:
     *
     * ```xml
     * <box>
     * 	<paragraph>Some text.</paragraph>
     * </box>
     * ```
     *
     * will be converted into this structure in the view:
     *
     * ```html
     * <div class="box" data-type="single">
     * 	<p>Some text.</p>
     * </div>
     * ```
     *
     * But if more items were inserted in the model:
     *
     * ```xml
     * <box>
     * 	<paragraph>Some text.</paragraph>
     * 	<paragraph>Other item.</paragraph>
     * </box>
     * ```
     *
     * it will be converted into this structure in the view (note the element `data-type` change):
     *
     * ```html
     * <div class="box" data-type="multiple">
     * 	<p>Some text.</p>
     * 	<p>Other item.</p>
     * </div>
     * ```
     *
     * Such a converter would look like this (note that the `paragraph` elements are converted separately):
     *
     * ```ts
     * editor.conversion.for( 'downcast' ).elementToElement( {
     * 	model: {
     * 		name: 'box',
     * 		children: true
     * 	},
     * 	view: ( modelElement, conversionApi ) => {
     * 		const { writer } = conversionApi;
     *
     * 		return writer.createContainerElement( 'div', {
     * 			class: 'box',
     * 			'data-type': modelElement.childCount == 1 ? 'single' : 'multiple'
     * 		} );
     * 	}
     * } );
     * ```
     *
     * In order to reconvert element if any of its attributes have been updated, use the `attributes` property on a `model`
     * description. For example, this model:
     *
     * ```xml
     * <heading level="2">Some text.</heading>
     * ```
     *
     * will be converted into this structure in the view:
     *
     * ```html
     * <h2>Some text.</h2>
     * ```
     *
     * But if the `heading` element's `level` attribute has been updated to `3` for example, then
     * it will be converted into this structure in the view:
     *
     * ```html
     * <h3>Some text.</h3>
     * ```
     *
     * Such a converter would look as follows:
     *
     * ```ts
     * editor.conversion.for( 'downcast' ).elementToElement( {
     * 	model: {
     * 		name: 'heading',
     * 		attributes: 'level'
     * 	},
     * 	view: ( modelElement, conversionApi ) => {
     * 		const { writer } = conversionApi;
     *
     * 		return writer.createContainerElement( 'h' + modelElement.getAttribute( 'level' ) );
     * 	}
     * } );
     * ```
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * You can read more about the element-to-element conversion in the
     * {@glink framework/deep-dive/conversion/downcast downcast conversion} guide.
     *
     * @param config Conversion configuration.
     * @param config.model The description or a name of the model element to convert.
     * @param config.model.attributes The list of attribute names that should be consumed while creating
     * the view element. Note that the view will be reconverted if any of the listed attributes changes.
     * @param config.model.children Specifies whether the view element requires reconversion if the list
     * of the model child nodes changed.
     * @param config.view A view element definition or a function that takes the model element and
     * {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi downcast conversion API}
     * as parameters and returns a view container element.
     */ elementToElement(config) {
        return this.add(downcastElementToElement(config));
    }
    /**
     * The model element to view structure (several elements) conversion helper.
     *
     * This conversion results in creating a view structure with one or more slots defined for the child nodes.
     * For example, a model `<table>` may become this structure in the view:
     *
     * ```html
     * <figure class="table">
     * 	<table>
     * 		<tbody>${ slot for table rows }</tbody>
     * 	</table>
     * </figure>
     * ```
     *
     * The children of the model's `<table>` element will be inserted into the `<tbody>` element.
     * If the `elementToElement()` helper was used, the children would be inserted into the `<figure>`.
     *
     * Imagine a table feature where for this model structure:
     *
     * ```xml
     * <table headingRows="1">
     * 	<tableRow> ... table cells 1 ... </tableRow>
     * 	<tableRow> ... table cells 2 ... </tableRow>
     * 	<tableRow> ... table cells 3 ... </tableRow>
     * 	<caption>Caption text</caption>
     * </table>
     * ```
     *
     * we want to generate this view structure:
     *
     * ```html
     * <figure class="table">
     * 	<table>
     * 		<thead>
     * 			<tr> ... table cells 1 ... </tr>
     * 		</thead>
     * 		<tbody>
     * 			<tr> ... table cells 2 ... </tr>
     * 			<tr> ... table cells 3 ... </tr>
     * 		</tbody>
     * 	</table>
     * 	<figcaption>Caption text</figcaption>
     * </figure>
     * ```
     *
     * The converter has to take the `headingRows` attribute into consideration when allocating the `<tableRow>` elements
     * into the `<tbody>` and `<thead>` elements. Hence, we need two slots and need to define proper filter callbacks for them.
     *
     * Additionally, all elements other than `<tableRow>` should be placed outside the `<table>` tag.
     * In the example above, this will handle the table caption.
     *
     * Such a converter would look like this:
     *
     * ```ts
     * editor.conversion.for( 'downcast' ).elementToStructure( {
     * 	model: {
     * 		name: 'table',
     * 		attributes: [ 'headingRows' ]
     * 	},
     * 	view: ( modelElement, conversionApi ) => {
     * 		const { writer } = conversionApi;
     *
     * 		const figureElement = writer.createContainerElement( 'figure', { class: 'table' } );
     * 		const tableElement = writer.createContainerElement( 'table' );
     *
     * 		writer.insert( writer.createPositionAt( figureElement, 0 ), tableElement );
     *
     * 		const headingRows = modelElement.getAttribute( 'headingRows' ) || 0;
     *
     * 		if ( headingRows > 0 ) {
     * 			const tableHead = writer.createContainerElement( 'thead' );
     *
     * 			const headSlot = writer.createSlot( node => node.is( 'element', 'tableRow' ) && node.index < headingRows );
     *
     * 			writer.insert( writer.createPositionAt( tableElement, 'end' ), tableHead );
     * 			writer.insert( writer.createPositionAt( tableHead, 0 ), headSlot );
     * 		}
     *
     * 		if ( headingRows < tableUtils.getRows( table ) ) {
     * 			const tableBody = writer.createContainerElement( 'tbody' );
     *
     * 			const bodySlot = writer.createSlot( node => node.is( 'element', 'tableRow' ) && node.index >= headingRows );
     *
     * 			writer.insert( writer.createPositionAt( tableElement, 'end' ), tableBody );
     * 			writer.insert( writer.createPositionAt( tableBody, 0 ), bodySlot );
     * 		}
     *
     * 		const restSlot = writer.createSlot( node => !node.is( 'element', 'tableRow' ) );
     *
     * 		writer.insert( writer.createPositionAt( figureElement, 'end' ), restSlot );
     *
     * 		return figureElement;
     * 	}
     * } );
     * ```
     *
     * Note: The children of a model element that's being converted must be allocated in the same order in the view
     * in which they are placed in the model.
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.model The description or a name of the model element to convert.
     * @param config.model.name The name of the model element to convert.
     * @param config.model.attributes The list of attribute names that should be consumed while creating
     * the view structure. Note that the view will be reconverted if any of the listed attributes will change.
     * @param config.view A function that takes the model element and
     * {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi downcast conversion API} as parameters
     * and returns a view container element with slots for model child nodes to be converted into.
     */ elementToStructure(config) {
        return this.add(downcastElementToStructure(config));
    }
    /**
     * Model attribute to view element conversion helper.
     *
     * This conversion results in wrapping view nodes with a view attribute element. For example, a model text node with
     * `"Foo"` as data and the `bold` attribute becomes `<strong>Foo</strong>` in the view.
     *
     * ```ts
     * editor.conversion.for( 'downcast' ).attributeToElement( {
     * 	model: 'bold',
     * 	view: 'strong'
     * } );
     *
     * editor.conversion.for( 'downcast' ).attributeToElement( {
     * 	model: 'bold',
     * 	view: 'b',
     * 	converterPriority: 'high'
     * } );
     *
     * editor.conversion.for( 'downcast' ).attributeToElement( {
     * 	model: 'invert',
     * 	view: {
     * 		name: 'span',
     * 		classes: [ 'font-light', 'bg-dark' ]
     * 	}
     * } );
     *
     * editor.conversion.for( 'downcast' ).attributeToElement( {
     * 	model: {
     * 		key: 'fontSize',
     * 		values: [ 'big', 'small' ]
     * 	},
     * 	view: {
     * 		big: {
     * 			name: 'span',
     * 			styles: {
     * 				'font-size': '1.2em'
     * 			}
     * 		},
     * 		small: {
     * 			name: 'span',
     * 			styles: {
     * 				'font-size': '0.8em'
     * 			}
     * 		}
     * 	}
     * } );
     *
     * editor.conversion.for( 'downcast' ).attributeToElement( {
     * 	model: 'bold',
     * 	view: ( modelAttributeValue, conversionApi ) => {
     * 		const { writer } = conversionApi;
     *
     * 		return writer.createAttributeElement( 'span', {
     * 			style: 'font-weight:' + modelAttributeValue
     * 		} );
     * 	}
     * } );
     *
     * editor.conversion.for( 'downcast' ).attributeToElement( {
     * 	model: {
     * 		key: 'color',
     * 		name: '$text'
     * 	},
     * 	view: ( modelAttributeValue, conversionApi ) => {
     * 		const { writer } = conversionApi;
     *
     * 		return writer.createAttributeElement( 'span', {
     * 			style: 'color:' + modelAttributeValue
     * 		} );
     * 	}
     * } );
     * ```
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.model The key of the attribute to convert from or a `{ key, values }` object. `values` is an array
     * of `String`s with possible values if the model attribute is an enumerable.
     * @param config.view A view element definition or a function
     * that takes the model attribute value and
     * {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi downcast conversion API} as parameters and returns a view
     * attribute element. If `config.model.values` is given, `config.view` should be an object assigning values from `config.model.values`
     * to view element definitions or functions.
     * @param config.converterPriority Converter priority.
     */ attributeToElement(config) {
        return this.add(downcastAttributeToElement(config));
    }
    /**
     * Model attribute to view attribute conversion helper.
     *
     * This conversion results in adding an attribute to a view node, basing on an attribute from a model node. For example,
     * `<imageInline src='foo.jpg'></imageInline>` is converted to `<img src='foo.jpg'></img>`.
     *
     * ```ts
     * editor.conversion.for( 'downcast' ).attributeToAttribute( {
     * 	model: 'source',
     * 	view: 'src'
     * } );
     *
     * editor.conversion.for( 'downcast' ).attributeToAttribute( {
     * 	model: 'source',
     * 	view: 'href',
     * 	converterPriority: 'high'
     * } );
     *
     * editor.conversion.for( 'downcast' ).attributeToAttribute( {
     * 	model: {
     * 		name: 'imageInline',
     * 		key: 'source'
     * 	},
     * 	view: 'src'
     * } );
     *
     * editor.conversion.for( 'downcast' ).attributeToAttribute( {
     * 	model: {
     * 		name: 'styled',
     * 		values: [ 'dark', 'light' ]
     * 	},
     * 	view: {
     * 		dark: {
     * 			key: 'class',
     * 			value: [ 'styled', 'styled-dark' ]
     * 		},
     * 		light: {
     * 			key: 'class',
     * 			value: [ 'styled', 'styled-light' ]
     * 		}
     * 	}
     * } );
     *
     * editor.conversion.for( 'downcast' ).attributeToAttribute( {
     * 	model: 'styled',
     * 	view: modelAttributeValue => ( {
     * 		key: 'class',
     * 		value: 'styled-' + modelAttributeValue
     * 	} )
     * } );
     * ```
     *
     * **Note**: Downcasting to a style property requires providing `value` as an object:
     *
     * ```ts
     * editor.conversion.for( 'downcast' ).attributeToAttribute( {
     * 	model: 'lineHeight',
     * 	view: modelAttributeValue => ( {
     * 		key: 'style',
     * 		value: {
     * 			'line-height': modelAttributeValue,
     * 			'border-bottom': '1px dotted #ba2'
     * 		}
     * 	} )
     * } );
     * ```
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.model The key of the attribute to convert from or a `{ key, values, [ name ] }` object describing
     * the attribute key, possible values and, optionally, an element name to convert from.
     * @param config.view A view attribute key, or a `{ key, value }` object or a function that takes the model attribute value and
     * {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi downcast conversion API}
     * as parameters and returns a `{ key, value }` object. If the `key` is `'class'`, the `value` can be a `String` or an
     * array of `String`s. If the `key` is `'style'`, the `value` is an object with key-value pairs. In other cases, `value` is a `String`.
     * If `config.model.values` is set, `config.view` should be an object assigning values from `config.model.values` to
     * `{ key, value }` objects or a functions.
     * @param config.converterPriority Converter priority.
     */ attributeToAttribute(config) {
        return this.add(downcastAttributeToAttribute(config));
    }
    /**
     * Model marker to view element conversion helper.
     *
     * **Note**: This method should be used mainly for editing the downcast and it is recommended
     * to use the {@link #markerToData `#markerToData()`} helper instead.
     *
     * This helper may produce invalid HTML code (e.g. a span between table cells).
     * It should only be used when you are sure that the produced HTML will be semantically correct.
     *
     * This conversion results in creating a view element on the boundaries of the converted marker. If the converted marker
     * is collapsed, only one element is created. For example, a model marker set like this: `<paragraph>F[oo b]ar</paragraph>`
     * becomes `<p>F<span data-marker="search"></span>oo b<span data-marker="search"></span>ar</p>` in the view.
     *
     * ```ts
     * editor.conversion.for( 'editingDowncast' ).markerToElement( {
     * 	model: 'search',
     * 	view: 'marker-search'
     * } );
     *
     * editor.conversion.for( 'editingDowncast' ).markerToElement( {
     * 	model: 'search',
     * 	view: 'search-result',
     * 	converterPriority: 'high'
     * } );
     *
     * editor.conversion.for( 'editingDowncast' ).markerToElement( {
     * 	model: 'search',
     * 	view: {
     * 		name: 'span',
     * 		attributes: {
     * 			'data-marker': 'search'
     * 		}
     * 	}
     * } );
     *
     * editor.conversion.for( 'editingDowncast' ).markerToElement( {
     * 	model: 'search',
     * 	view: ( markerData, conversionApi ) => {
     * 		const { writer } = conversionApi;
     *
     * 		return writer.createUIElement( 'span', {
     * 			'data-marker': 'search',
     * 			'data-start': markerData.isOpening
     * 		} );
     * 	}
     * } );
     * ```
     *
     * If a function is passed as the `config.view` parameter, it will be used to generate both boundary elements. The function
     * receives the `data` object and {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi downcast conversion API}
     * as a parameters and should return an instance of the
     * {@link module:engine/view/uielement~UIElement view UI element}. The `data` object and
     * {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi `conversionApi`} are passed from
     * {@link module:engine/conversion/downcastdispatcher~DowncastDispatcher#event:addMarker}. Additionally,
     * the `data.isOpening` parameter is passed, which is set to `true` for the marker start boundary element, and `false` for
     * the marker end boundary element.
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.model The name of the model marker (or model marker group) to convert.
     * @param config.view A view element definition or a function that takes the model marker data and
     * {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi downcast conversion API} as a parameters
     * and returns a view UI element.
     * @param config.converterPriority Converter priority.
     */ markerToElement(config) {
        return this.add(downcastMarkerToElement(config));
    }
    /**
     * Model marker to highlight conversion helper.
     *
     * This conversion results in creating a highlight on view nodes. For this kind of conversion,
     * the {@link module:engine/conversion/downcasthelpers~HighlightDescriptor} should be provided.
     *
     * For text nodes, a `<span>` {@link module:engine/view/attributeelement~AttributeElement} is created and it wraps all text nodes
     * in the converted marker range. For example, a model marker set like this: `<paragraph>F[oo b]ar</paragraph>` becomes
     * `<p>F<span class="comment">oo b</span>ar</p>` in the view.
     *
     * {@link module:engine/view/containerelement~ContainerElement} may provide a custom way of handling highlight. Most often,
     * the element itself is given classes and attributes described in the highlight descriptor (instead of being wrapped in `<span>`).
     * For example, a model marker set like this:
     * `[<imageInline src="foo.jpg"></imageInline>]` becomes `<img src="foo.jpg" class="comment"></img>` in the view.
     *
     * For container elements, the conversion is two-step. While the converter processes the highlight descriptor and passes it
     * to a container element, it is the container element instance itself that applies values from the highlight descriptor.
     * So, in a sense, the converter takes care of stating what should be applied on what, while the element decides how to apply that.
     *
     * ```ts
     * editor.conversion.for( 'downcast' ).markerToHighlight( { model: 'comment', view: { classes: 'comment' } } );
     *
     * editor.conversion.for( 'downcast' ).markerToHighlight( {
     * 	model: 'comment',
     * 	view: { classes: 'comment' },
     * 	converterPriority: 'high'
     * } );
     *
     * editor.conversion.for( 'downcast' ).markerToHighlight( {
     * 	model: 'comment',
     * 	view: ( data, conversionApi ) => {
     * 		// Assuming that the marker name is in a form of comment:commentType:commentId.
     * 		const [ , commentType, commentId ] = data.markerName.split( ':' );
     *
     * 		return {
     * 			classes: [ 'comment', 'comment-' + commentType ],
     * 			attributes: { 'data-comment-id': commentId }
     * 		};
     * 	}
     * } );
     * ```
     *
     * If a function is passed as the `config.view` parameter, it will be used to generate the highlight descriptor. The function
     * receives the `data` object and {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi downcast conversion API}
     * as the parameters and should return a
     * {@link module:engine/conversion/downcasthelpers~HighlightDescriptor highlight descriptor}.
     * The `data` object properties are passed from {@link module:engine/conversion/downcastdispatcher~DowncastDispatcher#event:addMarker}.
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.model The name of the model marker (or model marker group) to convert.
     * @param config.view A highlight descriptor that will be used for highlighting or a function that takes the model marker data and
     * {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi downcast conversion API} as a parameters
     * and returns a highlight descriptor.
     * @param config.converterPriority Converter priority.
     */ markerToHighlight(config) {
        return this.add(downcastMarkerToHighlight(config));
    }
    /**
     * Model marker converter for data downcast.
     *
     * This conversion creates a representation for model marker boundaries in the view:
     *
     * * If the marker boundary is before or after a model element, a view attribute is set on a corresponding view element.
     * * In other cases, a view element with the specified tag name is inserted at the corresponding view position.
     *
     * Typically, the marker names use the `group:uniqueId:otherData` convention. For example: `comment:e34zfk9k2n459df53sjl34:zx32c`.
     * The default configuration for this conversion is that the first part is the `group` part and the rest of
     * the marker name becomes the `name` part.
     *
     * Tag and attribute names and values are generated from the marker name:
     *
     * * The templates for attributes are `data-[group]-start-before="[name]"`, `data-[group]-start-after="[name]"`,
     * `data-[group]-end-before="[name]"` and `data-[group]-end-after="[name]"`.
     * * The templates for view elements are `<[group]-start name="[name]">` and `<[group]-end name="[name]">`.
     *
     * Attributes mark whether the given marker's start or end boundary is before or after the given element.
     * The `data-[group]-start-before` and `data-[group]-end-after` attributes are favored.
     * The other two are used when the former two cannot be used.
     *
     * The conversion configuration can take a function that will generate different group and name parts.
     * If such a function is set as the `config.view` parameter, it is passed a marker name and it is expected to return an object with two
     * properties: `group` and `name`. If the function returns a falsy value, the conversion will not take place.
     *
     * Basic usage:
     *
     * ```ts
     * // Using the default conversion.
     * // In this case, all markers with names starting with 'comment:' will be converted.
     * // The `group` parameter will be set to `comment`.
     * // The `name` parameter will be the rest of the marker name (without the `:`).
     * editor.conversion.for( 'dataDowncast' ).markerToData( {
     * 	model: 'comment'
     * } );
     * ```
     *
     * An example of a view that may be generated by this conversion (assuming a marker with the name `comment:commentId:uid` marked
     * by `[]`):
     *
     * ```
     * // Model:
     * <paragraph>Foo[bar</paragraph>
     * <imageBlock src="abc.jpg"></imageBlock>]
     *
     * // View:
     * <p>Foo<comment-start name="commentId:uid"></comment-start>bar</p>
     * <figure data-comment-end-after="commentId:uid" class="image"><img src="abc.jpg" /></figure>
     * ```
     *
     * In the example above, the comment starts before "bar" and ends after the image.
     *
     * If the `name` part is empty, the following view may be generated:
     *
     * ```html
     * <p>Foo <myMarker-start></myMarker-start>bar</p>
     * <figure data-myMarker-end-after="" class="image"><img src="abc.jpg" /></figure>
     * ```
     *
     * **Note:** A situation where some markers have the `name` part and some do not, is incorrect and should be avoided.
     *
     * Examples where `data-group-start-after` and `data-group-end-before` are used:
     *
     * ```
     * // Model:
     * <blockQuote>[]<paragraph>Foo</paragraph></blockQuote>
     *
     * // View:
     * <blockquote><p data-group-end-before="name" data-group-start-before="name">Foo</p></blockquote>
     * ```
     *
     * Similarly, when a marker is collapsed after the last element:
     *
     * ```
     * // Model:
     * <blockQuote><paragraph>Foo</paragraph>[]</blockQuote>
     *
     * // View:
     * <blockquote><p data-group-end-after="name" data-group-start-after="name">Foo</p></blockquote>
     * ```
     *
     * When there are multiple markers from the same group stored in the same attribute of the same element, their
     * name parts are put together in the attribute value, for example: `data-group-start-before="name1,name2,name3"`.
     *
     * Other examples of usage:
     *
     * ```ts
     * // Using a custom function which is the same as the default conversion:
     * editor.conversion.for( 'dataDowncast' ).markerToData( {
     * 	model: 'comment',
     * 	view: markerName => ( {
     * 		group: 'comment',
     * 		name: markerName.substr( 8 ) // Removes 'comment:' part.
     * 	} )
     * } );
     *
     * // Using the converter priority:
     * editor.conversion.for( 'dataDowncast' ).markerToData( {
     * 	model: 'comment',
     * 	view: markerName => ( {
     * 		group: 'comment',
     * 		name: markerName.substr( 8 ) // Removes 'comment:' part.
     * 	} ),
     * 	converterPriority: 'high'
     * } );
     * ```
     *
     * This kind of conversion is useful for saving data into the database, so it should be used in the data conversion pipeline.
     *
     * See the {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} API guide to learn how to
     * add a converter to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.model The name of the model marker (or the model marker group) to convert.
     * @param config.view A function that takes the model marker name and
     * {@link module:engine/conversion/downcastdispatcher~DowncastConversionApi downcast conversion API} as the parameters
     * and returns an object with the `group` and `name` properties.
     * @param config.converterPriority Converter priority.
     */ markerToData(config) {
        return this.add(downcastMarkerToData(config));
    }
}
function insertText() {
    return (evt, data, conversionApi)=>{
        if (!conversionApi.consumable.consume(data.item, evt.name)) {
            return;
        }
        const viewWriter = conversionApi.writer;
        const viewPosition = conversionApi.mapper.toViewPosition(data.range.start);
        const viewText = viewWriter.createText(data.item.data);
        viewWriter.insert(viewPosition, viewText);
    };
}
function insertAttributesAndChildren() {
    return (evt, data, conversionApi)=>{
        conversionApi.convertAttributes(data.item);
        // Start converting children of the current item.
        // In case of reconversion children were already re-inserted or converted separately.
        if (!data.reconversion && data.item.is('element') && !data.item.isEmpty) {
            conversionApi.convertChildren(data.item);
        }
    };
}
function remove() {
    return (evt, data, conversionApi)=>{
        // Find the view range start position by mapping the model position at which the remove happened.
        const viewStart = conversionApi.mapper.toViewPosition(data.position);
        const modelEnd = data.position.getShiftedBy(data.length);
        const viewEnd = conversionApi.mapper.toViewPosition(modelEnd, {
            isPhantom: true
        });
        const viewRange = conversionApi.writer.createRange(viewStart, viewEnd);
        // Trim the range to remove in case some UI elements are on the view range boundaries.
        const removed = conversionApi.writer.remove(viewRange.getTrimmed());
        // After the range is removed, unbind all view elements from the model.
        // Range inside view document fragment is used to unbind deeply.
        for (const child of conversionApi.writer.createRangeIn(removed).getItems()){
            conversionApi.mapper.unbindViewElement(child, {
                defer: true
            });
        }
    };
}
function createViewElementFromHighlightDescriptor(writer, descriptor) {
    const viewElement = writer.createAttributeElement('span', descriptor.attributes);
    if (descriptor.classes) {
        viewElement._addClass(descriptor.classes);
    }
    if (typeof descriptor.priority === 'number') {
        viewElement._priority = descriptor.priority;
    }
    viewElement._id = descriptor.id;
    return viewElement;
}
function convertRangeSelection() {
    return (evt, data, conversionApi)=>{
        const selection = data.selection;
        if (selection.isCollapsed) {
            return;
        }
        if (!conversionApi.consumable.consume(selection, 'selection')) {
            return;
        }
        const viewRanges = [];
        for (const range of selection.getRanges()){
            viewRanges.push(conversionApi.mapper.toViewRange(range));
        }
        conversionApi.writer.setSelection(viewRanges, {
            backward: selection.isBackward
        });
    };
}
function convertCollapsedSelection() {
    return (evt, data, conversionApi)=>{
        const selection = data.selection;
        if (!selection.isCollapsed) {
            return;
        }
        if (!conversionApi.consumable.consume(selection, 'selection')) {
            return;
        }
        const viewWriter = conversionApi.writer;
        const modelPosition = selection.getFirstPosition();
        const viewPosition = conversionApi.mapper.toViewPosition(modelPosition);
        const brokenPosition = viewWriter.breakAttributes(viewPosition);
        viewWriter.setSelection(brokenPosition);
    };
}
function cleanSelection() {
    return (evt, data, conversionApi)=>{
        const viewWriter = conversionApi.writer;
        const viewSelection = viewWriter.document.selection;
        for (const range of viewSelection.getRanges()){
            // Not collapsed selection should not have artifacts.
            if (range.isCollapsed) {
                // Position might be in the node removed by the view writer.
                if (range.end.parent.isAttached()) {
                    conversionApi.writer.mergeAttributes(range.start);
                }
            }
        }
        viewWriter.setSelection(null);
    };
}
function wrap(elementCreator) {
    return (evt, data, conversionApi)=>{
        if (!conversionApi.consumable.test(data.item, evt.name)) {
            return;
        }
        // Recreate current wrapping node. It will be used to unwrap view range if the attribute value has changed
        // or the attribute was removed.
        const oldViewElement = elementCreator(data.attributeOldValue, conversionApi, data);
        // Create node to wrap with.
        const newViewElement = elementCreator(data.attributeNewValue, conversionApi, data);
        if (!oldViewElement && !newViewElement) {
            return;
        }
        conversionApi.consumable.consume(data.item, evt.name);
        const viewWriter = conversionApi.writer;
        const viewSelection = viewWriter.document.selection;
        if (data.item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || data.item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            // Selection attribute conversion.
            viewWriter.wrap(viewSelection.getFirstRange(), newViewElement);
        } else {
            // Node attribute conversion.
            let viewRange = conversionApi.mapper.toViewRange(data.range);
            // First, unwrap the range from current wrapper.
            if (data.attributeOldValue !== null && oldViewElement) {
                viewRange = viewWriter.unwrap(viewRange, oldViewElement);
            }
            if (data.attributeNewValue !== null && newViewElement) {
                viewWriter.wrap(viewRange, newViewElement);
            }
        }
    };
}
function insertElement(elementCreator, consumer = defaultConsumer) {
    return (evt, data, conversionApi)=>{
        if (!consumer(data.item, conversionApi.consumable, {
            preflight: true
        })) {
            return;
        }
        const viewElement = elementCreator(data.item, conversionApi, data);
        if (!viewElement) {
            return;
        }
        // Consume an element insertion and all present attributes that are specified as a reconversion triggers.
        consumer(data.item, conversionApi.consumable);
        const viewPosition = conversionApi.mapper.toViewPosition(data.range.start);
        conversionApi.mapper.bindElements(data.item, viewElement);
        conversionApi.writer.insert(viewPosition, viewElement);
        // Convert attributes before converting children.
        conversionApi.convertAttributes(data.item);
        // Convert children or reinsert previous view elements.
        reinsertOrConvertNodes(viewElement, data.item.getChildren(), conversionApi, {
            reconversion: data.reconversion
        });
    };
}
function insertStructure(elementCreator, consumer) {
    return (evt, data, conversionApi)=>{
        if (!consumer(data.item, conversionApi.consumable, {
            preflight: true
        })) {
            return;
        }
        const slotsMap = new Map();
        conversionApi.writer._registerSlotFactory(createSlotFactory(data.item, slotsMap, conversionApi));
        // View creation.
        const viewElement = elementCreator(data.item, conversionApi, data);
        conversionApi.writer._clearSlotFactory();
        if (!viewElement) {
            return;
        }
        // Check if all children are covered by slots and there is no child that landed in multiple slots.
        validateSlotsChildren(data.item, slotsMap, conversionApi);
        // Consume an element insertion and all present attributes that are specified as a reconversion triggers.
        consumer(data.item, conversionApi.consumable);
        const viewPosition = conversionApi.mapper.toViewPosition(data.range.start);
        conversionApi.mapper.bindElements(data.item, viewElement);
        conversionApi.writer.insert(viewPosition, viewElement);
        // Convert attributes before converting children.
        conversionApi.convertAttributes(data.item);
        // Fill view slots with previous view elements or create new ones.
        fillSlots(viewElement, slotsMap, conversionApi, {
            reconversion: data.reconversion
        });
    };
}
function insertUIElement(elementCreator) {
    return (evt, data, conversionApi)=>{
        // Create two view elements. One will be inserted at the beginning of marker, one at the end.
        // If marker is collapsed, only "opening" element will be inserted.
        data.isOpening = true;
        const viewStartElement = elementCreator(data, conversionApi);
        data.isOpening = false;
        const viewEndElement = elementCreator(data, conversionApi);
        if (!viewStartElement || !viewEndElement) {
            return;
        }
        const markerRange = data.markerRange;
        // Marker that is collapsed has consumable build differently that non-collapsed one.
        // For more information see `addMarker` event description.
        // If marker's range is collapsed - check if it can be consumed.
        if (markerRange.isCollapsed && !conversionApi.consumable.consume(markerRange, evt.name)) {
            return;
        }
        // If marker's range is not collapsed - consume all items inside.
        for (const value of markerRange){
            if (!conversionApi.consumable.consume(value.item, evt.name)) {
                return;
            }
        }
        const mapper = conversionApi.mapper;
        const viewWriter = conversionApi.writer;
        // Add "opening" element.
        viewWriter.insert(mapper.toViewPosition(markerRange.start), viewStartElement);
        conversionApi.mapper.bindElementToMarker(viewStartElement, data.markerName);
        // Add "closing" element only if range is not collapsed.
        if (!markerRange.isCollapsed) {
            viewWriter.insert(mapper.toViewPosition(markerRange.end), viewEndElement);
            conversionApi.mapper.bindElementToMarker(viewEndElement, data.markerName);
        }
        evt.stop();
    };
}
/**
 * Function factory that returns a default downcast converter for removing a {@link module:engine/view/uielement~UIElement UI element}
 * based on marker remove change.
 *
 * This converter unbinds elements from the marker name.
 *
 * @returns Removed UI element converter.
 */ function removeUIElement() {
    return (evt, data, conversionApi)=>{
        const elements = conversionApi.mapper.markerNameToElements(data.markerName);
        if (!elements) {
            return;
        }
        for (const element of elements){
            conversionApi.mapper.unbindElementFromMarkerName(element, data.markerName);
            conversionApi.writer.clear(conversionApi.writer.createRangeOn(element), element);
        }
        conversionApi.writer.clearClonedElementsGroup(data.markerName);
        evt.stop();
    };
}
/**
 * Function factory that creates a default converter for model markers.
 *
 * See {@link DowncastHelpers#markerToData} for more information what type of view is generated.
 *
 * This converter binds created UI elements and affected view elements with the marker name
 * using {@link module:engine/conversion/mapper~Mapper#bindElementToMarker}.
 *
 * @returns Add marker converter.
 */ function insertMarkerData(viewCreator) {
    return (evt, data, conversionApi)=>{
        const viewMarkerData = viewCreator(data.markerName, conversionApi);
        if (!viewMarkerData) {
            return;
        }
        const markerRange = data.markerRange;
        if (!conversionApi.consumable.consume(markerRange, evt.name)) {
            return;
        }
        // Adding closing data first to keep the proper order in the view.
        handleMarkerBoundary(markerRange, false, conversionApi, data, viewMarkerData);
        handleMarkerBoundary(markerRange, true, conversionApi, data, viewMarkerData);
        evt.stop();
    };
}
/**
 * Helper function for `insertMarkerData()` that marks a marker boundary at the beginning or end of given `range`.
 */ function handleMarkerBoundary(range, isStart, conversionApi, data, viewMarkerData) {
    const modelPosition = isStart ? range.start : range.end;
    const elementAfter = modelPosition.nodeAfter && modelPosition.nodeAfter.is('element') ? modelPosition.nodeAfter : null;
    const elementBefore = modelPosition.nodeBefore && modelPosition.nodeBefore.is('element') ? modelPosition.nodeBefore : null;
    if (elementAfter || elementBefore) {
        let modelElement;
        let isBefore;
        // If possible, we want to add `data-group-start-before` and `data-group-end-after` attributes.
        if (isStart && elementAfter || !isStart && !elementBefore) {
            // [<elementAfter>...</elementAfter> -> <elementAfter data-group-start-before="...">...</elementAfter>
            // <parent>]<elementAfter> -> <parent><elementAfter data-group-end-before="...">
            modelElement = elementAfter;
            isBefore = true;
        } else {
            // <elementBefore>...</elementBefore>] -> <elementBefore data-group-end-after="...">...</elementBefore>
            // </elementBefore>[</parent> -> </elementBefore data-group-start-after="..."></parent>
            modelElement = elementBefore;
            isBefore = false;
        }
        const viewElement = conversionApi.mapper.toViewElement(modelElement);
        // In rare circumstances, the model element may be not mapped to any view element and that would cause an error.
        // One of those situations is a soft break inside code block.
        if (viewElement) {
            insertMarkerAsAttribute(viewElement, isStart, isBefore, conversionApi, data, viewMarkerData);
            return;
        }
    }
    const viewPosition = conversionApi.mapper.toViewPosition(modelPosition);
    insertMarkerAsElement(viewPosition, isStart, conversionApi, data, viewMarkerData);
}
/**
 * Helper function for `insertMarkerData()` that marks a marker boundary in the view as an attribute on a view element.
 */ function insertMarkerAsAttribute(viewElement, isStart, isBefore, conversionApi, data, viewMarkerData) {
    const attributeName = `data-${viewMarkerData.group}-${isStart ? 'start' : 'end'}-${isBefore ? 'before' : 'after'}`;
    const markerNames = viewElement.hasAttribute(attributeName) ? viewElement.getAttribute(attributeName).split(',') : [];
    // Adding marker name at the beginning to have the same order in the attribute as there is with marker elements.
    markerNames.unshift(viewMarkerData.name);
    conversionApi.writer.setAttribute(attributeName, markerNames.join(','), viewElement);
    conversionApi.mapper.bindElementToMarker(viewElement, data.markerName);
}
/**
 * Helper function for `insertMarkerData()` that marks a marker boundary in the view as a separate view ui element.
 */ function insertMarkerAsElement(position, isStart, conversionApi, data, viewMarkerData) {
    const viewElementName = `${viewMarkerData.group}-${isStart ? 'start' : 'end'}`;
    const attrs = viewMarkerData.name ? {
        'name': viewMarkerData.name
    } : null;
    const viewElement = conversionApi.writer.createUIElement(viewElementName, attrs);
    conversionApi.writer.insert(position, viewElement);
    conversionApi.mapper.bindElementToMarker(viewElement, data.markerName);
}
/**
 * Function factory that creates a converter for removing a model marker data added by the {@link #insertMarkerData} converter.
 *
 * @returns Remove marker converter.
 */ function removeMarkerData(viewCreator) {
    return (evt, data, conversionApi)=>{
        const viewData = viewCreator(data.markerName, conversionApi);
        if (!viewData) {
            return;
        }
        const elements = conversionApi.mapper.markerNameToElements(data.markerName);
        if (!elements) {
            return;
        }
        for (const element of elements){
            conversionApi.mapper.unbindElementFromMarkerName(element, data.markerName);
            if (element.is('containerElement')) {
                removeMarkerFromAttribute(`data-${viewData.group}-start-before`, element);
                removeMarkerFromAttribute(`data-${viewData.group}-start-after`, element);
                removeMarkerFromAttribute(`data-${viewData.group}-end-before`, element);
                removeMarkerFromAttribute(`data-${viewData.group}-end-after`, element);
            } else {
                conversionApi.writer.clear(conversionApi.writer.createRangeOn(element), element);
            }
        }
        conversionApi.writer.clearClonedElementsGroup(data.markerName);
        evt.stop();
        function removeMarkerFromAttribute(attributeName, element) {
            if (element.hasAttribute(attributeName)) {
                const markerNames = new Set(element.getAttribute(attributeName).split(','));
                markerNames.delete(viewData.name);
                if (markerNames.size == 0) {
                    conversionApi.writer.removeAttribute(attributeName, element);
                } else {
                    conversionApi.writer.setAttribute(attributeName, Array.from(markerNames).join(','), element);
                }
            }
        }
    };
}
/**
 * Function factory that creates a converter which converts the set/change/remove attribute changes from the model to the view.
 *
 * Attributes from the model are converted to the view element attributes in the view. You may provide a custom function to generate
 * a key-value attribute pair to add/change/remove. If not provided, model attributes will be converted to view element
 * attributes on a one-to-one basis.
 *
 * *Note:** The provided attribute creator should always return the same `key` for a given attribute from the model.
 *
 * The converter automatically consumes the corresponding value from the consumables list and stops the event (see
 * {@link module:engine/conversion/downcastdispatcher~DowncastDispatcher}).
 *
 * ```ts
 * modelDispatcher.on( 'attribute:customAttr:myElem', changeAttribute( ( value, data ) => {
 * 	// Change attribute key from `customAttr` to `class` in the view.
 * 	const key = 'class';
 * 	let value = data.attributeNewValue;
 *
 * 	// Force attribute value to 'empty' if the model element is empty.
 * 	if ( data.item.childCount === 0 ) {
 * 		value = 'empty';
 * 	}
 *
 * 	// Return the key-value pair.
 * 	return { key, value };
 * } ) );
 * ```
 *
 * @param attributeCreator Function returning an object with two properties: `key` and `value`, which
 * represent the attribute key and attribute value to be set on a {@link module:engine/view/element~Element view element}.
 * The function is passed the model attribute value as the first parameter and additional data about the change as the second parameter.
 * @returns Set/change attribute converter.
 */ function changeAttribute(attributeCreator) {
    return (evt, data, conversionApi)=>{
        if (!conversionApi.consumable.test(data.item, evt.name)) {
            return;
        }
        const oldAttribute = attributeCreator(data.attributeOldValue, conversionApi, data);
        const newAttribute = attributeCreator(data.attributeNewValue, conversionApi, data);
        if (!oldAttribute && !newAttribute) {
            return;
        }
        conversionApi.consumable.consume(data.item, evt.name);
        const viewElement = conversionApi.mapper.toViewElement(data.item);
        const viewWriter = conversionApi.writer;
        // If model item cannot be mapped to a view element, it means item is not an `Element` instance but a `TextProxy` node.
        // Only elements can have attributes in a view so do not proceed for anything else (#1587).
        if (!viewElement) {
            /**
             * This error occurs when a {@link module:engine/model/textproxy~TextProxy text node's} attribute is to be downcasted
             * by an {@link module:engine/conversion/conversion~Conversion#attributeToAttribute `Attribute to Attribute converter`}.
             * In most cases it is caused by converters misconfiguration when only "generic" converter is defined:
             *
             * ```ts
             * editor.conversion.for( 'downcast' ).attributeToAttribute( {
             * 	model: 'attribute-name',
             * 	view: 'attribute-name'
             * } ) );
             * ```
             *
             * and given attribute is used on text node, for example:
             *
             * ```ts
             * model.change( writer => {
             * 	writer.insertText( 'Foo', { 'attribute-name': 'bar' }, parent, 0 );
             * } );
             * ```
             *
             * In such cases, to convert the same attribute for both {@link module:engine/model/element~Element}
             * and {@link module:engine/model/textproxy~TextProxy `Text`} nodes, text specific
             * {@link module:engine/conversion/conversion~Conversion#attributeToElement `Attribute to Element converter`}
             * with higher {@link module:utils/priorities~PriorityString priority} must also be defined:
             *
             * ```ts
             * editor.conversion.for( 'downcast' ).attributeToElement( {
             * 	model: {
             * 		key: 'attribute-name',
             * 		name: '$text'
             * 	},
             * 	view: ( value, { writer } ) => {
             * 		return writer.createAttributeElement( 'span', { 'attribute-name': value } );
             * 	},
             * 	converterPriority: 'high'
             * } ) );
             * ```
             *
             * @error conversion-attribute-to-attribute-on-text
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('conversion-attribute-to-attribute-on-text', conversionApi.dispatcher, data);
        }
        // First remove the old attribute if there was one.
        if (data.attributeOldValue !== null && oldAttribute) {
            if (oldAttribute.key == 'class') {
                const classes = typeof oldAttribute.value == 'string' ? oldAttribute.value.split(/\s+/) : oldAttribute.value;
                for (const className of classes){
                    viewWriter.removeClass(className, viewElement);
                }
            } else if (oldAttribute.key == 'style') {
                if (typeof oldAttribute.value == 'string') {
                    const styles = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewWriter.document.stylesProcessor);
                    styles.setTo(oldAttribute.value);
                    for (const [key] of styles.getStylesEntries()){
                        viewWriter.removeStyle(key, viewElement);
                    }
                } else {
                    const keys = Object.keys(oldAttribute.value);
                    for (const key of keys){
                        viewWriter.removeStyle(key, viewElement);
                    }
                }
            } else {
                viewWriter.removeAttribute(oldAttribute.key, viewElement);
            }
        }
        // Then set the new attribute.
        if (data.attributeNewValue !== null && newAttribute) {
            if (newAttribute.key == 'class') {
                const classes = typeof newAttribute.value == 'string' ? newAttribute.value.split(/\s+/) : newAttribute.value;
                for (const className of classes){
                    viewWriter.addClass(className, viewElement);
                }
            } else if (newAttribute.key == 'style') {
                if (typeof newAttribute.value == 'string') {
                    const styles = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$stylesmap$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](viewWriter.document.stylesProcessor);
                    styles.setTo(newAttribute.value);
                    for (const [key, value] of styles.getStylesEntries()){
                        viewWriter.setStyle(key, value, viewElement);
                    }
                } else {
                    const keys = Object.keys(newAttribute.value);
                    for (const key of keys){
                        viewWriter.setStyle(key, newAttribute.value[key], viewElement);
                    }
                }
            } else {
                viewWriter.setAttribute(newAttribute.key, newAttribute.value, viewElement);
            }
        }
    };
}
/**
 * Function factory that creates a converter which converts the text inside marker's range. The converter wraps the text with
 * {@link module:engine/view/attributeelement~AttributeElement} created from the provided descriptor.
 * See {link module:engine/conversion/downcasthelpers~createViewElementFromHighlightDescriptor}.
 *
 * It can also be used to convert the selection that is inside a marker. In that case, an empty attribute element will be
 * created and the selection will be put inside it.
 *
 * If the highlight descriptor does not provide the `priority` property, `10` will be used.
 *
 * If the highlight descriptor does not provide the `id` property, the name of the marker will be used.
 *
 * This converter binds the created {@link module:engine/view/attributeelement~AttributeElement attribute elemens} with the marker name
 * using the {@link module:engine/conversion/mapper~Mapper#bindElementToMarker} method.
 */ function highlightText(highlightDescriptor) {
    return (evt, data, conversionApi)=>{
        if (!data.item) {
            return;
        }
        if (!(data.item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || data.item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) && !data.item.is('$textProxy')) {
            return;
        }
        const descriptor = prepareDescriptor(highlightDescriptor, data, conversionApi);
        if (!descriptor) {
            return;
        }
        if (!conversionApi.consumable.consume(data.item, evt.name)) {
            return;
        }
        const viewWriter = conversionApi.writer;
        const viewElement = createViewElementFromHighlightDescriptor(viewWriter, descriptor);
        const viewSelection = viewWriter.document.selection;
        if (data.item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$selection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] || data.item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$documentselection$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
            viewWriter.wrap(viewSelection.getFirstRange(), viewElement);
        } else {
            const viewRange = conversionApi.mapper.toViewRange(data.range);
            const rangeAfterWrap = viewWriter.wrap(viewRange, viewElement);
            for (const element of rangeAfterWrap.getItems()){
                if (element.is('attributeElement') && element.isSimilar(viewElement)) {
                    conversionApi.mapper.bindElementToMarker(element, data.markerName);
                    break;
                }
            }
        }
    };
}
/**
 * Converter function factory. It creates a function which applies the marker's highlight to an element inside the marker's range.
 *
 * The converter checks if an element has the `addHighlight` function stored as a
 * {@link module:engine/view/element~Element#_setCustomProperty custom property} and, if so, uses it to apply the highlight.
 * In such case the converter will consume all element's children, assuming that they were handled by the element itself.
 *
 * When the `addHighlight` custom property is not present, the element is not converted in any special way.
 * This means that converters will proceed to convert the element's child nodes.
 *
 * If the highlight descriptor does not provide the `priority` property, `10` will be used.
 *
 * If the highlight descriptor does not provide the `id` property, the name of the marker will be used.
 *
 * This converter binds altered {@link module:engine/view/containerelement~ContainerElement container elements} with the marker name using
 * the {@link module:engine/conversion/mapper~Mapper#bindElementToMarker} method.
 */ function highlightElement(highlightDescriptor) {
    return (evt, data, conversionApi)=>{
        if (!data.item) {
            return;
        }
        if (!(data.item instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$element$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            return;
        }
        const descriptor = prepareDescriptor(highlightDescriptor, data, conversionApi);
        if (!descriptor) {
            return;
        }
        if (!conversionApi.consumable.test(data.item, evt.name)) {
            return;
        }
        const viewElement = conversionApi.mapper.toViewElement(data.item);
        if (viewElement && viewElement.getCustomProperty('addHighlight')) {
            // Consume element itself.
            conversionApi.consumable.consume(data.item, evt.name);
            // Consume all children nodes.
            for (const value of __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(data.item)){
                conversionApi.consumable.consume(value.item, evt.name);
            }
            const addHighlightCallback = viewElement.getCustomProperty('addHighlight');
            addHighlightCallback(viewElement, descriptor, conversionApi.writer);
            conversionApi.mapper.bindElementToMarker(viewElement, data.markerName);
        }
    };
}
/**
 * Function factory that creates a converter which converts the removing model marker to the view.
 *
 * Both text nodes and elements are handled by this converter but they are handled a bit differently.
 *
 * Text nodes are unwrapped using the {@link module:engine/view/attributeelement~AttributeElement attribute element} created from the
 * provided highlight descriptor. See {link module:engine/conversion/downcasthelpers~HighlightDescriptor}.
 *
 * For elements, the converter checks if an element has the `removeHighlight` function stored as a
 * {@link module:engine/view/element~Element#_setCustomProperty custom property}. If so, it uses it to remove the highlight.
 * In such case, the children of that element will not be converted.
 *
 * When `removeHighlight` is not present, the element is not converted in any special way.
 * The converter will proceed to convert the element's child nodes instead.
 *
 * If the highlight descriptor does not provide the `priority` property, `10` will be used.
 *
 * If the highlight descriptor does not provide the `id` property, the name of the marker will be used.
 *
 * This converter unbinds elements from the marker name.
 */ function removeHighlight(highlightDescriptor) {
    return (evt, data, conversionApi)=>{
        // This conversion makes sense only for non-collapsed range.
        if (data.markerRange.isCollapsed) {
            return;
        }
        const descriptor = prepareDescriptor(highlightDescriptor, data, conversionApi);
        if (!descriptor) {
            return;
        }
        // View element that will be used to unwrap `AttributeElement`s.
        const viewHighlightElement = createViewElementFromHighlightDescriptor(conversionApi.writer, descriptor);
        // Get all elements bound with given marker name.
        const elements = conversionApi.mapper.markerNameToElements(data.markerName);
        if (!elements) {
            return;
        }
        for (const element of elements){
            conversionApi.mapper.unbindElementFromMarkerName(element, data.markerName);
            if (element.is('attributeElement')) {
                conversionApi.writer.unwrap(conversionApi.writer.createRangeOn(element), viewHighlightElement);
            } else {
                // if element.is( 'containerElement' ).
                const removeHighlightCallback = element.getCustomProperty('removeHighlight');
                removeHighlightCallback(element, descriptor.id, conversionApi.writer);
            }
        }
        conversionApi.writer.clearClonedElementsGroup(data.markerName);
        evt.stop();
    };
}
/**
 * Model element to view element conversion helper.
 *
 * See {@link ~DowncastHelpers#elementToElement `.elementToElement()` downcast helper} for examples and config params description.
 *
 * @param config Conversion configuration.
 * @param config.model The description or a name of the model element to convert.
 * @param config.model.attributes List of attributes triggering element reconversion.
 * @param config.model.children Should reconvert element if the list of model child nodes changed.
 * @returns Conversion helper.
 */ function downcastElementToElement(config) {
    const model = normalizeModelElementConfig(config.model);
    const view = normalizeToElementConfig(config.view, 'container');
    // Trigger reconversion on children list change if element is a subject to any reconversion.
    // This is required to be able to trigger Differ#refreshItem() on a direct child of the reconverted element.
    if (model.attributes.length) {
        model.children = true;
    }
    return (dispatcher)=>{
        dispatcher.on(`insert:${model.name}`, insertElement(view, createConsumer(model)), {
            priority: config.converterPriority || 'normal'
        });
        if (model.children || model.attributes.length) {
            dispatcher.on('reduceChanges', createChangeReducer(model), {
                priority: 'low'
            });
        }
    };
}
/**
 * Model element to view structure conversion helper.
 *
 * See {@link ~DowncastHelpers#elementToStructure `.elementToStructure()` downcast helper} for examples and config params description.
 *
 * @param config Conversion configuration.
 * @returns Conversion helper.
 */ function downcastElementToStructure(config) {
    const model = normalizeModelElementConfig(config.model);
    const view = normalizeToElementConfig(config.view, 'container');
    // Trigger reconversion on children list change because it always needs to use slots to put children in proper places.
    // This is required to be able to trigger Differ#refreshItem() on a direct child of the reconverted element.
    model.children = true;
    return (dispatcher)=>{
        if (dispatcher._conversionApi.schema.checkChild(model.name, '$text')) {
            /**
             * This error occurs when a {@link module:engine/model/element~Element model element} is downcasted
             * via {@link module:engine/conversion/downcasthelpers~DowncastHelpers#elementToStructure} helper but the element was
             * allowed to host `$text` by the {@link module:engine/model/schema~Schema model schema}.
             *
             * For instance, this may be the result of `myElement` allowing the content of
             * {@glink framework/deep-dive/schema#generic-items `$block`} in its schema definition:
             *
             * ```ts
             * // Element definition in schema.
             * schema.register( 'myElement', {
             * 	allowContentOf: '$block',
             *
             * 	// ...
             * } );
             *
             * // ...
             *
             * // Conversion of myElement with the use of elementToStructure().
             * editor.conversion.for( 'downcast' ).elementToStructure( {
             * 	model: 'myElement',
             * 	view: ( modelElement, { writer } ) => {
             * 		// ...
             * 	}
             * } );
             * ```
             *
             * In such case, {@link module:engine/conversion/downcasthelpers~DowncastHelpers#elementToElement `elementToElement()`} helper
             * can be used instead to get around this problem:
             *
             * ```ts
             * editor.conversion.for( 'downcast' ).elementToElement( {
             * 	model: 'myElement',
             * 	view: ( modelElement, { writer } ) => {
             * 		// ...
             * 	}
             * } );
             * ```
             *
             * @error conversion-element-to-structure-disallowed-text
             * @param {String} elementName The name of the element the structure is to be created for.
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('conversion-element-to-structure-disallowed-text', dispatcher, {
                elementName: model.name
            });
        }
        dispatcher.on(`insert:${model.name}`, insertStructure(view, createConsumer(model)), {
            priority: config.converterPriority || 'normal'
        });
        dispatcher.on('reduceChanges', createChangeReducer(model), {
            priority: 'low'
        });
    };
}
/**
 * Model attribute to view element conversion helper.
 *
 * See {@link ~DowncastHelpers#attributeToElement `.attributeToElement()` downcast helper} for examples.
 *
 * @param config Conversion configuration.
 * @param config.model The key of the attribute to convert from or a `{ key, values }` object. `values` is an array
 * of `String`s with possible values if the model attribute is an enumerable.
 * @param config.view A view element definition or a function that takes the model attribute value and
 * {@link module:engine/view/downcastwriter~DowncastWriter view downcast writer} as parameters and returns a view attribute element.
 * If `config.model.values` is given, `config.view` should be an object assigning values from `config.model.values` to view element
 * definitions or functions.
 * @param config.converterPriority Converter priority.
 * @returns Conversion helper.
 */ function downcastAttributeToElement(config) {
    config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__["cloneDeep"])(config);
    let model = config.model;
    if (typeof model == 'string') {
        model = {
            key: model
        };
    }
    let eventName = `attribute:${model.key}`;
    if (model.name) {
        eventName += ':' + model.name;
    }
    if (model.values) {
        for (const modelValue of model.values){
            config.view[modelValue] = normalizeToElementConfig(config.view[modelValue], 'attribute');
        }
    } else {
        config.view = normalizeToElementConfig(config.view, 'attribute');
    }
    const elementCreator = getFromAttributeCreator(config);
    return (dispatcher)=>{
        dispatcher.on(eventName, wrap(elementCreator), {
            priority: config.converterPriority || 'normal'
        });
    };
}
/**
 * Model attribute to view attribute conversion helper.
 *
 * See {@link ~DowncastHelpers#attributeToAttribute `.attributeToAttribute()` downcast helper} for examples.
 *
 * @param config Conversion configuration.
 * @param config.model The key of the attribute to convert from or a `{ key, values, [ name ] }` object describing
 * the attribute key, possible values and, optionally, an element name to convert from.
 * @param config.view A view attribute key, or a `{ key, value }` object or a function that takes the model attribute value and returns
 * a `{ key, value }` object.
 * If `key` is `'class'`, `value` can be a `String` or an array of `String`s. If `key` is `'style'`, `value` is an object with
 * key-value pairs. In other cases, `value` is a `String`.
 * If `config.model.values` is set, `config.view` should be an object assigning values from `config.model.values` to
 * `{ key, value }` objects or a functions.
 * @param config.converterPriority Converter priority.
 * @returns Conversion helper.
 */ function downcastAttributeToAttribute(config) {
    config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__["cloneDeep"])(config);
    let model = config.model;
    if (typeof model == 'string') {
        model = {
            key: model
        };
    }
    let eventName = `attribute:${model.key}`;
    if (model.name) {
        eventName += ':' + model.name;
    }
    if (model.values) {
        for (const modelValue of model.values){
            config.view[modelValue] = normalizeToAttributeConfig(config.view[modelValue]);
        }
    } else {
        config.view = normalizeToAttributeConfig(config.view);
    }
    const elementCreator = getFromAttributeCreator(config);
    return (dispatcher)=>{
        dispatcher.on(eventName, changeAttribute(elementCreator), {
            priority: config.converterPriority || 'normal'
        });
    };
}
/**
 * Model marker to view element conversion helper.
 *
 * See {@link ~DowncastHelpers#markerToElement `.markerToElement()` downcast helper} for examples.
 *
 * @param config Conversion configuration.
 * @param config.model The name of the model marker (or model marker group) to convert.
 * @param config.view A view element definition or a function that takes the model marker data as a parameter and returns a view UI element.
 * @param config.converterPriority Converter priority.
 * @returns Conversion helper.
 */ function downcastMarkerToElement(config) {
    const view = normalizeToElementConfig(config.view, 'ui');
    return (dispatcher)=>{
        dispatcher.on(`addMarker:${config.model}`, insertUIElement(view), {
            priority: config.converterPriority || 'normal'
        });
        dispatcher.on(`removeMarker:${config.model}`, removeUIElement(), {
            priority: config.converterPriority || 'normal'
        });
    };
}
/**
 * Model marker to view data conversion helper.
 *
 * See {@link ~DowncastHelpers#markerToData `markerToData()` downcast helper} to learn more.
 *
 * @returns Conversion helper.
 */ function downcastMarkerToData(config) {
    config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__["cloneDeep"])(config);
    const group = config.model;
    let view = config.view;
    // Default conversion.
    if (!view) {
        view = (markerName)=>({
                group,
                name: markerName.substr(config.model.length + 1)
            });
    }
    return (dispatcher)=>{
        dispatcher.on(`addMarker:${group}`, insertMarkerData(view), {
            priority: config.converterPriority || 'normal'
        });
        dispatcher.on(`removeMarker:${group}`, removeMarkerData(view), {
            priority: config.converterPriority || 'normal'
        });
    };
}
/**
 * Model marker to highlight conversion helper.
 *
 * See {@link ~DowncastHelpers#markerToElement `.markerToElement()` downcast helper} for examples.
 *
 * @param config Conversion configuration.
 * @param config.model The name of the model marker (or model marker group) to convert.
 * @param config.view A highlight descriptor that will be used for highlighting or a function that takes
 * the model marker data as a parameter and returns a highlight descriptor.
 * @param config.converterPriority Converter priority.
 * @returns Conversion helper.
 */ function downcastMarkerToHighlight(config) {
    return (dispatcher)=>{
        dispatcher.on(`addMarker:${config.model}`, highlightText(config.view), {
            priority: config.converterPriority || 'normal'
        });
        dispatcher.on(`addMarker:${config.model}`, highlightElement(config.view), {
            priority: config.converterPriority || 'normal'
        });
        dispatcher.on(`removeMarker:${config.model}`, removeHighlight(config.view), {
            priority: config.converterPriority || 'normal'
        });
    };
}
/**
 * Takes `config.model`, and converts it to an object with normalized structure.
 *
 * @param model Model configuration or element name.
 */ function normalizeModelElementConfig(model) {
    if (typeof model == 'string') {
        model = {
            name: model
        };
    }
    return {
        name: model.name,
        attributes: model.attributes ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(model.attributes) : [],
        children: !!model.children
    };
}
/**
 * Takes `config.view`, and if it is an {@link module:engine/view/elementdefinition~ElementDefinition}, converts it
 * to a function (because lower level converters accept only element creator functions).
 *
 * @param view View configuration.
 * @param viewElementType View element type to create.
 * @returns Element creator function to use in lower level converters.
 */ function normalizeToElementConfig(view, viewElementType) {
    if (typeof view == 'function') {
        // If `view` is already a function, don't do anything.
        return view;
    }
    return (modelData, conversionApi)=>createViewElementFromDefinition(view, conversionApi, viewElementType);
}
/**
 * Creates a view element instance from the provided {@link module:engine/view/elementdefinition~ElementDefinition} and class.
 */ function createViewElementFromDefinition(viewElementDefinition, conversionApi, viewElementType) {
    if (typeof viewElementDefinition == 'string') {
        // If `viewElementDefinition` is given as a `String`, normalize it to an object with `name` property.
        viewElementDefinition = {
            name: viewElementDefinition
        };
    }
    let element;
    const viewWriter = conversionApi.writer;
    const attributes = Object.assign({}, viewElementDefinition.attributes);
    if (viewElementType == 'container') {
        element = viewWriter.createContainerElement(viewElementDefinition.name, attributes);
    } else if (viewElementType == 'attribute') {
        const options = {
            priority: viewElementDefinition.priority || __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$attributeelement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].DEFAULT_PRIORITY
        };
        element = viewWriter.createAttributeElement(viewElementDefinition.name, attributes, options);
    } else {
        // 'ui'.
        element = viewWriter.createUIElement(viewElementDefinition.name, attributes);
    }
    if (viewElementDefinition.styles) {
        const keys = Object.keys(viewElementDefinition.styles);
        for (const key of keys){
            viewWriter.setStyle(key, viewElementDefinition.styles[key], element);
        }
    }
    if (viewElementDefinition.classes) {
        const classes = viewElementDefinition.classes;
        if (typeof classes == 'string') {
            viewWriter.addClass(classes, element);
        } else {
            for (const className of classes){
                viewWriter.addClass(className, element);
            }
        }
    }
    return element;
}
function getFromAttributeCreator(config) {
    if (config.model.values) {
        return (modelAttributeValue, conversionApi, data)=>{
            const view = config.view[modelAttributeValue];
            if (view) {
                return view(modelAttributeValue, conversionApi, data);
            }
            return null;
        };
    } else {
        return config.view;
    }
}
/**
 * Takes the configuration, adds default parameters if they do not exist and normalizes other parameters to be used in downcast converters
 * for generating a view attribute.
 *
 * @param view View configuration.
 */ function normalizeToAttributeConfig(view) {
    if (typeof view == 'string') {
        return (modelAttributeValue)=>({
                key: view,
                value: modelAttributeValue
            });
    } else if (typeof view == 'object') {
        // { key, value, ... }
        if (view.value) {
            return ()=>view;
        } else {
            return (modelAttributeValue)=>({
                    key: view.key,
                    value: modelAttributeValue
                });
        }
    } else {
        // function.
        return view;
    }
}
/**
 * Helper function for `highlight`. Prepares the actual descriptor object using value passed to the converter.
 */ function prepareDescriptor(highlightDescriptor, data, conversionApi) {
    // If passed descriptor is a creator function, call it. If not, just use passed value.
    const descriptor = typeof highlightDescriptor == 'function' ? highlightDescriptor(data, conversionApi) : highlightDescriptor;
    if (!descriptor) {
        return null;
    }
    // Apply default descriptor priority.
    if (!descriptor.priority) {
        descriptor.priority = 10;
    }
    // Default descriptor id is marker name.
    if (!descriptor.id) {
        descriptor.id = data.markerName;
    }
    return descriptor;
}
/**
 * Creates a function that checks a single differ diff item whether it should trigger reconversion.
 *
 * @param model A normalized `config.model` converter configuration.
 * @param model.name The name of element.
 * @param model.attributes The list of attribute names that should trigger reconversion.
 * @param model.children Whether the child list change should trigger reconversion.
 */ function createChangeReducerCallback(model) {
    return (node, change)=>{
        if (!node.is('element', model.name)) {
            return false;
        }
        if (change.type == 'attribute') {
            if (model.attributes.includes(change.attributeKey)) {
                return true;
            }
        } else {
            /* istanbul ignore else: This is always true because otherwise it would not register a reducer callback. -- @preserve */ if (model.children) {
                return true;
            }
        }
        return false;
    };
}
/**
 * Creates a `reduceChanges` event handler for reconversion.
 *
 * @param model A normalized `config.model` converter configuration.
 * @param model.name The name of element.
 * @param model.attributes The list of attribute names that should trigger reconversion.
 * @param model.children Whether the child list change should trigger reconversion.
 */ function createChangeReducer(model) {
    const shouldReplace = createChangeReducerCallback(model);
    return (evt, data)=>{
        const reducedChanges = [];
        if (!data.reconvertedElements) {
            data.reconvertedElements = new Set();
        }
        for (const change of data.changes){
            // For attribute use node affected by the change.
            // For insert or remove use parent element because we need to check if it's added/removed child.
            const node = change.type == 'attribute' ? change.range.start.nodeAfter : change.position.parent;
            if (!node || !shouldReplace(node, change)) {
                reducedChanges.push(change);
                continue;
            }
            // If it's already marked for reconversion, so skip this change, otherwise add the diff items.
            if (!data.reconvertedElements.has(node)) {
                data.reconvertedElements.add(node);
                const position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(node);
                let changeIndex = reducedChanges.length;
                // We need to insert remove+reinsert before any other change on and inside the re-converted element.
                // This is important because otherwise we would remove element that had already been modified by the previous change.
                // Note that there could be some element removed before the re-converted element, so we must not break this behavior.
                for(let i = reducedChanges.length - 1; i >= 0; i--){
                    const change = reducedChanges[i];
                    const changePosition = change.type == 'attribute' ? change.range.start : change.position;
                    const positionRelation = changePosition.compareWith(position);
                    if (positionRelation == 'before' || change.type == 'remove' && positionRelation == 'same') {
                        break;
                    }
                    changeIndex = i;
                }
                reducedChanges.splice(changeIndex, 0, {
                    type: 'remove',
                    name: node.name,
                    position,
                    length: 1
                }, {
                    type: 'reinsert',
                    name: node.name,
                    position,
                    length: 1
                });
            }
        }
        data.changes = reducedChanges;
    };
}
/**
 * Creates a function that checks if an element and its watched attributes can be consumed and consumes them.
 *
 * @param model A normalized `config.model` converter configuration.
 * @param model.name The name of element.
 * @param model.attributes The list of attribute names that should trigger reconversion.
 * @param model.children Whether the child list change should trigger reconversion.
 */ function createConsumer(model) {
    return (node, consumable, options = {})=>{
        const events = [
            'insert'
        ];
        // Collect all set attributes that are triggering conversion.
        for (const attributeName of model.attributes){
            if (node.hasAttribute(attributeName)) {
                events.push(`attribute:${attributeName}`);
            }
        }
        if (!events.every((event)=>consumable.test(node, event))) {
            return false;
        }
        if (!options.preflight) {
            events.forEach((event)=>consumable.consume(node, event));
        }
        return true;
    };
}
/**
 * Creates a function that create view slots.
 *
 * @returns Function exposed by writer as createSlot().
 */ function createSlotFactory(element, slotsMap, conversionApi) {
    return (writer, modeOrFilter)=>{
        const slot = writer.createContainerElement('$slot');
        let children = null;
        if (modeOrFilter === 'children') {
            children = Array.from(element.getChildren());
        } else if (typeof modeOrFilter == 'function') {
            children = Array.from(element.getChildren()).filter((element)=>modeOrFilter(element));
        } else {
            /**
             * Unknown slot mode was provided to `writer.createSlot()` in downcast converter.
             *
             * @error conversion-slot-mode-unknown
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('conversion-slot-mode-unknown', conversionApi.dispatcher, {
                modeOrFilter
            });
        }
        slotsMap.set(slot, children);
        return slot;
    };
}
/**
 * Checks if all children are covered by slots and there is no child that landed in multiple slots.
 */ function validateSlotsChildren(element, slotsMap, conversionApi) {
    const childrenInSlots = Array.from(slotsMap.values()).flat();
    const uniqueChildrenInSlots = new Set(childrenInSlots);
    if (uniqueChildrenInSlots.size != childrenInSlots.length) {
        /**
         * Filters provided to `writer.createSlot()` overlap (at least two filters accept the same child element).
         *
         * @error conversion-slot-filter-overlap
         * @param {module:engine/model/element~Element} element The element of which children would not be properly
         * allocated to multiple slots.
         */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('conversion-slot-filter-overlap', conversionApi.dispatcher, {
            element
        });
    }
    if (uniqueChildrenInSlots.size != element.childCount) {
        /**
         * Filters provided to `writer.createSlot()` are incomplete and exclude at least one children element (one of
         * the children elements would not be assigned to any of the slots).
         *
         * @error conversion-slot-filter-incomplete
         * @param {module:engine/model/element~Element} element The element of which children would not be properly
         * allocated to multiple slots.
         */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('conversion-slot-filter-incomplete', conversionApi.dispatcher, {
            element
        });
    }
}
/**
 * Fill slots with appropriate view elements.
 */ function fillSlots(viewElement, slotsMap, conversionApi, options) {
    // Set temporary position mapping to redirect child view elements into a proper slots.
    conversionApi.mapper.on('modelToViewPosition', toViewPositionMapping, {
        priority: 'highest'
    });
    let currentSlot = null;
    let currentSlotNodes = null;
    // Fill slots with nested view nodes.
    for ([currentSlot, currentSlotNodes] of slotsMap){
        reinsertOrConvertNodes(viewElement, currentSlotNodes, conversionApi, options);
        conversionApi.writer.move(conversionApi.writer.createRangeIn(currentSlot), conversionApi.writer.createPositionBefore(currentSlot));
        conversionApi.writer.remove(currentSlot);
    }
    conversionApi.mapper.off('modelToViewPosition', toViewPositionMapping);
    function toViewPositionMapping(evt, data) {
        const element = data.modelPosition.nodeAfter;
        // Find the proper offset within the slot.
        const index = currentSlotNodes.indexOf(element);
        if (index < 0) {
            return;
        }
        data.viewPosition = data.mapper.findPositionIn(currentSlot, index);
    }
}
/**
 * Inserts view representation of `nodes` into the `viewElement` either by bringing back just removed view nodes
 * or by triggering conversion for them.
 */ function reinsertOrConvertNodes(viewElement, modelNodes, conversionApi, options) {
    // Fill with nested view nodes.
    for (const modelChildNode of modelNodes){
        // Try reinserting the view node for the specified model node...
        if (!reinsertNode(viewElement.root, modelChildNode, conversionApi, options)) {
            // ...or else convert the model element to the view.
            conversionApi.convertItem(modelChildNode);
        }
    }
}
/**
 * Checks if the view for the given model element could be reused and reinserts it to the view.
 *
 * @returns `false` if view element can't be reused.
 */ function reinsertNode(viewRoot, modelNode, conversionApi, options) {
    const { writer, mapper } = conversionApi;
    // Don't reinsert if this is not a reconversion...
    if (!options.reconversion) {
        return false;
    }
    const viewChildNode = mapper.toViewElement(modelNode);
    // ...or there is no view to reinsert or it was already inserted to the view structure...
    if (!viewChildNode || viewChildNode.root == viewRoot) {
        return false;
    }
    // ...or it was strictly marked as not to be reused.
    if (!conversionApi.canReuseView(viewChildNode)) {
        return false;
    }
    // Otherwise reinsert the view node.
    writer.move(writer.createRangeOn(viewChildNode), mapper.toViewPosition(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createBefore(modelNode)));
    return true;
}
/**
 * The default consumer for insert events.
 *
 * @param item Model item.
 * @param consumable The model consumable.
 * @param options.preflight Whether should consume or just check if can be consumed.
 */ function defaultConsumer(item, consumable, { preflight } = {}) {
    if (preflight) {
        return consumable.test(item, 'insert');
    } else {
        return consumable.consume(item, 'insert');
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/upcasthelpers.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "convertSelectionChange",
    ()=>convertSelectionChange,
    "convertText",
    ()=>convertText,
    "convertToModelFragment",
    ()=>convertToModelFragment,
    "default",
    ()=>UpcastHelpers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/matcher.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$conversionhelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/conversionhelpers.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$autoparagraphing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/autoparagraphing.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$priorities$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__priorities$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/priorities.js [app-ssr] (ecmascript) <export default as priorities>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/cloneDeep.js [app-ssr] (ecmascript) <export default as cloneDeep>");
;
;
;
;
;
class UpcastHelpers extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$conversionhelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * View element to model element conversion helper.
     *
     * This conversion results in creating a model element. For example,
     * view `<p>Foo</p>` becomes `<paragraph>Foo</paragraph>` in the model.
     *
     * Keep in mind that the element will be inserted only if it is allowed
     * by {@link module:engine/model/schema~Schema schema} configuration.
     *
     * ```ts
     * editor.conversion.for( 'upcast' ).elementToElement( {
     * 	view: 'p',
     * 	model: 'paragraph'
     * } );
     *
     * editor.conversion.for( 'upcast' ).elementToElement( {
     * 	view: 'p',
     * 	model: 'paragraph',
     * 	converterPriority: 'high'
     * } );
     *
     * editor.conversion.for( 'upcast' ).elementToElement( {
     * 	view: {
     * 		name: 'p',
     * 		classes: 'fancy'
     * 	},
     * 	model: 'fancyParagraph'
     * } );
     *
     * editor.conversion.for( 'upcast' ).elementToElement( {
     * 	view: {
     * 		name: 'p',
     * 		classes: 'heading'
     * 	},
     * 	model: ( viewElement, conversionApi ) => {
     * 		const modelWriter = conversionApi.writer;
     *
     * 		return modelWriter.createElement( 'heading', { level: viewElement.getAttribute( 'data-level' ) } );
     * 	}
     * } );
     * ```
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.view Pattern matching all view elements which should be converted. If not set, the converter
     * will fire for every view element.
     * @param config.model Name of the model element, a model element instance or a function that takes a view element
     * and {@link module:engine/conversion/upcastdispatcher~UpcastConversionApi upcast conversion API}
     * and returns a model element. The model element will be inserted in the model.
     * @param config.converterPriority Converter priority.
     */ elementToElement(config) {
        return this.add(upcastElementToElement(config));
    }
    /**
     * View element to model attribute conversion helper.
     *
     * This conversion results in setting an attribute on a model node. For example, view `<strong>Foo</strong>` becomes
     * `Foo` {@link module:engine/model/text~Text model text node} with `bold` attribute set to `true`.
     *
     * This helper is meant to set a model attribute on all the elements that are inside the converted element:
     *
     * ```
     * <strong>Foo</strong>   -->   <strong><p>Foo</p></strong>   -->   <paragraph><$text bold="true">Foo</$text></paragraph>
     * ```
     *
     * Above is a sample of HTML code, that goes through autoparagraphing (first step) and then is converted (second step).
     * Even though `<strong>` is over `<p>` element, `bold="true"` was added to the text. See
     * {@link module:engine/conversion/upcasthelpers~UpcastHelpers#attributeToAttribute} for comparison.
     *
     * Keep in mind that the attribute will be set only if it is allowed by {@link module:engine/model/schema~Schema schema} configuration.
     *
     * ```ts
     * editor.conversion.for( 'upcast' ).elementToAttribute( {
     * 	view: 'strong',
     * 	model: 'bold'
     * } );
     *
     * editor.conversion.for( 'upcast' ).elementToAttribute( {
     * 	view: 'strong',
     * 	model: 'bold',
     * 	converterPriority: 'high'
     * } );
     *
     * editor.conversion.for( 'upcast' ).elementToAttribute( {
     * 	view: {
     * 		name: 'span',
     * 		classes: 'bold'
     * 	},
     * 	model: 'bold'
     * } );
     *
     * editor.conversion.for( 'upcast' ).elementToAttribute( {
     * 	view: {
     * 		name: 'span',
     * 		classes: [ 'styled', 'styled-dark' ]
     * 	},
     * 	model: {
     * 		key: 'styled',
     * 		value: 'dark'
     * 	}
     * } );
     *
     * editor.conversion.for( 'upcast' ).elementToAttribute( {
     * 	view: {
     * 		name: 'span',
     * 		styles: {
     * 			'font-size': /[\s\S]+/
     * 		}
     * 	},
     * 	model: {
     * 		key: 'fontSize',
     * 		value: ( viewElement, conversionApi ) => {
     * 			const fontSize = viewElement.getStyle( 'font-size' );
     * 			const value = fontSize.substr( 0, fontSize.length - 2 );
     *
     * 			if ( value <= 10 ) {
     * 				return 'small';
     * 			} else if ( value > 12 ) {
     * 				return 'big';
     * 			}
     *
     * 			return null;
     * 		}
     * 	}
     * } );
     * ```
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.view Pattern matching all view elements which should be converted.
     * @param config.model Model attribute key or an object with `key` and `value` properties, describing
     * the model attribute. `value` property may be set as a function that takes a view element and
     * {@link module:engine/conversion/upcastdispatcher~UpcastConversionApi upcast conversion API} and returns the value.
     * If `String` is given, the model attribute value will be set to `true`.
     * @param config.converterPriority Converter priority. Defaults to `low`.
     */ elementToAttribute(config) {
        return this.add(upcastElementToAttribute(config));
    }
    /**
     * View attribute to model attribute conversion helper.
     *
     * This conversion results in setting an attribute on a model node. For example, view `<img src="foo.jpg"></img>` becomes
     * `<imageBlock source="foo.jpg"></imageBlock>` in the model.
     *
     * This helper is meant to convert view attributes from view elements which got converted to the model, so the view attribute
     * is set only on the corresponding model node:
     *
     * ```
     * <div class="dark"><div>foo</div></div>    -->    <div dark="true"><div>foo</div></div>
     * ```
     *
     * Above, `class="dark"` attribute is added only to the `<div>` elements that has it. This is in contrast to
     * {@link module:engine/conversion/upcasthelpers~UpcastHelpers#elementToAttribute} which sets attributes for
     * all the children in the model:
     *
     * ```
     * <strong>Foo</strong>   -->   <strong><p>Foo</p></strong>   -->   <paragraph><$text bold="true">Foo</$text></paragraph>
     * ```
     *
     * Above is a sample of HTML code, that goes through autoparagraphing (first step) and then is converted (second step).
     * Even though `<strong>` is over `<p>` element, `bold="true"` was added to the text.
     *
     * Keep in mind that the attribute will be set only if it is allowed by {@link module:engine/model/schema~Schema schema} configuration.
     *
     * ```ts
     * editor.conversion.for( 'upcast' ).attributeToAttribute( {
     * 	view: 'src',
     * 	model: 'source'
     * } );
     *
     * editor.conversion.for( 'upcast' ).attributeToAttribute( {
     * 	view: { key: 'src' },
     * 	model: 'source'
     * } );
     *
     * editor.conversion.for( 'upcast' ).attributeToAttribute( {
     * 	view: { key: 'src' },
     * 	model: 'source',
     * 	converterPriority: 'normal'
     * } );
     *
     * editor.conversion.for( 'upcast' ).attributeToAttribute( {
     * 	view: {
     * 		key: 'data-style',
     * 		value: /[\s\S]+/
     * 	},
     * 	model: 'styled'
     * } );
     *
     * editor.conversion.for( 'upcast' ).attributeToAttribute( {
     * 	view: {
     * 		name: 'img',
     * 		key: 'class',
     * 		value: 'styled-dark'
     * 	},
     * 	model: {
     * 		key: 'styled',
     * 		value: 'dark'
     * 	}
     * } );
     *
     * editor.conversion.for( 'upcast' ).attributeToAttribute( {
     * 	view: {
     * 		key: 'class',
     * 		value: /styled-[\S]+/
     * 	},
     * 	model: {
     * 		key: 'styled'
     * 		value: ( viewElement, conversionApi ) => {
     * 			const regexp = /styled-([\S]+)/;
     * 			const match = viewElement.getAttribute( 'class' ).match( regexp );
     *
     * 			return match[ 1 ];
     * 		}
     * 	}
     * } );
     * ```
     *
     * Converting styles works a bit differently as it requires `view.styles` to be an object and by default
     * a model attribute will be set to `true` by such a converter. You can set the model attribute to any value by providing the `value`
     * callback that returns the desired value.
     *
     * ```ts
     * // Default conversion of font-weight style will result in setting bold attribute to true.
     * editor.conversion.for( 'upcast' ).attributeToAttribute( {
     * 	view: {
     * 		styles: {
     * 			'font-weight': 'bold'
     * 		}
     * 	},
     * 	model: 'bold'
     * } );
     *
     * // This converter will pass any style value to the `lineHeight` model attribute.
     * editor.conversion.for( 'upcast' ).attributeToAttribute( {
     * 	view: {
     * 		styles: {
     * 			'line-height': /[\s\S]+/
     * 		}
     * 	},
     * 	model: {
     * 		key: 'lineHeight',
     * 		value: ( viewElement, conversionApi ) => viewElement.getStyle( 'line-height' )
     * 	}
     * } );
     * ```
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.view Specifies which view attribute will be converted. If a `String` is passed,
     * attributes with given key will be converted. If an `Object` is passed, it must have a required `key` property,
     * specifying view attribute key, and may have an optional `value` property, specifying view attribute value and optional `name`
     * property specifying a view element name from/on which the attribute should be converted. `value` can be given as a `String`,
     * a `RegExp` or a function callback, that takes view attribute value as the only parameter and returns `Boolean`.
     * @param config.model Model attribute key or an object with `key` and `value` properties, describing
     * the model attribute. `value` property may be set as a function that takes a view element and
     * {@link module:engine/conversion/upcastdispatcher~UpcastConversionApi upcast conversion API} and returns the value.
     * If `String` is given, the model attribute value will be same as view attribute value.
     * @param config.converterPriority Converter priority. Defaults to `low`.
     */ attributeToAttribute(config) {
        return this.add(upcastAttributeToAttribute(config));
    }
    /**
     * View element to model marker conversion helper.
     *
     * This conversion results in creating a model marker. For example, if the marker was stored in a view as an element:
     * `<p>Fo<span data-marker="comment" data-comment-id="7"></span>o</p><p>B<span data-marker="comment" data-comment-id="7"></span>ar</p>`,
     * after the conversion is done, the marker will be available in
     * {@link module:engine/model/model~Model#markers model document markers}.
     *
     * **Note**: When this helper is used in the data upcast in combination with
     * {@link module:engine/conversion/downcasthelpers~DowncastHelpers#markerToData `#markerToData()`} in the data downcast,
     * then invalid HTML code (e.g. a span between table cells) may be produced by the latter converter.
     *
     * In most of the cases, the {@link #dataToMarker} should be used instead.
     *
     * ```ts
     * editor.conversion.for( 'upcast' ).elementToMarker( {
     * 	view: 'marker-search',
     * 	model: 'search'
     * } );
     *
     * editor.conversion.for( 'upcast' ).elementToMarker( {
     * 	view: 'marker-search',
     * 	model: 'search',
     * 	converterPriority: 'high'
     * } );
     *
     * editor.conversion.for( 'upcast' ).elementToMarker( {
     * 	view: 'marker-search',
     * 	model: ( viewElement, conversionApi ) => 'comment:' + viewElement.getAttribute( 'data-comment-id' )
     * } );
     *
     * editor.conversion.for( 'upcast' ).elementToMarker( {
     * 	view: {
     * 		name: 'span',
     * 		attributes: {
     * 			'data-marker': 'search'
     * 		}
     * 	},
     * 	model: 'search'
     * } );
     * ```
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.view Pattern matching all view elements which should be converted.
     * @param config.model Name of the model marker, or a function that takes a view element and returns
     * a model marker name.
     * @param config.converterPriority Converter priority.
     */ elementToMarker(config) {
        return this.add(upcastElementToMarker(config));
    }
    /**
     * View-to-model marker conversion helper.
     *
     * Converts view data created by {@link module:engine/conversion/downcasthelpers~DowncastHelpers#markerToData `#markerToData()`}
     * back to a model marker.
     *
     * This converter looks for specific view elements and view attributes that mark marker boundaries. See
     * {@link module:engine/conversion/downcasthelpers~DowncastHelpers#markerToData `#markerToData()`} to learn what view data
     * is expected by this converter.
     *
     * The `config.view` property is equal to the marker group name to convert.
     *
     * By default, this converter creates markers with the `group:name` name convention (to match the default `markerToData` conversion).
     *
     * The conversion configuration can take a function that will generate a marker name.
     * If such function is set as the `config.model` parameter, it is passed the `name` part from the view element or attribute and it is
     * expected to return a string with the marker name.
     *
     * Basic usage:
     *
     * ```ts
     * // Using the default conversion.
     * // In this case, all markers from the `comment` group will be converted.
     * // The conversion will look for `<comment-start>` and `<comment-end>` tags and
     * // `data-comment-start-before`, `data-comment-start-after`,
     * // `data-comment-end-before` and `data-comment-end-after` attributes.
     * editor.conversion.for( 'upcast' ).dataToMarker( {
     * 	view: 'comment'
     * } );
     * ```
     *
     * An example of a model that may be generated by this conversion:
     *
     * ```
     * // View:
     * <p>Foo<comment-start name="commentId:uid"></comment-start>bar</p>
     * <figure data-comment-end-after="commentId:uid" class="image"><img src="abc.jpg" /></figure>
     *
     * // Model:
     * <paragraph>Foo[bar</paragraph>
     * <imageBlock src="abc.jpg"></imageBlock>]
     * ```
     *
     * Where `[]` are boundaries of a marker that will receive the `comment:commentId:uid` name.
     *
     * Other examples of usage:
     *
     * ```ts
     * // Using a custom function which is the same as the default conversion:
     * editor.conversion.for( 'upcast' ).dataToMarker( {
     * 	view: 'comment',
     * 	model: ( name, conversionApi ) => 'comment:' + name,
     * } );
     *
     * // Using the converter priority:
     * editor.conversion.for( 'upcast' ).dataToMarker( {
     * 	view: 'comment',
     * 	model: ( name, conversionApi ) => 'comment:' + name,
     * 	converterPriority: 'high'
     * } );
     * ```
     *
     * See {@link module:engine/conversion/conversion~Conversion#for `conversion.for()`} to learn how to add a converter
     * to the conversion process.
     *
     * @param config Conversion configuration.
     * @param config.view The marker group name to convert.
     * @param config.model A function that takes the `name` part from the view element or attribute and
     * {@link module:engine/conversion/upcastdispatcher~UpcastConversionApi upcast conversion API} and returns the marker name.
     * @param config.converterPriority Converter priority.
     */ dataToMarker(config) {
        return this.add(upcastDataToMarker(config));
    }
}
function convertToModelFragment() {
    return (evt, data, conversionApi)=>{
        // Second argument in `consumable.consume` is discarded for ViewDocumentFragment but is needed for ViewElement.
        if (!data.modelRange && conversionApi.consumable.consume(data.viewItem, {
            name: true
        })) {
            const { modelRange, modelCursor } = conversionApi.convertChildren(data.viewItem, data.modelCursor);
            data.modelRange = modelRange;
            data.modelCursor = modelCursor;
        }
    };
}
function convertText() {
    return (evt, data, { schema, consumable, writer })=>{
        let position = data.modelCursor;
        // When node is already converted then do nothing.
        if (!consumable.test(data.viewItem)) {
            return;
        }
        if (!schema.checkChild(position, '$text')) {
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$autoparagraphing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isParagraphable"])(position, '$text', schema)) {
                return;
            }
            // Do not auto-paragraph whitespaces.
            if (data.viewItem.data.trim().length == 0) {
                return;
            }
            // Wrap `$text` in paragraph and include any marker that is directly before `$text`. See #13053.
            const nodeBefore = position.nodeBefore;
            position = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$autoparagraphing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["wrapInParagraph"])(position, writer);
            if (nodeBefore && nodeBefore.is('element', '$marker')) {
                // Move `$marker` to the paragraph.
                writer.move(writer.createRangeOn(nodeBefore), position);
                position = writer.createPositionAfter(nodeBefore);
            }
        }
        consumable.consume(data.viewItem);
        const text = writer.createText(data.viewItem.data);
        writer.insert(text, position);
        data.modelRange = writer.createRange(position, position.getShiftedBy(text.offsetSize));
        data.modelCursor = data.modelRange.end;
    };
}
function convertSelectionChange(model, mapper) {
    return (evt, data)=>{
        const viewSelection = data.newSelection;
        const ranges = [];
        for (const viewRange of viewSelection.getRanges()){
            ranges.push(mapper.toModelRange(viewRange));
        }
        const modelSelection = model.createSelection(ranges, {
            backward: viewSelection.isBackward
        });
        if (!modelSelection.isEqual(model.document.selection)) {
            model.change((writer)=>{
                writer.setSelection(modelSelection);
            });
        }
    };
}
/**
 * View element to model element conversion helper.
 *
 * See {@link ~UpcastHelpers#elementToElement `.elementToElement()` upcast helper} for examples.
 *
 * @param config Conversion configuration.
 * @param config.view Pattern matching all view elements which should be converted. If not
 * set, the converter will fire for every view element.
 * @param config.model Name of the model element, a model element
 * instance or a function that takes a view element and returns a model element. The model element will be inserted in the model.
 * @param config.converterPriority Converter priority.
 * @returns Conversion helper.
 */ function upcastElementToElement(config) {
    config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__["cloneDeep"])(config);
    const converter = prepareToElementConverter(config);
    const elementName = getViewElementNameFromConfig(config.view);
    const eventName = elementName ? `element:${elementName}` : 'element';
    return (dispatcher)=>{
        dispatcher.on(eventName, converter, {
            priority: config.converterPriority || 'normal'
        });
    };
}
/**
 * View element to model attribute conversion helper.
 *
 * See {@link ~UpcastHelpers#elementToAttribute `.elementToAttribute()` upcast helper} for examples.
 *
 * @param config Conversion configuration.
 * @param config.view Pattern matching all view elements which should be converted.
 * @param config.model Model attribute key or an object with `key` and `value` properties, describing
 * the model attribute. `value` property may be set as a function that takes a view element and returns the value.
 * If `String` is given, the model attribute value will be set to `true`.
 * @param config.converterPriority Converter priority. Defaults to `low`.
 * @returns Conversion helper.
 */ function upcastElementToAttribute(config) {
    config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__["cloneDeep"])(config);
    normalizeModelAttributeConfig(config);
    const converter = prepareToAttributeConverter(config, false);
    const elementName = getViewElementNameFromConfig(config.view);
    const eventName = elementName ? `element:${elementName}` : 'element';
    return (dispatcher)=>{
        dispatcher.on(eventName, converter, {
            priority: config.converterPriority || 'low'
        });
    };
}
/**
 * View attribute to model attribute conversion helper.
 *
 * See {@link ~UpcastHelpers#attributeToAttribute `.attributeToAttribute()` upcast helper} for examples.
 *
 * @param config Conversion configuration.
 * @param config.view Specifies which view attribute will be converted. If a `String` is passed,
 * attributes with given key will be converted. If an `Object` is passed, it must have a required `key` property,
 * specifying view attribute key, and may have an optional `value` property, specifying view attribute value and optional `name`
 * property specifying a view element name from/on which the attribute should be converted. `value` can be given as a `String`,
 * a `RegExp` or a function callback, that takes view attribute value as the only parameter and returns `Boolean`.
 * @param config.model Model attribute key or an object with `key` and `value` properties, describing
 * the model attribute. `value` property may be set as a function that takes a view element and returns the value.
 * If `String` is given, the model attribute value will be same as view attribute value.
 * @param config.converterPriority Converter priority. Defaults to `low`.
 * @returns Conversion helper.
 */ function upcastAttributeToAttribute(config) {
    config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__["cloneDeep"])(config);
    let viewKey = null;
    if (typeof config.view == 'string' || config.view.key) {
        viewKey = normalizeViewAttributeKeyValueConfig(config);
    }
    normalizeModelAttributeConfig(config, viewKey);
    const converter = prepareToAttributeConverter(config, true);
    return (dispatcher)=>{
        dispatcher.on('element', converter, {
            priority: config.converterPriority || 'low'
        });
    };
}
/**
 * View element to model marker conversion helper.
 *
 * See {@link ~UpcastHelpers#elementToMarker `.elementToMarker()` upcast helper} for examples.
 *
 * @param config Conversion configuration.
 * @param config.view Pattern matching all view elements which should be converted.
 * @param config.model Name of the model marker, or a function that takes a view element and returns
 * a model marker name.
 * @param config.converterPriority Converter priority.
 * @returns Conversion helper.
 */ function upcastElementToMarker(config) {
    const model = normalizeElementToMarkerModelConfig(config.model);
    return upcastElementToElement({
        ...config,
        model
    });
}
/**
 * View data to model marker conversion helper.
 *
 * See {@link ~UpcastHelpers#dataToMarker} to learn more.
 *
 * @returns Conversion helper.
 */ function upcastDataToMarker(config) {
    config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeep$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeep$3e$__["cloneDeep"])(config);
    // Default conversion.
    if (!config.model) {
        config.model = (name)=>{
            return name ? config.view + ':' + name : config.view;
        };
    }
    const normalizedConfig = {
        view: config.view,
        model: config.model
    };
    const converterStart = prepareToElementConverter(normalizeDataToMarkerConfig(normalizedConfig, 'start'));
    const converterEnd = prepareToElementConverter(normalizeDataToMarkerConfig(normalizedConfig, 'end'));
    return (dispatcher)=>{
        dispatcher.on(`element:${config.view}-start`, converterStart, {
            priority: config.converterPriority || 'normal'
        });
        dispatcher.on(`element:${config.view}-end`, converterEnd, {
            priority: config.converterPriority || 'normal'
        });
        // Below is a hack that is needed to properly handle `converterPriority` for both elements and attributes.
        // Attribute conversion needs to be performed *after* element conversion.
        // This converter handles both element conversion and attribute conversion, which means that if a single
        // `config.converterPriority` is used, it will lead to problems. For example, if the `'high'` priority is used,
        // the attribute conversion will be performed before a lot of element upcast converters.
        // On the other hand, we want to support `config.converterPriority` and converter overwriting.
        //
        // To make it work, we need to do some extra processing for priority for attribute converter.
        // Priority `'low'` value should be the base value and then we will change it depending on `config.converterPriority` value.
        //
        // This hack probably would not be needed if attributes are upcasted separately.
        //
        const basePriority = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$priorities$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__priorities$3e$__["priorities"].low;
        const maxPriority = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$priorities$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__priorities$3e$__["priorities"].highest;
        const priorityFactor = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$priorities$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__priorities$3e$__["priorities"].get(config.converterPriority) / maxPriority; // Number in range [ -1, 1 ].
        dispatcher.on('element', upcastAttributeToMarker(normalizedConfig), {
            priority: basePriority + priorityFactor
        });
    };
}
/**
 * Function factory, returns a callback function which converts view attributes to a model marker.
 *
 * The converter looks for elements with `data-group-start-before`, `data-group-start-after`, `data-group-end-before`
 * and `data-group-end-after` attributes and inserts `$marker` model elements before/after those elements.
 * `group` part is specified in `config.view`.
 *
 * @returns Marker converter.
 */ function upcastAttributeToMarker(config) {
    return (evt, data, conversionApi)=>{
        const attrName = `data-${config.view}`;
        // Check if any attribute for the given view item can be consumed before changing the conversion data
        // and consuming view items with these attributes.
        if (!conversionApi.consumable.test(data.viewItem, {
            attributes: attrName + '-end-after'
        }) && !conversionApi.consumable.test(data.viewItem, {
            attributes: attrName + '-start-after'
        }) && !conversionApi.consumable.test(data.viewItem, {
            attributes: attrName + '-end-before'
        }) && !conversionApi.consumable.test(data.viewItem, {
            attributes: attrName + '-start-before'
        })) {
            return;
        }
        // This converter wants to add a model element, marking a marker, before/after an element (or maybe even group of elements).
        // To do that, we can use `data.modelRange` which is set on an element (or a group of elements) that has been upcasted.
        // But, if the processed view element has not been upcasted yet (it does not have been converted), we need to
        // fire conversion for its children first, then we will have `data.modelRange` available.
        if (!data.modelRange) {
            Object.assign(data, conversionApi.convertChildren(data.viewItem, data.modelCursor));
        }
        if (conversionApi.consumable.consume(data.viewItem, {
            attributes: attrName + '-end-after'
        })) {
            addMarkerElements(data.modelRange.end, data.viewItem.getAttribute(attrName + '-end-after').split(','));
        }
        if (conversionApi.consumable.consume(data.viewItem, {
            attributes: attrName + '-start-after'
        })) {
            addMarkerElements(data.modelRange.end, data.viewItem.getAttribute(attrName + '-start-after').split(','));
        }
        if (conversionApi.consumable.consume(data.viewItem, {
            attributes: attrName + '-end-before'
        })) {
            addMarkerElements(data.modelRange.start, data.viewItem.getAttribute(attrName + '-end-before').split(','));
        }
        if (conversionApi.consumable.consume(data.viewItem, {
            attributes: attrName + '-start-before'
        })) {
            addMarkerElements(data.modelRange.start, data.viewItem.getAttribute(attrName + '-start-before').split(','));
        }
        function addMarkerElements(position, markerViewNames) {
            for (const markerViewName of markerViewNames){
                const markerName = config.model(markerViewName, conversionApi);
                const element = conversionApi.writer.createElement('$marker', {
                    'data-name': markerName
                });
                conversionApi.writer.insert(element, position);
                if (data.modelCursor.isEqual(position)) {
                    data.modelCursor = data.modelCursor.getShiftedBy(1);
                } else {
                    data.modelCursor = data.modelCursor._getTransformedByInsertion(position, 1);
                }
                data.modelRange = data.modelRange._getTransformedByInsertion(position, 1)[0];
            }
        }
    };
}
/**
 * Helper function for from-view-element conversion. Checks if `config.view` directly specifies converted view element's name
 * and if so, returns it.
 *
 * @param config Conversion view config.
 * @returns View element name or `null` if name is not directly set.
 */ function getViewElementNameFromConfig(viewConfig) {
    if (typeof viewConfig == 'string') {
        return viewConfig;
    }
    if (typeof viewConfig == 'object' && typeof viewConfig.name == 'string') {
        return viewConfig.name;
    }
    return null;
}
/**
 * Helper for to-model-element conversion. Takes a config object and returns a proper converter function.
 *
 * @param config Conversion configuration.
 * @returns View to model converter.
 */ function prepareToElementConverter(config) {
    const matcher = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](config.view);
    return (evt, data, conversionApi)=>{
        const matcherResult = matcher.match(data.viewItem);
        if (!matcherResult) {
            return;
        }
        const match = matcherResult.match;
        // Force consuming element's name.
        match.name = true;
        if (!conversionApi.consumable.test(data.viewItem, match)) {
            return;
        }
        const modelElement = getModelElement(config.model, data.viewItem, conversionApi);
        if (!modelElement) {
            return;
        }
        if (!conversionApi.safeInsert(modelElement, data.modelCursor)) {
            return;
        }
        conversionApi.consumable.consume(data.viewItem, match);
        conversionApi.convertChildren(data.viewItem, modelElement);
        conversionApi.updateConversionResult(modelElement, data);
    };
}
/**
 * Helper function for upcasting-to-element converter. Takes the model configuration, the converted view element
 * and a writer instance and returns a model element instance to be inserted in the model.
 *
 * @param model Model conversion configuration.
 * @param input The converted view node.
 * @param conversionApi The upcast conversion API.
 */ function getModelElement(model, input, conversionApi) {
    if (model instanceof Function) {
        return model(input, conversionApi);
    } else {
        return conversionApi.writer.createElement(model);
    }
}
/**
 * Helper function view-attribute-to-model-attribute helper. Normalizes `config.view` which was set as `String` or
 * as an `Object` with `key`, `value` and `name` properties. Normalized `config.view` has is compatible with
 * {@link module:engine/view/matcher~MatcherPattern}.
 *
 * @param config Conversion config.
 * @returns Key of the converted view attribute.
 */ function normalizeViewAttributeKeyValueConfig(config) {
    if (typeof config.view == 'string') {
        config.view = {
            key: config.view
        };
    }
    const key = config.view.key;
    const value = typeof config.view.value == 'undefined' ? /[\s\S]*/ : config.view.value;
    let normalized;
    if (key == 'class' || key == 'style') {
        const keyName = key == 'class' ? 'classes' : 'styles';
        normalized = {
            [keyName]: value
        };
    } else {
        normalized = {
            attributes: {
                [key]: value
            }
        };
    }
    if (config.view.name) {
        normalized.name = config.view.name;
    }
    config.view = normalized;
    return key;
}
/**
 * Helper function that normalizes `config.model` in from-model-attribute conversion. `config.model` can be set
 * as a `String`, an `Object` with only `key` property or an `Object` with `key` and `value` properties. Normalized
 * `config.model` is an `Object` with `key` and `value` properties.
 *
 * @param config Conversion config.
 * @param viewAttributeKeyToCopy Key of the converted view attribute. If it is set, model attribute value
 * will be equal to view attribute value.
 */ function normalizeModelAttributeConfig(config, viewAttributeKeyToCopy = null) {
    const defaultModelValue = viewAttributeKeyToCopy === null ? true : (viewElement)=>viewElement.getAttribute(viewAttributeKeyToCopy);
    const key = typeof config.model != 'object' ? config.model : config.model.key;
    const value = typeof config.model != 'object' || typeof config.model.value == 'undefined' ? defaultModelValue : config.model.value;
    config.model = {
        key,
        value
    };
}
/**
 * Helper for to-model-attribute conversion. Takes the model attribute name and conversion configuration and returns
 * a proper converter function.
 *
 * @param config Conversion configuration. It is possible to provide multiple configurations in an array.
 * @param shallow If set to `true` the attribute will be set only on top-level nodes. Otherwise, it will be set
 * on all elements in the range.
 */ function prepareToAttributeConverter(config, shallow) {
    const matcher = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$matcher$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](config.view);
    return (evt, data, conversionApi)=>{
        // Converting an attribute of an element that has not been converted to anything does not make sense
        // because there will be nowhere to set that attribute on. At this stage, the element should've already
        // been converted (https://github.com/ckeditor/ckeditor5/issues/11000).
        if (!data.modelRange && shallow) {
            return;
        }
        const match = matcher.match(data.viewItem);
        // If there is no match, this callback should not do anything.
        if (!match) {
            return;
        }
        if (onlyViewNameIsDefined(config.view, data.viewItem)) {
            match.match.name = true;
        } else {
            // Do not test `name` consumable because it could get consumed already while upcasting some other attribute
            // on the same element (for example <span class="big" style="color: red">foo</span>).
            delete match.match.name;
        }
        // Try to consume appropriate values from consumable values list.
        if (!conversionApi.consumable.test(data.viewItem, match.match)) {
            return;
        }
        const modelKey = config.model.key;
        const modelValue = typeof config.model.value == 'function' ? config.model.value(data.viewItem, conversionApi) : config.model.value;
        // Do not convert if attribute building function returned falsy value.
        if (modelValue === null) {
            return;
        }
        // Since we are converting to attribute we need a range on which we will set the attribute.
        // If the range is not created yet, let's create it by converting children of the current node first.
        if (!data.modelRange) {
            // Convert children and set conversion result as a current data.
            Object.assign(data, conversionApi.convertChildren(data.viewItem, data.modelCursor));
        }
        // Set attribute on current `output`. `Schema` is checked inside this helper function.
        const attributeWasSet = setAttributeOn(data.modelRange, {
            key: modelKey,
            value: modelValue
        }, shallow, conversionApi);
        // It may happen that a converter will try to set an attribute that is not allowed in the given context.
        // In such a situation we cannot consume the attribute. See: https://github.com/ckeditor/ckeditor5/pull/9249#issuecomment-815658459.
        if (attributeWasSet) {
            // Verify if the element itself wasn't consumed yet. It could be consumed already while upcasting some other attribute
            // on the same element (for example <span class="big" style="color: red">foo</span>).
            // We need to consume it so other features (especially GHS) won't try to convert it.
            // Note that it's not tested by the other element-to-attribute converters whether an element was consumed before
            // (in case of converters that the element itself is just a context and not the primary information to convert).
            if (conversionApi.consumable.test(data.viewItem, {
                name: true
            })) {
                match.match.name = true;
            }
            conversionApi.consumable.consume(data.viewItem, match.match);
        }
    };
}
/**
 * Helper function that checks if element name should be consumed in attribute converters.
 *
 * @param viewConfig Conversion view config.
 */ function onlyViewNameIsDefined(viewConfig, viewItem) {
    // https://github.com/ckeditor/ckeditor5-engine/issues/1786
    const configToTest = typeof viewConfig == 'function' ? viewConfig(viewItem) : viewConfig;
    if (typeof configToTest == 'object' && !getViewElementNameFromConfig(configToTest)) {
        return false;
    }
    return !configToTest.classes && !configToTest.attributes && !configToTest.styles;
}
/**
 * Helper function for to-model-attribute converter. Sets model attribute on given range. Checks {@link module:engine/model/schema~Schema}
 * to ensure proper model structure.
 *
 * If any node on the given range has already defined an attribute with the same name, its value will not be updated.
 *
 * @param modelRange Model range on which attribute should be set.
 * @param modelAttribute Model attribute to set.
 * @param conversionApi Conversion API.
 * @param shallow If set to `true` the attribute will be set only on top-level nodes. Otherwise, it will be set
 * on all elements in the range.
 * @returns `true` if attribute was set on at least one node from given `modelRange`.
 */ function setAttributeOn(modelRange, modelAttribute, shallow, conversionApi) {
    let result = false;
    // Set attribute on each item in range according to Schema.
    for (const node of Array.from(modelRange.getItems({
        shallow
    }))){
        // Skip if not allowed.
        if (!conversionApi.schema.checkAttribute(node, modelAttribute.key)) {
            continue;
        }
        // Mark the node as consumed even if the attribute will not be updated because it's in a valid context (schema)
        // and would be converted if the attribute wouldn't be present. See #8921.
        result = true;
        // Do not override the attribute if it's already present.
        if (node.hasAttribute(modelAttribute.key)) {
            continue;
        }
        conversionApi.writer.setAttribute(modelAttribute.key, modelAttribute.value, node);
    }
    return result;
}
/**
 * Helper function for upcasting-to-marker conversion. Takes the config in a format requested by `upcastElementToMarker()`
 * function and converts it to a format that is supported by `upcastElementToElement()` function.
 */ function normalizeElementToMarkerModelConfig(model) {
    return (viewElement, conversionApi)=>{
        const markerName = typeof model == 'string' ? model : model(viewElement, conversionApi);
        return conversionApi.writer.createElement('$marker', {
            'data-name': markerName
        });
    };
}
/**
 * Helper function for upcasting-to-marker conversion. Takes the config in a format requested by `upcastDataToMarker()`
 * function and converts it to a format that is supported by `upcastElementToElement()` function.
 */ function normalizeDataToMarkerConfig(config, type) {
    const elementCreatorFunction = (viewElement, conversionApi)=>{
        const viewName = viewElement.getAttribute('name');
        const markerName = config.model(viewName, conversionApi);
        return conversionApi.writer.createElement('$marker', {
            'data-name': markerName
        });
    };
    return {
        // Upcast <markerGroup-start> and <markerGroup-end> elements.
        view: `${config.view}-${type}`,
        model: elementCreatorFunction
    };
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/viewconsumable.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/conversion/viewconsumable
 */ __turbopack_context__.s([
    "ViewElementConsumables",
    ()=>ViewElementConsumables,
    "default",
    ()=>ViewConsumable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/toarray.js [app-ssr] (ecmascript) <export default as toArray>");
;
class ViewConsumable {
    constructor(){
        /**
         * Map of consumable elements. If {@link module:engine/view/element~Element element} is used as a key,
         * {@link module:engine/conversion/viewconsumable~ViewElementConsumables ViewElementConsumables} instance is stored as value.
         * For {@link module:engine/view/text~Text text nodes} and
         * {@link module:engine/view/documentfragment~DocumentFragment document fragments} boolean value is stored as value.
         */ this._consumables = new Map();
    }
    add(element, consumables) {
        let elementConsumables;
        // For text nodes and document fragments just mark them as consumable.
        if (element.is('$text') || element.is('documentFragment')) {
            this._consumables.set(element, true);
            return;
        }
        // For elements create new ViewElementConsumables or update already existing one.
        if (!this._consumables.has(element)) {
            elementConsumables = new ViewElementConsumables(element);
            this._consumables.set(element, elementConsumables);
        } else {
            elementConsumables = this._consumables.get(element);
        }
        elementConsumables.add(consumables);
    }
    /**
     * Tests if {@link module:engine/view/element~Element view element}, {@link module:engine/view/text~Text text node} or
     * {@link module:engine/view/documentfragment~DocumentFragment document fragment} can be consumed.
     * It returns `true` when all items included in method's call can be consumed. Returns `false` when
     * first already consumed item is found and `null` when first non-consumable item is found.
     *
     * ```ts
     * viewConsumable.test( p, { name: true } ); // Tests element's name.
     * viewConsumable.test( p, { attributes: 'name' } ); // Tests attribute.
     * viewConsumable.test( p, { classes: 'foobar' } ); // Tests class.
     * viewConsumable.test( p, { styles: 'color' } ); // Tests style.
     * viewConsumable.test( p, { attributes: 'name', styles: 'color' } ); // Tests attribute and style.
     * viewConsumable.test( p, { classes: [ 'baz', 'bar' ] } ); // Multiple consumables can be tested.
     * viewConsumable.test( textNode ); // Tests text node.
     * viewConsumable.test( docFragment ); // Tests document fragment.
     * ```
     *
     * Testing classes and styles as attribute will test if all added classes/styles can be consumed.
     *
     * ```ts
     * viewConsumable.test( p, { attributes: 'class' } ); // Tests if all added classes can be consumed.
     * viewConsumable.test( p, { attributes: 'style' } ); // Tests if all added styles can be consumed.
     * ```
     *
     * @param consumables Used only if first parameter is {@link module:engine/view/element~Element view element} instance.
     * @param consumables.name If set to true element's name will be included.
     * @param consumables.attributes Attribute name or array of attribute names.
     * @param consumables.classes Class name or array of class names.
     * @param consumables.styles Style name or array of style names.
     * @returns Returns `true` when all items included in method's call can be consumed. Returns `false`
     * when first already consumed item is found and `null` when first non-consumable item is found.
     */ test(element, consumables) {
        const elementConsumables = this._consumables.get(element);
        if (elementConsumables === undefined) {
            return null;
        }
        // For text nodes and document fragments return stored boolean value.
        if (element.is('$text') || element.is('documentFragment')) {
            return elementConsumables;
        }
        // For elements test consumables object.
        return elementConsumables.test(consumables);
    }
    /**
     * Consumes {@link module:engine/view/element~Element view element}, {@link module:engine/view/text~Text text node} or
     * {@link module:engine/view/documentfragment~DocumentFragment document fragment}.
     * It returns `true` when all items included in method's call can be consumed, otherwise returns `false`.
     *
     * ```ts
     * viewConsumable.consume( p, { name: true } ); // Consumes element's name.
     * viewConsumable.consume( p, { attributes: 'name' } ); // Consumes element's attribute.
     * viewConsumable.consume( p, { classes: 'foobar' } ); // Consumes element's class.
     * viewConsumable.consume( p, { styles: 'color' } ); // Consumes element's style.
     * viewConsumable.consume( p, { attributes: 'name', styles: 'color' } ); // Consumes attribute and style.
     * viewConsumable.consume( p, { classes: [ 'baz', 'bar' ] } ); // Multiple consumables can be consumed.
     * viewConsumable.consume( textNode ); // Consumes text node.
     * viewConsumable.consume( docFragment ); // Consumes document fragment.
     * ```
     *
     * Consuming classes and styles as attribute will test if all added classes/styles can be consumed.
     *
     * ```ts
     * viewConsumable.consume( p, { attributes: 'class' } ); // Consume only if all added classes can be consumed.
     * viewConsumable.consume( p, { attributes: 'style' } ); // Consume only if all added styles can be consumed.
     * ```
     *
     * @param consumables Used only if first parameter is {@link module:engine/view/element~Element view element} instance.
     * @param consumables.name If set to true element's name will be included.
     * @param consumables.attributes Attribute name or array of attribute names.
     * @param consumables.classes Class name or array of class names.
     * @param consumables.styles Style name or array of style names.
     * @returns Returns `true` when all items included in method's call can be consumed,
     * otherwise returns `false`.
     */ consume(element, consumables) {
        if (this.test(element, consumables)) {
            if (element.is('$text') || element.is('documentFragment')) {
                // For text nodes and document fragments set value to false.
                this._consumables.set(element, false);
            } else {
                // For elements - consume consumables object.
                this._consumables.get(element).consume(consumables);
            }
            return true;
        }
        return false;
    }
    /**
     * Reverts {@link module:engine/view/element~Element view element}, {@link module:engine/view/text~Text text node} or
     * {@link module:engine/view/documentfragment~DocumentFragment document fragment} so they can be consumed once again.
     * Method does not revert items that were never previously added for consumption, even if they are included in
     * method's call.
     *
     * ```ts
     * viewConsumable.revert( p, { name: true } ); // Reverts element's name.
     * viewConsumable.revert( p, { attributes: 'name' } ); // Reverts element's attribute.
     * viewConsumable.revert( p, { classes: 'foobar' } ); // Reverts element's class.
     * viewConsumable.revert( p, { styles: 'color' } ); // Reverts element's style.
     * viewConsumable.revert( p, { attributes: 'name', styles: 'color' } ); // Reverts attribute and style.
     * viewConsumable.revert( p, { classes: [ 'baz', 'bar' ] } ); // Multiple names can be reverted.
     * viewConsumable.revert( textNode ); // Reverts text node.
     * viewConsumable.revert( docFragment ); // Reverts document fragment.
     * ```
     *
     * Reverting classes and styles as attribute will revert all classes/styles that were previously added for
     * consumption.
     *
     * ```ts
     * viewConsumable.revert( p, { attributes: 'class' } ); // Reverts all classes added for consumption.
     * viewConsumable.revert( p, { attributes: 'style' } ); // Reverts all styles added for consumption.
     * ```
     *
     * @param consumables Used only if first parameter is {@link module:engine/view/element~Element view element} instance.
     * @param consumables.name If set to true element's name will be included.
     * @param consumables.attributes Attribute name or array of attribute names.
     * @param consumables.classes Class name or array of class names.
     * @param consumables.styles Style name or array of style names.
     */ revert(element, consumables) {
        const elementConsumables = this._consumables.get(element);
        if (elementConsumables !== undefined) {
            if (element.is('$text') || element.is('documentFragment')) {
                // For text nodes and document fragments - set consumable to true.
                this._consumables.set(element, true);
            } else {
                // For elements - revert items from consumables object.
                elementConsumables.revert(consumables);
            }
        }
    }
    /**
     * Creates consumable object from {@link module:engine/view/element~Element view element}. Consumable object will include
     * element's name and all its attributes, classes and styles.
     */ static consumablesFromElement(element) {
        const consumables = {
            element,
            name: true,
            attributes: [],
            classes: [],
            styles: []
        };
        const attributes = element.getAttributeKeys();
        for (const attribute of attributes){
            // Skip classes and styles - will be added separately.
            if (attribute == 'style' || attribute == 'class') {
                continue;
            }
            consumables.attributes.push(attribute);
        }
        const classes = element.getClassNames();
        for (const className of classes){
            consumables.classes.push(className);
        }
        const styles = element.getStyleNames();
        for (const style of styles){
            consumables.styles.push(style);
        }
        return consumables;
    }
    /**
     * Creates {@link module:engine/conversion/viewconsumable~ViewConsumable ViewConsumable} instance from
     * {@link module:engine/view/node~Node node} or {@link module:engine/view/documentfragment~DocumentFragment document fragment}.
     * Instance will contain all elements, child nodes, attributes, styles and classes added for consumption.
     *
     * @param from View node or document fragment from which `ViewConsumable` will be created.
     * @param instance If provided, given `ViewConsumable` instance will be used
     * to add all consumables. It will be returned instead of a new instance.
     */ static createFrom(from, instance) {
        if (!instance) {
            instance = new ViewConsumable();
        }
        if (from.is('$text')) {
            instance.add(from);
            return instance;
        }
        // Add `from` itself, if it is an element.
        if (from.is('element')) {
            instance.add(from, ViewConsumable.consumablesFromElement(from));
        }
        if (from.is('documentFragment')) {
            instance.add(from);
        }
        for (const child of from.getChildren()){
            instance = ViewConsumable.createFrom(child, instance);
        }
        return instance;
    }
}
const CONSUMABLE_TYPES = [
    'attributes',
    'classes',
    'styles'
];
class ViewElementConsumables {
    /**
     * Creates ViewElementConsumables instance.
     *
     * @param from View node or document fragment from which `ViewElementConsumables` is being created.
     */ constructor(from){
        this.element = from;
        this._canConsumeName = null;
        this._consumables = {
            attributes: new Map(),
            styles: new Map(),
            classes: new Map()
        };
    }
    /**
     * Adds consumable parts of the {@link module:engine/view/element~Element view element}.
     * Element's name itself can be marked to be consumed (when element's name is consumed its attributes, classes and
     * styles still could be consumed):
     *
     * ```ts
     * consumables.add( { name: true } );
     * ```
     *
     * Attributes classes and styles:
     *
     * ```ts
     * consumables.add( { attributes: 'title', classes: 'foo', styles: 'color' } );
     * consumables.add( { attributes: [ 'title', 'name' ], classes: [ 'foo', 'bar' ] );
     * ```
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `viewconsumable-invalid-attribute` when `class` or `style`
     * attribute is provided - it should be handled separately by providing `style` and `class` in consumables object.
     *
     * @param consumables Object describing which parts of the element can be consumed.
     * @param consumables.name If set to `true` element's name will be added as consumable.
     * @param consumables.attributes Attribute name or array of attribute names to add as consumable.
     * @param consumables.classes Class name or array of class names to add as consumable.
     * @param consumables.styles Style name or array of style names to add as consumable.
     */ add(consumables) {
        if (consumables.name) {
            this._canConsumeName = true;
        }
        for (const type of CONSUMABLE_TYPES){
            if (type in consumables) {
                this._add(type, consumables[type]);
            }
        }
    }
    /**
     * Tests if parts of the {@link module:engine/view/node~Node view node} can be consumed.
     *
     * Element's name can be tested:
     *
     * ```ts
     * consumables.test( { name: true } );
     * ```
     *
     * Attributes classes and styles:
     *
     * ```ts
     * consumables.test( { attributes: 'title', classes: 'foo', styles: 'color' } );
     * consumables.test( { attributes: [ 'title', 'name' ], classes: [ 'foo', 'bar' ] );
     * ```
     *
     * @param consumables Object describing which parts of the element should be tested.
     * @param consumables.name If set to `true` element's name will be tested.
     * @param consumables.attributes Attribute name or array of attribute names to test.
     * @param consumables.classes Class name or array of class names to test.
     * @param consumables.styles Style name or array of style names to test.
     * @returns `true` when all tested items can be consumed, `null` when even one of the items
     * was never marked for consumption and `false` when even one of the items was already consumed.
     */ test(consumables) {
        // Check if name can be consumed.
        if (consumables.name && !this._canConsumeName) {
            return this._canConsumeName;
        }
        for (const type of CONSUMABLE_TYPES){
            if (type in consumables) {
                const value = this._test(type, consumables[type]);
                if (value !== true) {
                    return value;
                }
            }
        }
        // Return true only if all can be consumed.
        return true;
    }
    /**
     * Consumes parts of {@link module:engine/view/element~Element view element}. This function does not check if consumable item
     * is already consumed - it consumes all consumable items provided.
     * Element's name can be consumed:
     *
     * ```ts
     * consumables.consume( { name: true } );
     * ```
     *
     * Attributes classes and styles:
     *
     * ```ts
     * consumables.consume( { attributes: 'title', classes: 'foo', styles: 'color' } );
     * consumables.consume( { attributes: [ 'title', 'name' ], classes: [ 'foo', 'bar' ] );
     * ```
     *
     * @param consumables Object describing which parts of the element should be consumed.
     * @param consumables.name If set to `true` element's name will be consumed.
     * @param consumables.attributes Attribute name or array of attribute names to consume.
     * @param consumables.classes Class name or array of class names to consume.
     * @param consumables.styles Style name or array of style names to consume.
     */ consume(consumables) {
        if (consumables.name) {
            this._canConsumeName = false;
        }
        for (const type of CONSUMABLE_TYPES){
            if (type in consumables) {
                this._consume(type, consumables[type]);
            }
        }
    }
    /**
     * Revert already consumed parts of {@link module:engine/view/element~Element view Element}, so they can be consumed once again.
     * Element's name can be reverted:
     *
     * ```ts
     * consumables.revert( { name: true } );
     * ```
     *
     * Attributes classes and styles:
     *
     * ```ts
     * consumables.revert( { attributes: 'title', classes: 'foo', styles: 'color' } );
     * consumables.revert( { attributes: [ 'title', 'name' ], classes: [ 'foo', 'bar' ] );
     * ```
     *
     * @param consumables Object describing which parts of the element should be reverted.
     * @param consumables.name If set to `true` element's name will be reverted.
     * @param consumables.attributes Attribute name or array of attribute names to revert.
     * @param consumables.classes Class name or array of class names to revert.
     * @param consumables.styles Style name or array of style names to revert.
     */ revert(consumables) {
        if (consumables.name) {
            this._canConsumeName = true;
        }
        for (const type of CONSUMABLE_TYPES){
            if (type in consumables) {
                this._revert(type, consumables[type]);
            }
        }
    }
    /**
     * Helper method that adds consumables of a given type: attribute, class or style.
     *
     * Throws {@link module:utils/ckeditorerror~CKEditorError CKEditorError} `viewconsumable-invalid-attribute` when `class` or `style`
     * type is provided - it should be handled separately by providing actual style/class type.
     *
     * @param type Type of the consumable item: `attributes`, `classes` or `styles`.
     * @param item Consumable item or array of items.
     */ _add(type, item) {
        const items = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(item);
        const consumables = this._consumables[type];
        for (const name of items){
            if (type === 'attributes' && (name === 'class' || name === 'style')) {
                /**
                 * Class and style attributes should be handled separately in
                 * {@link module:engine/conversion/viewconsumable~ViewConsumable#add `ViewConsumable#add()`}.
                 *
                 * What you have done is trying to use:
                 *
                 * ```ts
                 * consumables.add( { attributes: [ 'class', 'style' ] } );
                 * ```
                 *
                 * While each class and style should be registered separately:
                 *
                 * ```ts
                 * consumables.add( { classes: 'some-class', styles: 'font-weight' } );
                 * ```
                 *
                 * @error viewconsumable-invalid-attribute
                 */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('viewconsumable-invalid-attribute', this);
            }
            consumables.set(name, true);
            if (type === 'styles') {
                for (const alsoName of this.element.document.stylesProcessor.getRelatedStyles(name)){
                    consumables.set(alsoName, true);
                }
            }
        }
    }
    /**
     * Helper method that tests consumables of a given type: attribute, class or style.
     *
     * @param type Type of the consumable item: `attributes`, `classes` or `styles`.
     * @param item Consumable item or array of items.
     * @returns Returns `true` if all items can be consumed, `null` when one of the items cannot be
     * consumed and `false` when one of the items is already consumed.
     */ _test(type, item) {
        const items = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(item);
        const consumables = this._consumables[type];
        for (const name of items){
            if (type === 'attributes' && (name === 'class' || name === 'style')) {
                const consumableName = name == 'class' ? 'classes' : 'styles';
                // Check all classes/styles if class/style attribute is tested.
                const value = this._test(consumableName, [
                    ...this._consumables[consumableName].keys()
                ]);
                if (value !== true) {
                    return value;
                }
            } else {
                const value = consumables.get(name);
                // Return null if attribute is not found.
                if (value === undefined) {
                    return null;
                }
                if (!value) {
                    return false;
                }
            }
        }
        return true;
    }
    /**
     * Helper method that consumes items of a given type: attribute, class or style.
     *
     * @param type Type of the consumable item: `attributes`, `classes` or `styles`.
     * @param item Consumable item or array of items.
     */ _consume(type, item) {
        const items = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(item);
        const consumables = this._consumables[type];
        for (const name of items){
            if (type === 'attributes' && (name === 'class' || name === 'style')) {
                const consumableName = name == 'class' ? 'classes' : 'styles';
                // If class or style is provided for consumption - consume them all.
                this._consume(consumableName, [
                    ...this._consumables[consumableName].keys()
                ]);
            } else {
                consumables.set(name, false);
                if (type == 'styles') {
                    for (const toConsume of this.element.document.stylesProcessor.getRelatedStyles(name)){
                        consumables.set(toConsume, false);
                    }
                }
            }
        }
    }
    /**
     * Helper method that reverts items of a given type: attribute, class or style.
     *
     * @param type Type of the consumable item: `attributes`, `classes` or , `styles`.
     * @param item Consumable item or array of items.
     */ _revert(type, item) {
        const items = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(item);
        const consumables = this._consumables[type];
        for (const name of items){
            if (type === 'attributes' && (name === 'class' || name === 'style')) {
                const consumableName = name == 'class' ? 'classes' : 'styles';
                // If class or style is provided for reverting - revert them all.
                this._revert(consumableName, [
                    ...this._consumables[consumableName].keys()
                ]);
            } else {
                const value = consumables.get(name);
                if (value === false) {
                    consumables.set(name, true);
                }
            }
        }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/upcastdispatcher.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/conversion/upcastdispatcher
 */ __turbopack_context__.s([
    "default",
    ()=>UpcastDispatcher
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$viewconsumable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/viewconsumable.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/range.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/position.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$schema$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/schema.js [app-ssr] (ecmascript)"); // eslint-disable-line no-duplicate-imports
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$autoparagraphing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/utils/autoparagraphing.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/emittermixin.js [app-ssr] (ecmascript) <export default as EmitterMixin>");
;
;
;
;
;
;
class UpcastDispatcher extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$emittermixin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__EmitterMixin$3e$__["EmitterMixin"])() {
    /**
     * Creates an upcast dispatcher that operates using the passed API.
     *
     * @see module:engine/conversion/upcastdispatcher~UpcastConversionApi
     * @param conversionApi Additional properties for an interface that will be passed to events fired
     * by the upcast dispatcher.
     */ constructor(conversionApi){
        super();
        /**
         * The list of elements that were created during splitting.
         *
         * After the conversion process, the list is cleared.
         */ this._splitParts = new Map();
        /**
         * The list of cursor parent elements that were created during splitting.
         *
         * After the conversion process the list is cleared.
         */ this._cursorParents = new Map();
        /**
         * The position in the temporary structure where the converted content is inserted. The structure reflects the context of
         * the target position where the content will be inserted. This property is built based on the context parameter of the
         * convert method.
         */ this._modelCursor = null;
        /**
         * The list of elements that were created during the splitting but should not get removed on conversion end even if they are empty.
         *
         * The list is cleared after the conversion process.
         */ this._emptyElementsToKeep = new Set();
        this.conversionApi = {
            ...conversionApi,
            consumable: null,
            writer: null,
            store: null,
            convertItem: (viewItem, modelCursor)=>this._convertItem(viewItem, modelCursor),
            convertChildren: (viewElement, positionOrElement)=>this._convertChildren(viewElement, positionOrElement),
            safeInsert: (modelNode, position)=>this._safeInsert(modelNode, position),
            updateConversionResult: (modelElement, data)=>this._updateConversionResult(modelElement, data),
            // Advanced API - use only if custom position handling is needed.
            splitToAllowedParent: (modelNode, modelCursor)=>this._splitToAllowedParent(modelNode, modelCursor),
            getSplitParts: (modelElement)=>this._getSplitParts(modelElement),
            keepEmptyElement: (modelElement)=>this._keepEmptyElement(modelElement)
        };
    }
    /**
     * Starts the conversion process. The entry point for the conversion.
     *
     * @fires element
     * @fires text
     * @fires documentFragment
     * @param viewElement The part of the view to be converted.
     * @param writer An instance of the model writer.
     * @param context Elements will be converted according to this context.
     * @returns Model data that is the result of the conversion process
     * wrapped in `DocumentFragment`. Converted marker elements will be set as the document fragment's
     * {@link module:engine/model/documentfragment~DocumentFragment#markers static markers map}.
     */ convert(viewElement, writer, context = [
        '$root'
    ]) {
        this.fire('viewCleanup', viewElement);
        // Create context tree and set position in the top element.
        // Items will be converted according to this position.
        this._modelCursor = createContextTree(context, writer);
        // Store writer in conversion as a conversion API
        // to be sure that conversion process will use the same batch.
        this.conversionApi.writer = writer;
        // Create consumable values list for conversion process.
        this.conversionApi.consumable = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$viewconsumable$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].createFrom(viewElement);
        // Custom data stored by converter for conversion process.
        this.conversionApi.store = {};
        // Do the conversion.
        const { modelRange } = this._convertItem(viewElement, this._modelCursor);
        // Conversion result is always a document fragment so let's create it.
        const documentFragment = writer.createDocumentFragment();
        // When there is a conversion result.
        if (modelRange) {
            // Remove all empty elements that were created while splitting.
            this._removeEmptyElements();
            // Move all items that were converted in context tree to the document fragment.
            for (const item of Array.from(this._modelCursor.parent.getChildren())){
                writer.append(item, documentFragment);
            }
            // Extract temporary markers elements from model and set as static markers collection.
            documentFragment.markers = extractMarkersFromModelFragment(documentFragment, writer);
        }
        // Clear context position.
        this._modelCursor = null;
        // Clear split elements & parents lists.
        this._splitParts.clear();
        this._cursorParents.clear();
        this._emptyElementsToKeep.clear();
        // Clear conversion API.
        this.conversionApi.writer = null;
        this.conversionApi.store = null;
        // Return fragment as conversion result.
        return documentFragment;
    }
    /**
     * @see module:engine/conversion/upcastdispatcher~UpcastConversionApi#convertItem
     */ _convertItem(viewItem, modelCursor) {
        const data = {
            viewItem,
            modelCursor,
            modelRange: null
        };
        if (viewItem.is('element')) {
            this.fire(`element:${viewItem.name}`, data, this.conversionApi);
        } else if (viewItem.is('$text')) {
            this.fire('text', data, this.conversionApi);
        } else {
            this.fire('documentFragment', data, this.conversionApi);
        }
        // Handle incorrect conversion result.
        if (data.modelRange && !(data.modelRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])) {
            /**
             * Incorrect conversion result was dropped.
             *
             * {@link module:engine/model/range~Range Model range} should be a conversion result.
             *
             * @error view-conversion-dispatcher-incorrect-result
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('view-conversion-dispatcher-incorrect-result', this);
        }
        return {
            modelRange: data.modelRange,
            modelCursor: data.modelCursor
        };
    }
    /**
     * @see module:engine/conversion/upcastdispatcher~UpcastConversionApi#convertChildren
     */ _convertChildren(viewItem, elementOrModelCursor) {
        let nextModelCursor = elementOrModelCursor.is('position') ? elementOrModelCursor : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(elementOrModelCursor, 0);
        const modelRange = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](nextModelCursor);
        for (const viewChild of Array.from(viewItem.getChildren())){
            const result = this._convertItem(viewChild, nextModelCursor);
            if (result.modelRange instanceof __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]) {
                modelRange.end = result.modelRange.end;
                nextModelCursor = result.modelCursor;
            }
        }
        return {
            modelRange,
            modelCursor: nextModelCursor
        };
    }
    /**
     * @see module:engine/conversion/upcastdispatcher~UpcastConversionApi#safeInsert
     */ _safeInsert(modelNode, position) {
        // Find allowed parent for element that we are going to insert.
        // If current parent does not allow to insert element but one of the ancestors does
        // then split nodes to allowed parent.
        const splitResult = this._splitToAllowedParent(modelNode, position);
        // When there is no split result it means that we can't insert element to model tree, so let's skip it.
        if (!splitResult) {
            return false;
        }
        // Insert element on allowed position.
        this.conversionApi.writer.insert(modelNode, splitResult.position);
        return true;
    }
    /**
     * @see module:engine/conversion/upcastdispatcher~UpcastConversionApi#updateConversionResult
     */ _updateConversionResult(modelElement, data) {
        const parts = this._getSplitParts(modelElement);
        const writer = this.conversionApi.writer;
        // Set conversion result range - only if not set already.
        if (!data.modelRange) {
            data.modelRange = writer.createRange(writer.createPositionBefore(modelElement), writer.createPositionAfter(parts[parts.length - 1]));
        }
        const savedCursorParent = this._cursorParents.get(modelElement);
        // Now we need to check where the `modelCursor` should be.
        if (savedCursorParent) {
            // If we split parent to insert our element then we want to continue conversion in the new part of the split parent.
            //
            // before: <allowed><notAllowed>foo[]</notAllowed></allowed>
            // after:  <allowed><notAllowed>foo</notAllowed> <converted></converted> <notAllowed>[]</notAllowed></allowed>
            data.modelCursor = writer.createPositionAt(savedCursorParent, 0);
        } else {
            // Otherwise just continue after inserted element.
            data.modelCursor = data.modelRange.end;
        }
    }
    /**
     * @see module:engine/conversion/upcastdispatcher~UpcastConversionApi#splitToAllowedParent
     */ _splitToAllowedParent(node, modelCursor) {
        const { schema, writer } = this.conversionApi;
        // Try to find allowed parent.
        let allowedParent = schema.findAllowedParent(modelCursor, node);
        if (allowedParent) {
            // When current position parent allows to insert node then return this position.
            if (allowedParent === modelCursor.parent) {
                return {
                    position: modelCursor
                };
            }
            // When allowed parent is in context tree (it's outside the converted tree).
            if (this._modelCursor.parent.getAncestors().includes(allowedParent)) {
                allowedParent = null;
            }
        }
        if (!allowedParent) {
            // Check if the node wrapped with a paragraph would be accepted by the schema.
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$autoparagraphing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isParagraphable"])(modelCursor, node, schema)) {
                return null;
            }
            return {
                position: (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$utils$2f$autoparagraphing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["wrapInParagraph"])(modelCursor, writer)
            };
        }
        // Split element to allowed parent.
        const splitResult = this.conversionApi.writer.split(modelCursor, allowedParent);
        // Using the range returned by `model.Writer#split`, we will pair original elements with their split parts.
        //
        // The range returned from the writer spans "over the split" or, precisely saying, from the end of the original element (the one
        // that got split) to the beginning of the other part of that element:
        //
        // <limit><a><b><c>X[]Y</c></b><a></limit> ->
        // <limit><a><b><c>X[</c></b></a><a><b><c>]Y</c></b></a>
        //
        // After the split there cannot be any full node between the positions in `splitRange`. The positions are touching.
        // Also, because of how splitting works, it is easy to notice, that "closing tags" are in the reverse order than "opening tags".
        // Also, since we split all those elements, each of them has to have the other part.
        //
        // With those observations in mind, we will pair the original elements with their split parts by saving "closing tags" and matching
        // them with "opening tags" in the reverse order. For that we can use a stack.
        const stack = [];
        for (const treeWalkerValue of splitResult.range.getWalker()){
            if (treeWalkerValue.type == 'elementEnd') {
                stack.push(treeWalkerValue.item);
            } else {
                // There should not be any text nodes after the element is split, so the only other value is `elementStart`.
                const originalPart = stack.pop();
                const splitPart = treeWalkerValue.item;
                this._registerSplitPair(originalPart, splitPart);
            }
        }
        const cursorParent = splitResult.range.end.parent;
        this._cursorParents.set(node, cursorParent);
        return {
            position: splitResult.position,
            cursorParent
        };
    }
    /**
     * Registers that a `splitPart` element is a split part of the `originalPart` element.
     *
     * The data set by this method is used by {@link #_getSplitParts} and {@link #_removeEmptyElements}.
     */ _registerSplitPair(originalPart, splitPart) {
        if (!this._splitParts.has(originalPart)) {
            this._splitParts.set(originalPart, [
                originalPart
            ]);
        }
        const list = this._splitParts.get(originalPart);
        this._splitParts.set(splitPart, list);
        list.push(splitPart);
    }
    /**
     * @see module:engine/conversion/upcastdispatcher~UpcastConversionApi#getSplitParts
     */ _getSplitParts(element) {
        let parts;
        if (!this._splitParts.has(element)) {
            parts = [
                element
            ];
        } else {
            parts = this._splitParts.get(element);
        }
        return parts;
    }
    /**
     * Mark an element that were created during the splitting to not get removed on conversion end even if it is empty.
     */ _keepEmptyElement(element) {
        this._emptyElementsToKeep.add(element);
    }
    /**
     * Checks if there are any empty elements created while splitting and removes them.
     *
     * This method works recursively to re-check empty elements again after at least one element was removed in the initial call,
     * as some elements might have become empty after other empty elements were removed from them.
     */ _removeEmptyElements() {
        let anyRemoved = false;
        for (const element of this._splitParts.keys()){
            if (element.isEmpty && !this._emptyElementsToKeep.has(element)) {
                this.conversionApi.writer.remove(element);
                this._splitParts.delete(element);
                anyRemoved = true;
            }
        }
        if (anyRemoved) {
            this._removeEmptyElements();
        }
    }
}
/**
 * Traverses given model item and searches elements which marks marker range. Found element is removed from
 * DocumentFragment but path of this element is stored in a Map which is then returned.
 *
 * @param modelItem Fragment of model.
 * @returns List of static markers.
 */ function extractMarkersFromModelFragment(modelItem, writer) {
    const markerElements = new Set();
    const markers = new Map();
    // Create ModelTreeWalker.
    const range = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createIn(modelItem).getItems();
    // Walk through DocumentFragment and collect marker elements.
    for (const item of range){
        // Check if current element is a marker.
        if (item.is('element', '$marker')) {
            markerElements.add(item);
        }
    }
    // Walk through collected marker elements store its path and remove its from the DocumentFragment.
    for (const markerElement of markerElements){
        const markerName = markerElement.getAttribute('data-name');
        const currentPosition = writer.createPositionBefore(markerElement);
        // When marker of given name is not stored it means that we have found the beginning of the range.
        if (!markers.has(markerName)) {
            markers.set(markerName, new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$range$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](currentPosition.clone()));
        // Otherwise is means that we have found end of the marker range.
        } else {
            markers.get(markerName).end = currentPosition.clone();
        }
        // Remove marker element from DocumentFragment.
        writer.remove(markerElement);
    }
    return markers;
}
/**
 * Creates model fragment according to given context and returns position in the bottom (the deepest) element.
 */ function createContextTree(contextDefinition, writer) {
    let position;
    for (const item of new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$schema$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SchemaContext"](contextDefinition)){
        const attributes = {};
        for (const key of item.getAttributeKeys()){
            attributes[key] = item.getAttribute(key);
        }
        const current = writer.createElement(item.name, attributes);
        if (position) {
            writer.insert(current, position);
        }
        position = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$position$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]._createAt(current, 0);
    }
    return position;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/conversion.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module engine/conversion/conversion
 */ __turbopack_context__.s([
    "default",
    ()=>Conversion
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/ckeditorerror.js [app-ssr] (ecmascript) <export default as CKEditorError>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/toarray.js [app-ssr] (ecmascript) <export default as toArray>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/upcasthelpers.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/downcasthelpers.js [app-ssr] (ecmascript)");
;
;
;
class Conversion {
    /**
     * Creates a new conversion instance.
     */ constructor(downcastDispatchers, upcastDispatchers){
        /**
         * Maps dispatchers group name to ConversionHelpers instances.
         */ this._helpers = new Map();
        // Define default 'downcast' & 'upcast' dispatchers groups. Those groups are always available as two-way converters needs them.
        this._downcast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(downcastDispatchers);
        this._createConversionHelpers({
            name: 'downcast',
            dispatchers: this._downcast,
            isDowncast: true
        });
        this._upcast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(upcastDispatchers);
        this._createConversionHelpers({
            name: 'upcast',
            dispatchers: this._upcast,
            isDowncast: false
        });
    }
    /**
     * Define an alias for registered dispatcher.
     *
     * ```ts
     * const conversion = new Conversion(
     * 	[ dataDowncastDispatcher, editingDowncastDispatcher ],
     * 	upcastDispatcher
     * );
     *
     * conversion.addAlias( 'dataDowncast', dataDowncastDispatcher );
     * ```
     *
     * @param alias An alias of a dispatcher.
     * @param dispatcher Dispatcher which should have an alias.
     */ addAlias(alias, dispatcher) {
        const isDowncast = this._downcast.includes(dispatcher);
        const isUpcast = this._upcast.includes(dispatcher);
        if (!isUpcast && !isDowncast) {
            /**
             * Trying to register an alias for a dispatcher that nas not been registered.
             *
             * @error conversion-add-alias-dispatcher-not-registered
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('conversion-add-alias-dispatcher-not-registered', this);
        }
        this._createConversionHelpers({
            name: alias,
            dispatchers: [
                dispatcher
            ],
            isDowncast
        });
    }
    /**
     * Provides a chainable API to assign converters to a conversion dispatchers group.
     *
     * If the given group name has not been registered, the
     * {@link module:utils/ckeditorerror~CKEditorError `conversion-for-unknown-group` error} is thrown.
     *
     * You can use conversion helpers available directly in the `for()` chain or your custom ones via
     * the {@link module:engine/conversion/conversionhelpers~ConversionHelpers#add `add()`} method.
     *
     * # Using built-in conversion helpers
     *
     * The `for()` chain comes with a set of conversion helpers which you can use like this:
     *
     * ```ts
     * editor.conversion.for( 'downcast' )
     * 	.elementToElement( config1 )        // Adds an element-to-element downcast converter.
     * 	.attributeToElement( config2 );     // Adds an attribute-to-element downcast converter.
     *
     * editor.conversion.for( 'upcast' )
     * 	.elementToAttribute( config3 );     // Adds an element-to-attribute upcast converter.
     * ```
     *
     * Refer to the documentation of built-in conversion helpers to learn about their configuration options.
     *
     * * downcast (model-to-view) conversion helpers:
     *
     *	* {@link module:engine/conversion/downcasthelpers~DowncastHelpers#elementToElement `elementToElement()`},
     *	* {@link module:engine/conversion/downcasthelpers~DowncastHelpers#attributeToElement `attributeToElement()`},
     *	* {@link module:engine/conversion/downcasthelpers~DowncastHelpers#attributeToAttribute `attributeToAttribute()`}.
     *	* {@link module:engine/conversion/downcasthelpers~DowncastHelpers#markerToElement `markerToElement()`}.
     *	* {@link module:engine/conversion/downcasthelpers~DowncastHelpers#markerToHighlight `markerToHighlight()`}.
     *
     * * upcast (view-to-model) conversion helpers:
     *
     *	* {@link module:engine/conversion/upcasthelpers~UpcastHelpers#elementToElement `elementToElement()`},
     *	* {@link module:engine/conversion/upcasthelpers~UpcastHelpers#elementToAttribute `elementToAttribute()`},
     *	* {@link module:engine/conversion/upcasthelpers~UpcastHelpers#attributeToAttribute `attributeToAttribute()`}.
     *	* {@link module:engine/conversion/upcasthelpers~UpcastHelpers#elementToMarker `elementToMarker()`}.
     *
     * # Using custom conversion helpers
     *
     * If you need to implement an atypical converter, you can do so by calling:
     *
     * ```ts
     * editor.conversion.for( direction ).add( customHelper );
     * ```
     *
     * The `.add()` method takes exactly one parameter, which is a function. This function should accept one parameter that
     * is a dispatcher instance. The function should add an actual converter to the passed dispatcher instance.
     *
     * Example:
     *
     * ```ts
     * editor.conversion.for( 'upcast' ).add( dispatcher => {
     * 	dispatcher.on( 'element:a',  ( evt, data, conversionApi ) => {
     * 		// Do something with a view <a> element.
     * 	} );
     * } );
     * ```
     *
     * Refer to the documentation of {@link module:engine/conversion/upcastdispatcher~UpcastDispatcher}
     * and {@link module:engine/conversion/downcastdispatcher~DowncastDispatcher} to learn how to write
     * custom converters.
     *
     * @param groupName The name of dispatchers group to add the converters to.
     */ for(groupName) {
        if (!this._helpers.has(groupName)) {
            /**
             * Trying to add a converter to an unknown dispatchers group.
             *
             * @error conversion-for-unknown-group
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('conversion-for-unknown-group', this);
        }
        return this._helpers.get(groupName);
    }
    /**
     * Sets up converters between the model and the view that convert a model element to a view element (and vice versa).
     * For example, the model `<paragraph>Foo</paragraph>` is turned into `<p>Foo</p>` in the view.
     *
     * ```ts
     * // A simple conversion from the `paragraph` model element to the `<p>` view element (and vice versa).
     * editor.conversion.elementToElement( { model: 'paragraph', view: 'p' } );
     *
     * // Override other converters by specifying a converter definition with a higher priority.
     * editor.conversion.elementToElement( { model: 'paragraph', view: 'div', converterPriority: 'high' } );
     *
     * // View specified as an object instead of a string.
     * editor.conversion.elementToElement( {
     * 	model: 'fancyParagraph',
     * 	view: {
     * 		name: 'p',
     * 		classes: 'fancy'
     * 	}
     * } );
     *
     * // Use `upcastAlso` to define other view elements that should also be converted to a `paragraph` element.
     * editor.conversion.elementToElement( {
     * 	model: 'paragraph',
     * 	view: 'p',
     * 	upcastAlso: [
     * 		'div',
     * 		{
     * 			// Any element with the `display: block` style.
     * 			styles: {
     * 				display: 'block'
     * 			}
     * 		}
     * 	]
     * } );
     *
     * // `upcastAlso` set as callback enables a conversion of a wide range of different view elements.
     * editor.conversion.elementToElement( {
     * 	model: 'heading',
     * 	view: 'h2',
     * 	// Convert "heading-like" paragraphs to headings.
     * 	upcastAlso: viewElement => {
     * 		const fontSize = viewElement.getStyle( 'font-size' );
     *
     * 		if ( !fontSize ) {
     * 			return null;
     * 		}
     *
     * 		const match = fontSize.match( /(\d+)\s*px/ );
     *
     * 		if ( !match ) {
     * 			return null;
     * 		}
     *
     * 		const size = Number( match[ 1 ] );
     *
     * 		if ( size > 26 ) {
     * 			// Returned value can be an object with the matched properties.
     * 			// These properties will be "consumed" during the conversion.
     * 			// See `engine.view.Matcher~MatcherPattern` and `engine.view.Matcher#match` for more details.
     *
     * 			return { name: true, styles: [ 'font-size' ] };
     * 		}
     *
     * 		return null;
     * 	}
     * } );
     * ```
     *
     * `definition.model` is a `String` with a model element name to convert from or to.
     *
     * @param definition The converter definition.
     */ elementToElement(definition) {
        // Set up downcast converter.
        this.for('downcast').elementToElement(definition);
        // Set up upcast converter.
        for (const { model, view } of _getAllUpcastDefinitions(definition)){
            this.for('upcast').elementToElement({
                model,
                view,
                converterPriority: definition.converterPriority
            });
        }
    }
    /**
     * Sets up converters between the model and the view that convert a model attribute to a view element (and vice versa).
     * For example, a model text node with `"Foo"` as data and the `bold` attribute will be turned to `<strong>Foo</strong>` in the view.
     *
     * ```ts
     * // A simple conversion from the `bold=true` attribute to the `<strong>` view element (and vice versa).
     * editor.conversion.attributeToElement( { model: 'bold', view: 'strong' } );
     *
     * // Override other converters by specifying a converter definition with a higher priority.
     * editor.conversion.attributeToElement( { model: 'bold', view: 'b', converterPriority: 'high' } );
     *
     * // View specified as an object instead of a string.
     * editor.conversion.attributeToElement( {
     * 	model: 'bold',
     * 	view: {
     * 		name: 'span',
     * 		classes: 'bold'
     * 	}
     * } );
     *
     * // Use `config.model.name` to define the conversion only from a given node type, `$text` in this case.
     * // The same attribute on different elements may then be handled by a different converter.
     * editor.conversion.attributeToElement( {
     * 	model: {
     * 		key: 'textDecoration',
     * 		values: [ 'underline', 'lineThrough' ],
     * 		name: '$text'
     * 	},
     * 	view: {
     * 		underline: {
     * 			name: 'span',
     * 			styles: {
     * 				'text-decoration': 'underline'
     * 			}
     * 		},
     * 		lineThrough: {
     * 			name: 'span',
     * 			styles: {
     * 				'text-decoration': 'line-through'
     * 			}
     * 		}
     * 	}
     * } );
     *
     * // Use `upcastAlso` to define other view elements that should also be converted to the `bold` attribute.
     * editor.conversion.attributeToElement( {
     * 	model: 'bold',
     * 	view: 'strong',
     * 	upcastAlso: [
     * 		'b',
     * 		{
     * 			name: 'span',
     * 			classes: 'bold'
     * 		},
     * 		{
     * 			name: 'span',
     * 			styles: {
     * 				'font-weight': 'bold'
     * 			}
     * 		},
     * 		viewElement => {
     * 			const fontWeight = viewElement.getStyle( 'font-weight' );
     *
     * 			if ( viewElement.is( 'element', 'span' ) && fontWeight && /\d+/.test() && Number( fontWeight ) > 500 ) {
     * 				// Returned value can be an object with the matched properties.
     * 				// These properties will be "consumed" during the conversion.
     * 				// See `engine.view.Matcher~MatcherPattern` and `engine.view.Matcher#match` for more details.
     *
     * 				return {
     * 					name: true,
     * 					styles: [ 'font-weight' ]
     * 				};
     * 			}
     * 		}
     * 	]
     * } );
     *
     * // Conversion from and to a model attribute key whose value is an enum (`fontSize=big|small`).
     * // `upcastAlso` set as callback enables a conversion of a wide range of different view elements.
     * editor.conversion.attributeToElement( {
     * 	model: {
     * 		key: 'fontSize',
     * 		values: [ 'big', 'small' ]
     * 	},
     * 	view: {
     * 		big: {
     * 			name: 'span',
     * 			styles: {
     * 				'font-size': '1.2em'
     * 			}
     * 		},
     * 		small: {
     * 			name: 'span',
     * 			styles: {
     * 				'font-size': '0.8em'
     * 			}
     * 		}
     * 	},
     * 	upcastAlso: {
     * 		big: viewElement => {
     * 			const fontSize = viewElement.getStyle( 'font-size' );
     *
     * 			if ( !fontSize ) {
     * 				return null;
     * 			}
     *
     * 			const match = fontSize.match( /(\d+)\s*px/ );
     *
     * 			if ( !match ) {
     * 				return null;
     * 			}
     *
     * 			const size = Number( match[ 1 ] );
     *
     * 			if ( viewElement.is( 'element', 'span' ) && size > 10 ) {
     * 				// Returned value can be an object with the matched properties.
     * 				// These properties will be "consumed" during the conversion.
     * 				// See `engine.view.Matcher~MatcherPattern` and `engine.view.Matcher#match` for more details.
     *
     * 				return { name: true, styles: [ 'font-size' ] };
     * 			}
     *
     * 			return null;
     * 		},
     * 		small: viewElement => {
     * 			const fontSize = viewElement.getStyle( 'font-size' );
     *
     * 			if ( !fontSize ) {
     * 				return null;
     * 			}
     *
     * 			const match = fontSize.match( /(\d+)\s*px/ );
     *
     * 			if ( !match ) {
     * 				return null;
     * 			}
     *
     * 			const size = Number( match[ 1 ] );
     *
     * 			if ( viewElement.is( 'element', 'span' ) && size < 10 ) {
     * 				// Returned value can be an object with the matched properties.
     * 				// These properties will be "consumed" during the conversion.
     * 				// See `engine.view.Matcher~MatcherPattern` and `engine.view.Matcher#match` for more details.
     *
     * 				return { name: true, styles: [ 'font-size' ] };
     * 			}
     *
     * 			return null;
     * 		}
     * 	}
     * } );
     * ```
     *
     * The `definition.model` parameter specifies which model attribute should be converted from or to. It can be a `{ key, value }` object
     * describing the attribute key and value to convert or a `String` specifying just the attribute key (in such a case
     * `value` is set to `true`).
     *
     * @param definition The converter definition.
     */ attributeToElement(definition) {
        // Set up downcast converter.
        this.for('downcast').attributeToElement(definition);
        // Set up upcast converter.
        for (const { model, view } of _getAllUpcastDefinitions(definition)){
            this.for('upcast').elementToAttribute({
                view,
                model,
                converterPriority: definition.converterPriority
            });
        }
    }
    /**
     * Sets up converters between the model and the view that convert a model attribute to a view attribute (and vice versa). For example,
     * `<imageBlock src='foo.jpg'></imageBlock>` is converted to `<img src='foo.jpg'></img>` (the same attribute key and value).
     * This type of converters is intended to be used with {@link module:engine/model/element~Element model element} nodes.
     * To convert the text attributes,
     * the {@link module:engine/conversion/conversion~Conversion#attributeToElement `attributeToElement converter`}should be set up.
     *
     * ```ts
     * // A simple conversion from the `source` model attribute to the `src` view attribute (and vice versa).
     * editor.conversion.attributeToAttribute( { model: 'source', view: 'src' } );
     *
     * // Attribute values are strictly specified.
     * editor.conversion.attributeToAttribute( {
     * 	model: {
     * 		name: 'imageInline',
     * 		key: 'aside',
     * 		values: [ 'aside' ]
     * 	},
     * 	view: {
     * 		aside: {
     * 			name: 'img',
     * 			key: 'class',
     * 			value: [ 'aside', 'half-size' ]
     * 		}
     * 	}
     * } );
     *
     * // Set the style attribute.
     * editor.conversion.attributeToAttribute( {
     * 	model: {
     * 		name: 'imageInline',
     * 		key: 'aside',
     * 		values: [ 'aside' ]
     * 	},
     * 	view: {
     * 		aside: {
     * 			name: 'img',
     * 			key: 'style',
     * 			value: {
     * 				float: 'right',
     * 				width: '50%',
     * 				margin: '5px'
     * 			}
     * 		}
     * 	}
     * } );
     *
     * // Conversion from and to a model attribute key whose value is an enum (`align=right|center`).
     * // Use `upcastAlso` to define other view elements that should also be converted to the `align=right` attribute.
     * editor.conversion.attributeToAttribute( {
     * 	model: {
     * 		key: 'align',
     * 		values: [ 'right', 'center' ]
     * 	},
     * 	view: {
     * 		right: {
     * 			key: 'class',
     * 			value: 'align-right'
     * 		},
     * 		center: {
     * 			key: 'class',
     * 			value: 'align-center'
     * 		}
     * 	},
     * 	upcastAlso: {
     * 		right: {
     * 			styles: {
     * 				'text-align': 'right'
     * 			}
     * 		},
     * 		center: {
     * 			styles: {
     * 				'text-align': 'center'
     * 			}
     * 		}
     * 	}
     * } );
     * ```
     *
     * The `definition.model` parameter specifies which model attribute should be converted from and to.
     * It can be a `{ key, [ values ], [ name ] }` object or a `String`, which will be treated like `{ key: definition.model }`.
     * The `key` property is the model attribute key to convert from and to.
     * The `values` are the possible model attribute values. If the `values` parameter is not set, the model attribute value
     * will be the same as the view attribute value.
     * If `name` is set, the conversion will be set up only for model elements with the given name.
     *
     * The `definition.view` parameter specifies which view attribute should be converted from and to.
     * It can be a `{ key, value, [ name ] }` object or a `String`, which will be treated like `{ key: definition.view }`.
     * The `key` property is the view attribute key to convert from and to.
     * The `value` is the view attribute value to convert from and to. If `definition.value` is not set, the view attribute value will be
     * the same as the model attribute value.
     * If `key` is `'class'`, `value` can be a `String` or an array of `String`s.
     * If `key` is `'style'`, `value` is an object with key-value pairs.
     * In other cases, `value` is a `String`.
     * If `name` is set, the conversion will be set up only for model elements with the given name.
     * If `definition.model.values` is set, `definition.view` is an object that assigns values from `definition.model.values`
     * to `{ key, value, [ name ] }` objects.
     *
     * `definition.upcastAlso` specifies which other matching view elements should also be upcast to the given model configuration.
     * If `definition.model.values` is set, `definition.upcastAlso` should be an object assigning values from `definition.model.values`
     * to {@link module:engine/view/matcher~MatcherPattern}s or arrays of {@link module:engine/view/matcher~MatcherPattern}s.
     *
     * **Note:** `definition.model` and `definition.view` form should be mirrored, so the same types of parameters should
     * be given in both parameters.
     *
     * @param definition The converter definition.
     * @param definition.model The model attribute to convert from and to.
     * @param definition.view The view attribute to convert from and to.
     * @param definition.upcastAlso Any view element matching `definition.upcastAlso` will also be converted to the given model attribute.
     * `definition.upcastAlso` is used only if `config.model.values` is specified.
     */ attributeToAttribute(definition) {
        // Set up downcast converter.
        this.for('downcast').attributeToAttribute(definition);
        // Set up upcast converter.
        for (const { model, view } of _getAllUpcastDefinitions(definition)){
            this.for('upcast').attributeToAttribute({
                view,
                model
            });
        }
    }
    /**
     * Creates and caches conversion helpers for given dispatchers group.
     *
     * @param options.name Group name.
     */ _createConversionHelpers({ name, dispatchers, isDowncast }) {
        if (this._helpers.has(name)) {
            /**
             * Trying to register a group name that has already been registered.
             *
             * @error conversion-group-exists
             */ throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$ckeditorerror$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__CKEditorError$3e$__["CKEditorError"]('conversion-group-exists', this);
        }
        const helpers = isDowncast ? new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$downcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](dispatchers) : new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$upcasthelpers$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](dispatchers);
        this._helpers.set(name, helpers);
    }
}
/**
 * Helper function that creates a joint array out of an item passed in `definition.view` and items passed in
 * `definition.upcastAlso`.
 */ function* _getAllUpcastDefinitions(definition) {
    if (definition.model.values) {
        for (const value of definition.model.values){
            const model = {
                key: definition.model.key,
                value
            };
            const view = definition.view[value];
            const upcastAlso = definition.upcastAlso ? definition.upcastAlso[value] : undefined;
            yield* _getUpcastDefinition(model, view, upcastAlso);
        }
    } else {
        yield* _getUpcastDefinition(definition.model, definition.view, definition.upcastAlso);
    }
}
function* _getUpcastDefinition(model, view, upcastAlso) {
    yield {
        model,
        view
    };
    if (upcastAlso) {
        for (const upcastAlsoItem of (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$toarray$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__toArray$3e$__["toArray"])(upcastAlso)){
            yield {
                model,
                view: upcastAlsoItem
            };
        }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/conversion.js [app-ssr] (ecmascript) <export default as Conversion>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Conversion",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$conversion$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$conversion$2f$conversion$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/conversion/conversion.js [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=e9609_%40ckeditor_ckeditor5-engine_src_conversion_1f0e16c1._.js.map