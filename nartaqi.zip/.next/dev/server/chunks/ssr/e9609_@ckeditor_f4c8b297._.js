module.exports = [
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-react/dist/ckeditor.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

/*!
 * @license Copyright (c) 2003-2022, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md.
 */ !function(t, e) {
    ("TURBOPACK compile-time truthy", 1) ? module.exports = e(__turbopack_context__.r("[project]/Desktop/nartaqi/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)")) : "TURBOPACK unreachable";
}(window, function(t) {
    return function(t) {
        var e = {};
        function r(o) {
            if (e[o]) return e[o].exports;
            var n = e[o] = {
                i: o,
                l: !1,
                exports: {}
            };
            return t[o].call(n.exports, n, n.exports, r), n.l = !0, n.exports;
        }
        return r.m = t, r.c = e, r.d = function(t, e, o) {
            r.o(t, e) || Object.defineProperty(t, e, {
                enumerable: !0,
                get: o
            });
        }, r.r = function(t) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(t, "__esModule", {
                value: !0
            });
        }, r.t = function(t, e) {
            if (1 & e && (t = r(t)), 8 & e) return t;
            if (4 & e && "object" == typeof t && t && t.__esModule) return t;
            var o = Object.create(null);
            if (r.r(o), Object.defineProperty(o, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t) for(var n in t)r.d(o, n, (function(e) {
                return t[e];
            }).bind(null, n));
            return o;
        }, r.n = function(t) {
            var e = t && t.__esModule ? function() {
                return t.default;
            } : function() {
                return t;
            };
            return r.d(e, "a", e), e;
        }, r.o = function(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e);
        }, r.p = "", r(r.s = 12);
    }([
        function(t, e, r) {
            "use strict";
            var o = r(4), n = "object" == typeof self && self && self.Object === Object && self, i = o.a || n || Function("return this")();
            e.a = i;
        },
        function(t, e, r) {
            t.exports = r(10)();
        },
        function(t, e, r) {
            "use strict";
            (function(t) {
                var o = r(4), n = "object" == ("TURBOPACK compile-time value", "object") && exports && !exports.nodeType && exports, i = n && "object" == typeof t && t && !t.nodeType && t, a = i && i.exports === n && o.a.process, s = function() {
                    try {
                        var t = i && i.require && i.require("util").types;
                        return t || a && a.binding && a.binding("util");
                    } catch (t) {}
                }();
                e.a = s;
            }).call(this, r(6)(t));
        },
        function(e, r) {
            e.exports = t;
        },
        function(t, e, r) {
            "use strict";
            (function(t) {
                var r = "object" == typeof t && t && t.Object === Object && t;
                e.a = r;
            }).call(this, r(9));
        },
        function(t, e, r) {
            "use strict";
            (function(t) {
                var o = r(0), n = r(7), i = "object" == ("TURBOPACK compile-time value", "object") && exports && !exports.nodeType && exports, a = i && "object" == typeof t && t && !t.nodeType && t, s = a && a.exports === i ? o.a.Buffer : void 0, c = (s ? s.isBuffer : void 0) || n.a;
                e.a = c;
            }).call(this, r(6)(t));
        },
        function(t, e) {
            t.exports = function(t) {
                if (!t.webpackPolyfill) {
                    var e = Object.create(t);
                    e.children || (e.children = []), Object.defineProperty(e, "loaded", {
                        enumerable: !0,
                        get: function() {
                            return e.l;
                        }
                    }), Object.defineProperty(e, "id", {
                        enumerable: !0,
                        get: function() {
                            return e.i;
                        }
                    }), Object.defineProperty(e, "exports", {
                        enumerable: !0
                    }), e.webpackPolyfill = 1;
                }
                return e;
            };
        },
        function(t, e, r) {
            "use strict";
            e.a = function() {
                return !1;
            };
        },
        function(t, e, r) {
            "use strict";
            (function(t) {
                var o = r(0), n = "object" == ("TURBOPACK compile-time value", "object") && exports && !exports.nodeType && exports, i = n && "object" == typeof t && t && !t.nodeType && t, a = i && i.exports === n ? o.a.Buffer : void 0, s = a ? a.allocUnsafe : void 0;
                e.a = function(t, e) {
                    if (e) return t.slice();
                    var r = t.length, o = s ? s(r) : new t.constructor(r);
                    return t.copy(o), o;
                };
            }).call(this, r(6)(t));
        },
        function(t, e) {
            var r;
            r = function() {
                return this;
            }();
            try {
                r = r || new Function("return this")();
            } catch (t) {
                "object" == ("TURBOPACK compile-time value", "undefined") && (r = window);
            }
            t.exports = r;
        },
        function(t, e, r) {
            "use strict";
            var o = r(11);
            function n() {}
            function i() {}
            i.resetWarningCache = n, t.exports = function() {
                function t(t, e, r, n, i, a) {
                    if (a !== o) {
                        var s = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                        throw s.name = "Invariant Violation", s;
                    }
                }
                function e() {
                    return t;
                }
                t.isRequired = t;
                var r = {
                    array: t,
                    bigint: t,
                    bool: t,
                    func: t,
                    number: t,
                    object: t,
                    string: t,
                    symbol: t,
                    any: t,
                    arrayOf: e,
                    element: t,
                    elementType: t,
                    instanceOf: e,
                    node: t,
                    objectOf: e,
                    oneOf: e,
                    oneOfType: e,
                    shape: e,
                    exact: e,
                    checkPropTypes: i,
                    resetWarningCache: n
                };
                return r.PropTypes = r, r;
            };
        },
        function(t, e, r) {
            "use strict";
            t.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
        },
        function(t, e, r) {
            "use strict";
            r.r(e), r.d(e, "CKEditor", function() {
                return Rr;
            }), r.d(e, "CKEditorContext", function() {
                return Sr;
            });
            var o = r(3), n = r.n(o), i = r(1), a = r.n(i);
            var s = function(t) {
                var e = typeof t;
                return null != t && ("object" == e || "function" == e);
            }, c = r(0), u = function() {
                return c.a.Date.now();
            }, h = /\s/;
            var d = function(t) {
                for(var e = t.length; e-- && h.test(t.charAt(e)););
                return e;
            }, l = /^\s+/;
            var f = function(t) {
                return t ? t.slice(0, d(t) + 1).replace(l, "") : t;
            }, p = c.a.Symbol, _ = Object.prototype, y = _.hasOwnProperty, v = _.toString, b = p ? p.toStringTag : void 0;
            var g = function(t) {
                var e = y.call(t, b), r = t[b];
                try {
                    t[b] = void 0;
                    var o = !0;
                } catch (t) {}
                var n = v.call(t);
                return o && (e ? t[b] = r : delete t[b]), n;
            }, m = Object.prototype.toString;
            var j = function(t) {
                return m.call(t);
            }, w = p ? p.toStringTag : void 0;
            var x = function(t) {
                return null == t ? void 0 === t ? "[object Undefined]" : "[object Null]" : w && w in Object(t) ? g(t) : j(t);
            };
            var E = function(t) {
                return null != t && "object" == typeof t;
            };
            var O = function(t) {
                return "symbol" == typeof t || E(t) && "[object Symbol]" == x(t);
            }, P = /^[-+]0x[0-9a-f]+$/i, C = /^0b[01]+$/i, A = /^0o[0-7]+$/i, T = parseInt;
            var W = function(t) {
                if ("number" == typeof t) return t;
                if (O(t)) return NaN;
                if (s(t)) {
                    var e = "function" == typeof t.valueOf ? t.valueOf() : t;
                    t = s(e) ? e + "" : e;
                }
                if ("string" != typeof t) return 0 === t ? t : +t;
                t = f(t);
                var r = C.test(t);
                return r || A.test(t) ? T(t.slice(2), r ? 2 : 8) : P.test(t) ? NaN : +t;
            }, S = Math.max, R = Math.min;
            var D = function(t, e, r) {
                var o, n, i, a, c, h, d = 0, l = !1, f = !1, p = !0;
                if ("function" != typeof t) throw new TypeError("Expected a function");
                function _(e) {
                    var r = o, i = n;
                    return o = n = void 0, d = e, a = t.apply(i, r);
                }
                function y(t) {
                    return d = t, c = setTimeout(b, e), l ? _(t) : a;
                }
                function v(t) {
                    var r = t - h;
                    return void 0 === h || r >= e || r < 0 || f && t - d >= i;
                }
                function b() {
                    var t = u();
                    if (v(t)) return g(t);
                    c = setTimeout(b, function(t) {
                        var r = e - (t - h);
                        return f ? R(r, i - (t - d)) : r;
                    }(t));
                }
                function g(t) {
                    return c = void 0, p && o ? _(t) : (o = n = void 0, a);
                }
                function m() {
                    var t = u(), r = v(t);
                    if (o = arguments, n = this, h = t, r) {
                        if (void 0 === c) return y(h);
                        if (f) return clearTimeout(c), c = setTimeout(b, e), _(h);
                    }
                    return void 0 === c && (c = setTimeout(b, e)), a;
                }
                return e = W(e) || 0, s(r) && (l = !!r.leading, i = (f = "maxWait" in r) ? S(W(r.maxWait) || 0, e) : i, p = "trailing" in r ? !!r.trailing : p), m.cancel = function() {
                    void 0 !== c && clearTimeout(c), d = 0, o = h = n = c = void 0;
                }, m.flush = function() {
                    return void 0 === c ? a : g(u());
                }, m;
            };
            var I = function(t, e, r) {
                var o = !0, n = !0;
                if ("function" != typeof t) throw new TypeError("Expected a function");
                return s(r) && (o = "leading" in r ? !!r.leading : o, n = "trailing" in r ? !!r.trailing : n), D(t, e, {
                    leading: o,
                    maxWait: e,
                    trailing: n
                });
            };
            var z = function() {
                this.__data__ = [], this.size = 0;
            };
            var F = function(t, e) {
                return t === e || t != t && e != e;
            };
            var M = function(t, e) {
                for(var r = t.length; r--;)if (F(t[r][0], e)) return r;
                return -1;
            }, U = Array.prototype.splice;
            var N = function(t) {
                var e = this.__data__, r = M(e, t);
                return !(r < 0) && (r == e.length - 1 ? e.pop() : U.call(e, r, 1), --this.size, !0);
            };
            var k = function(t) {
                var e = this.__data__, r = M(e, t);
                return r < 0 ? void 0 : e[r][1];
            };
            var L = function(t) {
                return M(this.__data__, t) > -1;
            };
            var B = function(t, e) {
                var r = this.__data__, o = M(r, t);
                return o < 0 ? (++this.size, r.push([
                    t,
                    e
                ])) : r[o][1] = e, this;
            };
            function $(t) {
                var e = -1, r = null == t ? 0 : t.length;
                for(this.clear(); ++e < r;){
                    var o = t[e];
                    this.set(o[0], o[1]);
                }
            }
            $.prototype.clear = z, $.prototype.delete = N, $.prototype.get = k, $.prototype.has = L, $.prototype.set = B;
            var q = $;
            var H = function() {
                this.__data__ = new q, this.size = 0;
            };
            var Q = function(t) {
                var e = this.__data__, r = e.delete(t);
                return this.size = e.size, r;
            };
            var V = function(t) {
                return this.__data__.get(t);
            };
            var K = function(t) {
                return this.__data__.has(t);
            };
            var G, Y = function(t) {
                if (!s(t)) return !1;
                var e = x(t);
                return "[object Function]" == e || "[object GeneratorFunction]" == e || "[object AsyncFunction]" == e || "[object Proxy]" == e;
            }, J = c.a["__core-js_shared__"], X = (G = /[^.]+$/.exec(J && J.keys && J.keys.IE_PROTO || "")) ? "Symbol(src)_1." + G : "";
            var Z = function(t) {
                return !!X && X in t;
            }, tt = Function.prototype.toString;
            var et = function(t) {
                if (null != t) {
                    try {
                        return tt.call(t);
                    } catch (t) {}
                    try {
                        return t + "";
                    } catch (t) {}
                }
                return "";
            }, rt = /^\[object .+?Constructor\]$/, ot = Function.prototype, nt = Object.prototype, it = ot.toString, at = nt.hasOwnProperty, st = RegExp("^" + it.call(at).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
            var ct = function(t) {
                return !(!s(t) || Z(t)) && (Y(t) ? st : rt).test(et(t));
            };
            var ut = function(t, e) {
                return null == t ? void 0 : t[e];
            };
            var ht = function(t, e) {
                var r = ut(t, e);
                return ct(r) ? r : void 0;
            }, dt = ht(c.a, "Map"), lt = ht(Object, "create");
            var ft = function() {
                this.__data__ = lt ? lt(null) : {}, this.size = 0;
            };
            var pt = function(t) {
                var e = this.has(t) && delete this.__data__[t];
                return this.size -= e ? 1 : 0, e;
            }, _t = Object.prototype.hasOwnProperty;
            var yt = function(t) {
                var e = this.__data__;
                if (lt) {
                    var r = e[t];
                    return "__lodash_hash_undefined__" === r ? void 0 : r;
                }
                return _t.call(e, t) ? e[t] : void 0;
            }, vt = Object.prototype.hasOwnProperty;
            var bt = function(t) {
                var e = this.__data__;
                return lt ? void 0 !== e[t] : vt.call(e, t);
            };
            var gt = function(t, e) {
                var r = this.__data__;
                return this.size += this.has(t) ? 0 : 1, r[t] = lt && void 0 === e ? "__lodash_hash_undefined__" : e, this;
            };
            function mt(t) {
                var e = -1, r = null == t ? 0 : t.length;
                for(this.clear(); ++e < r;){
                    var o = t[e];
                    this.set(o[0], o[1]);
                }
            }
            mt.prototype.clear = ft, mt.prototype.delete = pt, mt.prototype.get = yt, mt.prototype.has = bt, mt.prototype.set = gt;
            var jt = mt;
            var wt = function() {
                this.size = 0, this.__data__ = {
                    hash: new jt,
                    map: new (dt || q),
                    string: new jt
                };
            };
            var xt = function(t) {
                var e = typeof t;
                return "string" == e || "number" == e || "symbol" == e || "boolean" == e ? "__proto__" !== t : null === t;
            };
            var Et = function(t, e) {
                var r = t.__data__;
                return xt(e) ? r["string" == typeof e ? "string" : "hash"] : r.map;
            };
            var Ot = function(t) {
                var e = Et(this, t).delete(t);
                return this.size -= e ? 1 : 0, e;
            };
            var Pt = function(t) {
                return Et(this, t).get(t);
            };
            var Ct = function(t) {
                return Et(this, t).has(t);
            };
            var At = function(t, e) {
                var r = Et(this, t), o = r.size;
                return r.set(t, e), this.size += r.size == o ? 0 : 1, this;
            };
            function Tt(t) {
                var e = -1, r = null == t ? 0 : t.length;
                for(this.clear(); ++e < r;){
                    var o = t[e];
                    this.set(o[0], o[1]);
                }
            }
            Tt.prototype.clear = wt, Tt.prototype.delete = Ot, Tt.prototype.get = Pt, Tt.prototype.has = Ct, Tt.prototype.set = At;
            var Wt = Tt;
            var St = function(t, e) {
                var r = this.__data__;
                if (r instanceof q) {
                    var o = r.__data__;
                    if (!dt || o.length < 199) return o.push([
                        t,
                        e
                    ]), this.size = ++r.size, this;
                    r = this.__data__ = new Wt(o);
                }
                return r.set(t, e), this.size = r.size, this;
            };
            function Rt(t) {
                var e = this.__data__ = new q(t);
                this.size = e.size;
            }
            Rt.prototype.clear = H, Rt.prototype.delete = Q, Rt.prototype.get = V, Rt.prototype.has = K, Rt.prototype.set = St;
            var Dt = Rt;
            var It = function(t, e) {
                for(var r = -1, o = null == t ? 0 : t.length; ++r < o && !1 !== e(t[r], r, t););
                return t;
            }, zt = function() {
                try {
                    var t = ht(Object, "defineProperty");
                    return t({}, "", {}), t;
                } catch (t) {}
            }();
            var Ft = function(t, e, r) {
                "__proto__" == e && zt ? zt(t, e, {
                    configurable: !0,
                    enumerable: !0,
                    value: r,
                    writable: !0
                }) : t[e] = r;
            }, Mt = Object.prototype.hasOwnProperty;
            var Ut = function(t, e, r) {
                var o = t[e];
                Mt.call(t, e) && F(o, r) && (void 0 !== r || e in t) || Ft(t, e, r);
            };
            var Nt = function(t, e, r, o) {
                var n = !r;
                r || (r = {});
                for(var i = -1, a = e.length; ++i < a;){
                    var s = e[i], c = o ? o(r[s], t[s], s, r, t) : void 0;
                    void 0 === c && (c = t[s]), n ? Ft(r, s, c) : Ut(r, s, c);
                }
                return r;
            };
            var kt = function(t, e) {
                for(var r = -1, o = Array(t); ++r < t;)o[r] = e(r);
                return o;
            };
            var Lt = function(t) {
                return E(t) && "[object Arguments]" == x(t);
            }, Bt = Object.prototype, $t = Bt.hasOwnProperty, qt = Bt.propertyIsEnumerable, Ht = Lt(function() {
                return arguments;
            }()) ? Lt : function(t) {
                return E(t) && $t.call(t, "callee") && !qt.call(t, "callee");
            }, Qt = Array.isArray, Vt = r(5), Kt = /^(?:0|[1-9]\d*)$/;
            var Gt = function(t, e) {
                var r = typeof t;
                return !!(e = null == e ? 9007199254740991 : e) && ("number" == r || "symbol" != r && Kt.test(t)) && t > -1 && t % 1 == 0 && t < e;
            };
            var Yt = function(t) {
                return "number" == typeof t && t > -1 && t % 1 == 0 && t <= 9007199254740991;
            }, Jt = {};
            Jt["[object Float32Array]"] = Jt["[object Float64Array]"] = Jt["[object Int8Array]"] = Jt["[object Int16Array]"] = Jt["[object Int32Array]"] = Jt["[object Uint8Array]"] = Jt["[object Uint8ClampedArray]"] = Jt["[object Uint16Array]"] = Jt["[object Uint32Array]"] = !0, Jt["[object Arguments]"] = Jt["[object Array]"] = Jt["[object ArrayBuffer]"] = Jt["[object Boolean]"] = Jt["[object DataView]"] = Jt["[object Date]"] = Jt["[object Error]"] = Jt["[object Function]"] = Jt["[object Map]"] = Jt["[object Number]"] = Jt["[object Object]"] = Jt["[object RegExp]"] = Jt["[object Set]"] = Jt["[object String]"] = Jt["[object WeakMap]"] = !1;
            var Xt = function(t) {
                return E(t) && Yt(t.length) && !!Jt[x(t)];
            };
            var Zt = function(t) {
                return function(e) {
                    return t(e);
                };
            }, te = r(2), ee = te.a && te.a.isTypedArray, re = ee ? Zt(ee) : Xt, oe = Object.prototype.hasOwnProperty;
            var ne = function(t, e) {
                var r = Qt(t), o = !r && Ht(t), n = !r && !o && Object(Vt.a)(t), i = !r && !o && !n && re(t), a = r || o || n || i, s = a ? kt(t.length, String) : [], c = s.length;
                for(var u in t)!e && !oe.call(t, u) || a && ("length" == u || n && ("offset" == u || "parent" == u) || i && ("buffer" == u || "byteLength" == u || "byteOffset" == u) || Gt(u, c)) || s.push(u);
                return s;
            }, ie = Object.prototype;
            var ae = function(t) {
                var e = t && t.constructor;
                return t === ("function" == typeof e && e.prototype || ie);
            };
            var se = function(t, e) {
                return function(r) {
                    return t(e(r));
                };
            }, ce = se(Object.keys, Object), ue = Object.prototype.hasOwnProperty;
            var he = function(t) {
                if (!ae(t)) return ce(t);
                var e = [];
                for(var r in Object(t))ue.call(t, r) && "constructor" != r && e.push(r);
                return e;
            };
            var de = function(t) {
                return null != t && Yt(t.length) && !Y(t);
            };
            var le = function(t) {
                return de(t) ? ne(t) : he(t);
            };
            var fe = function(t, e) {
                return t && Nt(e, le(e), t);
            };
            var pe = function(t) {
                var e = [];
                if (null != t) for(var r in Object(t))e.push(r);
                return e;
            }, _e = Object.prototype.hasOwnProperty;
            var ye = function(t) {
                if (!s(t)) return pe(t);
                var e = ae(t), r = [];
                for(var o in t)("constructor" != o || !e && _e.call(t, o)) && r.push(o);
                return r;
            };
            var ve = function(t) {
                return de(t) ? ne(t, !0) : ye(t);
            };
            var be = function(t, e) {
                return t && Nt(e, ve(e), t);
            }, ge = r(8);
            var me = function(t, e) {
                var r = -1, o = t.length;
                for(e || (e = Array(o)); ++r < o;)e[r] = t[r];
                return e;
            };
            var je = function(t, e) {
                for(var r = -1, o = null == t ? 0 : t.length, n = 0, i = []; ++r < o;){
                    var a = t[r];
                    e(a, r, t) && (i[n++] = a);
                }
                return i;
            };
            var we = function() {
                return [];
            }, xe = Object.prototype.propertyIsEnumerable, Ee = Object.getOwnPropertySymbols, Oe = Ee ? function(t) {
                return null == t ? [] : (t = Object(t), je(Ee(t), function(e) {
                    return xe.call(t, e);
                }));
            } : we;
            var Pe = function(t, e) {
                return Nt(t, Oe(t), e);
            };
            var Ce = function(t, e) {
                for(var r = -1, o = e.length, n = t.length; ++r < o;)t[n + r] = e[r];
                return t;
            }, Ae = se(Object.getPrototypeOf, Object), Te = Object.getOwnPropertySymbols ? function(t) {
                for(var e = []; t;)Ce(e, Oe(t)), t = Ae(t);
                return e;
            } : we;
            var We = function(t, e) {
                return Nt(t, Te(t), e);
            };
            var Se = function(t, e, r) {
                var o = e(t);
                return Qt(t) ? o : Ce(o, r(t));
            };
            var Re = function(t) {
                return Se(t, le, Oe);
            };
            var De = function(t) {
                return Se(t, ve, Te);
            }, Ie = ht(c.a, "DataView"), ze = ht(c.a, "Promise"), Fe = ht(c.a, "Set"), Me = ht(c.a, "WeakMap"), Ue = et(Ie), Ne = et(dt), ke = et(ze), Le = et(Fe), Be = et(Me), $e = x;
            (Ie && "[object DataView]" != $e(new Ie(new ArrayBuffer(1))) || dt && "[object Map]" != $e(new dt) || ze && "[object Promise]" != $e(ze.resolve()) || Fe && "[object Set]" != $e(new Fe) || Me && "[object WeakMap]" != $e(new Me)) && ($e = function(t) {
                var e = x(t), r = "[object Object]" == e ? t.constructor : void 0, o = r ? et(r) : "";
                if (o) switch(o){
                    case Ue:
                        return "[object DataView]";
                    case Ne:
                        return "[object Map]";
                    case ke:
                        return "[object Promise]";
                    case Le:
                        return "[object Set]";
                    case Be:
                        return "[object WeakMap]";
                }
                return e;
            });
            var qe = $e, He = Object.prototype.hasOwnProperty;
            var Qe = function(t) {
                var e = t.length, r = new t.constructor(e);
                return e && "string" == typeof t[0] && He.call(t, "index") && (r.index = t.index, r.input = t.input), r;
            }, Ve = c.a.Uint8Array;
            var Ke = function(t) {
                var e = new t.constructor(t.byteLength);
                return new Ve(e).set(new Ve(t)), e;
            };
            var Ge = function(t, e) {
                var r = e ? Ke(t.buffer) : t.buffer;
                return new t.constructor(r, t.byteOffset, t.byteLength);
            }, Ye = /\w*$/;
            var Je = function(t) {
                var e = new t.constructor(t.source, Ye.exec(t));
                return e.lastIndex = t.lastIndex, e;
            }, Xe = p ? p.prototype : void 0, Ze = Xe ? Xe.valueOf : void 0;
            var tr = function(t) {
                return Ze ? Object(Ze.call(t)) : {};
            };
            var er = function(t, e) {
                var r = e ? Ke(t.buffer) : t.buffer;
                return new t.constructor(r, t.byteOffset, t.length);
            };
            var rr = function(t, e, r) {
                var o = t.constructor;
                switch(e){
                    case "[object ArrayBuffer]":
                        return Ke(t);
                    case "[object Boolean]":
                    case "[object Date]":
                        return new o(+t);
                    case "[object DataView]":
                        return Ge(t, r);
                    case "[object Float32Array]":
                    case "[object Float64Array]":
                    case "[object Int8Array]":
                    case "[object Int16Array]":
                    case "[object Int32Array]":
                    case "[object Uint8Array]":
                    case "[object Uint8ClampedArray]":
                    case "[object Uint16Array]":
                    case "[object Uint32Array]":
                        return er(t, r);
                    case "[object Map]":
                        return new o;
                    case "[object Number]":
                    case "[object String]":
                        return new o(t);
                    case "[object RegExp]":
                        return Je(t);
                    case "[object Set]":
                        return new o;
                    case "[object Symbol]":
                        return tr(t);
                }
            }, or = Object.create, nr = function() {
                function t() {}
                return function(e) {
                    if (!s(e)) return {};
                    if (or) return or(e);
                    t.prototype = e;
                    var r = new t;
                    return t.prototype = void 0, r;
                };
            }();
            var ir = function(t) {
                return "function" != typeof t.constructor || ae(t) ? {} : nr(Ae(t));
            };
            var ar = function(t) {
                return E(t) && "[object Map]" == qe(t);
            }, sr = te.a && te.a.isMap, cr = sr ? Zt(sr) : ar;
            var ur = function(t) {
                return E(t) && "[object Set]" == qe(t);
            }, hr = te.a && te.a.isSet, dr = hr ? Zt(hr) : ur, lr = {};
            lr["[object Arguments]"] = lr["[object Array]"] = lr["[object ArrayBuffer]"] = lr["[object DataView]"] = lr["[object Boolean]"] = lr["[object Date]"] = lr["[object Float32Array]"] = lr["[object Float64Array]"] = lr["[object Int8Array]"] = lr["[object Int16Array]"] = lr["[object Int32Array]"] = lr["[object Map]"] = lr["[object Number]"] = lr["[object Object]"] = lr["[object RegExp]"] = lr["[object Set]"] = lr["[object String]"] = lr["[object Symbol]"] = lr["[object Uint8Array]"] = lr["[object Uint8ClampedArray]"] = lr["[object Uint16Array]"] = lr["[object Uint32Array]"] = !0, lr["[object Error]"] = lr["[object Function]"] = lr["[object WeakMap]"] = !1;
            var fr = function t(e, r, o, n, i, a) {
                var c, u = 1 & r, h = 2 & r, d = 4 & r;
                if (o && (c = i ? o(e, n, i, a) : o(e)), void 0 !== c) return c;
                if (!s(e)) return e;
                var l = Qt(e);
                if (l) {
                    if (c = Qe(e), !u) return me(e, c);
                } else {
                    var f = qe(e), p = "[object Function]" == f || "[object GeneratorFunction]" == f;
                    if (Object(Vt.a)(e)) return Object(ge.a)(e, u);
                    if ("[object Object]" == f || "[object Arguments]" == f || p && !i) {
                        if (c = h || p ? {} : ir(e), !u) return h ? We(e, be(c, e)) : Pe(e, fe(c, e));
                    } else {
                        if (!lr[f]) return i ? e : {};
                        c = rr(e, f, u);
                    }
                }
                a || (a = new Dt);
                var _ = a.get(e);
                if (_) return _;
                a.set(e, c), dr(e) ? e.forEach(function(n) {
                    c.add(t(n, r, o, n, e, a));
                }) : cr(e) && e.forEach(function(n, i) {
                    c.set(i, t(n, r, o, i, e, a));
                });
                var y = l ? void 0 : (d ? h ? De : Re : h ? ve : le)(e);
                return It(y || e, function(n, i) {
                    y && (n = e[i = n]), Ut(c, i, t(n, r, o, i, e, a));
                }), c;
            };
            var pr = function(t, e) {
                return fr(t, 5, e = "function" == typeof e ? e : void 0);
            }, _r = Function.prototype, yr = Object.prototype, vr = _r.toString, br = yr.hasOwnProperty, gr = vr.call(Object);
            var mr = function(t) {
                if (!E(t) || "[object Object]" != x(t)) return !1;
                var e = Ae(t);
                if (null === e) return !0;
                var r = br.call(e, "constructor") && e.constructor;
                return "function" == typeof r && r instanceof r && vr.call(r) == gr;
            };
            var jr = function(t) {
                return E(t) && 1 === t.nodeType && !mr(t);
            };
            function wr(t, e = new Set) {
                const r = [
                    t
                ], o = new Set;
                for(; r.length > 0;){
                    const t = r.shift();
                    if (!(o.has(t) || xr(t) || e.has(t))) if (o.add(t), t[Symbol.iterator]) try {
                        for (const e of t)r.push(e);
                    } catch (t) {}
                    else for(const e in t)"defaultValue" !== e && r.push(t[e]);
                }
                return o;
            }
            function xr(t) {
                const e = Object.prototype.toString.call(t), r = typeof t;
                return "number" === r || "boolean" === r || "string" === r || "symbol" === r || "function" === r || "[object Date]" === e || "[object RegExp]" === e || "[object Module]" === e || null == t || t instanceof EventTarget || t instanceof Event;
            }
            function Er(t, e, r = new Set) {
                if (t === e && "object" == typeof (o = t) && null !== o) return !0;
                var o;
                const n = wr(t, r), i = wr(e, r);
                for (const t of n)if (i.has(t)) return !0;
                return !1;
            }
            class Or {
                constructor(t){
                    if (this.crashes = [], this.state = "initializing", this._crashNumberLimit = "number" == typeof t.crashNumberLimit ? t.crashNumberLimit : 3, this._now = Date.now, this._minimumNonErrorTimePeriod = "number" == typeof t.minimumNonErrorTimePeriod ? t.minimumNonErrorTimePeriod : 5e3, this._boundErrorHandler = (t)=>{
                        const e = t.error || t.reason;
                        e instanceof Error && this._handleError(e, t);
                    }, this._listeners = {}, !this._restart) throw new Error("The Watchdog class was split into the abstract `Watchdog` class and the `EditorWatchdog` class. Please, use `EditorWatchdog` if you have used the `Watchdog` class previously.");
                }
                setCreator(t) {
                    this._creator = t;
                }
                setDestructor(t) {
                    this._destructor = t;
                }
                destroy() {
                    this._stopErrorHandling(), this._listeners = {};
                }
                on(t, e) {
                    this._listeners[t] || (this._listeners[t] = []), this._listeners[t].push(e);
                }
                off(t, e) {
                    this._listeners[t] = this._listeners[t].filter((t)=>t !== e);
                }
                _fire(t, ...e) {
                    const r = this._listeners[t] || [];
                    for (const t of r)t.apply(this, [
                        null,
                        ...e
                    ]);
                }
                _startErrorHandling() {
                    window.addEventListener("error", this._boundErrorHandler), window.addEventListener("unhandledrejection", this._boundErrorHandler);
                }
                _stopErrorHandling() {
                    window.removeEventListener("error", this._boundErrorHandler), window.removeEventListener("unhandledrejection", this._boundErrorHandler);
                }
                _handleError(t, e) {
                    if (this._shouldReactToError(t)) {
                        this.crashes.push({
                            message: t.message,
                            stack: t.stack,
                            filename: e.filename,
                            lineno: e.lineno,
                            colno: e.colno,
                            date: this._now()
                        });
                        const r = this._shouldRestart();
                        this.state = "crashed", this._fire("stateChange"), this._fire("error", {
                            error: t,
                            causesRestart: r
                        }), r ? this._restart() : (this.state = "crashedPermanently", this._fire("stateChange"));
                    }
                }
                _shouldReactToError(t) {
                    return t.is && t.is("CKEditorError") && void 0 !== t.context && null !== t.context && "ready" === this.state && this._isErrorComingFromThisItem(t);
                }
                _shouldRestart() {
                    if (this.crashes.length <= this._crashNumberLimit) return !0;
                    return (this.crashes[this.crashes.length - 1].date - this.crashes[this.crashes.length - 1 - this._crashNumberLimit].date) / this._crashNumberLimit > this._minimumNonErrorTimePeriod;
                }
            }
            class Pr extends Or {
                constructor(t, e = {}){
                    super(e), this._editor = null, this._throttledSave = I(this._save.bind(this), "number" == typeof e.saveInterval ? e.saveInterval : 5e3), this._creator = (e, r)=>t.create(e, r), this._destructor = (t)=>t.destroy();
                }
                get editor() {
                    return this._editor;
                }
                get _item() {
                    return this._editor;
                }
                _restart() {
                    return Promise.resolve().then(()=>(this.state = "initializing", this._fire("stateChange"), this._destroy())).catch((t)=>{
                        console.error("An error happened during the editor destroying.", t);
                    }).then(()=>{
                        if ("string" == typeof this._elementOrData) return this.create(this._data, this._config, this._config.context);
                        {
                            const t = Object.assign({}, this._config, {
                                initialData: this._data
                            });
                            return this.create(this._elementOrData, t, t.context);
                        }
                    }).then(()=>{
                        this._fire("restart");
                    });
                }
                create(t = this._elementOrData, e = this._config, r) {
                    return Promise.resolve().then(()=>(super._startErrorHandling(), this._elementOrData = t, this._config = this._cloneEditorConfiguration(e) || {}, this._config.context = r, this._creator(t, this._config))).then((t)=>{
                        this._editor = t, t.model.document.on("change:data", this._throttledSave), this._lastDocumentVersion = t.model.document.version, this._data = this._getData(), this.state = "ready", this._fire("stateChange");
                    });
                }
                destroy() {
                    return Promise.resolve().then(()=>(this.state = "destroyed", this._fire("stateChange"), super.destroy(), this._destroy()));
                }
                _destroy() {
                    return Promise.resolve().then(()=>{
                        this._stopErrorHandling(), this._throttledSave.flush();
                        const t = this._editor;
                        return this._editor = null, this._destructor(t);
                    });
                }
                _save() {
                    const t = this._editor.model.document.version;
                    if (t !== this._lastDocumentVersion) try {
                        this._data = this._getData(), this._lastDocumentVersion = t;
                    } catch (t) {
                        console.error(t, "An error happened during restoring editor data. Editor will be restored from the previously saved data.");
                    }
                }
                _setExcludedProperties(t) {
                    this._excludedProps = t;
                }
                _getData() {
                    const t = {};
                    for (const e of this._editor.model.document.getRootNames())t[e] = this._editor.data.get({
                        rootName: e
                    });
                    return t;
                }
                _isErrorComingFromThisItem(t) {
                    return Er(this._editor, t.context, this._excludedProps);
                }
                _cloneEditorConfiguration(t) {
                    return pr(t, (t, e)=>jr(t) || "context" === e ? t : void 0);
                }
            }
            const Cr = new Array(256).fill().map((t, e)=>("0" + e.toString(16)).slice(-2));
            class Ar extends Or {
                constructor(t, e = {}){
                    super(e), this._watchdogs = new Map, this._watchdogConfig = e, this._context = null, this._contextProps = new Set, this._actionQueue = new Tr, this._creator = (e)=>t.create(e), this._destructor = (t)=>t.destroy(), this._actionQueue.onEmpty(()=>{
                        "initializing" === this.state && (this.state = "ready", this._fire("stateChange"));
                    });
                }
                get context() {
                    return this._context;
                }
                create(t = {}) {
                    return this._actionQueue.enqueue(()=>(this._contextConfig = t, this._create()));
                }
                getItem(t) {
                    return this._getWatchdog(t)._item;
                }
                getItemState(t) {
                    return this._getWatchdog(t).state;
                }
                add(t) {
                    const e = Array.isArray(t) ? t : [
                        t
                    ];
                    return this._actionQueue.enqueue(()=>{
                        if ("destroyed" === this.state) throw new Error("Cannot add items to destroyed watchdog.");
                        if (!this._context) throw new Error("Context was not created yet. You should call the `ContextWatchdog#create()` method first.");
                        return Promise.all(e.map((t)=>{
                            let e;
                            if (this._watchdogs.has(t.id)) throw new Error(`Item with the given id is already added: '${t.id}'.`);
                            if ("editor" === t.type) return e = new Pr(this._watchdogConfig), e.setCreator(t.creator), e._setExcludedProperties(this._contextProps), t.destructor && e.setDestructor(t.destructor), this._watchdogs.set(t.id, e), e.on("error", (r, { error: o, causesRestart: n })=>{
                                this._fire("itemError", {
                                    itemId: t.id,
                                    error: o
                                }), n && this._actionQueue.enqueue(()=>new Promise((r)=>{
                                        e.on("restart", (function o() {
                                            e.off("restart", o), this._fire("itemRestart", {
                                                itemId: t.id
                                            }), r();
                                        }).bind(this));
                                    }));
                            }), e.create(t.sourceElementOrData, t.config, this._context);
                            throw new Error(`Not supported item type: '${t.type}'.`);
                        }));
                    });
                }
                remove(t) {
                    const e = Array.isArray(t) ? t : [
                        t
                    ];
                    return this._actionQueue.enqueue(()=>Promise.all(e.map((t)=>{
                            const e = this._getWatchdog(t);
                            return this._watchdogs.delete(t), e.destroy();
                        })));
                }
                destroy() {
                    return this._actionQueue.enqueue(()=>(this.state = "destroyed", this._fire("stateChange"), super.destroy(), this._destroy()));
                }
                _restart() {
                    return this._actionQueue.enqueue(()=>(this.state = "initializing", this._fire("stateChange"), this._destroy().catch((t)=>{
                            console.error("An error happened during destroying the context or items.", t);
                        }).then(()=>this._create()).then(()=>this._fire("restart"))));
                }
                _create() {
                    return Promise.resolve().then(()=>(this._startErrorHandling(), this._creator(this._contextConfig))).then((t)=>(this._context = t, this._contextProps = wr(this._context), Promise.all(Array.from(this._watchdogs.values()).map((t)=>(t._setExcludedProperties(this._contextProps), t.create(void 0, void 0, this._context))))));
                }
                _destroy() {
                    return Promise.resolve().then(()=>{
                        this._stopErrorHandling();
                        const t = this._context;
                        return this._context = null, this._contextProps = new Set, Promise.all(Array.from(this._watchdogs.values()).map((t)=>t.destroy())).then(()=>this._destructor(t));
                    });
                }
                _getWatchdog(t) {
                    const e = this._watchdogs.get(t);
                    if (!e) throw new Error(`Item with the given id was not registered: ${t}.`);
                    return e;
                }
                _isErrorComingFromThisItem(t) {
                    for (const e of this._watchdogs.values())if (e._isErrorComingFromThisItem(t)) return !1;
                    return Er(this._context, t.context);
                }
            }
            class Tr {
                constructor(){
                    this._promiseQueue = Promise.resolve(), this._onEmptyCallbacks = [];
                }
                onEmpty(t) {
                    this._onEmptyCallbacks.push(t);
                }
                enqueue(t) {
                    let e;
                    const r = this._promiseQueue.then(t).then(()=>{
                        this._promiseQueue === e && this._onEmptyCallbacks.forEach((t)=>t());
                    });
                    return e = this._promiseQueue = r.catch(()=>{}), r;
                }
            }
            const Wr = n.a.createContext("contextWatchdog");
            class Sr extends n.a.Component {
                constructor(t, e){
                    super(t, e), this.contextWatchdog = null, this.props.isLayoutReady && this._initializeContextWatchdog(this.props.config);
                }
                shouldComponentUpdate(t) {
                    return t.id !== this.props.id && (this.contextWatchdog && this.contextWatchdog.destroy(), this._initializeContextWatchdog(t.config)), t.isLayoutReady && !this.contextWatchdog ? (this._initializeContextWatchdog(t.config), !0) : this.props.children !== t.children;
                }
                render() {
                    return n.a.createElement(Wr.Provider, {
                        value: this.contextWatchdog
                    }, this.props.children);
                }
                componentWillUnmount() {
                    this._destroyContext();
                }
                _initializeContextWatchdog(t) {
                    this.contextWatchdog = new Ar(this.props.context), this.contextWatchdog.create(t).catch((t)=>{
                        this.props.onError(t, {
                            phase: "initialization",
                            willContextRestart: !1
                        });
                    }), this.contextWatchdog.on("error", (t, e)=>{
                        this.props.onError(e.error, {
                            phase: "runtime",
                            willContextRestart: e.causesRestart
                        });
                    }), this.contextWatchdog.on("stateChange", ()=>{
                        "ready" === this.contextWatchdog.state && this.props.onReady && this.props.onReady(this.contextWatchdog.context);
                    });
                }
                async _destroyContext() {
                    this.contextWatchdog && (await this.contextWatchdog.destroy(), this.contextWatchdog = null);
                }
            }
            Sr.defaultProps = {
                isLayoutReady: !0,
                onError: (t, e)=>console.error(t, e)
            }, Sr.propTypes = {
                id: a.a.string,
                isLayoutReady: a.a.bool,
                context: a.a.func,
                config: a.a.object,
                onReady: a.a.func,
                onError: a.a.func
            };
            class Rr extends n.a.Component {
                constructor(t){
                    super(t), this.domContainer = n.a.createRef(), this.watchdog = null;
                }
                get editor() {
                    return this.watchdog ? this.watchdog.editor : null;
                }
                shouldComponentUpdate(t) {
                    return !!this.editor && (t.id !== this.props.id || (this._shouldUpdateEditor(t) && this.editor.setData(t.data), "disabled" in t && (this.editor.isReadOnly = t.disabled), !1));
                }
                componentDidMount() {
                    this._initializeEditor();
                }
                componentDidUpdate() {
                    this._destroyEditor(), this._initializeEditor();
                }
                componentWillUnmount() {
                    this._destroyEditor();
                }
                render() {
                    return n.a.createElement("div", {
                        ref: this.domContainer
                    });
                }
                _initializeEditor() {
                    this.context instanceof Ar ? this.watchdog = new Dr(this.context) : this.watchdog = new Rr._EditorWatchdog(this.props.editor), this.watchdog.setCreator((t, e)=>this._createEditor(t, e)), this.watchdog.on("error", (t, { error: e, causesRestart: r })=>{
                        this.props.onError(e, {
                            phase: "runtime",
                            willEditorRestart: r
                        });
                    }), this.watchdog.create(this.domContainer.current, this._getConfig()).catch((t)=>this.props.onError(t, {
                            phase: "initialization",
                            willEditorRestart: !1
                        }));
                }
                _createEditor(t, e) {
                    return this.props.editor.create(t, e).then((t)=>{
                        "disabled" in this.props && (t.isReadOnly = this.props.disabled);
                        const e = t.model.document, r = t.editing.view.document;
                        return e.on("change:data", (e)=>{
                            this.props.onChange && this.props.onChange(e, t);
                        }), r.on("focus", (e)=>{
                            this.props.onFocus && this.props.onFocus(e, t);
                        }), r.on("blur", (e)=>{
                            this.props.onBlur && this.props.onBlur(e, t);
                        }), setTimeout(()=>{
                            this.props.onReady && this.props.onReady(this.editor);
                        }), t;
                    });
                }
                _destroyEditor() {
                    this.watchdog && (this.watchdog.destroy(), this.watchdog = null);
                }
                _shouldUpdateEditor(t) {
                    return this.props.data !== t.data && this.editor.getData() !== t.data;
                }
                _getConfig() {
                    return this.props.data && this.props.config.initialData && console.warn("Editor data should be provided either using `config.initialData` or `data` properties. The config property is over the data value and the first one will be used when specified both."), {
                        ...this.props.config,
                        initialData: this.props.config.initialData || this.props.data || ""
                    };
                }
            }
            class Dr {
                constructor(t){
                    this._contextWatchdog = t, this._id = function() {
                        const t = 4294967296 * Math.random() >>> 0, e = 4294967296 * Math.random() >>> 0, r = 4294967296 * Math.random() >>> 0, o = 4294967296 * Math.random() >>> 0;
                        return "e" + Cr[t >> 0 & 255] + Cr[t >> 8 & 255] + Cr[t >> 16 & 255] + Cr[t >> 24 & 255] + Cr[e >> 0 & 255] + Cr[e >> 8 & 255] + Cr[e >> 16 & 255] + Cr[e >> 24 & 255] + Cr[r >> 0 & 255] + Cr[r >> 8 & 255] + Cr[r >> 16 & 255] + Cr[r >> 24 & 255] + Cr[o >> 0 & 255] + Cr[o >> 8 & 255] + Cr[o >> 16 & 255] + Cr[o >> 24 & 255];
                    }();
                }
                setCreator(t) {
                    this._creator = t;
                }
                create(t, e) {
                    return this._contextWatchdog.add({
                        sourceElementOrData: t,
                        config: e,
                        creator: this._creator,
                        id: this._id,
                        type: "editor"
                    });
                }
                on(t, e) {
                    this._contextWatchdog.on("itemError", (t, { itemId: r, causesRestart: o, error: n })=>{
                        r === this._id && e(null, {
                            error: n,
                            causesRestart: o
                        });
                    });
                }
                destroy() {
                    this._contextWatchdog.remove(this._id);
                }
                get editor() {
                    return this._contextWatchdog.getItem(this._id);
                }
            }
            Rr.contextType = Wr, Rr.propTypes = {
                editor: a.a.func.isRequired,
                data: a.a.string,
                config: a.a.object,
                onChange: a.a.func,
                onReady: a.a.func,
                onFocus: a.a.func,
                onBlur: a.a.func,
                onError: a.a.func,
                disabled: a.a.bool,
                onInit: (t, e)=>{
                    if (t[e]) return new Error('The "onInit" property is not supported anymore by the CKEditor component. Use the "onReady" property instead.');
                }
            }, Rr.defaultProps = {
                config: {},
                onError: (t, e)=>console.error(t, e)
            }, Rr._EditorWatchdog = Pr;
        }
    ]);
}); //# sourceMappingURL=ckeditor.js.map
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-editor-classic/src/classiceditorui.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "default",
    ()=>ClassicEditorUI
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$ui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/ui.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-ui/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$engine$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/engine.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$placeholder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/placeholder.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/utils.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript)");
;
;
;
class ClassicEditorUI extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EditorUI"] {
    /**
     * Creates an instance of the classic editor UI class.
     *
     * @param editor The editor instance.
     * @param view The view of the UI.
     */ constructor(editor, view){
        super(editor);
        this.view = view;
        this._toolbarConfig = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["normalizeToolbarConfig"])(editor.config.get('toolbar'));
        this._elementReplacer = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ElementReplacer"]();
        this.listenTo(editor.editing.view, 'scrollToTheSelection', this._handleScrollToTheSelectionWithStickyPanel.bind(this));
    }
    /**
     * @inheritDoc
     */ get element() {
        return this.view.element;
    }
    /**
     * Initializes the UI.
     *
     * @param replacementElement The DOM element that will be the source for the created editor.
     */ init(replacementElement) {
        const editor = this.editor;
        const view = this.view;
        const editingView = editor.editing.view;
        const editable = view.editable;
        const editingRoot = editingView.document.getRoot();
        // The editable UI and editing root should share the same name. Then name is used
        // to recognize the particular editable, for instance in ARIA attributes.
        editable.name = editingRoot.rootName;
        view.render();
        // The editable UI element in DOM is available for sure only after the editor UI view has been rendered.
        // But it can be available earlier if a DOM element has been passed to BalloonEditor.create().
        const editableElement = editable.element;
        // Register the editable UI view in the editor. A single editor instance can aggregate multiple
        // editable areas (roots) but the classic editor has only one.
        this.setEditableElement(editable.name, editableElement);
        // Let the editable UI element respond to the changes in the global editor focus
        // tracker. It has been added to the same tracker a few lines above but, in reality, there are
        // many focusable areas in the editor, like balloons, toolbars or dropdowns and as long
        // as they have focus, the editable should act like it is focused too (although technically
        // it isn't), e.g. by setting the proper CSS class, visually announcing focus to the user.
        // Doing otherwise will result in editable focus styles disappearing, once e.g. the
        // toolbar gets focused.
        view.editable.bind('isFocused').to(this.focusTracker);
        // Bind the editable UI element to the editing view, making it an end– and entry–point
        // of the editor's engine. This is where the engine meets the UI.
        editingView.attachDomRoot(editableElement);
        // If an element containing the initial data of the editor was provided, replace it with
        // an editor instance's UI in DOM until the editor is destroyed. For instance, a <textarea>
        // can be such element.
        if (replacementElement) {
            this._elementReplacer.replace(replacementElement, this.element);
        }
        this._initPlaceholder();
        this._initToolbar();
        if (view.menuBarView) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["_initMenuBar"])(editor, view.menuBarView);
        }
        this._initDialogPluginIntegration();
        this.fire('ready');
    }
    /**
     * @inheritDoc
     */ destroy() {
        super.destroy();
        const view = this.view;
        const editingView = this.editor.editing.view;
        this._elementReplacer.restore();
        editingView.detachDomRoot(view.editable.name);
        view.destroy();
    }
    /**
     * Initializes the editor toolbar.
     */ _initToolbar() {
        const view = this.view;
        // Set–up the sticky panel with toolbar.
        view.stickyPanel.bind('isActive').to(this.focusTracker, 'isFocused');
        view.stickyPanel.limiterElement = view.element;
        view.stickyPanel.bind('viewportTopOffset').to(this, 'viewportOffset', ({ top })=>top || 0);
        view.toolbar.fillFromConfig(this._toolbarConfig, this.componentFactory);
        // Register the toolbar so it becomes available for Alt+F10 and Esc navigation.
        this.addToolbar(view.toolbar);
    }
    /**
     * Enable the placeholder text on the editing root.
     */ _initPlaceholder() {
        const editor = this.editor;
        const editingView = editor.editing.view;
        const editingRoot = editingView.document.getRoot();
        const sourceElement = editor.sourceElement;
        let placeholderText;
        const placeholder = editor.config.get('placeholder');
        if (placeholder) {
            placeholderText = typeof placeholder === 'string' ? placeholder : placeholder[this.view.editable.name];
        }
        if (!placeholderText && sourceElement && sourceElement.tagName.toLowerCase() === 'textarea') {
            placeholderText = sourceElement.getAttribute('placeholder');
        }
        if (placeholderText) {
            editingRoot.placeholder = placeholderText;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$placeholder$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["enablePlaceholder"])({
            view: editingView,
            element: editingRoot,
            isDirectHost: false,
            keepOnFocus: true
        });
    }
    /**
     * Provides an integration between the sticky toolbar and {@link module:utils/dom/scroll~scrollViewportToShowTarget}.
     * It allows the UI-agnostic engine method to consider the geometry of the
     * {@link module:editor-classic/classiceditoruiview~ClassicEditorUIView#stickyPanel} that pins to the
     * edge of the viewport and can obscure the user caret after scrolling the window.
     *
     * @param evt The `scrollToTheSelection` event info.
     * @param data The payload carried by the `scrollToTheSelection` event.
     * @param originalArgs The original arguments passed to `scrollViewportToShowTarget()` method (see implementation to learn more).
     */ _handleScrollToTheSelectionWithStickyPanel(evt, data, originalArgs) {
        const stickyPanel = this.view.stickyPanel;
        if (stickyPanel.isSticky) {
            const stickyPanelHeight = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rect"](stickyPanel.element).height;
            data.viewportOffset.top += stickyPanelHeight;
        } else {
            const scrollViewportOnPanelGettingSticky = ()=>{
                this.editor.editing.view.scrollToTheSelection(originalArgs);
            };
            this.listenTo(stickyPanel, 'change:isSticky', scrollViewportOnPanelGettingSticky);
            // This works as a post-scroll-fixer because it's impossible predict whether the panel will be sticky after scrolling or not.
            // Listen for a short period of time only and if the toolbar does not become sticky very soon, cancel the listener.
            setTimeout(()=>{
                this.stopListening(stickyPanel, 'change:isSticky', scrollViewportOnPanelGettingSticky);
            }, 20);
        }
    }
    /**
     * Provides an integration between the sticky toolbar and {@link module:ui/dialog/dialog the Dialog plugin}.
     *
     * It moves the dialog down to ensure that the
     * {@link module:editor-classic/classiceditoruiview~ClassicEditorUIView#stickyPanel sticky panel}
     * used by the editor UI will not get obscured by the dialog when the dialog uses one of its automatic positions.
     */ _initDialogPluginIntegration() {
        if (!this.editor.plugins.has('Dialog')) {
            return;
        }
        const stickyPanel = this.view.stickyPanel;
        const dialogPlugin = this.editor.plugins.get('Dialog');
        dialogPlugin.on('show', ()=>{
            const dialogView = dialogPlugin.view;
            dialogView.on('moveTo', (evt, data)=>{
                // Engage only when the panel is sticky, and the dialog is using one of default positions.
                if (!stickyPanel.isSticky || dialogView.wasMoved) {
                    return;
                }
                const stickyPanelContentRect = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Rect"](stickyPanel.contentPanelElement);
                if (data[1] < stickyPanelContentRect.bottom + __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogView"].defaultOffset) {
                    data[1] = stickyPanelContentRect.bottom + __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["DialogView"].defaultOffset;
                }
            }, {
                priority: 'high'
            });
        }, {
            priority: 'low'
        });
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-editor-classic/src/classiceditoruiview.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module editor-classic/classiceditoruiview
 */ __turbopack_context__.s([
    "default",
    ()=>ClassicEditorUIView
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$ui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/ui.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-ui/src/index.js [app-ssr] (ecmascript)");
;
;
class ClassicEditorUIView extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BoxedEditorUIView"] {
    /**
     * Creates an instance of the classic editor UI view.
     *
     * @param locale The {@link module:core/editor/editor~Editor#locale} instance.
     * @param editingView The editing view instance this view is related to.
     * @param options Configuration options for the view instance.
     * @param options.shouldToolbarGroupWhenFull When set `true` enables automatic items grouping
     * in the main {@link module:editor-classic/classiceditoruiview~ClassicEditorUIView#toolbar toolbar}.
     * See {@link module:ui/toolbar/toolbarview~ToolbarOptions#shouldGroupWhenFull} to learn more.
     */ constructor(locale, editingView, options = {}){
        super(locale);
        this.stickyPanel = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["StickyPanelView"](locale);
        this.toolbar = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ToolbarView"](locale, {
            shouldGroupWhenFull: options.shouldToolbarGroupWhenFull
        });
        if (options.useMenuBar) {
            this.menuBarView = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MenuBarView"](locale);
        }
        this.editable = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["InlineEditableUIView"](locale, editingView);
    }
    /**
     * @inheritDoc
     */ render() {
        super.render();
        if (this.menuBarView) {
            // Set toolbar as a child of a stickyPanel and makes toolbar sticky.
            this.stickyPanel.content.addMany([
                this.menuBarView,
                this.toolbar
            ]);
        } else {
            this.stickyPanel.content.add(this.toolbar);
        }
        this.top.add(this.stickyPanel);
        this.main.add(this.editable);
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-editor-classic/src/classiceditor.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module editor-classic/classiceditor
 */ __turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$editor$2d$classic$2f$src$2f$classiceditorui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-editor-classic/src/classiceditorui.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$editor$2d$classic$2f$src$2f$classiceditoruiview$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-editor-classic/src/classiceditoruiview.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$core$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/core.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/utils.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$watchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/watchdog.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isElement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isElement$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/isElement.js [app-ssr] (ecmascript) <export default as isElement>");
;
;
;
;
;
;
/**
 * The {@glink installation/getting-started/predefined-builds#classic-editor classic editor} implementation.
 * It uses an inline editable and a sticky toolbar, all enclosed in a boxed UI.
 * See the {@glink examples/builds/classic-editor demo}.
 *
 * In order to create a classic editor instance, use the static
 * {@link module:editor-classic/classiceditor~ClassicEditor.create `ClassicEditor.create()`} method.
 *
 * # Classic editor and classic build
 *
 * The classic editor can be used directly from source (if you installed the
 * [`@ckeditor/ckeditor5-editor-classic`](https://www.npmjs.com/package/@ckeditor/ckeditor5-editor-classic) package)
 * but it is also available in the {@glink installation/getting-started/predefined-builds#classic-editor classic build}.
 *
 * {@glink installation/getting-started/predefined-builds Builds}
 * are ready-to-use editors with plugins bundled in. When using the editor from
 * source you need to take care of loading all plugins by yourself
 * (through the {@link module:core/editor/editorconfig~EditorConfig#plugins `config.plugins`} option).
 * Using the editor from source gives much better flexibility and allows easier customization.
 *
 * Read more about initializing the editor from source or as a build in
 * {@link module:editor-classic/classiceditor~ClassicEditor.create `ClassicEditor.create()`}.
 */ class ClassicEditor extends (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ElementApiMixin"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Editor"]) {
    /**
     * Creates an instance of the classic editor.
     *
     * **Note:** do not use the constructor to create editor instances. Use the static
     * {@link module:editor-classic/classiceditor~ClassicEditor.create `ClassicEditor.create()`} method instead.
     *
     * @param sourceElementOrData The DOM element that will be the source for the created editor
     * or the editor's initial data. For more information see
     * {@link module:editor-classic/classiceditor~ClassicEditor.create `ClassicEditor.create()`}.
     * @param config The editor configuration.
     */ constructor(sourceElementOrData, config = {}){
        // If both `config.initialData` is set and initial data is passed as the constructor parameter, then throw.
        if (!isElement(sourceElementOrData) && config.initialData !== undefined) {
            // Documented in core/editor/editorconfig.jsdoc.
            // eslint-disable-next-line ckeditor5-rules/ckeditor-error-message
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CKEditorError"]('editor-create-initial-data', null);
        }
        super(config);
        this.config.define('menuBar.isVisible', false);
        if (this.config.get('initialData') === undefined) {
            this.config.set('initialData', getInitialData(sourceElementOrData));
        }
        if (isElement(sourceElementOrData)) {
            this.sourceElement = sourceElementOrData;
        }
        this.model.document.createRoot();
        const shouldToolbarGroupWhenFull = !this.config.get('toolbar.shouldNotGroupWhenFull');
        const menuBarConfig = this.config.get('menuBar');
        const view = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$editor$2d$classic$2f$src$2f$classiceditoruiview$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this.locale, this.editing.view, {
            shouldToolbarGroupWhenFull,
            useMenuBar: menuBarConfig.isVisible
        });
        this.ui = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$editor$2d$classic$2f$src$2f$classiceditorui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](this, view);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["attachToForm"])(this);
    }
    /**
     * Destroys the editor instance, releasing all resources used by it.
     *
     * Updates the original editor element with the data if the
     * {@link module:core/editor/editorconfig~EditorConfig#updateSourceElementOnDestroy `updateSourceElementOnDestroy`}
     * configuration option is set to `true`.
     */ destroy() {
        if (this.sourceElement) {
            this.updateSourceElement();
        }
        this.ui.destroy();
        return super.destroy();
    }
    /**
     * Creates a new classic editor instance.
     *
     * There are three ways how the editor can be initialized.
     *
     * # Replacing a DOM element (and loading data from it)
     *
     * You can initialize the editor using an existing DOM element:
     *
     * ```ts
     * ClassicEditor
     * 	.create( document.querySelector( '#editor' ) )
     * 	.then( editor => {
     * 		console.log( 'Editor was initialized', editor );
     * 	} )
     * 	.catch( err => {
     * 		console.error( err.stack );
     * 	} );
     * ```
     *
     * The element's content will be used as the editor data and the element will be replaced by the editor UI.
     *
     * # Creating a detached editor
     *
     * Alternatively, you can initialize the editor by passing the initial data directly as a string.
     * In this case, the editor will render an element that must be inserted into the DOM:
     *
     * ```ts
     * ClassicEditor
     * 	.create( '<p>Hello world!</p>' )
     * 	.then( editor => {
     * 		console.log( 'Editor was initialized', editor );
     *
     * 		// Initial data was provided so the editor UI element needs to be added manually to the DOM.
     * 		document.body.appendChild( editor.ui.element );
     * 	} )
     * 	.catch( err => {
     * 		console.error( err.stack );
     * 	} );
     * ```
     *
     * This lets you dynamically append the editor to your web page whenever it is convenient for you. You may use this method if your
     * web page content is generated on the client side and the DOM structure is not ready at the moment when you initialize the editor.
     *
     * # Replacing a DOM element (and data provided in `config.initialData`)
     *
     * You can also mix these two ways by providing a DOM element to be used and passing the initial data through the configuration:
     *
     * ```ts
     * ClassicEditor
     * 	.create( document.querySelector( '#editor' ), {
     * 		initialData: '<h2>Initial data</h2><p>Foo bar.</p>'
     * 	} )
     * 	.then( editor => {
     * 		console.log( 'Editor was initialized', editor );
     * 	} )
     * 	.catch( err => {
     * 		console.error( err.stack );
     * 	} );
     * ```
     *
     * This method can be used to initialize the editor on an existing element with the specified content in case if your integration
     * makes it difficult to set the content of the source element.
     *
     * Note that an error will be thrown if you pass the initial data both as the first parameter and also in the configuration.
     *
     * # Configuring the editor
     *
     * See the {@link module:core/editor/editorconfig~EditorConfig editor configuration documentation} to learn more about
     * customizing plugins, toolbar and more.
     *
     * # Using the editor from source
     *
     * The code samples listed in the previous sections of this documentation assume that you are using an
     * {@glink installation/getting-started/predefined-builds editor build} (for example – `@ckeditor/ckeditor5-build-classic`).
     *
     * If you want to use the classic editor from source (`@ckeditor/ckeditor5-editor-classic/src/classiceditor`),
     * you need to define the list of
     * {@link module:core/editor/editorconfig~EditorConfig#plugins plugins to be initialized} and
     * {@link module:core/editor/editorconfig~EditorConfig#toolbar toolbar items}. Read more about using the editor from
     * source in the {@glink installation/advanced/alternative-setups/integrating-from-source-webpack dedicated guide}.
     *
     * @param sourceElementOrData The DOM element that will be the source for the created editor
     * or the editor's initial data.
     *
     * If a DOM element is passed, its content will be automatically loaded to the editor upon initialization
     * and the {@link module:editor-classic/classiceditorui~ClassicEditorUI#element editor element} will replace the passed element
     * in the DOM (the original one will be hidden and the editor will be injected next to it).
     *
     * If the {@link module:core/editor/editorconfig~EditorConfig#updateSourceElementOnDestroy updateSourceElementOnDestroy}
     * option is set to `true`, the editor data will be set back to the original element once the editor is destroyed and when a form,
     * in which this element is contained, is submitted (if the original element is a `<textarea>`). This ensures seamless integration
     * with native web forms.
     *
     * If the initial data is passed, a detached editor will be created. In this case you need to insert it into the DOM manually.
     * It is available under the {@link module:editor-classic/classiceditorui~ClassicEditorUI#element `editor.ui.element`} property.
     *
     * @param config The editor configuration.
     * @returns A promise resolved once the editor is ready. The promise resolves with the created editor instance.
     */ static create(sourceElementOrData, config = {}) {
        return new Promise((resolve)=>{
            const editor = new this(sourceElementOrData, config);
            resolve(editor.initPlugins().then(()=>editor.ui.init(isElement(sourceElementOrData) ? sourceElementOrData : null)).then(()=>editor.data.init(editor.config.get('initialData'))).then(()=>editor.fire('ready')).then(()=>editor));
        });
    }
}
/**
 * The {@link module:core/context~Context} class.
 *
 * Exposed as static editor field for easier access in editor builds.
 */ ClassicEditor.Context = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Context"];
/**
 * The {@link module:watchdog/editorwatchdog~EditorWatchdog} class.
 *
 * Exposed as static editor field for easier access in editor builds.
 */ ClassicEditor.EditorWatchdog = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EditorWatchdog"];
/**
 * The {@link module:watchdog/contextwatchdog~ContextWatchdog} class.
 *
 * Exposed as static editor field for easier access in editor builds.
 */ ClassicEditor.ContextWatchdog = __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ContextWatchdog"];
const __TURBOPACK__default__export__ = ClassicEditor;
function getInitialData(sourceElementOrData) {
    return isElement(sourceElementOrData) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDataFromElement"])(sourceElementOrData) : sourceElementOrData;
}
function isElement(value) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isElement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isElement$3e$__["isElement"])(value);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/watchdog.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * An abstract watchdog class that handles most of the error handling process and the state of the underlying component.
 *
 * See the {@glink features/watchdog Watchdog feature guide} to learn the rationale behind it and how to use it.
 *
 * @internal
 */ __turbopack_context__.s([
    "default",
    ()=>Watchdog
]);
class Watchdog {
    /**
     * @param {module:watchdog/watchdog~WatchdogConfig} config The watchdog plugin configuration.
     */ constructor(config){
        /**
         * An array of crashes saved as an object with the following properties:
         *
         * * `message`: `String`,
         * * `stack`: `String`,
         * * `date`: `Number`,
         * * `filename`: `String | undefined`,
         * * `lineno`: `Number | undefined`,
         * * `colno`: `Number | undefined`,
         */ this.crashes = [];
        /**
         * Specifies the state of the item watched by the watchdog. The state can be one of the following values:
         *
         * * `initializing` &ndash; Before the first initialization, and after crashes, before the item is ready.
         * * `ready` &ndash; A state when the user can interact with the item.
         * * `crashed` &ndash; A state when an error occurs. It quickly changes to `initializing` or `crashedPermanently`
         * depending on how many and how frequent errors have been caught recently.
         * * `crashedPermanently` &ndash; A state when the watchdog stops reacting to errors and keeps the item it is watching crashed,
         * * `destroyed` &ndash; A state when the item is manually destroyed by the user after calling `watchdog.destroy()`.
         */ this.state = 'initializing';
        /**
         * Returns the result of the `Date.now()` call. It can be overridden in tests to mock time as some popular
         * approaches like `sinon.useFakeTimers()` do not work well with error handling.
         */ this._now = Date.now;
        this.crashes = [];
        this._crashNumberLimit = typeof config.crashNumberLimit === 'number' ? config.crashNumberLimit : 3;
        this._minimumNonErrorTimePeriod = typeof config.minimumNonErrorTimePeriod === 'number' ? config.minimumNonErrorTimePeriod : 5000;
        this._boundErrorHandler = (evt)=>{
            // `evt.error` is exposed by EventError while `evt.reason` is available in PromiseRejectionEvent.
            const error = 'error' in evt ? evt.error : evt.reason;
            // Note that `evt.reason` might be everything that is in the promise rejection.
            // Similarly everything that is thrown lands in `evt.error`.
            if (error instanceof Error) {
                this._handleError(error, evt);
            }
        };
        this._listeners = {};
        if (!this._restart) {
            throw new Error('The Watchdog class was split into the abstract `Watchdog` class and the `EditorWatchdog` class. ' + 'Please, use `EditorWatchdog` if you have used the `Watchdog` class previously.');
        }
    }
    /**
     * Destroys the watchdog and releases the resources.
     */ destroy() {
        this._stopErrorHandling();
        this._listeners = {};
    }
    /**
     * Starts listening to a specific event name by registering a callback that will be executed
     * whenever an event with a given name fires.
     *
     * Note that this method differs from the CKEditor 5's default `EventEmitterMixin` implementation.
     *
     * @param eventName The event name.
     * @param callback A callback which will be added to event listeners.
     */ on(eventName, callback) {
        if (!this._listeners[eventName]) {
            this._listeners[eventName] = [];
        }
        this._listeners[eventName].push(callback);
    }
    /**
     * Stops listening to the specified event name by removing the callback from event listeners.
     *
     * Note that this method differs from the CKEditor 5's default `EventEmitterMixin` implementation.
     *
     * @param eventName The event name.
     * @param callback A callback which will be removed from event listeners.
     */ off(eventName, callback) {
        this._listeners[eventName] = this._listeners[eventName].filter((cb)=>cb !== callback);
    }
    /**
     * Fires an event with a given event name and arguments.
     *
     * Note that this method differs from the CKEditor 5's default `EventEmitterMixin` implementation.
     */ _fire(eventName, ...args) {
        const callbacks = this._listeners[eventName] || [];
        for (const callback of callbacks){
            callback.apply(this, [
                null,
                ...args
            ]);
        }
    }
    /**
     * Starts error handling by attaching global error handlers.
     */ _startErrorHandling() {
        window.addEventListener('error', this._boundErrorHandler);
        window.addEventListener('unhandledrejection', this._boundErrorHandler);
    }
    /**
     * Stops error handling by detaching global error handlers.
     */ _stopErrorHandling() {
        window.removeEventListener('error', this._boundErrorHandler);
        window.removeEventListener('unhandledrejection', this._boundErrorHandler);
    }
    /**
     * Checks if an error comes from the watched item and restarts it.
     * It reacts to {@link module:utils/ckeditorerror~CKEditorError `CKEditorError` errors} only.
     *
     * @fires error
     * @param error Error.
     * @param evt An error event.
     */ _handleError(error, evt) {
        // @if CK_DEBUG // const err = error as CKEditorError;
        // @if CK_DEBUG // if ( err.is && err.is( 'CKEditorError' ) && err.context === undefined ) {
        // @if CK_DEBUG // console.warn( 'The error is missing its context and Watchdog cannot restart the proper item.' );
        // @if CK_DEBUG // }
        if (this._shouldReactToError(error)) {
            this.crashes.push({
                message: error.message,
                stack: error.stack,
                // `evt.filename`, `evt.lineno` and `evt.colno` are available only in ErrorEvent events
                filename: evt instanceof ErrorEvent ? evt.filename : undefined,
                lineno: evt instanceof ErrorEvent ? evt.lineno : undefined,
                colno: evt instanceof ErrorEvent ? evt.colno : undefined,
                date: this._now()
            });
            const causesRestart = this._shouldRestart();
            this.state = 'crashed';
            this._fire('stateChange');
            this._fire('error', {
                error,
                causesRestart
            });
            if (causesRestart) {
                this._restart();
            } else {
                this.state = 'crashedPermanently';
                this._fire('stateChange');
            }
        }
    }
    /**
     * Checks whether an error should be handled by the watchdog.
     *
     * @param error An error that was caught by the error handling process.
     */ _shouldReactToError(error) {
        return error.is && error.is('CKEditorError') && error.context !== undefined && // In some cases the watched item should not be restarted - e.g. during the item initialization.
        // That's why the `null` was introduced as a correct error context which does cause restarting.
        error.context !== null && // Do not react to errors if the watchdog is in states other than `ready`.
        this.state === 'ready' && this._isErrorComingFromThisItem(error);
    }
    /**
     * Checks if the watchdog should restart the underlying item.
     */ _shouldRestart() {
        if (this.crashes.length <= this._crashNumberLimit) {
            return true;
        }
        const lastErrorTime = this.crashes[this.crashes.length - 1].date;
        const firstMeaningfulErrorTime = this.crashes[this.crashes.length - 1 - this._crashNumberLimit].date;
        const averageNonErrorTimePeriod = (lastErrorTime - firstMeaningfulErrorTime) / this._crashNumberLimit;
        return averageNonErrorTimePeriod > this._minimumNonErrorTimePeriod;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/utils/getsubnodes.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module watchdog/utils/getsubnodes
 */ /* globals EventTarget, Event */ __turbopack_context__.s([
    "default",
    ()=>getSubNodes
]);
function getSubNodes(head, excludedProperties = new Set()) {
    const nodes = [
        head
    ];
    // @if CK_DEBUG_WATCHDOG // const prevNodeMap = new Map();
    // Nodes are stored to prevent infinite looping.
    const subNodes = new Set();
    let nodeIndex = 0;
    while(nodes.length > nodeIndex){
        // Incrementing the iterator is much faster than changing size of the array with Array.prototype.shift().
        const node = nodes[nodeIndex++];
        if (subNodes.has(node) || !shouldNodeBeIncluded(node) || excludedProperties.has(node)) {
            continue;
        }
        subNodes.add(node);
        // Handle arrays, maps, sets, custom collections that implements `[ Symbol.iterator ]()`, etc.
        if (Symbol.iterator in node) {
            // The custom editor iterators might cause some problems if the editor is crashed.
            try {
                for (const n of node){
                    nodes.push(n);
                // @if CK_DEBUG_WATCHDOG // if ( !prevNodeMap.has( n ) ) {
                // @if CK_DEBUG_WATCHDOG // 	prevNodeMap.set( n, node );
                // @if CK_DEBUG_WATCHDOG // }
                }
            } catch (err) {
            // Do not log errors for broken structures
            // since we are in the error handling process already.
            // eslint-disable-line no-empty
            }
        } else {
            for(const key in node){
                // We share a reference via the protobuf library within the editors,
                // hence the shared value should be skipped. Although, it's not a perfect
                // solution since new places like that might occur in the future.
                if (key === 'defaultValue') {
                    continue;
                }
                nodes.push(node[key]);
            // @if CK_DEBUG_WATCHDOG // if ( !prevNodeMap.has( node[ key ] ) ) {
            // @if CK_DEBUG_WATCHDOG // 	prevNodeMap.set( node[ key ], node );
            // @if CK_DEBUG_WATCHDOG // }
            }
        }
    }
    // @if CK_DEBUG_WATCHDOG // return { subNodes, prevNodeMap } as any;
    return subNodes;
}
function shouldNodeBeIncluded(node) {
    const type = Object.prototype.toString.call(node);
    const typeOfNode = typeof node;
    return !(typeOfNode === 'number' || typeOfNode === 'boolean' || typeOfNode === 'string' || typeOfNode === 'symbol' || typeOfNode === 'function' || type === '[object Date]' || type === '[object RegExp]' || type === '[object Module]' || node === undefined || node === null || // This flag is meant to exclude singletons shared across editor instances. So when an error is thrown in one editor,
    // the other editors connected through the reference to the same singleton are not restarted. This is a temporary workaround
    // until a better solution is found.
    // More in https://github.com/ckeditor/ckeditor5/issues/12292.
    node._watchdogExcluded || // Skip native DOM objects, e.g. Window, nodes, events, etc.
    node instanceof EventTarget || node instanceof Event);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/utils/areconnectedthroughproperties.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module watchdog/utils/areconnectedthroughproperties
 */ /* globals console */ __turbopack_context__.s([
    "default",
    ()=>areConnectedThroughProperties
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$getsubnodes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/utils/getsubnodes.js [app-ssr] (ecmascript)");
;
function areConnectedThroughProperties(target1, target2, excludedNodes = new Set()) {
    if (target1 === target2 && isObject(target1)) {
        return true;
    }
    // @if CK_DEBUG_WATCHDOG // return checkConnectionBetweenProps( target1, target2, excludedNodes );
    const subNodes1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$getsubnodes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(target1, excludedNodes);
    const subNodes2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$getsubnodes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(target2, excludedNodes);
    for (const node of subNodes1){
        if (subNodes2.has(node)) {
            return true;
        }
    }
    return false;
}
/* istanbul ignore next -- @preserve */ // eslint-disable-next-line
function checkConnectionBetweenProps(target1, target2, excludedNodes) {
    const { subNodes: subNodes1, prevNodeMap: prevNodeMap1 } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$getsubnodes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(target1, excludedNodes.subNodes);
    const { subNodes: subNodes2, prevNodeMap: prevNodeMap2 } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$getsubnodes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(target2, excludedNodes.subNodes);
    for (const sharedNode of subNodes1){
        if (subNodes2.has(sharedNode)) {
            const connection = [];
            connection.push(sharedNode);
            let node = prevNodeMap1.get(sharedNode);
            while(node && node !== target1){
                connection.push(node);
                node = prevNodeMap1.get(node);
            }
            node = prevNodeMap2.get(sharedNode);
            while(node && node !== target2){
                connection.unshift(node);
                node = prevNodeMap2.get(node);
            }
            console.log('--------');
            console.log({
                target1
            });
            console.log({
                sharedNode
            });
            console.log({
                target2
            });
            console.log({
                connection
            });
            return true;
        }
    }
    return false;
}
function isObject(structure) {
    return typeof structure === 'object' && structure !== null;
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/editorwatchdog.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "default",
    ()=>EditorWatchdog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$areconnectedthroughproperties$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/utils/areconnectedthroughproperties.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$watchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/watchdog.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$throttle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__throttle$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/throttle.js [app-ssr] (ecmascript) <export default as throttle>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeepWith$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeepWith$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/cloneDeepWith.js [app-ssr] (ecmascript) <export default as cloneDeepWith>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isElement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isElement$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/lodash-es/isElement.js [app-ssr] (ecmascript) <export default as isElement>");
;
;
;
class EditorWatchdog extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$watchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * @param Editor The editor class.
     * @param watchdogConfig The watchdog plugin configuration.
     */ constructor(Editor, watchdogConfig = {}){
        super(watchdogConfig);
        /**
         * The current editor instance.
         */ this._editor = null;
        /**
         * A promise associated with the life cycle of the editor (creation or destruction processes).
         *
         * It is used to prevent the initialization of the editor if the previous instance has not been destroyed yet,
         * and conversely, to prevent the destruction of the editor if it has not been initialized.
         */ this._lifecyclePromise = null;
        /**
         * Specifies whether the editor was initialized using document data (`true`) or HTML elements (`false`).
         */ this._initUsingData = true;
        /**
         * The latest record of the editor editable elements. Used to restart the editor.
         */ this._editables = {};
        // this._editorClass = Editor;
        this._throttledSave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$throttle$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__throttle$3e$__["throttle"])(this._save.bind(this), typeof watchdogConfig.saveInterval === 'number' ? watchdogConfig.saveInterval : 5000);
        // Set default creator and destructor functions:
        if (Editor) {
            this._creator = (elementOrData, config)=>Editor.create(elementOrData, config);
        }
        this._destructor = (editor)=>editor.destroy();
    }
    /**
     * The current editor instance.
     */ get editor() {
        return this._editor;
    }
    /**
     * @internal
     */ get _item() {
        return this._editor;
    }
    /**
     * Sets the function that is responsible for the editor creation.
     * It expects a function that should return a promise.
     *
     * ```ts
     * watchdog.setCreator( ( element, config ) => ClassicEditor.create( element, config ) );
     * ```
     */ setCreator(creator) {
        this._creator = creator;
    }
    /**
     * Sets the function that is responsible for the editor destruction.
     * Overrides the default destruction function, which destroys only the editor instance.
     * It expects a function that should return a promise or `undefined`.
     *
     * ```ts
     * watchdog.setDestructor( editor => {
     * 	// Do something before the editor is destroyed.
     *
     * 	return editor
     * 		.destroy()
     * 		.then( () => {
     * 			// Do something after the editor is destroyed.
     * 		} );
     * } );
     * ```
     */ setDestructor(destructor) {
        this._destructor = destructor;
    }
    /**
     * Restarts the editor instance. This method is called whenever an editor error occurs. It fires the `restart` event and changes
     * the state to `initializing`.
     *
     * @fires restart
     */ _restart() {
        return Promise.resolve().then(()=>{
            this.state = 'initializing';
            this._fire('stateChange');
            return this._destroy();
        }).catch((err)=>{
            console.error('An error happened during the editor destroying.', err);
        }).then(()=>{
            // Pre-process some data from the original editor config.
            // Our goal here is to make sure that the restarted editor will be reinitialized with correct set of roots.
            // We are not interested in any data set in config or in `.create()` first parameter. It will be replaced anyway.
            // But we need to set them correctly to make sure that proper roots are created.
            //
            // Since a different set of roots will be created, `lazyRoots` and `rootsAttributes` properties must be managed too.
            // Keys are root names, values are ''. Used when the editor was initialized by setting the first parameter to document data.
            const existingRoots = {};
            // Keeps lazy roots. They may be different when compared to initial config if some of the roots were loaded.
            const lazyRoots = [];
            // Roots attributes from the old config. Will be referred when setting new attributes.
            const oldRootsAttributes = this._config.rootsAttributes || {};
            // New attributes to be set. Is filled only for roots that still exist in the document.
            const rootsAttributes = {};
            // Traverse through the roots saved when the editor crashed and set up the discussed values.
            for (const [rootName, rootData] of Object.entries(this._data.roots)){
                if (rootData.isLoaded) {
                    existingRoots[rootName] = '';
                    rootsAttributes[rootName] = oldRootsAttributes[rootName] || {};
                } else {
                    lazyRoots.push(rootName);
                }
            }
            const updatedConfig = {
                ...this._config,
                extraPlugins: this._config.extraPlugins || [],
                lazyRoots,
                rootsAttributes,
                _watchdogInitialData: this._data
            };
            // Delete `initialData` as it is not needed. Data will be set by the watchdog based on `_watchdogInitialData`.
            // First parameter of the editor `.create()` will be used to set up initial roots.
            delete updatedConfig.initialData;
            updatedConfig.extraPlugins.push(EditorWatchdogInitPlugin);
            if (this._initUsingData) {
                return this.create(existingRoots, updatedConfig, updatedConfig.context);
            } else {
                // Set correct editables to make sure that proper roots are created and linked with DOM elements.
                // No need to set initial data, as it would be discarded anyway.
                //
                // If one element was initially set in `elementOrData`, then use that original element to restart the editor.
                // This is for compatibility purposes with single-root editor types.
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isElement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isElement$3e$__["isElement"])(this._elementOrData)) {
                    return this.create(this._elementOrData, updatedConfig, updatedConfig.context);
                } else {
                    return this.create(this._editables, updatedConfig, updatedConfig.context);
                }
            }
        }).then(()=>{
            this._fire('restart');
        });
    }
    /**
     * Creates the editor instance and keeps it running, using the defined creator and destructor.
     *
     * @param elementOrData The editor source element or the editor data.
     * @param config The editor configuration.
     * @param context A context for the editor.
     */ create(elementOrData = this._elementOrData, config = this._config, context) {
        this._lifecyclePromise = Promise.resolve(this._lifecyclePromise).then(()=>{
            super._startErrorHandling();
            this._elementOrData = elementOrData;
            // Use document data in the first parameter of the editor `.create()` call only if it was used like this originally.
            // Use document data if a string or object with strings was passed.
            this._initUsingData = typeof elementOrData == 'string' || Object.keys(elementOrData).length > 0 && typeof Object.values(elementOrData)[0] == 'string';
            // Clone configuration because it might be shared within multiple watchdog instances. Otherwise,
            // when an error occurs in one of these editors, the watchdog will restart all of them.
            this._config = this._cloneEditorConfiguration(config) || {};
            this._config.context = context;
            return this._creator(elementOrData, this._config);
        }).then((editor)=>{
            this._editor = editor;
            editor.model.document.on('change:data', this._throttledSave);
            this._lastDocumentVersion = editor.model.document.version;
            this._data = this._getData();
            if (!this._initUsingData) {
                this._editables = this._getEditables();
            }
            this.state = 'ready';
            this._fire('stateChange');
        }).finally(()=>{
            this._lifecyclePromise = null;
        });
        return this._lifecyclePromise;
    }
    /**
     * Destroys the watchdog and the current editor instance. It fires the callback
     * registered in {@link #setDestructor `setDestructor()`} and uses it to destroy the editor instance.
     * It also sets the state to `destroyed`.
     */ destroy() {
        this._lifecyclePromise = Promise.resolve(this._lifecyclePromise).then(()=>{
            this.state = 'destroyed';
            this._fire('stateChange');
            super.destroy();
            return this._destroy();
        }).finally(()=>{
            this._lifecyclePromise = null;
        });
        return this._lifecyclePromise;
    }
    _destroy() {
        return Promise.resolve().then(()=>{
            this._stopErrorHandling();
            this._throttledSave.cancel();
            const editor = this._editor;
            this._editor = null;
            // Remove the `change:data` listener before destroying the editor.
            // Incorrectly written plugins may trigger firing `change:data` events during the editor destruction phase
            // causing the watchdog to call `editor.getData()` when some parts of editor are already destroyed.
            editor.model.document.off('change:data', this._throttledSave);
            return this._destructor(editor);
        });
    }
    /**
     * Saves the editor data, so it can be restored after the crash even if the data cannot be fetched at
     * the moment of the crash.
     */ _save() {
        const version = this._editor.model.document.version;
        try {
            this._data = this._getData();
            if (!this._initUsingData) {
                this._editables = this._getEditables();
            }
            this._lastDocumentVersion = version;
        } catch (err) {
            console.error(err, 'An error happened during restoring editor data. ' + 'Editor will be restored from the previously saved data.');
        }
    }
    /**
     * @internal
     */ _setExcludedProperties(props) {
        this._excludedProps = props;
    }
    /**
     * Gets all data that is required to reinitialize editor instance.
     */ _getData() {
        const editor = this._editor;
        const roots = editor.model.document.roots.filter((root)=>root.isAttached() && root.rootName != '$graveyard');
        const { plugins } = editor;
        // `as any` to avoid linking from external private repo.
        const commentsRepository = plugins.has('CommentsRepository') && plugins.get('CommentsRepository');
        const trackChanges = plugins.has('TrackChanges') && plugins.get('TrackChanges');
        const data = {
            roots: {},
            markers: {},
            commentThreads: JSON.stringify([]),
            suggestions: JSON.stringify([])
        };
        roots.forEach((root)=>{
            data.roots[root.rootName] = {
                content: JSON.stringify(Array.from(root.getChildren())),
                attributes: JSON.stringify(Array.from(root.getAttributes())),
                isLoaded: root._isLoaded
            };
        });
        for (const marker of editor.model.markers){
            if (!marker._affectsData) {
                continue;
            }
            data.markers[marker.name] = {
                rangeJSON: marker.getRange().toJSON(),
                usingOperation: marker._managedUsingOperations,
                affectsData: marker._affectsData
            };
        }
        if (commentsRepository) {
            data.commentThreads = JSON.stringify(commentsRepository.getCommentThreads({
                toJSON: true,
                skipNotAttached: true
            }));
        }
        if (trackChanges) {
            data.suggestions = JSON.stringify(trackChanges.getSuggestions({
                toJSON: true,
                skipNotAttached: true
            }));
        }
        return data;
    }
    /**
     * For each attached model root, returns its HTML editable element (if available).
     */ _getEditables() {
        const editables = {};
        for (const rootName of this.editor.model.document.getRootNames()){
            const editable = this.editor.ui.getEditableElement(rootName);
            if (editable) {
                editables[rootName] = editable;
            }
        }
        return editables;
    }
    /**
     * Traverses the error context and the current editor to find out whether these structures are connected
     * to each other via properties.
     *
     * @internal
     */ _isErrorComingFromThisItem(error) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$areconnectedthroughproperties$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this._editor, error.context, this._excludedProps);
    }
    /**
     * Clones the editor configuration.
     */ _cloneEditorConfiguration(config) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$cloneDeepWith$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__cloneDeepWith$3e$__["cloneDeepWith"])(config, (value, key)=>{
            // Leave DOM references.
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$lodash$2d$es$2f$isElement$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__isElement$3e$__["isElement"])(value)) {
                return value;
            }
            if (key === 'context') {
                return value;
            }
        });
    }
}
/**
 * Internal plugin that is used to stop the default editor initialization and restoring the editor state
 * based on the `editor.config._watchdogInitialData` data.
 */ class EditorWatchdogInitPlugin {
    constructor(editor){
        this.editor = editor;
        this._data = editor.config.get('_watchdogInitialData');
    }
    /**
     * @inheritDoc
     */ init() {
        // Stops the default editor initialization and use the saved data to restore the editor state.
        // Some of data could not be initialize as a config properties. It is important to keep the data
        // in the same form as it was before the restarting.
        this.editor.data.on('init', (evt)=>{
            evt.stop();
            this.editor.model.enqueueChange({
                isUndoable: false
            }, (writer)=>{
                this._restoreCollaborationData();
                this._restoreEditorData(writer);
            });
            this.editor.data.fire('ready');
        // Keep priority `'high' - 1` to be sure that RTC initialization will be first.
        }, {
            priority: 1000 - 1
        });
    }
    /**
     * Creates a model node (element or text) based on provided JSON.
     */ _createNode(writer, jsonNode) {
        if ('name' in jsonNode) {
            // If child has name property, it is an Element.
            const element = writer.createElement(jsonNode.name, jsonNode.attributes);
            if (jsonNode.children) {
                for (const child of jsonNode.children){
                    element._appendChild(this._createNode(writer, child));
                }
            }
            return element;
        } else {
            // Otherwise, it is a Text node.
            return writer.createText(jsonNode.data, jsonNode.attributes);
        }
    }
    /**
     * Restores the editor by setting the document data, roots attributes and markers.
     */ _restoreEditorData(writer) {
        const editor = this.editor;
        Object.entries(this._data.roots).forEach(([rootName, { content, attributes }])=>{
            const parsedNodes = JSON.parse(content);
            const parsedAttributes = JSON.parse(attributes);
            const rootElement = editor.model.document.getRoot(rootName);
            for (const [key, value] of parsedAttributes){
                writer.setAttribute(key, value, rootElement);
            }
            for (const child of parsedNodes){
                const node = this._createNode(writer, child);
                writer.insert(node, rootElement, 'end');
            }
        });
        Object.entries(this._data.markers).forEach(([markerName, markerOptions])=>{
            const { document } = editor.model;
            const { rangeJSON: { start, end }, ...options } = markerOptions;
            const root = document.getRoot(start.root);
            const startPosition = writer.createPositionFromPath(root, start.path, start.stickiness);
            const endPosition = writer.createPositionFromPath(root, end.path, end.stickiness);
            const range = writer.createRange(startPosition, endPosition);
            writer.addMarker(markerName, {
                range,
                ...options
            });
        });
    }
    /**
     * Restores the editor collaboration data - comment threads and suggestions.
     */ _restoreCollaborationData() {
        // `as any` to avoid linking from external private repo.
        const parsedCommentThreads = JSON.parse(this._data.commentThreads);
        const parsedSuggestions = JSON.parse(this._data.suggestions);
        parsedCommentThreads.forEach((commentThreadData)=>{
            const channelId = this.editor.config.get('collaboration.channelId');
            const commentsRepository = this.editor.plugins.get('CommentsRepository');
            if (commentsRepository.hasCommentThread(commentThreadData.threadId)) {
                const commentThread = commentsRepository.getCommentThread(commentThreadData.threadId);
                commentThread.remove();
            }
            commentsRepository.addCommentThread({
                channelId,
                ...commentThreadData
            });
        });
        parsedSuggestions.forEach((suggestionData)=>{
            const trackChangesEditing = this.editor.plugins.get('TrackChangesEditing');
            if (trackChangesEditing.hasSuggestion(suggestionData.id)) {
                const suggestion = trackChangesEditing.getSuggestion(suggestionData.id);
                suggestion.attributes = suggestionData.attributes;
            } else {
                trackChangesEditing.addSuggestionData(suggestionData);
            }
        });
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/contextwatchdog.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([
    "default",
    ()=>ContextWatchdog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$watchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/watchdog.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$editorwatchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/editorwatchdog.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$areconnectedthroughproperties$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/utils/areconnectedthroughproperties.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$getsubnodes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/utils/getsubnodes.js [app-ssr] (ecmascript)");
;
;
;
;
const mainQueueId = Symbol('MainQueueId');
class ContextWatchdog extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$watchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * The context watchdog class constructor.
     *
     * ```ts
     * const watchdog = new ContextWatchdog( Context );
     *
     * await watchdog.create( contextConfiguration );
     *
     * await watchdog.add( item );
     * ```
     *
     * See the {@glink features/watchdog Watchdog feature guide} to learn more how to use this feature.
     *
     * @param Context The {@link module:core/context~Context} class.
     * @param watchdogConfig The watchdog configuration.
     */ constructor(Context, watchdogConfig = {}){
        super(watchdogConfig);
        /**
         * A map of internal watchdogs for added items.
         */ this._watchdogs = new Map();
        /**
         * The current context instance.
         */ this._context = null;
        /**
         * Context properties (nodes/references) that are gathered during the initial context creation
         * and are used to distinguish the origin of an error.
         */ this._contextProps = new Set();
        /**
         * An action queue, which is used to handle async functions queuing.
         */ this._actionQueues = new ActionQueues();
        this._watchdogConfig = watchdogConfig;
        // Default creator and destructor.
        this._creator = (contextConfig)=>Context.create(contextConfig);
        this._destructor = (context)=>context.destroy();
        this._actionQueues.onEmpty(()=>{
            if (this.state === 'initializing') {
                this.state = 'ready';
                this._fire('stateChange');
            }
        });
    }
    /**
     * Sets the function that is responsible for the context creation.
     * It expects a function that should return a promise (or `undefined`).
     *
     * ```ts
     * watchdog.setCreator( config => Context.create( config ) );
     * ```
     */ setCreator(creator) {
        this._creator = creator;
    }
    /**
     * Sets the function that is responsible for the context destruction.
     * Overrides the default destruction function, which destroys only the context instance.
     * It expects a function that should return a promise (or `undefined`).
     *
     * ```ts
     * watchdog.setDestructor( context => {
     * 	// Do something before the context is destroyed.
     *
     * 	return context
     * 		.destroy()
     * 		.then( () => {
     * 			// Do something after the context is destroyed.
     * 		} );
     * } );
     * ```
     */ setDestructor(destructor) {
        this._destructor = destructor;
    }
    /**
     * The context instance. Keep in mind that this property might be changed when the context watchdog restarts,
     * so do not keep this instance internally. Always operate on the `ContextWatchdog#context` property.
     */ get context() {
        return this._context;
    }
    /**
     * Initializes the context watchdog. Once it is created, the watchdog takes care about
     * recreating the context and the provided items, and starts the error handling mechanism.
     *
     * ```ts
     * await watchdog.create( {
     * 	plugins: []
     * } );
     * ```
     *
     * @param contextConfig The context configuration. See {@link module:core/context~Context}.
     */ create(contextConfig = {}) {
        return this._actionQueues.enqueue(mainQueueId, ()=>{
            this._contextConfig = contextConfig;
            return this._create();
        });
    }
    /**
     * Returns an item instance with the given `itemId`.
     *
     * ```ts
     * const editor1 = watchdog.getItem( 'editor1' );
     * ```
     *
     * @param itemId The item ID.
     * @returns The item instance or `undefined` if an item with a given ID has not been found.
     */ getItem(itemId) {
        const watchdog = this._getWatchdog(itemId);
        return watchdog._item;
    }
    /**
     * Gets the state of the given item. See {@link #state} for a list of available states.
     *
     * ```ts
     * const editor1State = watchdog.getItemState( 'editor1' );
     * ```
     *
     * @param itemId Item ID.
     * @returns The state of the item.
     */ getItemState(itemId) {
        const watchdog = this._getWatchdog(itemId);
        return watchdog.state;
    }
    /**
     * Adds items to the watchdog. Once created, instances of these items will be available using the {@link #getItem} method.
     *
     * Items can be passed together as an array of objects:
     *
     * ```ts
     * await watchdog.add( [ {
     * 	id: 'editor1',
     * 	type: 'editor',
     * 	sourceElementOrData: document.querySelector( '#editor' ),
     * 	config: {
     * 		plugins: [ Essentials, Paragraph, Bold, Italic ],
     * 		toolbar: [ 'bold', 'italic', 'alignment' ]
     * 	},
     * 	creator: ( element, config ) => ClassicEditor.create( element, config )
     * } ] );
     * ```
     *
     * Or one by one as objects:
     *
     * ```ts
     * await watchdog.add( {
     * 	id: 'editor1',
     * 	type: 'editor',
     * 	sourceElementOrData: document.querySelector( '#editor' ),
     * 	config: {
     * 		plugins: [ Essentials, Paragraph, Bold, Italic ],
     * 		toolbar: [ 'bold', 'italic', 'alignment' ]
     * 	},
     * 	creator: ( element, config ) => ClassicEditor.create( element, config )
     * ] );
     * ```
     *
     * Then an instance can be retrieved using the {@link #getItem} method:
     *
     * ```ts
     * const editor1 = watchdog.getItem( 'editor1' );
     * ```
     *
     * Note that this method can be called multiple times, but for performance reasons it is better
     * to pass all items together.
     *
     * @param itemConfigurationOrItemConfigurations An item configuration object or an array of item configurations.
     */ add(itemConfigurationOrItemConfigurations) {
        const itemConfigurations = toArray(itemConfigurationOrItemConfigurations);
        return Promise.all(itemConfigurations.map((item)=>{
            return this._actionQueues.enqueue(item.id, ()=>{
                if (this.state === 'destroyed') {
                    throw new Error('Cannot add items to destroyed watchdog.');
                }
                if (!this._context) {
                    throw new Error('Context was not created yet. You should call the `ContextWatchdog#create()` method first.');
                }
                let watchdog;
                if (this._watchdogs.has(item.id)) {
                    throw new Error(`Item with the given id is already added: '${item.id}'.`);
                }
                if (item.type === 'editor') {
                    watchdog = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$editorwatchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](null, this._watchdogConfig);
                    watchdog.setCreator(item.creator);
                    watchdog._setExcludedProperties(this._contextProps);
                    if (item.destructor) {
                        watchdog.setDestructor(item.destructor);
                    }
                    this._watchdogs.set(item.id, watchdog);
                    // Enqueue the internal watchdog errors within the main queue.
                    // And propagate the internal `error` events as `itemError` event.
                    watchdog.on('error', (evt, { error, causesRestart })=>{
                        this._fire('itemError', {
                            itemId: item.id,
                            error
                        });
                        // Do not enqueue the item restart action if the item will not restart.
                        if (!causesRestart) {
                            return;
                        }
                        this._actionQueues.enqueue(item.id, ()=>new Promise((res)=>{
                                const rethrowRestartEventOnce = ()=>{
                                    watchdog.off('restart', rethrowRestartEventOnce);
                                    this._fire('itemRestart', {
                                        itemId: item.id
                                    });
                                    res();
                                };
                                watchdog.on('restart', rethrowRestartEventOnce);
                            }));
                    });
                    return watchdog.create(item.sourceElementOrData, item.config, this._context);
                } else {
                    throw new Error(`Not supported item type: '${item.type}'.`);
                }
            });
        }));
    }
    /**
     * Removes and destroys item(s) with given ID(s).
     *
     * ```ts
     * await watchdog.remove( 'editor1' );
     * ```
     *
     * Or
     *
     * ```ts
     * await watchdog.remove( [ 'editor1', 'editor2' ] );
     * ```
     *
     * @param itemIdOrItemIds Item ID or an array of item IDs.
     */ remove(itemIdOrItemIds) {
        const itemIds = toArray(itemIdOrItemIds);
        return Promise.all(itemIds.map((itemId)=>{
            return this._actionQueues.enqueue(itemId, ()=>{
                const watchdog = this._getWatchdog(itemId);
                this._watchdogs.delete(itemId);
                return watchdog.destroy();
            });
        }));
    }
    /**
     * Destroys the context watchdog and all added items.
     * Once the context watchdog is destroyed, new items cannot be added.
     *
     * ```ts
     * await watchdog.destroy();
     * ```
     */ destroy() {
        return this._actionQueues.enqueue(mainQueueId, ()=>{
            this.state = 'destroyed';
            this._fire('stateChange');
            super.destroy();
            return this._destroy();
        });
    }
    /**
     * Restarts the context watchdog.
     */ _restart() {
        return this._actionQueues.enqueue(mainQueueId, ()=>{
            this.state = 'initializing';
            this._fire('stateChange');
            return this._destroy().catch((err)=>{
                console.error('An error happened during destroying the context or items.', err);
            }).then(()=>this._create()).then(()=>this._fire('restart'));
        });
    }
    /**
     * Initializes the context watchdog.
     */ _create() {
        return Promise.resolve().then(()=>{
            this._startErrorHandling();
            return this._creator(this._contextConfig);
        }).then((context)=>{
            this._context = context;
            this._contextProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$getsubnodes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this._context);
            return Promise.all(Array.from(this._watchdogs.values()).map((watchdog)=>{
                watchdog._setExcludedProperties(this._contextProps);
                return watchdog.create(undefined, undefined, this._context);
            }));
        });
    }
    /**
     * Destroys the context instance and all added items.
     */ _destroy() {
        return Promise.resolve().then(()=>{
            this._stopErrorHandling();
            const context = this._context;
            this._context = null;
            this._contextProps = new Set();
            return Promise.all(Array.from(this._watchdogs.values()).map((watchdog)=>watchdog.destroy()))// Context destructor destroys each editor.
            .then(()=>this._destructor(context));
        });
    }
    /**
     * Returns the watchdog for a given item ID.
     *
     * @param itemId Item ID.
     */ _getWatchdog(itemId) {
        const watchdog = this._watchdogs.get(itemId);
        if (!watchdog) {
            throw new Error(`Item with the given id was not registered: ${itemId}.`);
        }
        return watchdog;
    }
    /**
     * Checks whether an error comes from the context instance and not from the item instances.
     *
     * @internal
     */ _isErrorComingFromThisItem(error) {
        for (const watchdog of this._watchdogs.values()){
            if (watchdog._isErrorComingFromThisItem(error)) {
                return false;
            }
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$utils$2f$areconnectedthroughproperties$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"])(this._context, error.context);
    }
}
/**
 * Manager of action queues that allows queuing async functions.
 */ class ActionQueues {
    constructor(){
        this._onEmptyCallbacks = [];
        this._queues = new Map();
        this._activeActions = 0;
    }
    /**
     * Used to register callbacks that will be run when the queue becomes empty.
     *
     * @param onEmptyCallback A callback that will be run whenever the queue becomes empty.
     */ onEmpty(onEmptyCallback) {
        this._onEmptyCallbacks.push(onEmptyCallback);
    }
    /**
     * It adds asynchronous actions (functions) to the proper queue and runs them one by one.
     *
     * @param queueId The action queue ID.
     * @param action A function that should be enqueued.
     */ enqueue(queueId, action) {
        const isMainAction = queueId === mainQueueId;
        this._activeActions++;
        if (!this._queues.get(queueId)) {
            this._queues.set(queueId, Promise.resolve());
        }
        // List all sources of actions that the current action needs to await for.
        // For the main action wait for all other actions.
        // For the item action wait only for the item queue and the main queue.
        const awaitedActions = isMainAction ? Promise.all(this._queues.values()) : Promise.all([
            this._queues.get(mainQueueId),
            this._queues.get(queueId)
        ]);
        const queueWithAction = awaitedActions.then(action);
        // Catch all errors in the main queue to stack promises even if an error occurred in the past.
        const nonErrorQueue = queueWithAction.catch(()=>{});
        this._queues.set(queueId, nonErrorQueue);
        return queueWithAction.finally(()=>{
            this._activeActions--;
            if (this._queues.get(queueId) === nonErrorQueue && this._activeActions === 0) {
                this._onEmptyCallbacks.forEach((cb)=>cb());
            }
        });
    }
}
/**
 * Transforms any value to an array. If the provided value is already an array, it is returned unchanged.
 *
 * @param elementOrArray The value to transform to an array.
 * @returns An array created from data.
 */ function toArray(elementOrArray) {
    return Array.isArray(elementOrArray) ? elementOrArray : [
        elementOrArray
    ];
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/augmentation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([]);
;
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module watchdog
 */ __turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$contextwatchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/contextwatchdog.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$editorwatchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/editorwatchdog.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$watchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/watchdog.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$augmentation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/augmentation.js [app-ssr] (ecmascript)");
;
;
;
;
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContextWatchdog",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$contextwatchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "EditorWatchdog",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$editorwatchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "Watchdog",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$watchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$contextwatchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/contextwatchdog.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$editorwatchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/editorwatchdog.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$watchdog$2f$src$2f$watchdog$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-watchdog/src/watchdog.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * Returns attributes that should be preserved on the enter keystroke.
 *
 * Filtering is realized based on `copyOnEnter` attribute property. Read more about attribute properties
 * {@link module:engine/model/schema~Schema#setAttributeProperties here}.
 *
 * @param schema Model's schema.
 * @param allAttributes Attributes to filter.
 */ __turbopack_context__.s([
    "getCopyOnEnterAttributes",
    ()=>getCopyOnEnterAttributes
]);
function* getCopyOnEnterAttributes(schema, allAttributes) {
    for (const attribute of allAttributes){
        if (attribute && schema.getAttributeProperties(attribute[0]).copyOnEnter) {
            yield attribute;
        }
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/entercommand.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module enter/entercommand
 */ __turbopack_context__.s([
    "default",
    ()=>EnterCommand
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$command$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Command$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/command.js [app-ssr] (ecmascript) <export default as Command>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/utils.js [app-ssr] (ecmascript)");
;
;
class EnterCommand extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$command$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Command$3e$__["Command"] {
    /**
     * @inheritDoc
     */ execute() {
        this.editor.model.change((writer)=>{
            this.enterBlock(writer);
            this.fire('afterExecute', {
                writer
            });
        });
    }
    /**
     * Splits a block where the document selection is placed, in the way how the <kbd>Enter</kbd> key is expected to work:
     *
     * ```
     * <p>Foo[]bar</p>   ->   <p>Foo</p><p>[]bar</p>
     * <p>Foobar[]</p>   ->   <p>Foobar</p><p>[]</p>
     * <p>Fo[ob]ar</p>   ->   <p>Fo</p><p>[]ar</p>
     * ```
     *
     * In some cases, the split will not happen:
     *
     * ```
     * // The selection parent is a limit element:
     * <figcaption>A[bc]d</figcaption>   ->   <figcaption>A[]d</figcaption>
     *
     * // The selection spans over multiple elements:
     * <h>x[x</h><p>y]y<p>   ->   <h>x</h><p>[]y</p>
     * ```
     *
     * @param writer Writer to use when performing the enter action.
     * @returns Boolean indicating if the block was split.
     */ enterBlock(writer) {
        const model = this.editor.model;
        const selection = model.document.selection;
        const schema = model.schema;
        const isSelectionEmpty = selection.isCollapsed;
        const range = selection.getFirstRange();
        const startElement = range.start.parent;
        const endElement = range.end.parent;
        // Don't touch the roots and other limit elements.
        if (schema.isLimit(startElement) || schema.isLimit(endElement)) {
            // Delete the selected content but only if inside a single limit element.
            // Abort, when crossing limit elements boundary (e.g. <limit1>x[x</limit1>donttouchme<limit2>y]y</limit2>).
            // This is an edge case and it's hard to tell what should actually happen because such a selection
            // is not entirely valid.
            if (!isSelectionEmpty && startElement == endElement) {
                model.deleteContent(selection);
            }
            return false;
        }
        if (isSelectionEmpty) {
            const attributesToCopy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getCopyOnEnterAttributes"])(writer.model.schema, selection.getAttributes());
            splitBlock(writer, range.start);
            writer.setSelectionAttribute(attributesToCopy);
            return true;
        } else {
            const leaveUnmerged = !(range.start.isAtStart && range.end.isAtEnd);
            const isContainedWithinOneElement = startElement == endElement;
            model.deleteContent(selection, {
                leaveUnmerged
            });
            if (leaveUnmerged) {
                // Partially selected elements.
                //
                // <h>x[xx]x</h>		-> <h>x^x</h>			-> <h>x</h><h>^x</h>
                if (isContainedWithinOneElement) {
                    splitBlock(writer, selection.focus);
                    return true;
                } else {
                    writer.setSelection(endElement, 0);
                }
            }
        }
        return false;
    }
}
function splitBlock(writer, splitPos) {
    writer.split(splitPos);
    writer.setSelection(splitPos.parent.nextSibling, 0);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/enterobserver.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module enter/enterobserver
 */ __turbopack_context__.s([
    "default",
    ()=>EnterObserver
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Observer$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/observer.js [app-ssr] (ecmascript) <export default as Observer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventdata$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DomEventData$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/domeventdata.js [app-ssr] (ecmascript) <export default as DomEventData>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BubblingEventInfo$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/view/observer/bubblingeventinfo.js [app-ssr] (ecmascript) <export default as BubblingEventInfo>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/env.js [app-ssr] (ecmascript) <export default as env>");
;
;
const ENTER_EVENT_TYPES = {
    insertParagraph: {
        isSoft: false
    },
    insertLineBreak: {
        isSoft: true
    }
};
class EnterObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$observer$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Observer$3e$__["Observer"] {
    /**
     * @inheritDoc
     */ constructor(view){
        super(view);
        const doc = this.document;
        let shiftPressed = false;
        doc.on('keydown', (evt, data)=>{
            shiftPressed = data.shiftKey;
        });
        doc.on('beforeinput', (evt, data)=>{
            if (!this.isEnabled) {
                return;
            }
            let inputType = data.inputType;
            // See https://github.com/ckeditor/ckeditor5/issues/13321.
            if (__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$env$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__env$3e$__["env"].isSafari && shiftPressed && inputType == 'insertParagraph') {
                inputType = 'insertLineBreak';
            }
            const domEvent = data.domEvent;
            const enterEventSpec = ENTER_EVENT_TYPES[inputType];
            if (!enterEventSpec) {
                return;
            }
            const event = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$bubblingeventinfo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BubblingEventInfo$3e$__["BubblingEventInfo"](doc, 'enter', data.targetRanges[0]);
            doc.fire(event, new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$view$2f$observer$2f$domeventdata$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__DomEventData$3e$__["DomEventData"](view, domEvent, {
                isSoft: enterEventSpec.isSoft
            }));
            // Stop `beforeinput` event if `enter` event was stopped.
            // https://github.com/ckeditor/ckeditor5/issues/753
            if (event.stop.called) {
                evt.stop();
            }
        });
    }
    /**
     * @inheritDoc
     */ observe() {}
    /**
     * @inheritDoc
     */ stopObserving() {}
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/enter.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module enter/enter
 */ __turbopack_context__.s([
    "default",
    ()=>Enter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/plugin.js [app-ssr] (ecmascript) <export default as Plugin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$entercommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/entercommand.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$enterobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/enterobserver.js [app-ssr] (ecmascript)");
;
;
;
class Enter extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'Enter';
    }
    init() {
        const editor = this.editor;
        const view = editor.editing.view;
        const viewDocument = view.document;
        const t = this.editor.t;
        view.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$enterobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        editor.commands.add('enter', new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$entercommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](editor));
        this.listenTo(viewDocument, 'enter', (evt, data)=>{
            // When not in composition, we handle the action, so prevent the default one.
            // When in composition, it's the browser who modify the DOM (renderer is disabled).
            if (!viewDocument.isComposing) {
                data.preventDefault();
            }
            // The soft enter key is handled by the ShiftEnter plugin.
            if (data.isSoft) {
                return;
            }
            editor.execute('enter');
            view.scrollToTheSelection();
        }, {
            priority: 'low'
        });
        // Add the information about the keystroke to the accessibility database.
        editor.accessibility.addKeystrokeInfos({
            keystrokes: [
                {
                    label: t('Insert a hard break (a new paragraph)'),
                    keystroke: 'Enter'
                }
            ]
        });
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/shiftentercommand.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module enter/shiftentercommand
 */ __turbopack_context__.s([
    "default",
    ()=>ShiftEnterCommand
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$command$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Command$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/command.js [app-ssr] (ecmascript) <export default as Command>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/utils.js [app-ssr] (ecmascript)");
;
;
class ShiftEnterCommand extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$command$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Command$3e$__["Command"] {
    /**
     * @inheritDoc
     */ execute() {
        const model = this.editor.model;
        const doc = model.document;
        model.change((writer)=>{
            softBreakAction(model, writer, doc.selection);
            this.fire('afterExecute', {
                writer
            });
        });
    }
    /**
     * @inheritDoc
     */ refresh() {
        const model = this.editor.model;
        const doc = model.document;
        this.isEnabled = isEnabled(model.schema, doc.selection);
    }
}
/**
 * Checks whether the ShiftEnter command should be enabled in the specified selection.
 */ function isEnabled(schema, selection) {
    // At this moment it is okay to support single range selections only.
    // But in the future we may need to change that.
    if (selection.rangeCount > 1) {
        return false;
    }
    const anchorPos = selection.anchor;
    // Check whether the break element can be inserted in the current selection anchor.
    if (!anchorPos || !schema.checkChild(anchorPos, 'softBreak')) {
        return false;
    }
    const range = selection.getFirstRange();
    const startElement = range.start.parent;
    const endElement = range.end.parent;
    // Do not modify the content if selection is cross-limit elements.
    if ((isInsideLimitElement(startElement, schema) || isInsideLimitElement(endElement, schema)) && startElement !== endElement) {
        return false;
    }
    return true;
}
/**
 * Creates a break in the way that the <kbd>Shift</kbd>+<kbd>Enter</kbd> keystroke is expected to work.
 */ function softBreakAction(model, writer, selection) {
    const isSelectionEmpty = selection.isCollapsed;
    const range = selection.getFirstRange();
    const startElement = range.start.parent;
    const endElement = range.end.parent;
    const isContainedWithinOneElement = startElement == endElement;
    if (isSelectionEmpty) {
        const attributesToCopy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getCopyOnEnterAttributes"])(model.schema, selection.getAttributes());
        insertBreak(model, writer, range.end);
        writer.removeSelectionAttribute(selection.getAttributeKeys());
        writer.setSelectionAttribute(attributesToCopy);
    } else {
        const leaveUnmerged = !(range.start.isAtStart && range.end.isAtEnd);
        model.deleteContent(selection, {
            leaveUnmerged
        });
        // Selection within one element:
        //
        // <h>x[xx]x</h>		-> <h>x^x</h>			-> <h>x<br>^x</h>
        if (isContainedWithinOneElement) {
            insertBreak(model, writer, selection.focus);
        } else {
            // Move the selection to the 2nd element (last step of the example above).
            if (leaveUnmerged) {
                writer.setSelection(endElement, 0);
            }
        }
    }
}
function insertBreak(model, writer, position) {
    const breakLineElement = writer.createElement('softBreak');
    model.insertContent(breakLineElement, position);
    writer.setSelection(breakLineElement, 'after');
}
/**
 * Checks whether the specified `element` is a child of the limit element.
 *
 * Checking whether the `<p>` element is inside a limit element:
 *   - `<$root><p>Text.</p></$root> => false`
 *   - `<$root><limitElement><p>Text</p></limitElement></$root> => true`
 */ function isInsideLimitElement(element, schema) {
    // `$root` is a limit element but in this case is an invalid element.
    if (element.is('rootElement')) {
        return false;
    }
    return schema.isLimit(element) || isInsideLimitElement(element.parent, schema);
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/shiftenter.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module enter/shiftenter
 */ __turbopack_context__.s([
    "default",
    ()=>ShiftEnter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$shiftentercommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/shiftentercommand.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$enterobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/enterobserver.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/plugin.js [app-ssr] (ecmascript) <export default as Plugin>");
;
;
;
class ShiftEnter extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'ShiftEnter';
    }
    init() {
        const editor = this.editor;
        const schema = editor.model.schema;
        const conversion = editor.conversion;
        const view = editor.editing.view;
        const viewDocument = view.document;
        const t = this.editor.t;
        // Configure the schema.
        schema.register('softBreak', {
            allowWhere: '$text',
            isInline: true
        });
        // Configure converters.
        conversion.for('upcast').elementToElement({
            model: 'softBreak',
            view: 'br'
        });
        conversion.for('downcast').elementToElement({
            model: 'softBreak',
            view: (modelElement, { writer })=>writer.createEmptyElement('br')
        });
        view.addObserver(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$enterobserver$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]);
        editor.commands.add('shiftEnter', new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$shiftentercommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](editor));
        this.listenTo(viewDocument, 'enter', (evt, data)=>{
            // When not in composition, we handle the action, so prevent the default one.
            // When in composition, it's the browser who modify the DOM (renderer is disabled).
            if (!viewDocument.isComposing) {
                data.preventDefault();
            }
            // The hard enter key is handled by the Enter plugin.
            if (!data.isSoft) {
                return;
            }
            editor.execute('shiftEnter');
            view.scrollToTheSelection();
        }, {
            priority: 'low'
        });
        // Add the information about the keystroke to the accessibility database.
        editor.accessibility.addKeystrokeInfos({
            keystrokes: [
                {
                    label: t('Insert a soft break (a <code>&lt;br&gt;</code> element)'),
                    keystroke: 'Shift+Enter'
                }
            ]
        });
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/augmentation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([]);
;
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module enter
 */ __turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$enter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/enter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$shiftenter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/shiftenter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$augmentation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/augmentation.js [app-ssr] (ecmascript)");
;
;
;
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/enter.js [app-ssr] (ecmascript) <export default as Enter>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Enter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$enter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$enter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/enter.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Enter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$enter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "ShiftEnter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$shiftenter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$enter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/enter.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$shiftenter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/shiftenter.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectallcommand.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module select-all/selectallcommand
 */ __turbopack_context__.s([
    "default",
    ()=>SelectAllCommand
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$command$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Command$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/command.js [app-ssr] (ecmascript) <export default as Command>");
;
class SelectAllCommand extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$command$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Command$3e$__["Command"] {
    /**
     * @inheritDoc
     */ constructor(editor){
        super(editor);
        // It does not affect data so should be enabled in read-only mode.
        this.affectsData = false;
    }
    /**
     * @inheritDoc
     */ execute() {
        const model = this.editor.model;
        const selection = model.document.selection;
        let scopeElement = model.schema.getLimitElement(selection);
        // If an entire scope is selected, or the selection's ancestor is not a scope yet,
        // browse through ancestors to find the enclosing parent scope.
        if (selection.containsEntireContent(scopeElement) || !isSelectAllScope(model.schema, scopeElement)) {
            do {
                scopeElement = scopeElement.parent;
                // Do nothing, if the entire `root` is already selected.
                if (!scopeElement) {
                    return;
                }
            }while (!isSelectAllScope(model.schema, scopeElement))
        }
        model.change((writer)=>{
            writer.setSelection(scopeElement, 'in');
        });
    }
}
/**
 * Checks whether the element is a valid select-all scope. Returns true, if the element is a
 * {@link module:engine/model/schema~Schema#isLimit limit}, and can contain any text or paragraph.
 *
 * @param schema Schema to check against.
 * @param element Model element.
 */ function isSelectAllScope(schema, element) {
    return schema.isLimit(element) && (schema.checkChild(element, '$text') || schema.checkChild(element, 'paragraph'));
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectallediting.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module select-all/selectallediting
 */ __turbopack_context__.s([
    "default",
    ()=>SelectAllEditing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/plugin.js [app-ssr] (ecmascript) <export default as Plugin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-utils/src/keyboard.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallcommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectallcommand.js [app-ssr] (ecmascript)");
;
;
;
const SELECT_ALL_KEYSTROKE = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseKeystroke"])('Ctrl+A');
class SelectAllEditing extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'SelectAllEditing';
    }
    /**
     * @inheritDoc
     */ init() {
        const editor = this.editor;
        const t = editor.t;
        const view = editor.editing.view;
        const viewDocument = view.document;
        editor.commands.add('selectAll', new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallcommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](editor));
        this.listenTo(viewDocument, 'keydown', (eventInfo, domEventData)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$utils$2f$src$2f$keyboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getCode"])(domEventData) === SELECT_ALL_KEYSTROKE) {
                editor.execute('selectAll');
                domEventData.preventDefault();
            }
        });
        // Add the information about the keystroke to the accessibility database.
        editor.accessibility.addKeystrokeInfos({
            keystrokes: [
                {
                    label: t('Select all'),
                    keystroke: 'CTRL+A'
                }
            ]
        });
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/theme/icons/select-all.svg (static in ecmascript)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/select-all.7d2a0bf7.svg");}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectallui.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module select-all/selectallui
 */ __turbopack_context__.s([
    "default",
    ()=>SelectAllUI
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/plugin.js [app-ssr] (ecmascript) <export default as Plugin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-ui/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$button$2f$buttonview$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ButtonView$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-ui/src/button/buttonview.js [app-ssr] (ecmascript) <export default as ButtonView>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$menubar$2f$menubarmenulistitembuttonview$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuBarMenuListItemButtonView$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-ui/src/menubar/menubarmenulistitembuttonview.js [app-ssr] (ecmascript) <export default as MenuBarMenuListItemButtonView>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$theme$2f$icons$2f$select$2d$all$2e$svg__$28$static__in__ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/theme/icons/select-all.svg (static in ecmascript)");
;
;
;
class SelectAllUI extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'SelectAllUI';
    }
    /**
     * @inheritDoc
     */ init() {
        const editor = this.editor;
        editor.ui.componentFactory.add('selectAll', ()=>{
            const buttonView = this._createButton(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$button$2f$buttonview$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ButtonView$3e$__["ButtonView"]);
            buttonView.set({
                tooltip: true
            });
            return buttonView;
        });
        editor.ui.componentFactory.add('menuBar:selectAll', ()=>{
            return this._createButton(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$menubar$2f$menubarmenulistitembuttonview$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuBarMenuListItemButtonView$3e$__["MenuBarMenuListItemButtonView"]);
        });
    }
    /**
     * Creates a button for select all command to use either in toolbar or in menu bar.
     */ _createButton(ButtonClass) {
        const editor = this.editor;
        const locale = editor.locale;
        const command = editor.commands.get('selectAll');
        const view = new ButtonClass(editor.locale);
        const t = locale.t;
        view.set({
            label: t('Select all'),
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$theme$2f$icons$2f$select$2d$all$2e$svg__$28$static__in__ecmascript$29$__["default"],
            keystroke: 'Ctrl+A'
        });
        view.bind('isEnabled').to(command, 'isEnabled');
        // Execute the command.
        this.listenTo(view, 'execute', ()=>{
            editor.execute('selectAll');
            editor.editing.view.focus();
        });
        return view;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectall.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module select-all/selectall
 */ __turbopack_context__.s([
    "default",
    ()=>SelectAll
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/plugin.js [app-ssr] (ecmascript) <export default as Plugin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectallediting.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectallui.js [app-ssr] (ecmascript)");
;
;
;
class SelectAll extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get requires() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
        ];
    }
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'SelectAll';
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/augmentation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([]);
;
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module select-all
 */ __turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectall$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectall.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectallediting.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectallui.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$augmentation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/augmentation.js [app-ssr] (ecmascript)");
;
;
;
;
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SelectAll",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectall$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "SelectAllEditing",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "SelectAllUI",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectall$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectall.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectallediting.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$selectallui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/selectallui.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/basecommand.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module undo/basecommand
 */ __turbopack_context__.s([
    "default",
    ()=>BaseCommand
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$command$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Command$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/command.js [app-ssr] (ecmascript) <export default as Command>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$transform$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/transform.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__NoOperation$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-engine/src/model/operation/nooperation.js [app-ssr] (ecmascript) <export default as NoOperation>");
;
;
class BaseCommand extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$command$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Command$3e$__["Command"] {
    /**
     * @inheritDoc
     */ constructor(editor){
        super(editor);
        /**
         * Stack of items stored by the command. These are pairs of:
         *
         * * {@link module:engine/model/batch~Batch batch} saved by the command,
         * * {@link module:engine/model/selection~Selection selection} state at the moment of saving the batch.
         */ this._stack = [];
        /**
         * Stores all batches that were created by this command.
         *
         * @internal
         */ this._createdBatches = new WeakSet();
        // Refresh state, so the command is inactive right after initialization.
        this.refresh();
        // This command should not depend on selection change.
        this._isEnabledBasedOnSelection = false;
        // Set the transparent batch for the `editor.data.set()` call if the
        // batch type is not set already.
        this.listenTo(editor.data, 'set', (evt, data)=>{
            // Create a shallow copy of the options to not change the original args.
            // And make sure that an object is assigned to data[ 1 ].
            data[1] = {
                ...data[1]
            };
            const options = data[1];
            // If batch type is not set, default to non-undoable batch.
            if (!options.batchType) {
                options.batchType = {
                    isUndoable: false
                };
            }
        }, {
            priority: 'high'
        });
        // Clear the stack for the `transparent` batches.
        this.listenTo(editor.data, 'set', (evt, data)=>{
            // We can assume that the object exists and it has a `batchType` property.
            // It was ensured with a higher priority listener before.
            const options = data[1];
            if (!options.batchType.isUndoable) {
                this.clearStack();
            }
        });
    }
    /**
     * @inheritDoc
     */ refresh() {
        this.isEnabled = this._stack.length > 0;
    }
    /**
     * Returns all batches created by this command.
     */ get createdBatches() {
        return this._createdBatches;
    }
    /**
     * Stores a batch in the command, together with the selection state of the {@link module:engine/model/document~Document document}
     * created by the editor which this command is registered to.
     *
     * @param batch The batch to add.
     */ addBatch(batch) {
        const docSelection = this.editor.model.document.selection;
        const selection = {
            ranges: docSelection.hasOwnRange ? Array.from(docSelection.getRanges()) : [],
            isBackward: docSelection.isBackward
        };
        this._stack.push({
            batch,
            selection
        });
        this.refresh();
    }
    /**
     * Removes all items from the stack.
     */ clearStack() {
        this._stack = [];
        this.refresh();
    }
    /**
     * Restores the {@link module:engine/model/document~Document#selection document selection} state after a batch was undone.
     *
     * @param ranges Ranges to be restored.
     * @param isBackward A flag describing whether the restored range was selected forward or backward.
     * @param operations Operations which has been applied since selection has been stored.
     */ _restoreSelection(ranges, isBackward, operations) {
        const model = this.editor.model;
        const document = model.document;
        // This will keep the transformed selection ranges.
        const selectionRanges = [];
        // Transform all ranges from the restored selection.
        const transformedRangeGroups = ranges.map((range)=>range.getTransformedByOperations(operations));
        const allRanges = transformedRangeGroups.flat();
        for (const rangeGroup of transformedRangeGroups){
            // While transforming there could appear ranges that are contained by other ranges, we shall ignore them.
            const transformed = rangeGroup.filter((range)=>range.root != document.graveyard).filter((range)=>!isRangeContainedByAnyOtherRange(range, allRanges));
            // All the transformed ranges ended up in graveyard.
            if (!transformed.length) {
                continue;
            }
            // After the range got transformed, we have an array of ranges. Some of those
            // ranges may be "touching" -- they can be next to each other and could be merged.
            normalizeRanges(transformed);
            // For each `range` from `ranges`, we take only one transformed range.
            // This is because we want to prevent situation where single-range selection
            // got transformed to multi-range selection.
            selectionRanges.push(transformed[0]);
        }
        // @if CK_DEBUG_ENGINE // console.log( `Restored selection by undo: ${ selectionRanges.join( ', ' ) }` );
        // `selectionRanges` may be empty if all ranges ended up in graveyard. If that is the case, do not restore selection.
        if (selectionRanges.length) {
            model.change((writer)=>{
                writer.setSelection(selectionRanges, {
                    backward: isBackward
                });
            });
        }
    }
    /**
     * Undoes a batch by reversing that batch, transforming reversed batch and finally applying it.
     * This is a helper method for {@link #execute}.
     *
     * @param batchToUndo The batch to be undone.
     * @param undoingBatch The batch that will contain undoing changes.
     */ _undo(batchToUndo, undoingBatch) {
        const model = this.editor.model;
        const document = model.document;
        // All changes done by the command execution will be saved as one batch.
        this._createdBatches.add(undoingBatch);
        const operationsToUndo = batchToUndo.operations.slice().filter((operation)=>operation.isDocumentOperation);
        operationsToUndo.reverse();
        // We will process each operation from `batchToUndo`, in reverse order. If there were operations A, B and C in undone batch,
        // we need to revert them in reverse order, so first C' (reversed C), then B', then A'.
        for (const operationToUndo of operationsToUndo){
            const nextBaseVersion = operationToUndo.baseVersion + 1;
            const historyOperations = Array.from(document.history.getOperations(nextBaseVersion));
            const transformedSets = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$transform$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["transformSets"])([
                operationToUndo.getReversed()
            ], historyOperations, {
                useRelations: true,
                document: this.editor.model.document,
                padWithNoOps: false,
                forceWeakRemove: true
            });
            const reversedOperations = transformedSets.operationsA;
            // After reversed operation has been transformed by all history operations, apply it.
            for (let operation of reversedOperations){
                // Do not apply any operation on non-editable space.
                const affectedSelectable = operation.affectedSelectable;
                if (affectedSelectable && !model.canEditAt(affectedSelectable)) {
                    operation = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$engine$2f$src$2f$model$2f$operation$2f$nooperation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__NoOperation$3e$__["NoOperation"](operation.baseVersion);
                }
                // Before applying, add the operation to the `undoingBatch`.
                undoingBatch.addOperation(operation);
                model.applyOperation(operation);
                document.history.setOperationAsUndone(operationToUndo, operation);
            }
        }
    }
}
/**
 * Normalizes list of ranges by joining intersecting or "touching" ranges.
 *
 * @param ranges Ranges to be normalized.
 */ function normalizeRanges(ranges) {
    ranges.sort((a, b)=>a.start.isBefore(b.start) ? -1 : 1);
    for(let i = 1; i < ranges.length; i++){
        const previousRange = ranges[i - 1];
        const joinedRange = previousRange.getJoined(ranges[i], true);
        if (joinedRange) {
            // Replace the ranges on the list with the new joined range.
            i--;
            ranges.splice(i, 2, joinedRange);
        }
    }
}
function isRangeContainedByAnyOtherRange(range, ranges) {
    return ranges.some((otherRange)=>otherRange !== range && otherRange.containsRange(range, true));
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undocommand.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module undo/undocommand
 */ __turbopack_context__.s([
    "default",
    ()=>UndoCommand
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$basecommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/basecommand.js [app-ssr] (ecmascript)");
;
class UndoCommand extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$basecommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Executes the command. This method reverts a {@link module:engine/model/batch~Batch batch} added to the command's stack, transforms
     * and applies the reverted version on the {@link module:engine/model/document~Document document} and removes the batch from the stack.
     * Then, it restores the {@link module:engine/model/document~Document#selection document selection}.
     *
     * @fires execute
     * @fires revert
     * @param batch A batch that should be undone. If not set, the last added batch will be undone.
     */ execute(batch = null) {
        // If batch is not given, set `batchIndex` to the last index in command stack.
        const batchIndex = batch ? this._stack.findIndex((a)=>a.batch == batch) : this._stack.length - 1;
        const item = this._stack.splice(batchIndex, 1)[0];
        const undoingBatch = this.editor.model.createBatch({
            isUndo: true
        });
        // All changes have to be done in one `enqueueChange` callback so other listeners will not
        // step between consecutive operations, or won't do changes to the document before selection is properly restored.
        this.editor.model.enqueueChange(undoingBatch, ()=>{
            this._undo(item.batch, undoingBatch);
            const operations = this.editor.model.document.history.getOperations(item.batch.baseVersion);
            this._restoreSelection(item.selection.ranges, item.selection.isBackward, operations);
        });
        // Firing `revert` event after the change block to make sure that it includes all changes from post-fixers
        // and make sure that the selection is "stabilized" (the selection range is saved after undo is executed and then
        // restored on redo, so it is important that the selection range is saved after post-fixers are done).
        this.fire('revert', item.batch, undoingBatch);
        this.refresh();
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/redocommand.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module undo/redocommand
 */ __turbopack_context__.s([
    "default",
    ()=>RedoCommand
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$basecommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/basecommand.js [app-ssr] (ecmascript)");
;
class RedoCommand extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$basecommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"] {
    /**
     * Executes the command. This method reverts the last {@link module:engine/model/batch~Batch batch} added to
     * the command's stack, applies the reverted and transformed version on the
     * {@link module:engine/model/document~Document document} and removes the batch from the stack.
     * Then, it restores the {@link module:engine/model/document~Document#selection document selection}.
     *
     * @fires execute
     */ execute() {
        const item = this._stack.pop();
        const redoingBatch = this.editor.model.createBatch({
            isUndo: true
        });
        // All changes have to be done in one `enqueueChange` callback so other listeners will not step between consecutive
        // operations, or won't do changes to the document before selection is properly restored.
        this.editor.model.enqueueChange(redoingBatch, ()=>{
            const lastOperation = item.batch.operations[item.batch.operations.length - 1];
            const nextBaseVersion = lastOperation.baseVersion + 1;
            const operations = this.editor.model.document.history.getOperations(nextBaseVersion);
            this._restoreSelection(item.selection.ranges, item.selection.isBackward, operations);
            this._undo(item.batch, redoingBatch);
        });
        this.refresh();
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undoediting.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module undo/undoediting
 */ __turbopack_context__.s([
    "default",
    ()=>UndoEditing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/plugin.js [app-ssr] (ecmascript) <export default as Plugin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undocommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undocommand.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$redocommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/redocommand.js [app-ssr] (ecmascript)");
;
;
;
class UndoEditing extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__["Plugin"] {
    constructor(){
        super(...arguments);
        /**
         * Keeps track of which batches were registered in undo.
         */ this._batchRegistry = new WeakSet();
    }
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'UndoEditing';
    }
    /**
     * @inheritDoc
     */ init() {
        const editor = this.editor;
        const t = editor.t;
        // Create commands.
        this._undoCommand = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undocommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](editor);
        this._redoCommand = new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$redocommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](editor);
        // Register command to the editor.
        editor.commands.add('undo', this._undoCommand);
        editor.commands.add('redo', this._redoCommand);
        this.listenTo(editor.model, 'applyOperation', (evt, args)=>{
            const operation = args[0];
            // Do not register batch if the operation is not a document operation.
            // This prevents from creating empty undo steps, where all operations where non-document operations.
            // Non-document operations creates and alters content in detached tree fragments (for example, document fragments).
            // Most of time this is preparing data before it is inserted into actual tree (for example during copy & paste).
            // Such operations should not be reversed.
            if (!operation.isDocumentOperation) {
                return;
            }
            const batch = operation.batch;
            const isRedoBatch = this._redoCommand.createdBatches.has(batch);
            const isUndoBatch = this._undoCommand.createdBatches.has(batch);
            const wasProcessed = this._batchRegistry.has(batch);
            // Skip the batch if it was already processed.
            if (wasProcessed) {
                return;
            }
            // Add the batch to the registry so it will not be processed again.
            this._batchRegistry.add(batch);
            if (!batch.isUndoable) {
                return;
            }
            if (isRedoBatch) {
                // If this batch comes from `redoCommand`, add it to the `undoCommand` stack.
                this._undoCommand.addBatch(batch);
            } else if (!isUndoBatch) {
                // If the batch comes neither  from `redoCommand` nor from `undoCommand` then it is a new, regular batch.
                // Add the batch to the `undoCommand` stack and clear the `redoCommand` stack.
                this._undoCommand.addBatch(batch);
                this._redoCommand.clearStack();
            }
        }, {
            priority: 'highest'
        });
        this.listenTo(this._undoCommand, 'revert', (evt, undoneBatch, undoingBatch)=>{
            this._redoCommand.addBatch(undoingBatch);
        });
        editor.keystrokes.set('CTRL+Z', 'undo');
        editor.keystrokes.set('CTRL+Y', 'redo');
        editor.keystrokes.set('CTRL+SHIFT+Z', 'redo');
        // Add the information about the keystrokes to the accessibility database.
        editor.accessibility.addKeystrokeInfos({
            keystrokes: [
                {
                    label: t('Undo'),
                    keystroke: 'CTRL+Z'
                },
                {
                    label: t('Redo'),
                    keystroke: [
                        [
                            'CTRL+Y'
                        ],
                        [
                            'CTRL+SHIFT+Z'
                        ]
                    ]
                }
            ]
        });
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undoui.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module undo/undoui
 */ __turbopack_context__.s([
    "default",
    ()=>UndoUI
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/plugin.js [app-ssr] (ecmascript) <export default as Plugin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-ui/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$button$2f$buttonview$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ButtonView$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-ui/src/button/buttonview.js [app-ssr] (ecmascript) <export default as ButtonView>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$menubar$2f$menubarmenulistitembuttonview$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuBarMenuListItemButtonView$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-ui/src/menubar/menubarmenulistitembuttonview.js [app-ssr] (ecmascript) <export default as MenuBarMenuListItemButtonView>");
;
;
class UndoUI extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'UndoUI';
    }
    /**
     * @inheritDoc
     */ init() {
        const editor = this.editor;
        const locale = editor.locale;
        const t = editor.t;
        const localizedUndoIcon = locale.uiLanguageDirection == 'ltr' ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["icons"].undo : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["icons"].redo;
        const localizedRedoIcon = locale.uiLanguageDirection == 'ltr' ? __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["icons"].redo : __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["icons"].undo;
        this._addButtonsToFactory('undo', t('Undo'), 'CTRL+Z', localizedUndoIcon);
        this._addButtonsToFactory('redo', t('Redo'), 'CTRL+Y', localizedRedoIcon);
    }
    /**
     * Creates a button for the specified command.
     *
     * @param name Command name.
     * @param label Button label.
     * @param keystroke Command keystroke.
     * @param Icon Source of the icon.
     */ _addButtonsToFactory(name, label, keystroke, Icon) {
        const editor = this.editor;
        editor.ui.componentFactory.add(name, ()=>{
            const buttonView = this._createButton(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$button$2f$buttonview$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ButtonView$3e$__["ButtonView"], name, label, keystroke, Icon);
            buttonView.set({
                tooltip: true
            });
            return buttonView;
        });
        editor.ui.componentFactory.add('menuBar:' + name, ()=>{
            return this._createButton(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$menubar$2f$menubarmenulistitembuttonview$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__MenuBarMenuListItemButtonView$3e$__["MenuBarMenuListItemButtonView"], name, label, keystroke, Icon);
        });
    }
    /**
     * TODO
     */ _createButton(ButtonClass, name, label, keystroke, Icon) {
        const editor = this.editor;
        const locale = editor.locale;
        const command = editor.commands.get(name);
        const view = new ButtonClass(locale);
        view.set({
            label,
            icon: Icon,
            keystroke
        });
        view.bind('isEnabled').to(command, 'isEnabled');
        this.listenTo(view, 'execute', ()=>{
            editor.execute(name);
            editor.editing.view.focus();
        });
        return view;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undo.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module undo/undo
 */ __turbopack_context__.s([
    "default",
    ()=>Undo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/plugin.js [app-ssr] (ecmascript) <export default as Plugin>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undoediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undoediting.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undoui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undoui.js [app-ssr] (ecmascript)");
;
;
;
class Undo extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$plugin$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plugin$3e$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get requires() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undoediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undoui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
        ];
    }
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'Undo';
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/augmentation.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ __turbopack_context__.s([]);
;
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module undo
 */ __turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undo.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undoediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undoediting.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undoui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undoui.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$augmentation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/augmentation.js [app-ssr] (ecmascript)");
;
;
;
;
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Undo",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "UndoEditing",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undoediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
    "UndoUI",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undoui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undo.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undoediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undoediting.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$undoui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/undoui.js [app-ssr] (ecmascript)");
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-essentials/src/essentials.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module essentials/essentials
 */ __turbopack_context__.s([
    "default",
    ()=>Essentials
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$core$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/core.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$clipboard$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/clipboard.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$clipboard$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-clipboard/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$enter$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/enter.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-enter/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$select$2d$all$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/select-all.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-select-all/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$typing$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/typing.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$typing$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-typing/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$undo$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/undo.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-undo/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$ui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/ui.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-ui/src/index.js [app-ssr] (ecmascript)");
;
;
;
;
;
;
;
class Essentials extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get requires() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AccessibilityHelp"],
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$clipboard$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Clipboard"],
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Enter"],
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$select$2d$all$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["SelectAll"],
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$enter$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ShiftEnter"],
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$typing$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Typing"],
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$undo$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Undo"]
        ];
    }
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'Essentials';
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-basic-styles/src/attributecommand.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module basic-styles/attributecommand
 */ __turbopack_context__.s([
    "default",
    ()=>AttributeCommand
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$core$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/core.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript)");
;
class AttributeCommand extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Command"] {
    /**
     * @param attributeKey Attribute that will be set by the command.
     */ constructor(editor, attributeKey){
        super(editor);
        this.attributeKey = attributeKey;
    }
    /**
     * Updates the command's {@link #value} and {@link #isEnabled} based on the current selection.
     */ refresh() {
        const model = this.editor.model;
        const doc = model.document;
        this.value = this._getValueFromFirstAllowedNode();
        this.isEnabled = model.schema.checkAttributeInSelection(doc.selection, this.attributeKey);
    }
    /**
     * Executes the command &ndash; applies the attribute to the selection or removes it from the selection.
     *
     * If the command is active (`value == true`), it will remove attributes. Otherwise, it will set attributes.
     *
     * The execution result differs, depending on the {@link module:engine/model/document~Document#selection}:
     *
     * * If the selection is on a range, the command applies the attribute to all nodes in that range
     * (if they are allowed to have this attribute by the {@link module:engine/model/schema~Schema schema}).
     * * If the selection is collapsed in a non-empty node, the command applies the attribute to the
     * {@link module:engine/model/document~Document#selection} itself (note that typed characters copy attributes from the selection).
     * * If the selection is collapsed in an empty node, the command applies the attribute to the parent node of the selection (note
     * that the selection inherits all attributes from a node if it is in an empty node).
     *
     * @fires execute
     * @param options Command options.
     * @param options.forceValue If set, it will force the command behavior. If `true`,
     * the command will apply the attribute, otherwise the command will remove the attribute.
     * If not set, the command will look for its current value to decide what it should do.
     */ execute(options = {}) {
        const model = this.editor.model;
        const doc = model.document;
        const selection = doc.selection;
        const value = options.forceValue === undefined ? !this.value : options.forceValue;
        model.change((writer)=>{
            if (selection.isCollapsed) {
                if (value) {
                    writer.setSelectionAttribute(this.attributeKey, true);
                } else {
                    writer.removeSelectionAttribute(this.attributeKey);
                }
            } else {
                const ranges = model.schema.getValidRanges(selection.getRanges(), this.attributeKey);
                for (const range of ranges){
                    if (value) {
                        writer.setAttribute(this.attributeKey, value, range);
                    } else {
                        writer.removeAttribute(this.attributeKey, range);
                    }
                }
            }
        });
    }
    /**
     * Checks the attribute value of the first node in the selection that allows the attribute.
     * For the collapsed selection returns the selection attribute.
     *
     * @returns The attribute value.
     */ _getValueFromFirstAllowedNode() {
        const model = this.editor.model;
        const schema = model.schema;
        const selection = model.document.selection;
        if (selection.isCollapsed) {
            return selection.hasAttribute(this.attributeKey);
        }
        for (const range of selection.getRanges()){
            for (const item of range.getItems()){
                if (schema.checkAttribute(item, this.attributeKey)) {
                    return item.hasAttribute(this.attributeKey);
                }
            }
        }
        return false;
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-basic-styles/src/bold/boldediting.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module basic-styles/bold/boldediting
 */ __turbopack_context__.s([
    "default",
    ()=>BoldEditing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$core$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/core.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$basic$2d$styles$2f$src$2f$attributecommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-basic-styles/src/attributecommand.js [app-ssr] (ecmascript)");
;
;
const BOLD = 'bold';
class BoldEditing extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'BoldEditing';
    }
    /**
     * @inheritDoc
     */ init() {
        const editor = this.editor;
        const t = this.editor.t;
        // Allow bold attribute on text nodes.
        editor.model.schema.extend('$text', {
            allowAttributes: BOLD
        });
        editor.model.schema.setAttributeProperties(BOLD, {
            isFormatting: true,
            copyOnEnter: true
        });
        // Build converter from model to view for data and editing pipelines.
        editor.conversion.attributeToElement({
            model: BOLD,
            view: 'strong',
            upcastAlso: [
                'b',
                (viewElement)=>{
                    const fontWeight = viewElement.getStyle('font-weight');
                    if (!fontWeight) {
                        return null;
                    }
                    // Value of the `font-weight` attribute can be defined as a string or a number.
                    if (fontWeight == 'bold' || Number(fontWeight) >= 600) {
                        return {
                            name: true,
                            styles: [
                                'font-weight'
                            ]
                        };
                    }
                    return null;
                }
            ]
        });
        // Create bold command.
        editor.commands.add(BOLD, new __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$basic$2d$styles$2f$src$2f$attributecommand$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"](editor, BOLD));
        // Set the Ctrl+B keystroke.
        editor.keystrokes.set('CTRL+B', BOLD);
        // Add the information about the keystroke to the accessibility database.
        editor.accessibility.addKeystrokeInfos({
            keystrokes: [
                {
                    label: t('Bold text'),
                    keystroke: 'CTRL+B'
                }
            ]
        });
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-basic-styles/src/utils.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * Returns a function that creates a (toolbar or menu bar) button for a basic style feature.
 */ __turbopack_context__.s([
    "getButtonCreator",
    ()=>getButtonCreator
]);
function getButtonCreator({ editor, commandName, plugin, icon, label, keystroke }) {
    return (ButtonClass)=>{
        const command = editor.commands.get(commandName);
        const view = new ButtonClass(editor.locale);
        view.set({
            label,
            icon,
            keystroke,
            isToggleable: true
        });
        view.bind('isEnabled').to(command, 'isEnabled');
        // Execute the command.
        plugin.listenTo(view, 'execute', ()=>{
            editor.execute(commandName);
            editor.editing.view.focus();
        });
        return view;
    };
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-basic-styles/src/bold/boldui.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module basic-styles/bold/boldui
 */ __turbopack_context__.s([
    "default",
    ()=>BoldUI
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$core$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/core.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$ui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/ui.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-ui/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$basic$2d$styles$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-basic-styles/src/utils.js [app-ssr] (ecmascript)");
;
;
;
const BOLD = 'bold';
class BoldUI extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'BoldUI';
    }
    /**
     * @inheritDoc
     */ init() {
        const editor = this.editor;
        const t = editor.locale.t;
        const command = editor.commands.get(BOLD);
        const createButton = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$basic$2d$styles$2f$src$2f$utils$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getButtonCreator"])({
            editor,
            commandName: BOLD,
            plugin: this,
            icon: __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["icons"].bold,
            label: t('Bold'),
            keystroke: 'CTRL+B'
        });
        // Add bold button to feature components.
        editor.ui.componentFactory.add(BOLD, ()=>{
            const buttonView = createButton(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ButtonView"]);
            buttonView.set({
                tooltip: true
            });
            buttonView.bind('isOn').to(command, 'value');
            return buttonView;
        });
        editor.ui.componentFactory.add('menuBar:' + BOLD, ()=>{
            return createButton(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$ui$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MenuBarMenuListItemButtonView"]);
        });
    }
}
}),
"[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-basic-styles/src/bold.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * @license Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */ /**
 * @module basic-styles/bold
 */ __turbopack_context__.s([
    "default",
    ()=>Bold
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f$ckeditor5$2f$src$2f$core$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/ckeditor5/src/core.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-core/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$basic$2d$styles$2f$src$2f$bold$2f$boldediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-basic-styles/src/bold/boldediting.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$basic$2d$styles$2f$src$2f$bold$2f$boldui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/nartaqi/node_modules/@ckeditor/ckeditor5-basic-styles/src/bold/boldui.js [app-ssr] (ecmascript)");
;
;
;
class Bold extends __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$core$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Plugin"] {
    /**
     * @inheritDoc
     */ static get requires() {
        return [
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$basic$2d$styles$2f$src$2f$bold$2f$boldediting$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"],
            __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$nartaqi$2f$node_modules$2f40$ckeditor$2f$ckeditor5$2d$basic$2d$styles$2f$src$2f$bold$2f$boldui$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"]
        ];
    }
    /**
     * @inheritDoc
     */ static get pluginName() {
        return 'Bold';
    }
}
}),
];

//# sourceMappingURL=e9609_%40ckeditor_f4c8b297._.js.map