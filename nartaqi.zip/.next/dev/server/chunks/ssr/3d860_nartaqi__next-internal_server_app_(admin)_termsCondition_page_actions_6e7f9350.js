module.exports = [
"[project]/Desktop/nartaqi/.next-internal/server/app/(admin)/termsCondition/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_nartaqi__next-internal_server_app_%28admin%29_termsCondition_page_actions_6e7f9350.js.map