globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/e9609_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_2d02123b._.js",
    "static/chunks/e9609_next_dist_compiled_react-dom_e6f76122._.js",
    "static/chunks/e9609_next_dist_compiled_react-server-dom-turbopack_7f5858bf._.js",
    "static/chunks/e9609_next_dist_compiled_next-devtools_index_d9d0c220.js",
    "static/chunks/e9609_next_dist_compiled_b08c753e._.js",
    "static/chunks/e9609_next_dist_client_3eb2ac7f._.js",
    "static/chunks/e9609_next_dist_e749d665._.js",
    "static/chunks/e9609_@swc_helpers_cjs_b1dfb26b._.js",
    "static/chunks/Desktop_nartaqi_a0ff3932._.js",
    "static/chunks/turbopack-Desktop_nartaqi_c4e4350d._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];